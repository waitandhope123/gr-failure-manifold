#!/usr/bin/env python3
"""
Toy 063 — Symmetry breaking without singularity: Anisotropic (Bianchi I) cosmology

What it probes (pressure point):
- "Generic" spacetimes are not FLRW: small symmetry breaking (anisotropic expansion) produces
  observable differences (directional Hubble rates, shear, Weyl-dominated curvature) even when
  scalar curvature can remain modest.
- Isotropization is NOT guaranteed by GR alone; it depends on matter content (equation of state)
  and on initial anisotropy (shear). This exposes how symmetry assumptions hide dynamics.

Model / assumptions:
- Bianchi I metric (spatially homogeneous, anisotropic, flat spatial slices):
    ds^2 = -dt^2 + a1(t)^2 dx^2 + a2(t)^2 dy^2 + a3(t)^2 dz^2
- Perfect fluid with constant equation of state p = w ρ (w constant).
- Geometric units G=c=1.
- Use a convenient parametrization in terms of:
    a(t) := (a1 a2 a3)^(1/3)  (mean scale factor)
    Hi := d/dt ln(ai)         (directional Hubble rates)
    H  := (H1+H2+H3)/3        (mean Hubble rate)
    shear eigenvalues βdot_i with sum zero so that Hi = H + βdot_i
- Shear evolution (Bianchi I, no anisotropic stress): βdot_i ∝ a^{-3}.
  We implement:
    βdot_i(t) = s_i / a(t)^3  with constants s_i, and s1+s2+s3=0.
- Energy conservation:
    dρ/dt = -3(1+w) H ρ  =>  ρ ∝ a^{-3(1+w)}
- Constraint (generalized Friedmann for Bianchi I):
    3 H^2 = 8π ρ + σ^2
  where shear scalar:
    σ^2 = (1/2) Σ_i βdot_i^2

Curvature diagnostics:
- Ricci scalar from perfect fluid trace:
    R = 8π (ρ - 3p) = 8π ρ (1 - 3w)
- Kretschmann scalar K computed from directional Hubble rates using orthonormal-frame components:
    R_{0i0i} = - (dHi/dt + Hi^2)
    R_{ijij} = Hi Hj  (i≠j)
  Proxy exact for Bianchi I in orthonormal tetrad:
    K = 4 Σ_i (dHi/dt + Hi^2)^2 + 4 Σ_{i<j} (Hi Hj)^2

Experiment-style observables exported:
- Directional Hubble rates (H1,H2,H3), mean H, shear σ^2
- "Isotropization ratio" σ/H (tells if anisotropy becomes negligible)
- Compare two nearby initial conditions (s_i vs s_i+δs_i) to quantify sensitivity in
  anisotropy observables over time.

Export:
- JSON schema exactly as specified in protocol.
- Undefined quantities => null; keys never omitted.
"""

from __future__ import annotations

import argparse
import json
import math
import os
from typing import Any, Dict, List, Optional, Tuple


# ----------------------------
# Helpers
# ----------------------------

def py_to_json_name(py_path: str) -> str:
    base = os.path.splitext(os.path.basename(py_path))[0]
    return base + ".json"


def require(cond: bool, msg: str) -> None:
    if not cond:
        raise ValueError(msg)


def parse_csv_floats(s: str) -> List[float]:
    return [float(x.strip()) for x in s.split(",") if x.strip()]


def finite_or_none(x: float) -> Optional[float]:
    return x if (isinstance(x, (int, float)) and math.isfinite(x)) else None


# ----------------------------
# Physics: Bianchi I ODE system
# ----------------------------

def shear_betadots(a: float, s: Tuple[float, float, float]) -> Tuple[float, float, float]:
    # βdot_i = s_i / a^3
    require(a > 0.0, "a must be > 0")
    inv = 1.0 / (a ** 3)
    return (s[0] * inv, s[1] * inv, s[2] * inv)


def shear_sigma2(bd: Tuple[float, float, float]) -> float:
    # σ^2 = 1/2 Σ βdot_i^2
    return 0.5 * (bd[0] ** 2 + bd[1] ** 2 + bd[2] ** 2)


def H_from_constraint(rho: float, sigma2: float) -> Optional[float]:
    # 3H^2 = 8πρ + σ^2
    val = (8.0 * math.pi * rho + sigma2) / 3.0
    if val < 0.0:
        return None
    return math.sqrt(val)


def derivs(t: float, y: Tuple[float, float], w: float, s: Tuple[float, float, float]) -> Tuple[float, float]:
    """
    State y = (a, rho)
    Equations:
      da/dt = a H
      dρ/dt = -3(1+w) H ρ
    with H from constraint and σ^2 from shear.
    """
    a, rho = y
    if a <= 0.0 or rho < 0.0:
        return (float("nan"), float("nan"))

    bd = shear_betadots(a, s)
    sigma2 = shear_sigma2(bd)
    H = H_from_constraint(rho, sigma2)
    if H is None:
        return (float("nan"), float("nan"))

    da = a * H
    drho = -3.0 * (1.0 + w) * H * rho
    return (da, drho)


def rk4_step(t: float, y: Tuple[float, float], dt: float, w: float, s: Tuple[float, float, float]) -> Tuple[float, float]:
    a, rho = y
    k1 = derivs(t, (a, rho), w, s)
    k2 = derivs(t + 0.5 * dt, (a + 0.5 * dt * k1[0], rho + 0.5 * dt * k1[1]), w, s)
    k3 = derivs(t + 0.5 * dt, (a + 0.5 * dt * k2[0], rho + 0.5 * dt * k2[1]), w, s)
    k4 = derivs(t + dt, (a + dt * k3[0], rho + dt * k3[1]), w, s)
    a_next = a + (dt / 6.0) * (k1[0] + 2.0 * k2[0] + 2.0 * k3[0] + k4[0])
    rho_next = rho + (dt / 6.0) * (k1[1] + 2.0 * k2[1] + 2.0 * k3[1] + k4[1])
    return (a_next, rho_next)


def directional_hubbles(a: float, rho: float, w: float, s: Tuple[float, float, float]) -> Dict[str, Optional[float]]:
    """
    Compute H, beta dots, and H1,H2,H3 at given (a,rho).
    """
    if a <= 0.0 or rho < 0.0:
        return {"H": None, "H1": None, "H2": None, "H3": None, "sigma2": None, "bd1": None, "bd2": None, "bd3": None}

    bd = shear_betadots(a, s)
    sigma2 = shear_sigma2(bd)
    H = H_from_constraint(rho, sigma2)
    if H is None:
        return {"H": None, "H1": None, "H2": None, "H3": None, "sigma2": finite_or_none(sigma2), "bd1": bd[0], "bd2": bd[1], "bd3": bd[2]}

    H1 = H + bd[0]
    H2 = H + bd[1]
    H3 = H + bd[2]
    return {"H": H, "H1": H1, "H2": H2, "H3": H3, "sigma2": sigma2, "bd1": bd[0], "bd2": bd[1], "bd3": bd[2]}


def dHi_dt(t: float, y: Tuple[float, float], dt: float, w: float, s: Tuple[float, float, float]) -> Dict[str, Optional[float]]:
    """
    Numerical derivative of H_i using a centered finite difference in time.
    We evolve forward/backward one RK4 step for the same model.

    Returns dH1/dt, dH2/dt, dH3/dt, or null if invalid.
    """
    a, rho = y
    if dt <= 0.0:
        return {"dH1": None, "dH2": None, "dH3": None}

    # forward
    y_f = rk4_step(t, (a, rho), dt, w, s)
    # backward (approx by stepping with -dt)
    y_b = rk4_step(t, (a, rho), -dt, w, s)

    hb_f = directional_hubbles(y_f[0], y_f[1], w, s)
    hb_b = directional_hubbles(y_b[0], y_b[1], w, s)

    if hb_f["H1"] is None or hb_b["H1"] is None:
        return {"dH1": None, "dH2": None, "dH3": None}

    dH1 = (hb_f["H1"] - hb_b["H1"]) / (2.0 * dt)
    dH2 = (hb_f["H2"] - hb_b["H2"]) / (2.0 * dt)
    dH3 = (hb_f["H3"] - hb_b["H3"]) / (2.0 * dt)
    return {"dH1": dH1, "dH2": dH2, "dH3": dH3}


def kretschmann_bianchiI(Hs: Dict[str, Optional[float]], dHs: Dict[str, Optional[float]]) -> Optional[float]:
    """
    K = 4 Σ_i (dHi/dt + Hi^2)^2 + 4 Σ_{i<j} (Hi Hj)^2
    """
    H1, H2, H3 = Hs.get("H1"), Hs.get("H2"), Hs.get("H3")
    dH1, dH2, dH3 = dHs.get("dH1"), dHs.get("dH2"), dHs.get("dH3")
    if any(x is None for x in [H1, H2, H3, dH1, dH2, dH3]):
        return None
    assert H1 is not None and H2 is not None and H3 is not None
    assert dH1 is not None and dH2 is not None and dH3 is not None

    term_time = (dH1 + H1 * H1) ** 2 + (dH2 + H2 * H2) ** 2 + (dH3 + H3 * H3) ** 2
    term_space = (H1 * H2) ** 2 + (H2 * H3) ** 2 + (H3 * H1) ** 2
    return 4.0 * term_time + 4.0 * term_space


def ricci_scalar_fluid(rho: float, w: float) -> Optional[float]:
    # R = 8π(ρ - 3p) = 8π ρ (1 - 3w)
    if rho < 0.0 or not math.isfinite(rho):
        return None
    return 8.0 * math.pi * rho * (1.0 - 3.0 * w)


# ----------------------------
# Toy 063 driver
# ----------------------------

class Toy063BianchiIAnisotropy:
    toy_id = "063"

    def __init__(
        self,
        *,
        w: float,
        a0: float,
        rho0: float,
        s: Tuple[float, float, float],
        delta_s: Tuple[float, float, float],
        t_start: float,
        t_end: float,
        dt: float,
        sample_every: int,
    ) -> None:
        require(a0 > 0.0, "a0 must be > 0.")
        require(rho0 >= 0.0, "rho0 must be >= 0.")
        require(dt > 0.0, "dt must be > 0.")
        require(t_end > t_start, "t_end must be > t_start.")
        require(sample_every >= 1, "sample_every must be >= 1.")
        require(abs(s[0] + s[1] + s[2]) < 1e-12, "Require s1+s2+s3=0 (trace-free shear).")
        require(abs(delta_s[0] + delta_s[1] + delta_s[2]) < 1e-12, "Require delta_s sum = 0.")

        self.w = float(w)
        self.a0 = float(a0)
        self.rho0 = float(rho0)
        self.s = (float(s[0]), float(s[1]), float(s[2]))
        self.delta_s = (float(delta_s[0]), float(delta_s[1]), float(delta_s[2]))
        self.t_start = float(t_start)
        self.t_end = float(t_end)
        self.dt = float(dt)
        self.sample_every = int(sample_every)

    def evolve(self, s_used: Tuple[float, float, float]) -> List[Dict[str, Any]]:
        t = self.t_start
        y = (self.a0, self.rho0)
        steps = int(math.floor((self.t_end - self.t_start) / self.dt))
        out: List[Dict[str, Any]] = []

        for n in range(steps + 1):
            if n % self.sample_every == 0 or n == steps:
                a, rho = y
                Hs = directional_hubbles(a, rho, self.w, s_used)
                dHs = dHi_dt(t, y, self.dt, self.w, s_used)  # numeric derivative
                K = kretschmann_bianchiI(Hs, dHs)
                R = ricci_scalar_fluid(rho, self.w)

                # Constraint check: 3H^2 - (8πρ + σ^2) should be ~0
                H = Hs["H"]
                sigma2 = Hs["sigma2"]
                constraint = None
                if H is not None and sigma2 is not None:
                    constraint = 3.0 * H * H - (8.0 * math.pi * rho + sigma2)

                # Isotropization measure
                iso_ratio = None
                if H is not None and H != 0.0 and sigma2 is not None:
                    iso_ratio = math.sqrt(max(sigma2, 0.0)) / abs(H)

                out.append({
                    "t": t,
                    "a": finite_or_none(a),
                    "rho": finite_or_none(rho),
                    "H": finite_or_none(H) if H is not None else None,
                    "H1": finite_or_none(Hs["H1"]) if Hs["H1"] is not None else None,
                    "H2": finite_or_none(Hs["H2"]) if Hs["H2"] is not None else None,
                    "H3": finite_or_none(Hs["H3"]) if Hs["H3"] is not None else None,
                    "sigma2": finite_or_none(sigma2) if sigma2 is not None else None,
                    "sigma_over_H": finite_or_none(iso_ratio) if iso_ratio is not None else None,
                    "constraint_residual": finite_or_none(constraint) if constraint is not None else None,
                    "ricci_scalar": finite_or_none(R) if R is not None else None,
                    "kretschmann": finite_or_none(K) if K is not None else None,
                })

            # step forward
            y = rk4_step(t, y, self.dt, self.w, s_used)
            t += self.dt

        return out

    def build_payload(self) -> Dict[str, Any]:
        base = self.evolve(self.s)
        pert_s = (self.s[0] + self.delta_s[0], self.s[1] + self.delta_s[1], self.s[2] + self.delta_s[2])
        pert = self.evolve(pert_s)

        # Build sample_points by time matching
        sample_points: List[Dict[str, Any]] = []
        for b, p in zip(base, pert):
            # sensitivity metrics
            d_sigma = None
            d_iso = None
            if b["sigma2"] is not None and p["sigma2"] is not None:
                d_sigma = math.sqrt(max(p["sigma2"], 0.0)) - math.sqrt(max(b["sigma2"], 0.0))
            if b["sigma_over_H"] is not None and p["sigma_over_H"] is not None:
                d_iso = p["sigma_over_H"] - b["sigma_over_H"]

            sample_points.append({
                "coordinates": {"t": b["t"]},
                "curvature_invariants": {
                    "ricci_scalar": b["ricci_scalar"],
                    "kretschmann": b["kretschmann"],
                    "note": "Ricci from fluid trace; Kretschmann from directional Hubble rates (Bianchi I tetrad formula)."
                },
                "local_observables": {
                    "mean_scale_factor_a": b["a"],
                    "rho": b["rho"],
                    "directional_hubbles": {"H1": b["H1"], "H2": b["H2"], "H3": b["H3"]},
                    "H_mean": b["H"],
                    "shear_sigma2": b["sigma2"],
                    "isotropization_sigma_over_H": b["sigma_over_H"],
                    "constraint_residual_3H2_minus_8pirho_minus_sigma2": b["constraint_residual"],
                    "nearby_initial_condition": {
                        "delta_s_used": {"ds1": self.delta_s[0], "ds2": self.delta_s[1], "ds3": self.delta_s[2]},
                        "sigma2_perturbed": p["sigma2"],
                        "sigma_over_H_perturbed": p["sigma_over_H"],
                        "delta_sigma_root": finite_or_none(d_sigma) if d_sigma is not None else None,
                        "delta_sigma_over_H": finite_or_none(d_iso) if d_iso is not None else None,
                    },
                },
                "causal_structure": {
                    "radial_null_cone_dr_dt": None,
                    "horizon_radius": None,
                    "region": "Bianchi I (homogeneous anisotropic expansion)",
                    "note": "No horizons in this homogeneous model; pressure point is symmetry breaking (directional expansion) rather than causal barriers."
                }
            })

        # Simple summary stats: did isotropization occur by end?
        end_iso = base[-1]["sigma_over_H"] if base else None
        payload: Dict[str, Any] = {
            "toy_id": self.toy_id,
            "theory": "General Relativity (Bianchi I anisotropic cosmology)",
            "spacetime": "Bianchi I (homogeneous, anisotropic, k=0) + perfect fluid p=wρ",
            "units": {"G": 1, "c": 1},
            "parameters": {
                "w": self.w,
                "initial_conditions": {"a0": self.a0, "rho0": self.rho0, "s1": self.s[0], "s2": self.s[1], "s3": self.s[2]},
                "delta_s_for_sensitivity": {"ds1": self.delta_s[0], "ds2": self.delta_s[1], "ds3": self.delta_s[2]},
                "t_start": self.t_start,
                "t_end": self.t_end,
                "dt": self.dt,
                "sample_every": self.sample_every,
            },
            "notes": {
                "pressure_point": (
                    "Dropping FLRW symmetry changes the physics: directional expansion rates differ and shear contributes to the constraint. "
                    "Whether the universe isotropizes depends on matter (w) and initial shear; symmetry assumptions can hide these degrees of freedom."
                ),
                "key_equations": {
                    "constraint": "3H^2 = 8πρ + σ^2,  σ^2=(1/2)Σ βdot_i^2,  βdot_i=s_i/a^3, Σ s_i=0",
                    "fluid_conservation": "dρ/dt = -3(1+w)Hρ",
                    "mean_scale_factor": "a=(a1 a2 a3)^(1/3),  Hi=H+βdot_i",
                    "ricci_scalar": "R=8πρ(1-3w)",
                    "kretschmann": "K=4Σ(dHi/dt+Hi^2)^2 + 4Σ_{i<j}(Hi Hj)^2",
                },
                "domain_of_validity": (
                    "Homogeneous anisotropic cosmology; ignores inhomogeneities, anisotropic stresses, viscosity, and spatial curvature (Bianchi IX etc.)."
                ),
            },
            "sample_points": sample_points,
            "observables": {
                "summary": {
                    "final_sigma_over_H": end_iso,
                    "isotropization_heuristic": (
                        None if end_iso is None else ("isotropized (sigma/H << 1)" if end_iso < 1e-2 else "anisotropy still dynamically relevant")
                    ),
                    "note": "Use sigma/H as an operational measure of how visible anisotropy remains to comoving observers."
                }
            },
        }
        return payload

    def export_json(self, out_path: Optional[str] = None) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)
        payload = self.build_payload()
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2, sort_keys=True)
        return out_path


def main() -> None:
    ap = argparse.ArgumentParser(description="Toy 063: Bianchi I anisotropic cosmology and isotropization diagnostics.")
    ap.add_argument("--w", type=float, default=0.0, help="Equation of state p=wρ (e.g., 0 dust, 1/3 radiation)")
    ap.add_argument("--a0", type=float, default=1.0, help="Initial mean scale factor a0>0")
    ap.add_argument("--rho0", type=float, default=1e-3, help="Initial energy density rho0>=0")
    ap.add_argument("--s", type=str, default="0.02,-0.01,-0.01",
                    help="Comma-separated shear constants s1,s2,s3 with sum zero")
    ap.add_argument("--ds", type=str, default="1e-4,-5e-5,-5e-5",
                    help="Comma-separated delta shear ds1,ds2,ds3 with sum zero (sensitivity test)")
    ap.add_argument("--t_start", type=float, default=0.0, help="Start time")
    ap.add_argument("--t_end", type=float, default=200.0, help="End time")
    ap.add_argument("--dt", type=float, default=0.1, help="Time step dt>0")
    ap.add_argument("--sample_every", type=int, default=50, help="Sample every N steps")
    ap.add_argument("--out", type=str, default="", help="Optional output path; default is <script>.json")
    args = ap.parse_args()

    s_vals = parse_csv_floats(args.s)
    ds_vals = parse_csv_floats(args.ds)
    require(len(s_vals) == 3, "--s must have 3 values")
    require(len(ds_vals) == 3, "--ds must have 3 values")

    toy = Toy063BianchiIAnisotropy(
        w=float(args.w),
        a0=float(args.a0),
        rho0=float(args.rho0),
        s=(s_vals[0], s_vals[1], s_vals[2]),
        delta_s=(ds_vals[0], ds_vals[1], ds_vals[2]),
        t_start=float(args.t_start),
        t_end=float(args.t_end),
        dt=float(args.dt),
        sample_every=int(args.sample_every),
    )

    out_path = args.out.strip() or None
    json_path = toy.export_json(out_path=out_path)
    print(f"Wrote {json_path}")
    print("Notes:")
    print("- If sigma/H decreases over time, the model isotropizes; if not, anisotropy remains observable.")
    print("- Nearby initial shear (s+ds) is evolved to quantify sensitivity in anisotropy observables.")


if __name__ == "__main__":
    main()
