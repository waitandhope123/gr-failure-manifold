#!/usr/bin/env python3
"""
Toy 069 — Entanglement area-law without horizons (flat spacetime, lattice scalar)

What it probes (pressure point):
- "Entropy ~ area" behavior does not require horizons or curvature.
- In a flat (Minkowski) setting, ground-state entanglement entropy of local QFT-like systems
  scales primarily with the *boundary size* of a region (area-law analogue).
- This supports separating "area/entropy correspondence" from black holes specifically.

Model (controlled approximation):
- 2D square lattice of coupled harmonic oscillators (discretized free massive scalar field).
- Hamiltonian (units with ħ=1; this is QFT/quantum-information convention):
    H = 1/2 (p^T p + x^T K x)
  where K = m^2 I + Laplacian_2D (nearest-neighbor coupling, open boundaries).

Gaussian ground state:
- Position covariance:  Cx = 1/2 K^{-1/2}
- Momentum covariance:  Cp = 1/2 K^{+1/2}

For a subregion A (a contiguous LxL block), the reduced state is Gaussian.
Let Cx_A and Cp_A be the restricted covariances to A. The symplectic eigenvalues ν_i are
eigenvalues of sqrt(Cx_A Cp_A). The von Neumann entropy is:
  S = Σ_i [ (ν_i+1/2) ln(ν_i+1/2) - (ν_i-1/2) ln(ν_i-1/2) ]  (natural log)

Notes:
- m>0 avoids the zero-mode IR issue for finite open lattices.
- Deterministic; numerical linear algebra only.

GR schema compliance:
- Curvature invariants are set to zero (flat background).
- This is not a GR curvature toy; it is a diagnostic that "entropy-area-like" behavior
  can arise without horizons.

Export:
- Strict JSON schema per lab protocol.
- Undefined quantities => null; keys never omitted.
"""

from __future__ import annotations

import argparse
import json
import math
import os
from typing import Any, Dict, List, Optional, Tuple

import numpy as np


# ----------------------------
# Helpers
# ----------------------------

def py_to_json_name(py_path: str) -> str:
    base = os.path.splitext(os.path.basename(py_path))[0]
    return base + ".json"


def require(cond: bool, msg: str) -> None:
    if not cond:
        raise ValueError(msg)


def finite_or_none(x: float) -> Optional[float]:
    return x if (isinstance(x, (int, float)) and math.isfinite(x)) else None


def parse_csv_ints(s: str) -> List[int]:
    out: List[int] = []
    for tok in s.split(","):
        tok = tok.strip()
        if tok:
            out.append(int(tok))
    return out


# ----------------------------
# Physics: lattice construction
# ----------------------------

def idx(i: int, j: int, N: int) -> int:
    return i * N + j


def build_K_matrix(N: int, m: float) -> np.ndarray:
    """
    Build stiffness matrix K = m^2 I + Laplacian_2D (open boundaries, nearest neighbor).
    Using convention:
      x^T K x = Σ (m^2 x^2) + Σ_{<ab>} (x_a - x_b)^2
    which yields:
      K_aa = m^2 + degree(a)
      K_ab = -1 if neighbors
    """
    require(N >= 2, "N must be >= 2")
    require(m > 0.0, "m must be > 0 to avoid zero modes")

    n = N * N
    K = np.zeros((n, n), dtype=float)

    for i in range(N):
        for j in range(N):
            a = idx(i, j, N)
            deg = 0
            # neighbors (open boundary)
            for di, dj in [(-1, 0), (1, 0), (0, -1), (0, 1)]:
                ii, jj = i + di, j + dj
                if 0 <= ii < N and 0 <= jj < N:
                    b = idx(ii, jj, N)
                    K[a, b] = -1.0
                    deg += 1
            K[a, a] = m * m + deg

    # Symmetrize (should already be symmetric)
    K = 0.5 * (K + K.T)
    return K


def matrix_sqrt_and_invsqrt_spd(A: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
    """
    For symmetric positive definite A, return (A^{1/2}, A^{-1/2})
    using eigen-decomposition.
    """
    w, V = np.linalg.eigh(A)
    # Numerical safety
    require(np.all(w > 0.0), "Matrix not SPD (eigenvalue <= 0). Increase m or check construction.")
    sqrt_w = np.sqrt(w)
    invsqrt_w = 1.0 / sqrt_w
    A_sqrt = (V * sqrt_w) @ V.T
    A_invsqrt = (V * invsqrt_w) @ V.T
    return A_sqrt, A_invsqrt


def subregion_indices_square(N: int, L: int, anchor: Tuple[int, int]) -> List[int]:
    """
    Indices for an LxL square subregion anchored at (i0,j0) (top-left),
    open boundaries, must fit.
    """
    i0, j0 = anchor
    require(1 <= L <= N, "L must be between 1 and N")
    require(0 <= i0 <= N - L and 0 <= j0 <= N - L, "Anchor must allow LxL block inside lattice")
    inds: List[int] = []
    for i in range(i0, i0 + L):
        for j in range(j0, j0 + L):
            inds.append(idx(i, j, N))
    return inds


def boundary_length_square(L: int) -> int:
    """
    Boundary length (perimeter) for LxL block on a square lattice in units of edges.
    Perimeter = 4L for L>=1 (counting boundary sites along edges is ~4L-4; we use edge-length).
    For "area-law" diagnostic we care about scaling with L.
    """
    require(L >= 1, "L must be >= 1")
    return 4 * L


def entanglement_entropy_gaussian(CxA: np.ndarray, CpA: np.ndarray) -> float:
    """
    Compute von Neumann entropy of a bosonic Gaussian state for region A using
    symplectic eigenvalues of sqrt(CxA CpA).
    """
    # Ensure symmetry
    CxA = 0.5 * (CxA + CxA.T)
    CpA = 0.5 * (CpA + CpA.T)

    M = CxA @ CpA
    # Symmetrize numerically
    M = 0.5 * (M + M.T)

    eig = np.linalg.eigvalsh(M)
    # ν_i = sqrt(eig_i)
    nu = np.sqrt(np.clip(eig, 0.0, None))

    S = 0.0
    for v in nu:
        # For a physical Gaussian state, v >= 1/2 (Heisenberg). Numerical errors might violate slightly.
        v = max(v, 0.5)
        a = v + 0.5
        b = v - 0.5
        # S_i = a ln a - b ln b, with b=0 allowed -> 0
        term = a * math.log(a) - (b * math.log(b) if b > 0.0 else 0.0)
        S += term
    return float(S)


# ----------------------------
# Toy 069
# ----------------------------

class Toy069EntanglementAreaLaw:
    toy_id = "069"

    def __init__(self, *, N: int, m: float, anchor_i: int, anchor_j: int) -> None:
        require(N >= 2, "N must be >= 2.")
        require(m > 0.0, "m must be > 0.")
        self.N = int(N)
        self.m = float(m)
        self.anchor = (int(anchor_i), int(anchor_j))

        self.K = build_K_matrix(self.N, self.m)
        K_sqrt, K_invsqrt = matrix_sqrt_and_invsqrt_spd(self.K)

        # Ground state covariances (ħ=1 convention)
        self.Cp = 0.5 * K_sqrt
        self.Cx = 0.5 * K_invsqrt

    def sample_point_for_L(self, L: int) -> Dict[str, Any]:
        inds = subregion_indices_square(self.N, L, self.anchor)
        CxA = self.Cx[np.ix_(inds, inds)]
        CpA = self.Cp[np.ix_(inds, inds)]

        S = entanglement_entropy_gaussian(CxA, CpA)
        perim = boundary_length_square(L)
        SA = S / perim if perim > 0 else None

        return {
            "coordinates": {
                "t": None,
                "x": None,
                "y": None,
                "z": None,
                "region_square_L": L,
            },
            "curvature_invariants": {
                "ricci_scalar": 0.0,
                "kretschmann": 0.0,
                "note": "Flat background: this is an entanglement diagnostic without curvature or horizons.",
            },
            "local_observables": {
                "lattice_size_N": self.N,
                "mass_gap_m": self.m,
                "region_anchor_top_left": {"i0": self.anchor[0], "j0": self.anchor[1]},
                "region_size_L": L,
                "region_area_sites_L2": L * L,
                "boundary_length_perimeter_4L": perim,
                "entanglement_entropy_S": finite_or_none(S),
                "entropy_per_boundary_length_S_over_4L": finite_or_none(SA) if SA is not None else None,
                "note": "If S scales ~ perimeter (4L) rather than area (L^2), this is an area-law analogue in flat space.",
            },
            "causal_structure": {
                "rindler_horizon_present": False,
                "horizon_radius": None,
                "region": "flat lattice QFT ground state (no horizons)",
                "note": "No gravitational horizons; entropy arises from tracing out degrees of freedom across a boundary.",
            },
        }

    def build_payload(self, L_values: List[int]) -> Dict[str, Any]:
        require(len(L_values) >= 1, "Need at least one L sample.")
        for L in L_values:
            require(1 <= L <= self.N, "Each L must be in [1, N].")
            require(self.anchor[0] <= self.N - L and self.anchor[1] <= self.N - L, "Anchor must fit all L.")

        sample_points = [self.sample_point_for_L(L) for L in L_values]

        # Simple scaling diagnostics: compare S vs perimeter and S vs area via naive ratios
        Ss = [sp["local_observables"]["entanglement_entropy_S"] for sp in sample_points]
        perims = [sp["local_observables"]["boundary_length_perimeter_4L"] for sp in sample_points]
        areas = [sp["local_observables"]["region_area_sites_L2"] for sp in sample_points]

        # Compute S/perimeter and S/area ranges (where defined)
        S_over_perim = [S / p for S, p in zip(Ss, perims) if (S is not None and p > 0)]
        S_over_area = [S / a for S, a in zip(Ss, areas) if (S is not None and a > 0)]

        summary: Dict[str, Any] = {
            "curvature_invariants_zero": True,
            "horizons_present": False,
            "note": "Entropy scaling in flat space; compare S/(4L) vs S/(L^2) across samples.",
            "S_over_perimeter_min": finite_or_none(min(S_over_perim)) if S_over_perim else None,
            "S_over_perimeter_max": finite_or_none(max(S_over_perim)) if S_over_perim else None,
            "S_over_area_min": finite_or_none(min(S_over_area)) if S_over_area else None,
            "S_over_area_max": finite_or_none(max(S_over_area)) if S_over_area else None,
        }

        return {
            "toy_id": self.toy_id,
            "theory": "Flat spacetime quantum field toy (Gaussian ground state entanglement; ħ=1 convention)",
            "spacetime": "Minkowski (discretized as 2D harmonic lattice; no curvature, no horizons)",
            "units": {"G": 1, "c": 1},
            "parameters": {
                "lattice_N_by_N": self.N,
                "mass_gap_m": self.m,
                "region_anchor_top_left_i0_j0": {"i0": self.anchor[0], "j0": self.anchor[1]},
                "region_sizes_L": L_values,
                "conventions": "ħ = 1 for quantum covariances; entropy uses natural log.",
            },
            "notes": {
                "pressure_point": (
                    "Area-law-like entanglement scaling appears in flat space without horizons: "
                    "entropy is driven by boundary tracing, not by gravitational thermodynamics."
                ),
                "key_equations": {
                    "hamiltonian": "H = 1/2 (p^T p + x^T K x),  K = m^2 I + Laplacian_2D",
                    "covariances": "Cx = 1/2 K^{-1/2}, Cp = 1/2 K^{+1/2}",
                    "symplectic": "ν_i = eig(sqrt(Cx_A Cp_A))",
                    "entropy": "S = Σ[(ν+1/2)ln(ν+1/2) - (ν-1/2)ln(ν-1/2)]",
                },
                "domain_of_validity": (
                    "Free (Gaussian) field approximation on finite lattice; m>0 avoids IR zero-mode issues; "
                    "boundary scaling is approximate for small N."
                ),
            },
            "sample_points": sample_points,
            "observables": {"summary": summary},
        }

    def export_json(self, L_values: List[int], out_path: Optional[str] = None) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)
        payload = self.build_payload(L_values=L_values)
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2, sort_keys=True)
        return out_path


def main() -> None:
    ap = argparse.ArgumentParser(description="Toy 069: entanglement entropy area-law analogue in flat space (2D harmonic lattice).")
    ap.add_argument("--N", type=int, default=8, help="Lattice size N (NxN), N>=2")
    ap.add_argument("--m", type=float, default=0.5, help="Mass gap m>0 (avoids zero-mode)")
    ap.add_argument("--anchor_i", type=int, default=0, help="Top-left i0 for LxL subregion")
    ap.add_argument("--anchor_j", type=int, default=0, help="Top-left j0 for LxL subregion")
    ap.add_argument("--L", type=str, default="1,2,3,4", help="Comma-separated region sizes L (<=N)")
    ap.add_argument("--out", type=str, default="", help="Optional output JSON path")
    args = ap.parse_args()

    L_values = parse_csv_ints(args.L)
    toy = Toy069EntanglementAreaLaw(N=int(args.N), m=float(args.m), anchor_i=int(args.anchor_i), anchor_j=int(args.anchor_j))

    out_path = args.out.strip() or None
    json_path = toy.export_json(L_values=L_values, out_path=out_path)

    print(f"Wrote {json_path}")
    print("Toy 069 complete: entanglement entropy scaling without horizons or curvature.")


if __name__ == "__main__":
    main()
