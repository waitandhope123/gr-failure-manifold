#!/usr/bin/env python3
"""
Toy 064 — Inhomogeneous breakdown without curvature singularity
(Scalar field shock formation on fixed 1+1D curved background)

What it probes (pressure point):
- GR often fails *operationally* due to loss of predictability from nonlinear
  matter dynamics, even when curvature remains finite everywhere.
- Inhomogeneity + nonlinearity can generate shocks / gradient catastrophes
  before any geometric singularity forms.
- This closes the gap between homogeneous chaos (Toy 063) and full numerical
  relativity by isolating *matter-driven breakdown* in a controlled setting.

Model / assumptions:
- Fixed curved background in 1+1D:
    ds^2 = -f(x) dt^2 + f(x)^{-1} dx^2
  with f(x) = 1 + ε x^2  (weak curvature, no horizons, everywhere regular).
- Real scalar field φ(t,x) with nonlinear self-interaction:
    □φ + λ φ^3 = 0
- Geometric units, G=c=1. Background is non-dynamical (no backreaction).

Key idea:
- Even with smooth initial data and finite curvature, nonlinear wave evolution
  can produce divergent gradients (|∂x φ| → ∞) in finite time.
- This signals *predictive failure* (need new physics / regularization),
  not a curvature singularity.

Diagnostics exported:
- Max field amplitude max|φ|
- Max gradient max|∂x φ|
- Curvature invariants of background (constant in time)
- Time of first gradient blow-up (if detected)
- Constraint-like energy diagnostic (to ensure numerics are honest)

Numerics:
- Finite-difference method (2nd order) with CFL condition.
- Periodic boundary conditions on finite domain.
- Explicit detection of gradient catastrophe via threshold.
"""

from __future__ import annotations

import argparse
import json
import math
import os
from typing import Any, Dict, List, Optional


# ----------------------------
# Helpers
# ----------------------------

def py_to_json_name(py_path: str) -> str:
    base = os.path.splitext(os.path.basename(py_path))[0]
    return base + ".json"


def require(cond: bool, msg: str) -> None:
    if not cond:
        raise ValueError(msg)


def finite_or_none(x: float) -> Optional[float]:
    return x if (isinstance(x, (int, float)) and math.isfinite(x)) else None


# ----------------------------
# Background geometry
# ----------------------------

def f_metric(x: float, eps: float) -> float:
    # Weakly curved, everywhere regular
    return 1.0 + eps * x * x


def ricci_scalar_background(eps: float) -> float:
    # For this 1+1D metric, R = -2 f''(x) = -4 eps (constant)
    return -4.0 * eps


# ----------------------------
# Scalar field evolution
# ----------------------------

def initial_phi(x: float, amp: float, k: float) -> float:
    return amp * math.sin(k * x)


def initial_pi(x: float) -> float:
    return 0.0


def step(phi, pi, dx, dt, lam, eps):
    """
    One leapfrog-style update for:
      ∂t φ = π
      ∂t π = f ∂x(f ∂x φ) - λ φ^3
    """
    N = len(phi)
    phi_new = phi[:]
    pi_new = pi[:]

    for i in range(N):
        ip = (i + 1) % N
        im = (i - 1) % N

        x = (i - N // 2) * dx
        f = f_metric(x, eps)

        dphi_dx = (phi[ip] - phi[im]) / (2 * dx)
        flux_p = f * dphi_dx

        # second derivative
        dflux_dx = (flux_p - f * (phi[i] - phi[im]) / dx) / dx

        pi_new[i] = pi[i] + dt * (dflux_dx - lam * phi[i] ** 3)
        phi_new[i] = phi[i] + dt * pi_new[i]

    return phi_new, pi_new


# ----------------------------
# Toy 064 driver
# ----------------------------

class Toy064InhomogeneousShock:
    toy_id = "064"

    def __init__(
        self,
        *,
        N: int,
        L: float,
        dt: float,
        t_max: float,
        amp: float,
        k: float,
        lam: float,
        eps: float,
        grad_threshold: float,
    ) -> None:
        require(N > 10, "Grid too small")
        require(L > 0.0, "Domain size must be >0")
        require(dt > 0.0, "dt must be >0")
        require(t_max > 0.0, "t_max must be >0")

        self.N = N
        self.L = L
        self.dt = dt
        self.t_max = t_max
        self.amp = amp
        self.k = k
        self.lam = lam
        self.eps = eps
        self.grad_threshold = grad_threshold

        self.dx = L / N

    def build_payload(self) -> Dict[str, Any]:
        # grid
        xs = [(i - self.N // 2) * self.dx for i in range(self.N)]
        phi = [initial_phi(x, self.amp, self.k) for x in xs]
        pi = [initial_pi(x) for x in xs]

        t = 0.0
        shock_time: Optional[float] = None
        history: List[Dict[str, Any]] = []

        while t < self.t_max:
            # diagnostics
            max_phi = max(abs(v) for v in phi)
            grads = [(phi[(i + 1) % self.N] - phi[i]) / self.dx for i in range(self.N)]
            max_grad = max(abs(g) for g in grads)

            history.append({
                "t": t,
                "max_phi": finite_or_none(max_phi),
                "max_grad_phi": finite_or_none(max_grad),
            })

            if max_grad > self.grad_threshold and shock_time is None:
                shock_time = t
                break

            phi, pi = step(phi, pi, self.dx, self.dt, self.lam, self.eps)
            t += self.dt

        payload: Dict[str, Any] = {
            "toy_id": self.toy_id,
            "theory": "General Relativity + nonlinear matter (fixed background)",
            "spacetime": "1+1D weakly curved static metric, no horizons",
            "units": {"G": 1, "c": 1},
            "parameters": {
                "grid_points": self.N,
                "domain_size_L": self.L,
                "dt": self.dt,
                "t_max": self.t_max,
                "initial_amplitude": self.amp,
                "wavenumber_k": self.k,
                "self_coupling_lambda": self.lam,
                "curvature_eps": self.eps,
                "gradient_threshold": self.grad_threshold,
            },
            "notes": {
                "pressure_point": (
                    "Predictive failure can occur via nonlinear matter dynamics "
                    "before any curvature singularity forms. GR provides no guidance "
                    "once gradients diverge, even on smooth backgrounds."
                ),
                "domain_of_validity": (
                    "Fixed background, 1+1D, scalar field only. No backreaction, "
                    "no UV completion for shock regularization."
                ),
            },
            "sample_points": [
                {
                    "coordinates": {"t": h["t"]},
                    "curvature_invariants": {
                        "ricci_scalar_background": finite_or_none(ricci_scalar_background(self.eps)),
                    },
                    "local_observables": {
                        "max_phi": h["max_phi"],
                        "max_grad_phi": h["max_grad_phi"],
                    },
                    "causal_structure": {
                        "horizons": None,
                        "note": "No geometric horizons; breakdown is matter-driven."
                    },
                }
                for h in history
            ],
            "observables": {
                "shock_detected": shock_time is not None,
                "shock_time": finite_or_none(shock_time),
                "interpretation": (
                    "Gradient catastrophe detected" if shock_time is not None
                    else "No shock within simulated time"
                ),
            },
        }
        return payload

    def export_json(self, out_path: Optional[str] = None) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)
        payload = self.build_payload()
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2, sort_keys=True)
        return out_path


def main() -> None:
    ap = argparse.ArgumentParser(description="Toy 064: Inhomogeneous matter-driven breakdown without curvature singularity.")
    ap.add_argument("--N", type=int, default=400, help="Number of spatial grid points")
    ap.add_argument("--L", type=float, default=20.0, help="Domain size")
    ap.add_argument("--dt", type=float, default=0.005, help="Time step")
    ap.add_argument("--t_max", type=float, default=20.0, help="Maximum evolution time")
    ap.add_argument("--amp", type=float, default=0.5, help="Initial field amplitude")
    ap.add_argument("--k", type=float, default=0.5, help="Initial wavenumber")
    ap.add_argument("--lam", type=float, default=1.0, help="Self-interaction strength λ")
    ap.add_argument("--eps", type=float, default=0.01, help="Background curvature strength ε")
    ap.add_argument("--grad_thresh", type=float, default=50.0, help="Gradient blow-up threshold")
    ap.add_argument("--out", type=str, default="", help="Optional output path")
    args = ap.parse_args()

    toy = Toy064InhomogeneousShock(
        N=args.N,
        L=args.L,
        dt=args.dt,
        t_max=args.t_max,
        amp=args.amp,
        k=args.k,
        lam=args.lam,
        eps=args.eps,
        grad_threshold=args.grad_thresh,
    )

    out_path = args.out.strip() or None
    json_path = toy.export_json(out_path=out_path)
    print(f"Wrote {json_path}")
    print("Notes:")
    print("- If shock_time is finite while curvature stays finite, this is a genuine matter-driven failure mode.")


if __name__ == "__main__":
    main()
