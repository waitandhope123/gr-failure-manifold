#!/usr/bin/env python3
"""
Toy 059 — Shell crossing / multi-stream breakdown (density blow-up without curvature blow-up)

What it probes (pressure point):
- “Singular behavior” need not appear in curvature invariants: matter models can fail first.
- Multi-stream flow (shell crossing) causes density → ∞ in a dust description while the metric
  can remain only mildly curved (no spacetime curvature divergence at crossing).
- This is a controlled Newtonian/LTB-analogue toy that isolates the failure of the single-valued
  velocity field / perfect-fluid (or dust) assumption.

Model (controlled approximation; Newtonian spherical dust):
- Consider many noninteracting spherical dust shells labeled by initial radius r0.
- Each shell follows radial motion in the gravitational field of the enclosed mass:
    d^2 r / dt^2 = - G M_enclosed(r0) / r^2   (G=1)
  where M_enclosed(r0) is fixed by initial mass profile and is constant for a given shell.

- Choose a mass profile that is monotonic in r0 (so no mass inversion), but choose an initial
  inward velocity profile v0(r0) that causes inner shells to slow less than outer shells,
  so that outer shells can overtake inner shells ⇒ shell crossing.

Shell-crossing diagnostic:
- The mapping r(t; r0). Shell crossing occurs when ∂r/∂r0 = 0 (Jacobian vanishes).
- For dust, the Eulerian density scales like:
    ρ(t, r0) = ρ0(r0) * (r0^2 / r(t)^2) * 1 / (∂r/∂r0)
  so density diverges when ∂r/∂r0 → 0 even if r(t) is finite.

Curvature proxy:
- Use a simple curvature scale proxy from enclosed mass:
    K_proxy ~ 48 M_enclosed(r0)^2 / r(t)^6   (Schwarzschild-like scaling)
  This is *not* exact Newtonian curvature; it is an interpretable GR-like scaling to show:
  density can blow up while K_proxy stays finite at shell crossing.

Numerics:
- Discretize r0 shells. Integrate each shell's ODE via RK4.
- Compute finite-difference Jacobian ∂r/∂r0 and flag sign changes / minima near 0.

Exports:
- sample_points across (t, r0) with r(t), v(t), Jacobian, density estimate, K_proxy, crossing flags.
"""

from __future__ import annotations

import argparse
import json
import math
import os
from typing import Any, Dict, List, Optional


# ----------------------------
# Helpers
# ----------------------------

def py_to_json_name(py_path: str) -> str:
    base = os.path.splitext(os.path.basename(py_path))[0]
    return base + ".json"


def require(cond: bool, msg: str) -> None:
    if not cond:
        raise ValueError(msg)


def finite_or_none(x: float) -> Optional[float]:
    return x if math.isfinite(x) else None


# ----------------------------
# Toy 059
# ----------------------------

class Toy059ShellCrossing:
    toy_id = "059"

    def __init__(
        self,
        *,
        r0_min: float = 5.0,
        r0_max: float = 20.0,
        n_shells: int = 101,
        M_total: float = 1.0,
        v_in: float = -0.2,
        v_slope: float = 0.03,
        dt: float = 0.01,
        T: float = 20.0,
        n_snapshots: int = 8,
    ) -> None:
        require(r0_min > 0.0 and r0_max > r0_min, "Require r0_max > r0_min > 0.")
        require(n_shells >= 21 and n_shells % 2 == 1, "Use odd n_shells >= 21 for centered differences.")
        require(M_total > 0.0, "M_total must be > 0.")
        require(dt > 0.0 and T > 0.0, "dt,T must be > 0.")
        require(n_snapshots >= 2, "n_snapshots must be >= 2.")
        self.r0_min = float(r0_min)
        self.r0_max = float(r0_max)
        self.n_shells = int(n_shells)
        self.M_total = float(M_total)
        self.v_in = float(v_in)
        self.v_slope = float(v_slope)
        self.dt = float(dt)
        self.T = float(T)
        self.n_snapshots = int(n_snapshots)

        self.r0_grid = [
            self.r0_min + i * (self.r0_max - self.r0_min) / (self.n_shells - 1)
            for i in range(self.n_shells)
        ]
        self.dr0 = self.r0_grid[1] - self.r0_grid[0]

        # Choose an initial mass profile: uniform initial density in r0-space
        # M_enclosed(r0) = M_total * ( (r0^3 - r0_min^3) / (r0_max^3 - r0_min^3) ), clipped
        self.r0min3 = self.r0_min ** 3
        self.r0max3 = self.r0_max ** 3
        self.norm3 = self.r0max3 - self.r0min3

        # Initial density in terms of r0 coordinate:
        # dM = 4π ρ0 r0^2 dr0  => choose constant ρ0 such that total mass matches.
        # Then ρ0 = M_total / (4π ∫ r0^2 dr0) = M_total / (4π (r0_max^3 - r0_min^3)/3)
        self.rho0 = self.M_total / (4.0 * math.pi * (self.norm3 / 3.0))

    def M_enclosed(self, r0: float) -> float:
        x = (r0**3 - self.r0min3) / self.norm3
        if x < 0.0:
            x = 0.0
        if x > 1.0:
            x = 1.0
        return self.M_total * x

    def v0(self, r0: float) -> float:
        # inward velocity that increases (less negative) for smaller r0:
        # v0(r0) = v_in + v_slope * (r0 - r0_min)
        return self.v_in + self.v_slope * (r0 - self.r0_min)

    def accel(self, r: float, Menc: float) -> float:
        # d2r/dt2 = -Menc / r^2  (G=1)
        if r <= 0.0:
            return float("nan")
        return -Menc / (r * r)

    def rk4_step(self, r: float, v: float, Menc: float, dt: float) -> Tuple[float, float]:
        # State: (r, v), dr/dt=v, dv/dt = a(r)
        def a(rr: float) -> float:
            return self.accel(rr, Menc)

        k1_r = v
        k1_v = a(r)

        k2_r = v + 0.5 * dt * k1_v
        k2_v = a(r + 0.5 * dt * k1_r)

        k3_r = v + 0.5 * dt * k2_v
        k3_v = a(r + 0.5 * dt * k2_r)

        k4_r = v + dt * k3_v
        k4_v = a(r + dt * k3_r)

        r_next = r + (dt / 6.0) * (k1_r + 2.0 * k2_r + 2.0 * k3_r + k4_r)
        v_next = v + (dt / 6.0) * (k1_v + 2.0 * k2_v + 2.0 * k3_v + k4_v)

        return r_next, v_next

    def compute_jacobian_dr_dr0(self, r_list: List[float]) -> List[Optional[float]]:
        # Centered differences; endpoints set None
        J: List[Optional[float]] = [None] * self.n_shells
        for i in range(1, self.n_shells - 1):
            J[i] = (r_list[i + 1] - r_list[i - 1]) / (2.0 * self.dr0)
        return J

    def density_from_jacobian(self, r0: float, r: float, J: Optional[float]) -> Optional[float]:
        # ρ = ρ0 * (r0^2 / r^2) * 1/J
        if J is None:
            return None
        if r <= 0.0:
            return None
        if J == 0.0:
            return None
        return self.rho0 * (r0 * r0) / (r * r) * (1.0 / J)

    def K_proxy(self, Menc: float, r: float) -> Optional[float]:
        # GR-like curvature scaling proxy
        if r <= 0.0:
            return None
        return 48.0 * (Menc * Menc) / (r ** 6)

    def run(self) -> Dict[str, Any]:
        # Initialize shells
        r = self.r0_grid.copy()
        v = [self.v0(r0) for r0 in self.r0_grid]
        Menc = [self.M_enclosed(r0) for r0 in self.r0_grid]

        steps = int(round(self.T / self.dt))
        snapshot_steps = set(int(round(i * steps / (self.n_snapshots - 1))) for i in range(self.n_snapshots))

        snapshots: List[Dict[str, Any]] = []
        first_cross_time: Optional[float] = None

        for n in range(steps + 1):
            t = n * self.dt

            # compute Jacobian and shell-crossing flags
            J = self.compute_jacobian_dr_dr0(r)
            min_abs_J = float("inf")
            crossing_count = 0
            for i in range(1, self.n_shells - 1):
                if J[i] is None:
                    continue
                min_abs_J = min(min_abs_J, abs(J[i]))
                # shell crossing indicated by J <= 0 (loss of monotonicity) or very small positive J
                if J[i] <= 0.0:
                    crossing_count += 1

            if first_cross_time is None and crossing_count > 0:
                first_cross_time = t

            if n in snapshot_steps:
                # Store snapshot arrays and per-shell diagnostics
                shell_rows: List[Dict[str, float]] = []
                for i in range(self.n_shells):
                    rho = self.density_from_jacobian(self.r0_grid[i], r[i], J[i])
                    Kp = self.K_proxy(Menc[i], r[i])
                    shell_rows.append({
                        "r0": self.r0_grid[i],
                        "r": r[i],
                        "v": v[i],
                        "M_enclosed": Menc[i],
                        "J_dr_dr0": J[i] if J[i] is not None else float("nan"),
                        "rho_est": rho if (rho is not None and math.isfinite(rho)) else float("nan"),
                        "K_proxy": Kp if (Kp is not None and math.isfinite(Kp)) else float("nan"),
                    })

                snapshots.append({
                    "t": t,
                    "min_abs_J": min_abs_J if math.isfinite(min_abs_J) else float("nan"),
                    "crossing_count": crossing_count,
                    "shells": shell_rows,
                })

            # advance (skip after final snapshot)
            if n == steps:
                break

            # step each shell independently
            r_next = [0.0] * self.n_shells
            v_next = [0.0] * self.n_shells
            for i in range(self.n_shells):
                r_next[i], v_next[i] = self.rk4_step(r[i], v[i], Menc[i], self.dt)

            r, v = r_next, v_next

        return {
            "snapshots": snapshots,
            "first_cross_time": first_cross_time,
        }

    def build_payload(self) -> Dict[str, Any]:
        result = self.run()
        snaps = result["snapshots"]

        # Build sample_points: downsample shells and snapshots
        shell_stride = max(1, self.n_shells // 35)

        sample_points: List[Dict[str, Any]] = []
        for snap in snaps:
            t = float(snap["t"])
            shells = snap["shells"]

            for i in range(0, len(shells), shell_stride):
                row = shells[i]
                r0 = float(row["r0"])
                rr = float(row["r"])
                vv = float(row["v"])
                J = row["J_dr_dr0"]
                rho = row["rho_est"]
                Kp = row["K_proxy"]

                # crossing diagnostics
                crossing = (math.isfinite(J) and J <= 0.0)
                near_crossing = (math.isfinite(J) and abs(J) < 1e-3)

                sample_points.append({
                    "coordinates": {"t": t, "r0": r0},
                    "curvature_invariants": {
                        # Proxy only (this is a controlled approximation toy)
                        "kretschmann_proxy_48Menc2_over_r6": finite_or_none(Kp) if math.isfinite(Kp) else None,
                        "ricci_scalar": None,
                    },
                    "local_observables": {
                        "r": finite_or_none(rr),
                        "v": finite_or_none(vv),
                        "M_enclosed": finite_or_none(float(row["M_enclosed"])),
                        "jacobian_dr_dr0": finite_or_none(J) if math.isfinite(J) else None,
                        "rho_est_from_jacobian": finite_or_none(rho) if math.isfinite(rho) else None,
                        "rho0_initial": self.rho0,
                        "flags": {
                            "shell_crossing_J_le_0": crossing,
                            "near_crossing_absJ_lt_1e-3": near_crossing,
                        },
                    },
                    "causal_structure": {
                        "note": (
                            "Shell crossing is a matter-model (multi-stream) breakdown: density blows up as J→0 "
                            "even when curvature proxy remains finite."
                        ),
                    },
                })

        # Summary observables
        first_cross_time = result["first_cross_time"]
        min_abs_J_overall = None
        max_abs_rho = 0.0
        max_Kp = 0.0
        for snap in snaps:
            if math.isfinite(snap["min_abs_J"]):
                if min_abs_J_overall is None:
                    min_abs_J_overall = snap["min_abs_J"]
                else:
                    min_abs_J_overall = min(min_abs_J_overall, snap["min_abs_J"])
            for row in snap["shells"]:
                rho = row["rho_est"]
                Kp = row["K_proxy"]
                if math.isfinite(rho):
                    max_abs_rho = max(max_abs_rho, abs(rho))
                if math.isfinite(Kp):
                    max_Kp = max(max_Kp, abs(Kp))

        return {
            "toy_id": self.toy_id,
            "theory": "Controlled approximation (Newtonian spherical dust; GR-like curvature proxy)",
            "spacetime": "Spherical dust shells with multi-stream (shell-crossing) breakdown",
            "units": {"G": 1, "c": 1},
            "parameters": {
                "r0_min": self.r0_min,
                "r0_max": self.r0_max,
                "n_shells": self.n_shells,
                "M_total": self.M_total,
                "v_in": self.v_in,
                "v_slope": self.v_slope,
                "dt": self.dt,
                "T": self.T,
                "n_snapshots": self.n_snapshots,
                "rho0_initial": self.rho0,
            },
            "notes": {
                "assumptions": [
                    "Dust shells do not collide or shock; they pass through each other (multi-stream)",
                    "Enclosed mass M_enclosed(r0) is fixed by initial profile and constant for each shell",
                    "Shell crossing diagnosed by Jacobian J=∂r/∂r0 → 0",
                    "Density estimate uses dust continuity mapping; diverges as J→0",
                    "Curvature is represented by a GR-like scaling proxy ~ 48 M^2/r^6 for interpretability",
                ],
                "pressure_point": (
                    "Matter-model pathologies can appear before curvature blow-up. "
                    "Shell crossing produces density divergence from multi-streaming while curvature proxies remain finite. "
                    "This breaks perfect-fluid/dust assumptions without requiring a spacetime singularity."
                ),
                "key_equations": {
                    "shell_eom": "d^2r/dt^2 = -M_enclosed(r0)/r^2 (G=1)",
                    "jacobian": "J = ∂r/∂r0 (shell crossing when J=0)",
                    "density_map": "ρ = ρ0 (r0^2/r^2)(1/J)",
                    "curvature_proxy": "K_proxy ~ 48 M_enclosed^2 / r^6",
                },
            },
            "sample_points": sample_points,
            "observables": {
                "summary": {
                    "first_shell_cross_time": first_cross_time,
                    "min_abs_J_overall": finite_or_none(min_abs_J_overall) if min_abs_J_overall is not None else None,
                    "max_abs_rho_est": finite_or_none(max_abs_rho),
                    "max_K_proxy": finite_or_none(max_Kp),
                    "note": (
                        "If first_shell_cross_time is not null, you have multi-stream breakdown: "
                        "density spikes due to J→0. This can happen with moderate curvature proxy values."
                    ),
                }
            },
        }

    def export_json(self, out_path: Optional[str] = None) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)
        payload = self.build_payload()
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2, sort_keys=True)
        return out_path


# ----------------------------
# CLI
# ----------------------------

def main() -> None:
    ap = argparse.ArgumentParser(description="Toy 059: shell crossing / multi-stream breakdown.")
    ap.add_argument("--r0_min", type=float, default=5.0, help="Minimum initial radius")
    ap.add_argument("--r0_max", type=float, default=20.0, help="Maximum initial radius")
    ap.add_argument("--n_shells", type=int, default=101, help="Number of shells (odd, >=21)")
    ap.add_argument("--M_total", type=float, default=1.0, help="Total mass scale")
    ap.add_argument("--v_in", type=float, default=-0.2, help="Base inward velocity at r0_min")
    ap.add_argument("--v_slope", type=float, default=0.03, help="Velocity slope vs r0")
    ap.add_argument("--dt", type=float, default=0.01, help="Time step")
    ap.add_argument("--T", type=float, default=20.0, help="Final time")
    ap.add_argument("--n_snapshots", type=int, default=8, help="Number of snapshots")
    ap.add_argument("--out", type=str, default="", help="Optional output path")
    args = ap.parse_args()

    toy = Toy059ShellCrossing(
        r0_min=float(args.r0_min),
        r0_max=float(args.r0_max),
        n_shells=int(args.n_shells),
        M_total=float(args.M_total),
        v_in=float(args.v_in),
        v_slope=float(args.v_slope),
        dt=float(args.dt),
        T=float(args.T),
        n_snapshots=int(args.n_snapshots),
    )

    out_path = args.out.strip() or None
    json_path = toy.export_json(out_path=out_path)

    print(f"Wrote {json_path}")
    print("Toy 059 complete: shell crossing / multi-stream breakdown.")


if __name__ == "__main__":
    main()
