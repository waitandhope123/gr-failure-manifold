#!/usr/bin/env python3
"""
Toy 033 — Backreaction: when the test-particle approximation fails (proxy diagnostic)

Pressure point / weakness probed:
- Many GR calculations assume "test bodies" that do not gravitate (m/M -> 0).
- But GR is nonlinear: adding even a small mass m changes the geometry and shifts key invariants
  (horizon radius, ISCO, photon sphere, redshift, curvature scale).
- This toy provides a controlled proxy: treat the total mass parameter as M_total = M(1+ε),
  where ε = m/M, and quantify how "test-particle" observables shift with ε.

Important limitation (explicit):
- This is NOT a full self-force / two-body solution. It is a clean diagnostic that shows the *scaling*
  of backreaction sensitivity and provides a numerical "breakdown parameter" ε.

Spacetime used:
- Schwarzschild family in geometric units (G=c=1).
- Background mass: M
- Backreacted proxy: M_total = M (1 + ε)

Key observables:
- Horizon radius: r_h = 2M
- Photon sphere: r_ph = 3M
- ISCO: r_isco = 6M
- Gravitational redshift factor for static observer at radius r (exterior only):
    alpha(r) = sqrt(1 - 2M/r)   (null if r <= 2M)
- Curvature (Kretschmann): K = 48 M^2 / r^6   (null if r <= 0)

Export:
- Writes JSON named exactly like this .py file.
- Uses mandatory schema; undefined quantities are null.
"""

from __future__ import annotations

import argparse
import json
import math
import os
from typing import Any, Dict, List, Optional


# ----------------------------
# Helpers
# ----------------------------

def py_to_json_name(py_path: str) -> str:
    base = os.path.splitext(os.path.basename(py_path))[0]
    return base + ".json"


def require(cond: bool, msg: str) -> None:
    if not cond:
        raise ValueError(msg)


def parse_csv_floats(s: str) -> List[float]:
    return [float(x.strip()) for x in s.split(",") if x.strip()]


# ----------------------------
# Schwarzschild diagnostics
# ----------------------------

def horizon_radius(M: float) -> float:
    return 2.0 * M


def photon_sphere_radius(M: float) -> float:
    return 3.0 * M


def isco_radius(M: float) -> float:
    return 6.0 * M


def lapse_alpha(M: float, r: float) -> Optional[float]:
    # alpha = sqrt(1 - 2M/r) for static observers outside horizon
    if r <= 0.0:
        return None
    if r <= horizon_radius(M):
        return None
    val = 1.0 - 2.0 * M / r
    if val <= 0.0:
        return None
    return math.sqrt(val)


def kretschmann(M: float, r: float) -> Optional[float]:
    if r <= 0.0:
        return None
    return 48.0 * (M * M) / (r ** 6)


# ----------------------------
# Toy 033 driver
# ----------------------------

class Toy033BackreactionProxy:
    toy_id = "033"

    def __init__(self, M: float, eps_values: List[float], r_values: List[float]) -> None:
        require(M > 0.0, "M must be > 0")
        require(len(eps_values) > 0, "eps_values must be non-empty")
        require(len(r_values) > 0, "r_values must be non-empty")
        for e in eps_values:
            require(e >= 0.0, "epsilon values must be >= 0")
        for r in r_values:
            require(r > 0.0, "r sample radii must be > 0")

        self.M = float(M)
        self.eps_values = [float(e) for e in eps_values]
        self.r_values = [float(r) for r in r_values]

    def build_payload(self) -> Dict[str, Any]:
        M0 = self.M

        # Background landmarks
        bg = {
            "M": M0,
            "r_h": horizon_radius(M0),
            "r_ph": photon_sphere_radius(M0),
            "r_isco": isco_radius(M0),
        }

        sample_points: List[Dict[str, Any]] = []

        for eps in self.eps_values:
            Mtot = M0 * (1.0 + eps)

            # Backreacted landmarks
            br = {
                "M_total": Mtot,
                "r_h_total": horizon_radius(Mtot),
                "r_ph_total": photon_sphere_radius(Mtot),
                "r_isco_total": isco_radius(Mtot),
            }

            # Fractional shifts (exact for this proxy because radii scale with M)
            frac_shift_h = (br["r_h_total"] - bg["r_h"]) / bg["r_h"]
            frac_shift_ph = (br["r_ph_total"] - bg["r_ph"]) / bg["r_ph"]
            frac_shift_isco = (br["r_isco_total"] - bg["r_isco"]) / bg["r_isco"]

            for r in self.r_values:
                alpha_bg = lapse_alpha(M0, r)
                alpha_br = lapse_alpha(Mtot, r)
                K_bg = kretschmann(M0, r)
                K_br = kretschmann(Mtot, r)

                # Where alpha is defined, compute relative change; else null
                rel_change_alpha = None
                if alpha_bg is not None and alpha_br is not None and alpha_bg != 0.0:
                    rel_change_alpha = (alpha_br - alpha_bg) / alpha_bg

                rel_change_K = None
                if K_bg is not None and K_br is not None and K_bg != 0.0:
                    rel_change_K = (K_br - K_bg) / K_bg

                region_bg = "exterior" if r > bg["r_h"] else ("horizon" if r == bg["r_h"] else "interior")
                region_br = "exterior" if r > br["r_h_total"] else ("horizon" if r == br["r_h_total"] else "interior")

                sample_points.append({
                    "coordinates": {
                        "r": r,
                        "epsilon_m_over_M": eps,
                        "M_background": M0,
                        "M_total_proxy": Mtot
                    },
                    "curvature_invariants": {
                        "kretschmann_background": K_bg,
                        "kretschmann_total_proxy": K_br,
                        "kretschmann_relative_change": rel_change_K
                    },
                    "local_observables": {
                        "alpha_lapse_background": alpha_bg,
                        "alpha_lapse_total_proxy": alpha_br,
                        "alpha_relative_change": rel_change_alpha,
                        "horizon_radius_background": bg["r_h"],
                        "horizon_radius_total_proxy": br["r_h_total"],
                        "isco_radius_background": bg["r_isco"],
                        "isco_radius_total_proxy": br["r_isco_total"],
                        "photon_sphere_radius_background": bg["r_ph"],
                        "photon_sphere_radius_total_proxy": br["r_ph_total"],
                        "fractional_shift_horizon": frac_shift_h,
                        "fractional_shift_isco": frac_shift_isco,
                        "fractional_shift_photon_sphere": frac_shift_ph,
                        "breakdown_parameter_epsilon": eps,
                        "notes": (
                            "Proxy backreaction: replace M with M_total=M(1+ε). "
                            "If ε is not negligible compared to your target accuracy, test-particle assumptions fail."
                        )
                    },
                    "causal_structure": {
                        "region_background": region_bg,
                        "region_total_proxy": region_br,
                        "energy_warning": (
                            "Nonlinearity means matter changes geometry; geodesics in a fixed background are an approximation."
                        ),
                        "predictability_warning": None
                    }
                })

        # Summary observables: show scaling and an “accuracy budget” interpretation
        max_eps = max(self.eps_values)
        payload: Dict[str, Any] = {
            "toy_id": self.toy_id,
            "theory": "General Relativity (nonlinearity / backreaction diagnostics)",
            "spacetime": "Schwarzschild family (backreaction proxy via M -> M(1+ε))",
            "units": {"G": 1, "c": 1},
            "parameters": {
                "M": self.M,
                "eps_values": self.eps_values,
                "r_values": self.r_values
            },
            "notes": {
                "pressure_point": (
                    "The test-particle approximation assumes m/M -> 0 so the probe does not affect geometry. "
                    "Because GR is nonlinear, even small ε=m/M shifts invariant radii (horizon, ISCO, photon sphere) "
                    "and local observables (redshift, curvature). This toy quantifies those shifts as a breakdown diagnostic."
                ),
                "limitations": (
                    "This toy is a proxy diagnostic, not a full self-force or two-body GR solution. "
                    "Its role is to expose scaling: fractional shifts are O(ε) for mass-scaled observables."
                ),
                "definitions_used": {
                    "M_total_proxy": "M_total = M(1+ε)",
                    "horizon": "r_h = 2M",
                    "photon_sphere": "r_ph = 3M",
                    "ISCO": "r_isco = 6M",
                    "lapse_static": "alpha(r)=sqrt(1-2M/r) (null if r<=2M)",
                    "kretschmann": "K=48 M^2 / r^6"
                }
            },
            "sample_points": sample_points,
            "observables": {
                "summary": {
                    "key_result": "In this proxy, landmark radii shift fractionally by exactly ε (since they scale with M).",
                    "max_epsilon_sampled": max_eps,
                    "rule_of_thumb": (
                        "If ε = m/M exceeds your tolerated fractional error budget, "
                        "treating the body as a test particle is unjustified."
                    )
                }
            }
        }
        return payload

    def export_json(self, out_path: Optional[str] = None) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)
        payload = self.build_payload()
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2, sort_keys=True)
        return out_path


def main() -> None:
    ap = argparse.ArgumentParser(description="Toy 033: Backreaction proxy diagnostic (test-particle breakdown).")
    ap.add_argument("--M", type=float, default=1.0, help="Background mass M > 0")
    ap.add_argument("--eps", type=str, default="0,1e-6,1e-3,1e-2,1e-1",
                    help="Comma-separated epsilon values ε=m/M (>=0)")
    ap.add_argument("--r", type=str, default="2.2,3,6,10,20",
                    help="Comma-separated radii r>0 at which to sample observables")
    ap.add_argument("--out", type=str, default="",
                    help="Optional output path. If omitted, uses <this_script_name>.json")
    args = ap.parse_args()

    toy = Toy033BackreactionProxy(
        M=float(args.M),
        eps_values=parse_csv_floats(args.eps),
        r_values=parse_csv_floats(args.r),
    )

    out_path = args.out.strip() or None
    json_path = toy.export_json(out_path=out_path)
    print(f"Wrote {json_path}")
    print("Notes:")
    print("- This toy is a controlled proxy: it quantifies O(epsilon) shifts from M -> M(1+epsilon).")


if __name__ == "__main__":
    main()
