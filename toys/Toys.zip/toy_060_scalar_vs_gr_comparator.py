#!/usr/bin/env python3
"""
Toy 060 — Minimal non-GR gravity comparator (scalar gravity vs GR redshift baseline)

What it probes (pressure point):
- GR is not the only internally consistent classical gravity model that reproduces
  Newtonian behavior and redshift effects.
- By running an *identical observable pipeline* on a non-GR theory, we can identify
  which predictions are genuinely GR-specific versus model-dependent.
- This toy provides a clean comparator, not a straw man.

Models compared (G=c=1):

(A) GR baseline:
    - Weak-field Schwarzschild redshift between two static observers at r1, r2:
        z_GR = sqrt((1 - 2M/r2) / (1 - 2M/r1)) - 1

(B) Scalar gravity (Nordström-type, conformally flat):
    - Metric: g_ab = φ(r)^2 η_ab
    - Field equation (vacuum exterior of point mass):
        φ(r) = exp(-M / r)
    - Gravitational redshift from metric time component:
        z_scalar = φ(r1) / φ(r2) - 1 = exp(M(1/r2 - 1/r1)) - 1

Both:
- Reduce to Newtonian potential Φ ≈ -M/r at leading order
- Agree to first order in weak field, differ at higher order

Exports:
- Redshift predictions from both theories for identical (M, r1, r2)
- Relative deviation Δz / z_GR
- Curvature diagnostics:
    * GR: Kretschmann scalar
    * Scalar gravity: Ricci scalar from conformal factor
"""

from __future__ import annotations

import argparse
import json
import math
import os
from typing import Any, Dict, List, Optional


# ----------------------------
# Helpers
# ----------------------------

def py_to_json_name(py_path: str) -> str:
    base = os.path.splitext(os.path.basename(py_path))[0]
    return base + ".json"


def parse_csv_floats(s: str) -> List[float]:
    return [float(x.strip()) for x in s.split(",") if x.strip()]


def require(cond: bool, msg: str) -> None:
    if not cond:
        raise ValueError(msg)


def finite_or_none(x):
    if x is None:
        return None
    return x if math.isfinite(x) else None


# ----------------------------
# Toy 060
# ----------------------------

class Toy060ScalarVsGRComparator:
    toy_id = "060"

    def __init__(self, *, M: float = 1.0) -> None:
        require(M > 0.0, "M must be > 0.")
        self.M = float(M)

    # ---------- GR ----------
    def z_gr(self, r1: float, r2: float) -> Optional[float]:
        if r1 <= 2.0 * self.M or r2 <= 2.0 * self.M:
            return None
        return math.sqrt((1.0 - 2.0 * self.M / r2) / (1.0 - 2.0 * self.M / r1)) - 1.0

    def kretschmann_gr(self, r: float) -> Optional[float]:
        if r <= 0.0:
            return None
        return 48.0 * self.M * self.M / (r ** 6)

    # ---------- Scalar gravity ----------
    def phi(self, r: float) -> float:
        return math.exp(-self.M / r)

    def z_scalar(self, r1: float, r2: float) -> Optional[float]:
        if r1 <= 0.0 or r2 <= 0.0:
            return None
        return self.phi(r1) / self.phi(r2) - 1.0

    def ricci_scalar_scalar_gravity(self, r: float) -> Optional[float]:
        """
        For g_ab = φ^2 η_ab in 4D:
        R = -6 φ^{-3} □φ   (flat-space d'Alembertian; static ⇒ Laplacian)
        φ = exp(-M/r) ⇒ ∇^2 φ = φ * (M^2 / r^4)
        """
        if r <= 0.0:
            return None
        phi = self.phi(r)
        lap_phi = phi * (self.M * self.M) / (r ** 4)
        return -6.0 * lap_phi / (phi ** 3)

    # ---------- Sampling ----------
    def sample_point(self, r1: float, r2: float) -> Dict[str, Any]:
        zgr = self.z_gr(r1, r2)
        zsc = self.z_scalar(r1, r2)

        rel_diff = None
        if zgr not in (None, 0.0) and zsc is not None:
            rel_diff = (zsc - zgr) / zgr

        return {
            "coordinates": {"r_emitter": r1, "r_receiver": r2},
            "curvature_invariants": {
                "kretschmann_GR_at_r1": finite_or_none(self.kretschmann_gr(r1)),
                "kretschmann_GR_at_r2": finite_or_none(self.kretschmann_gr(r2)),
                "ricci_scalar_scalar_gravity_at_r1": finite_or_none(self.ricci_scalar_scalar_gravity(r1)),
                "ricci_scalar_scalar_gravity_at_r2": finite_or_none(self.ricci_scalar_scalar_gravity(r2)),
            },
            "local_observables": {
                "redshift_GR": finite_or_none(zgr),
                "redshift_scalar_gravity": finite_or_none(zsc),
                "relative_difference_(scalar_minus_GR)_over_GR": finite_or_none(rel_diff),
            },
            "causal_structure": {
                "GR_horizon_radius_2M": 2.0 * self.M,
                "scalar_gravity_horizon": None,
                "note": (
                    "Scalar gravity has no event horizon here; deviations grow in strong field."
                ),
            },
        }

    def build_payload(self, r1_values: List[float], r2_values: List[float]) -> Dict[str, Any]:
        require(len(r1_values) >= 1 and len(r2_values) >= 1, "Need r1 and r2 samples.")

        sample_points: List[Dict[str, Any]] = []
        max_rel_diff = 0.0

        for r1 in r1_values:
            for r2 in r2_values:
                sp = self.sample_point(float(r1), float(r2))
                sample_points.append(sp)
                rd = sp["local_observables"]["relative_difference_(scalar_minus_GR)_over_GR"]
                if rd is not None:
                    max_rel_diff = max(max_rel_diff, abs(rd))

        return {
            "toy_id": self.toy_id,
            "theory": "Comparator: General Relativity vs scalar gravity",
            "spacetime": "Static spherically symmetric field (GR Schwarzschild vs scalar conformal gravity)",
            "units": {"G": 1, "c": 1},
            "parameters": {
                "M": self.M,
                "r1_samples": r1_values,
                "r2_samples": r2_values,
            },
            "notes": {
                "assumptions": [
                    "Weak-to-moderate field regime comparison",
                    "Static observers",
                    "Scalar gravity uses conformally flat metric g_ab = φ^2 η_ab",
                    "φ(r)=exp(-M/r) chosen to recover Newtonian limit",
                ],
                "pressure_point": (
                    "GR is not uniquely selected by redshift or Newtonian limits alone. "
                    "Alternative metric theories can agree at leading order and diverge only "
                    "in strong-field regimes. A comparator is required to isolate genuinely GR-specific predictions."
                ),
                "key_formulas": {
                    "z_GR": "sqrt((1-2M/r2)/(1-2M/r1)) - 1",
                    "phi_scalar": "φ(r)=exp(-M/r)",
                    "z_scalar": "φ(r1)/φ(r2) - 1",
                    "R_scalar": "R = -6 φ^{-3} ∇^2 φ",
                },
            },
            "sample_points": sample_points,
            "observables": {
                "summary": {
                    "max_relative_redshift_difference_over_samples": finite_or_none(max_rel_diff),
                    "note": (
                        "Relative difference is small in weak field (large r) and grows near r~few M. "
                        "Only comparison against alternatives identifies GR-specific content."
                    ),
                }
            },
        }

    def export_json(self, r1_values: List[float], r2_values: List[float], out_path: Optional[str] = None) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)
        payload = self.build_payload(r1_values=r1_values, r2_values=r2_values)
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2, sort_keys=True)
        return out_path


# ----------------------------
# CLI
# ----------------------------

def main() -> None:
    ap = argparse.ArgumentParser(description="Toy 060: GR vs scalar gravity redshift comparator.")
    ap.add_argument("--M", type=float, default=1.0, help="Mass parameter M")
    ap.add_argument("--r1", type=str, default="4,6,10,20", help="Comma-separated emitter radii")
    ap.add_argument("--r2", type=str, default="10,20,50", help="Comma-separated receiver radii")
    ap.add_argument("--out", type=str, default="", help="Optional output path")
    args = ap.parse_args()

    r1_values = parse_csv_floats(args.r1)
    r2_values = parse_csv_floats(args.r2)

    toy = Toy060ScalarVsGRComparator(M=float(args.M))
    out_path = args.out.strip() or None
    json_path = toy.export_json(r1_values=r1_values, r2_values=r2_values, out_path=out_path)

    print(f"Wrote {json_path}")
    print("Toy 060 complete: GR vs scalar gravity comparator.")


if __name__ == "__main__":
    main()
