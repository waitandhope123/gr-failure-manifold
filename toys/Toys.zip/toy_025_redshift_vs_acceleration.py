#!/usr/bin/env python3
"""
Toy 025 — Gravitational redshift vs local acceleration (Schwarzschild mismatch)

What it probes:
- Gravitational redshift is a global comparison, not a local force.
- Proper acceleration needed to hover diverges at the horizon,
  while redshift remains finite between nearby radii.
- Kills the intuition that redshift directly measures local gravity.

Model (G=c=1):
Static observers in Schwarzschild spacetime.

Key formulas:
  f(r) = 1 - 2M/r
  Gravitational redshift:
    z = sqrt(f(r_obs)/f(r_emit)) - 1
  Proper acceleration of static observer:
    a = M / (r^2 * sqrt(f(r)))
"""

from __future__ import annotations

import argparse
import json
import math
import os
from typing import Any, Dict, List, Optional


# ----------------------------
# Helpers
# ----------------------------

def py_to_json_name(py_path: str) -> str:
    base = os.path.splitext(os.path.basename(py_path))[0]
    return base + ".json"


def parse_csv_floats(s: str) -> List[float]:
    return [float(x.strip()) for x in s.split(",") if x.strip()]


def require(cond: bool, msg: str) -> None:
    if not cond:
        raise ValueError(msg)


# ----------------------------
# Toy 025
# ----------------------------

class Toy025RedshiftVsAcceleration:
    toy_id = "025"

    def __init__(self, M: float = 1.0, r_obs: float = 10.0) -> None:
        require(M > 0.0, "M must be > 0.")
        require(r_obs > 2.0 * M, "Observer must be outside horizon.")
        self.M = float(M)
        self.r_obs = float(r_obs)

    def f(self, r: float) -> float:
        return 1.0 - 2.0 * self.M / r

    def horizon(self) -> float:
        return 2.0 * self.M

    def redshift(self, r_emit: float) -> Optional[float]:
        fe = self.f(r_emit)
        fo = self.f(self.r_obs)
        if fe <= 0.0 or fo <= 0.0:
            return None
        return math.sqrt(fo / fe) - 1.0

    def proper_acceleration(self, r: float) -> Optional[float]:
        f = self.f(r)
        if f <= 0.0:
            return None
        return self.M / (r * r * math.sqrt(f))

    def build_payload(self, r_emit_values: List[float]) -> Dict[str, Any]:
        sample_points: List[Dict[str, Any]] = []

        for r in r_emit_values:
            require(r > 0.0, "All radii must be > 0.")
            r = float(r)

            sample_points.append({
                "coordinates": {"t": None, "r": r, "theta": None, "phi": None},
                "curvature_invariants": {
                    "ricci_scalar": 0.0,
                    "kretschmann": 48.0 * self.M**2 / r**6,
                },
                "local_observables": {
                    "metric_f": self.f(r),
                    "proper_acceleration_static": self.proper_acceleration(r),
                    "gravitational_redshift_to_r_obs": self.redshift(r),
                },
                "causal_structure": {
                    "horizon_radius": self.horizon(),
                    "region": (
                        "exterior (r>2M)" if r > self.horizon() else
                        ("horizon (r=2M)" if abs(r - self.horizon()) < 1e-12 else
                         "interior (r<2M)")
                    ),
                },
            })

        payload: Dict[str, Any] = {
            "toy_id": self.toy_id,
            "theory": "General Relativity (static observers)",
            "spacetime": "Schwarzschild (redshift vs acceleration)",
            "units": {"G": 1, "c": 1},
            "parameters": {
                "M": self.M,
                "r_obs": self.r_obs,
            },
            "notes": {
                "pressure_point": (
                    "Gravitational redshift is a global comparison between clocks, "
                    "while proper acceleration is a local quantity that diverges "
                    "at the horizon. The two are not equivalent measures of gravity."
                )
            },
            "sample_points": sample_points,
            "observables": {
                "observer_radius": self.r_obs,
                "horizon_radius": self.horizon(),
            },
        }

        return payload

    def export_json(self, r_emit_values: List[float], out_path: Optional[str] = None) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)
        payload = self.build_payload(r_emit_values)
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2, sort_keys=True)
        return out_path


# ----------------------------
# CLI
# ----------------------------

def main() -> None:
    ap = argparse.ArgumentParser(description="Toy 025: redshift vs proper acceleration.")
    ap.add_argument("--M", type=float, default=1.0, help="Black hole mass M")
    ap.add_argument("--r_obs", type=float, default=10.0, help="Observer radius")
    ap.add_argument("--r_emit", type=str,
                    default="20,10,6,4,3,2.5,2.1",
                    help="Comma-separated emitter radii")
    ap.add_argument("--out", type=str, default="",
                    help="Optional output path")
    args = ap.parse_args()

    toy = Toy025RedshiftVsAcceleration(M=args.M, r_obs=args.r_obs)
    r_emit_values = parse_csv_floats(args.r_emit)

    out_path = args.out.strip() or None
    json_path = toy.export_json(r_emit_values, out_path)

    print(f"Wrote {json_path}")
    print(f"Horizon radius: r = {toy.horizon():g}")


if __name__ == "__main__":
    main()
