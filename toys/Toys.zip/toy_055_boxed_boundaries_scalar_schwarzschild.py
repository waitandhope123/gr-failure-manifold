#!/usr/bin/env python3
"""
Toy 055 — Finite-radius boundaries (“boxed” GR surrogate) for scalar waves on Schwarzschild

What it probes (pressure point):
- Boundary conditions are *physics inputs* in practice. Even if the local field equations are correct,
  finite-radius boundaries can inject reflections, spurious energy nonconservation, and artificial
  late-time tails that masquerade as physical GR effects.
- Asymptotic flatness is not an innocent idealization in numerical work.

Model (controlled approximation):
- Use a proxy field on a fixed Schwarzschild background (G=c=1), not full NR:
  A massless scalar field ψ(t,r*) obeys the 1+1 wave equation with the Regge–Wheeler-like potential:
    ∂_t^2 ψ - ∂_{r*}^2 ψ + V_l(r) ψ = 0
  with (for scalar, s=0):
    V_l(r) = (1 - 2M/r) [ l(l+1)/r^2 + 2M/r^3 ]
- r* is the tortoise coordinate: dr*/dr = (1 - 2M/r)^(-1)

Numerics:
- Solve on a finite domain r* ∈ [r*_min, r*_max] using a leapfrog scheme.
- Inner boundary near the horizon: apply ingoing condition (Sommerfeld in r*):
    (∂_t + ∂_{r*}) ψ = 0  at r*_min
- Outer boundary: choose one of:
    (A) absorbing (Sommerfeld outgoing): (∂_t - ∂_{r*}) ψ = 0
    (B) reflective (Dirichlet): ψ = 0
- Track an energy-like quantity on the grid:
    E = 1/2 ∫ [ (∂_t ψ)^2 + (∂_{r*} ψ)^2 + V ψ^2 ] dr*
  and boundary flux proxies from the Sommerfeld conditions.

Exports:
- Sample points along (t, r*) snapshots at selected times
- Observables: energy(t), fractional drift, boundary reflection signature
"""

from __future__ import annotations

import argparse
import json
import math
import os
from typing import Any, Dict, List, Optional, Tuple


# ----------------------------
# Helpers
# ----------------------------

def py_to_json_name(py_path: str) -> str:
    base = os.path.splitext(os.path.basename(py_path))[0]
    return base + ".json"


def require(cond: bool, msg: str) -> None:
    if not cond:
        raise ValueError(msg)


def finite_or_none(x: float) -> Optional[float]:
    return x if math.isfinite(x) else None


# ----------------------------
# Schwarzschild tortoise mapping (numerical inversion)
# ----------------------------

def rstar_of_r(r: float, M: float) -> float:
    # r* = r + 2M ln(r/(2M) - 1)
    require(r > 2.0 * M, "r must be > 2M for r*(r) definition.")
    return r + 2.0 * M * math.log(r / (2.0 * M) - 1.0)


def r_of_rstar(rstar: float, M: float, r_guess: float) -> float:
    """
    Invert r*(r) numerically using Newton iterations.
    Works for r > 2M.
    """
    r = max(r_guess, 2.0 * M * (1.0 + 1e-6))
    for _ in range(60):
        f = rstar_of_r(r, M) - rstar
        # dr*/dr = 1/(1-2M/r)
        d = 1.0 / (1.0 - 2.0 * M / r)
        step = f / d
        r_new = r - step
        # keep outside horizon
        if r_new <= 2.0 * M * (1.0 + 1e-12):
            r_new = 2.0 * M * (1.0 + 1e-12)
        if abs(r_new - r) < 1e-12 * max(1.0, abs(r)):
            r = r_new
            break
        r = r_new
    return r


def V_scalar_l(r: float, M: float, ell: int) -> float:
    require(r > 2.0 * M, "r must be > 2M for potential.")
    f = 1.0 - 2.0 * M / r
    return f * (ell * (ell + 1) / (r * r) + 2.0 * M / (r ** 3))


# ----------------------------
# Toy 055
# ----------------------------

class Toy055BoxedScalarOnSchwarzschild:
    toy_id = "055"

    def __init__(
        self,
        *,
        M: float = 1.0,
        ell: int = 0,
        rstar_min: float = -60.0,
        rstar_max: float = 60.0,
        N: int = 800,
        dt: float = 0.05,
        T: float = 80.0,
        outer_bc: str = "absorbing",   # "absorbing" or "reflective"
        inner_bc: str = "ingoing",     # fixed
        pulse_center: float = 0.0,
        pulse_width: float = 5.0,
        pulse_amp: float = 1.0,
        snapshot_times: Optional[List[float]] = None,
    ) -> None:
        require(M > 0.0, "M must be > 0.")
        require(N >= 100, "N must be >= 100.")
        require(rstar_max > rstar_min, "rstar_max must be > rstar_min.")
        require(dt > 0.0 and T > 0.0, "dt,T must be >0.")
        require(outer_bc in ("absorbing", "reflective"), "outer_bc must be 'absorbing' or 'reflective'.")
        require(inner_bc == "ingoing", "Only ingoing inner_bc supported.")
        require(pulse_width > 0.0, "pulse_width must be > 0.")
        self.M = float(M)
        self.ell = int(ell)
        self.rstar_min = float(rstar_min)
        self.rstar_max = float(rstar_max)
        self.N = int(N)
        self.dt = float(dt)
        self.T = float(T)
        self.outer_bc = outer_bc
        self.inner_bc = inner_bc
        self.pulse_center = float(pulse_center)
        self.pulse_width = float(pulse_width)
        self.pulse_amp = float(pulse_amp)
        self.snapshot_times = snapshot_times if snapshot_times is not None else [0.0, 10.0, 20.0, 40.0, 80.0]

        self.drstar = (self.rstar_max - self.rstar_min) / (self.N - 1)
        require(self.dt <= 0.95 * self.drstar, "For stability, choose dt <= ~dr* (CFL).")

        # Precompute grid r*(i) and map to r(i) and V(i)
        self.rstar_grid = [self.rstar_min + i * self.drstar for i in range(self.N)]

        # Invert r*(r) → r for each r* using a walking initial guess
        self.r_grid: List[float] = []
        r_guess = 2.0 * self.M + 1.0
        for rs in self.rstar_grid:
            # Larger r* corresponds to larger r, so use last value as next guess
            r_guess = r_of_rstar(rs, self.M, r_guess=r_guess)
            self.r_grid.append(r_guess)

        self.V_grid = [V_scalar_l(r, self.M, self.ell) for r in self.r_grid]

    def initial_pulse(self, rstar: float) -> float:
        # Gaussian in r*
        x = (rstar - self.pulse_center) / self.pulse_width
        return self.pulse_amp * math.exp(-0.5 * x * x)

    def energy(self, psi: List[float], psi_prev: List[float]) -> float:
        """
        E = 1/2 ∫ [ (∂t ψ)^2 + (∂r* ψ)^2 + V ψ^2 ] dr*
        ∂t ψ approximated by (psi - psi_prev)/dt at integer time.
        """
        E = 0.0
        for i in range(1, self.N - 1):
            dtpsi = (psi[i] - psi_prev[i]) / self.dt
            drpsi = (psi[i + 1] - psi[i - 1]) / (2.0 * self.drstar)
            V = self.V_grid[i]
            E += 0.5 * (dtpsi * dtpsi + drpsi * drpsi + V * psi[i] * psi[i]) * self.drstar
        return E

    def step(self, psi: List[float], psi_prev: List[float]) -> List[float]:
        """
        Leapfrog update:
            psi_next = 2 psi - psi_prev + dt^2 (∂r*^2 psi - V psi)
        """
        psi_next = [0.0] * self.N

        c2 = (self.dt / self.drstar) ** 2

        # interior
        for i in range(1, self.N - 1):
            lap = psi[i + 1] - 2.0 * psi[i] + psi[i - 1]
            psi_next[i] = 2.0 * psi[i] - psi_prev[i] + c2 * lap - (self.dt ** 2) * self.V_grid[i] * psi[i]

        # inner BC at i=0 (ingoing Sommerfeld): (∂t + ∂r*)ψ = 0
        # Discretize: (psi_next - psi_prev)/(2dt) + (psi[1]-psi[0])/dr* = 0
        # => psi_next[0] = psi_prev[0] - 2dt (psi[1]-psi[0])/dr*
        psi_next[0] = psi_prev[0] - 2.0 * self.dt * (psi[1] - psi[0]) / self.drstar

        # outer BC at i=N-1
        if self.outer_bc == "absorbing":
            # outgoing Sommerfeld: (∂t - ∂r*)ψ = 0
            # (psi_next - psi_prev)/(2dt) - (psi[N-1]-psi[N-2])/dr* = 0
            # => psi_next[N-1] = psi_prev[N-1] + 2dt (psi[N-1]-psi[N-2])/dr*
            psi_next[-1] = psi_prev[-1] + 2.0 * self.dt * (psi[-1] - psi[-2]) / self.drstar
        else:
            # reflective Dirichlet
            psi_next[-1] = 0.0

        return psi_next

    def run(self) -> Dict[str, Any]:
        # Initial data: psi(t=0)=Gaussian, psi_t(t=0)=0 => psi_prev = psi - dt*psi_t = psi
        psi = [self.initial_pulse(rs) for rs in self.rstar_grid]
        psi_prev = psi.copy()

        t = 0.0
        steps = int(round(self.T / self.dt))

        # time series
        energy_series: List[Dict[str, float]] = []
        snapshots: Dict[float, List[float]] = {}

        # For sampling points: we will export a subset of r* points at snapshot times
        snap_set = set(float(x) for x in self.snapshot_times)

        E0 = self.energy(psi, psi_prev)
        energy_series.append({"t": t, "E": E0})

        if t in snap_set:
            snapshots[t] = psi.copy()

        for n in range(1, steps + 1):
            psi_next = self.step(psi, psi_prev)
            psi_prev, psi = psi, psi_next
            t = n * self.dt

            if (n % max(1, steps // 400)) == 0 or n == steps:
                E = self.energy(psi, psi_prev)
                energy_series.append({"t": t, "E": E})

            # snapshot if close to requested time
            for ts in list(snap_set):
                if abs(t - ts) < 0.5 * self.dt and ts not in snapshots:
                    snapshots[ts] = psi.copy()

        # Sort energy series
        energy_series = sorted(energy_series, key=lambda d: d["t"])

        # Summaries
        E_end = energy_series[-1]["E"]
        frac_drift = (E_end - E0) / E0 if E0 != 0.0 else None

        # Reflection signature: if outer bc is reflective, late-time energy should plateau/oscillate.
        reflection_expected = (self.outer_bc == "reflective")

        return {
            "energy_series": energy_series,
            "snapshots": snapshots,
            "E0": E0,
            "E_end": E_end,
            "frac_drift": frac_drift,
            "reflection_expected": reflection_expected,
        }

    def build_payload(self) -> Dict[str, Any]:
        result = self.run()

        # Build sample_points from snapshots: choose a coarse set of spatial indices
        spatial_indices = list(range(0, self.N, max(1, self.N // 40)))
        if spatial_indices[-1] != self.N - 1:
            spatial_indices.append(self.N - 1)

        sample_points: List[Dict[str, Any]] = []
        for t_snap, psi_snap in sorted(result["snapshots"].items(), key=lambda kv: kv[0]):
            for i in spatial_indices:
                rs = self.rstar_grid[i]
                r = self.r_grid[i]
                V = self.V_grid[i]
                psi_val = psi_snap[i]
                sample_points.append({
                    "coordinates": {"t": t_snap, "r_star": rs, "r": r},
                    "curvature_invariants": {
                        # Background invariants for Schwarzschild vacuum at radius r
                        "ricci_scalar": 0.0,
                        "kretschmann": finite_or_none(48.0 * (self.M ** 2) / (r ** 6)) if r > 0.0 else None,
                    },
                    "local_observables": {
                        "psi": finite_or_none(psi_val),
                        "V_effective": finite_or_none(V),
                        "tortoise_spacing_dr_star": self.drstar,
                    },
                    "causal_structure": {
                        "horizon_radius_2M": 2.0 * self.M,
                        "near_horizon": (r < 2.0 * self.M * 1.05),
                        "boundary_condition_outer": self.outer_bc,
                        "boundary_condition_inner": self.inner_bc,
                    },
                })

        # Energy series for observables
        E_series = result["energy_series"]
        E0 = result["E0"]
        E_end = result["E_end"]
        frac_drift = result["frac_drift"]

        # Detect "late reflection bump": compare energy at late time to minimum after initial pulse
        energies = [d["E"] for d in E_series]
        Emin = min(energies) if energies else None
        reflection_bump = (E_end - Emin) / E0 if (Emin is not None and E0 != 0.0) else None

        return {
            "toy_id": self.toy_id,
            "theory": "General Relativity (fixed background) + scalar field proxy",
            "spacetime": "Schwarzschild exterior with finite-radius boundaries (boxed domain)",
            "units": {"G": 1, "c": 1},
            "parameters": {
                "M": self.M,
                "ell": self.ell,
                "r_star_min": self.rstar_min,
                "r_star_max": self.rstar_max,
                "N_grid": self.N,
                "dt": self.dt,
                "T_final": self.T,
                "outer_boundary_condition": self.outer_bc,
                "inner_boundary_condition": self.inner_bc,
                "initial_pulse": {
                    "center_r_star": self.pulse_center,
                    "width": self.pulse_width,
                    "amplitude": self.pulse_amp,
                },
                "snapshot_times": self.snapshot_times,
            },
            "notes": {
                "assumptions": [
                    "Fixed Schwarzschild background (no backreaction)",
                    "Massless scalar field as a proxy for wave propagation",
                    "Finite computational domain in tortoise coordinate r*",
                    "Sommerfeld (ingoing) inner boundary near horizon",
                    "Outer boundary chosen as absorbing Sommerfeld or reflective Dirichlet",
                ],
                "pressure_point": (
                    "Finite boundaries introduce unphysical reflections and energy drift. "
                    "Boundary conditions are part of the effective physics of a simulation; "
                    "asymptotic flatness is not a harmless idealization."
                ),
                "key_equations": {
                    "wave_eq": "∂_t^2 ψ - ∂_{r*}^2 ψ + V_l(r) ψ = 0",
                    "potential": "V_l=(1-2M/r)[l(l+1)/r^2 + 2M/r^3] (scalar s=0)",
                    "energy_like": "E=1/2∫[(∂tψ)^2+(∂r*ψ)^2+Vψ^2]dr*",
                    "rstar": "r* = r + 2M ln(r/(2M)-1)",
                },
            },
            "sample_points": sample_points,
            "observables": {
                "energy": {
                    "E0": finite_or_none(E0),
                    "E_end": finite_or_none(E_end),
                    "fractional_energy_drift": finite_or_none(frac_drift) if frac_drift is not None else None,
                    "reflection_bump_proxy": finite_or_none(reflection_bump) if reflection_bump is not None else None,
                    "outer_bc": self.outer_bc,
                    "note": (
                        "Reflective BC tends to re-inject energy; absorbing BC should reduce reflections "
                        "but still shows finite-domain drift and imperfect absorption."
                    ),
                },
                "energy_time_series": E_series,  # small dict list, safe in observables
            },
        }

    def export_json(self, out_path: Optional[str] = None) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)
        payload = self.build_payload()
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2, sort_keys=True)
        return out_path


# ----------------------------
# CLI
# ----------------------------

def main() -> None:
    ap = argparse.ArgumentParser(description="Toy 055: boxed boundaries for waves on Schwarzschild (scalar proxy).")
    ap.add_argument("--M", type=float, default=1.0, help="Schwarzschild mass M")
    ap.add_argument("--ell", type=int, default=0, help="Multipole ell >=0")
    ap.add_argument("--rstar_min", type=float, default=-60.0, help="Domain min r*")
    ap.add_argument("--rstar_max", type=float, default=60.0, help="Domain max r*")
    ap.add_argument("--N", type=int, default=800, help="Number of spatial points (>=100)")
    ap.add_argument("--dt", type=float, default=0.05, help="Time step dt (CFL: dt<=~dr*)")
    ap.add_argument("--T", type=float, default=80.0, help="Final time")
    ap.add_argument("--outer_bc", type=str, default="absorbing", choices=["absorbing", "reflective"],
                    help="Outer boundary condition")
    ap.add_argument("--pulse_center", type=float, default=0.0, help="Initial Gaussian center in r*")
    ap.add_argument("--pulse_width", type=float, default=5.0, help="Initial Gaussian width in r*")
    ap.add_argument("--pulse_amp", type=float, default=1.0, help="Initial Gaussian amplitude")
    ap.add_argument("--snapshots", type=str, default="0,10,20,40,80", help="Comma-separated snapshot times")
    ap.add_argument("--out", type=str, default="", help="Optional output path")
    args = ap.parse_args()

    snapshot_times = [float(x.strip()) for x in args.snapshots.split(",") if x.strip()]

    toy = Toy055BoxedScalarOnSchwarzschild(
        M=float(args.M),
        ell=int(args.ell),
        rstar_min=float(args.rstar_min),
        rstar_max=float(args.rstar_max),
        N=int(args.N),
        dt=float(args.dt),
        T=float(args.T),
        outer_bc=str(args.outer_bc),
        pulse_center=float(args.pulse_center),
        pulse_width=float(args.pulse_width),
        pulse_amp=float(args.pulse_amp),
        snapshot_times=snapshot_times,
    )

    out_path = args.out.strip() or None
    json_path = toy.export_json(out_path=out_path)

    print(f"Wrote {json_path}")
    print("Toy 055 complete: finite-boundary (boxed) scalar proxy on Schwarzschild.")


if __name__ == "__main__":
    main()
