#!/usr/bin/env python3
"""
Toy 022 — Raychaudhuri equation: geodesic focusing vs energy conditions

Model (G=c=1):
Timelike geodesic congruence with zero vorticity.

Raychaudhuri equation:
  dθ/dτ = - (1/3) θ^2 - σ^2 - R_ab u^a u^b

Assumptions:
- shear σ = 0
- vorticity = 0
- R_ab u^a u^b = 4π (ρ + 3p)
- perfect fluid with p = w ρ
"""

from __future__ import annotations

import argparse
import json
import os
from typing import Any, Dict, List, Optional


# ----------------------------
# Helpers
# ----------------------------

def py_to_json_name(py_path: str) -> str:
    base = os.path.splitext(os.path.basename(py_path))[0]
    return base + ".json"


def parse_csv_floats(s: str) -> List[float]:
    return [float(x.strip()) for x in s.split(",") if x.strip()]


def require(cond: bool, msg: str) -> None:
    if not cond:
        raise ValueError(msg)


# ----------------------------
# Toy 022
# ----------------------------

class Toy022Raychaudhuri:
    toy_id = "022"

    def __init__(self, theta0: float, rho: float, w: float = 0.0) -> None:
        self.theta0 = float(theta0)
        self.rho = float(rho)
        self.w = float(w)

    def ricci_contraction(self) -> float:
        # R_ab u^a u^b = 4π (ρ + 3p)
        return 4.0 * 3.141592653589793 * self.rho * (1.0 + 3.0 * self.w)

    def evolve_theta(self, tau: float) -> float:
        # Analytic solution for constant Ricci term, σ=0
        R = self.ricci_contraction()
        if abs(R) < 1e-15:
            return self.theta0 / (1.0 + (self.theta0 * tau / 3.0))
        else:
            return - ( (3.0 * R) ** 0.5 ) * (
                ( (self.theta0 - (3.0 * R) ** 0.5) /
                  (self.theta0 + (3.0 * R) ** 0.5) )
                * pow(
                    ( (self.theta0 + (3.0 * R) ** 0.5) /
                      (self.theta0 - (3.0 * R) ** 0.5) ),
                    tau
                )
                - 1
            )

    def build_payload(self, tau_values: List[float]) -> Dict[str, Any]:
        sample_points: List[Dict[str, Any]] = []

        for tau in tau_values:
            theta = self.evolve_theta(tau)

            sample_points.append({
                "coordinates": {"proper_time": tau},
                "curvature_invariants": {
                    "ricci_contraction_Rab_uu": self.ricci_contraction()
                },
                "local_observables": {
                    "expansion_theta": theta
                },
                "causal_structure": {
                    "focusing": theta < 0
                },
            })

        payload: Dict[str, Any] = {
            "toy_id": self.toy_id,
            "theory": "General Relativity (Raychaudhuri equation)",
            "spacetime": "Generic timelike geodesic congruence",
            "units": {"G": 1, "c": 1},
            "parameters": {
                "theta0": self.theta0,
                "rho": self.rho,
                "w": self.w,
            },
            "notes": {
                "pressure_point": (
                    "Geodesic focusing is controlled entirely by energy conditions. "
                    "Violating them removes the singularity guarantee."
                )
            },
            "sample_points": sample_points,
            "observables": {
                "strong_energy_condition": (self.rho * (1 + 3 * self.w)) >= 0
            },
        }

        return payload

    def export_json(self, tau_values: List[float], out_path: Optional[str] = None) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)
        payload = self.build_payload(tau_values)
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2, sort_keys=True)
        return out_path


# ----------------------------
# CLI
# ----------------------------

def main() -> None:
    ap = argparse.ArgumentParser(description="Toy 022: Raychaudhuri focusing exporter.")
    ap.add_argument("--theta0", type=float, default=-0.1, help="Initial expansion θ(0)")
    ap.add_argument("--rho", type=float, default=0.01, help="Energy density ρ")
    ap.add_argument("--w", type=float, default=0.0, help="Equation of state p = wρ")
    ap.add_argument("--t", type=str, default="0,1,2,3,4,5",
                    help="Comma-separated proper times")
    ap.add_argument("--out", type=str, default="",
                    help="Optional output path")
    args = ap.parse_args()

    toy = Toy022Raychaudhuri(theta0=args.theta0, rho=args.rho, w=args.w)
    tau_values = parse_csv_floats(args.t)

    out_path = args.out.strip() or None
    json_path = toy.export_json(tau_values, out_path)

    print(f"Wrote {json_path}")


if __name__ == "__main__":
    main()
