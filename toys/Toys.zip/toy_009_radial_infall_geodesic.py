#!/usr/bin/env python3
"""
Toy 009 — Radial timelike geodesic: infall from rest at infinity (E=1)

What it probes (weak points / pressure points):
- Physical vs coordinate time:
  * Proper time to cross the horizon is finite.
  * Schwarzschild coordinate time t -> +∞ as r -> 2M (coordinate pathology).
  * Painlevé–Gullstrand (PG) time stays finite; for this specific infall, Δt_PG = Δτ.
- Conserved quantity (energy per unit mass):
  * E = (1-2M/r) dt/dτ ; for 'rest at infinity' E=1.
- Same geometry, different charts:
  * Exposes where "infinite time" is just coordinates.

Assumptions/Model:
- Schwarzschild spacetime, geometric units G=c=1
- Radial infall, starting at radius r0 with τ=0 and t=0
- Energy E=1 (rest at infinity)

Key equations:
- f(r) = 1 - 2M/r
- dr/dτ = -sqrt(2M/r)
- dt/dτ = 1/f(r)   (since E=1)
- Schwarzschild coordinate time vs r (analytic; using u = sqrt(r/(2M))):
    t(r) = 4M[ (u0^3-u^3)/3 + (u0-u) + (1/2) ln| (u0-1)/(u0+1) * (u+1)/(u-1) | ]
  where u0=sqrt(r0/(2M))
  (Diverges as r->2M+)
- Proper time vs r:
    τ(r) = (2/3) * (r0^(3/2) - r^(3/2)) / sqrt(2M)
- For this 'rain' infall, PG time satisfies:
    Δt_PG = Δτ  (we export t_PG = τ with same zero at r0)

STRICT EXPORT RULE:
- Writes JSON named exactly like this .py file (toy_009_radial_infall_geodesic.json).
- JSON follows the canonical schema with required keys and required subkeys.
- Undefined quantities are exported as null (JSON null).
"""

from __future__ import annotations

import argparse
import json
import math
import os
from typing import Any, Dict, List, Optional


# ----------------------------
# Helpers
# ----------------------------

def py_to_json_name(py_path: str) -> str:
    base = os.path.splitext(os.path.basename(py_path))[0]
    return base + ".json"


def parse_csv_floats(s: str) -> List[float]:
    return [float(x.strip()) for x in s.split(",") if x.strip()]


def require(cond: bool, msg: str) -> None:
    if not cond:
        raise ValueError(msg)


# ----------------------------
# Toy 009: radial infall (E=1)
# ----------------------------

class Toy009RadialInfall:
    toy_id = "009"

    def __init__(self, M: float = 1.0, r0: float = 10.0) -> None:
        require(M > 0.0, "M must be > 0.")
        require(r0 > 0.0, "r0 must be > 0.")
        self.M = float(M)
        self.r0 = float(r0)

    def rh(self) -> float:
        return 2.0 * self.M

    def f(self, r: float) -> float:
        require(r > 0.0, "r must be > 0.")
        return 1.0 - 2.0 * self.M / r

    # --- Invariants (same as Schwarzschild geometry) ---
    def ricci_scalar(self, r: float) -> float:
        require(r > 0.0, "r must be > 0.")
        return 0.0

    def kretschmann(self, r: float) -> float:
        require(r > 0.0, "r must be > 0.")
        return 48.0 * (self.M ** 2) / (r ** 6)

    # --- Geodesic kinematics (E=1) ---
    def dr_dtau(self, r: float) -> float:
        # dr/dτ = -sqrt(2M/r)
        require(r > 0.0, "r must be > 0.")
        return -math.sqrt(2.0 * self.M / r)

    def dt_dtau_schwarzschild(self, r: float) -> Optional[float]:
        # dt/dτ = 1/f ; diverges at r=2M
        require(r > 0.0, "r must be > 0.")
        if r <= self.rh():
            return None
        return 1.0 / self.f(r)

    def dr_dt_schwarzschild(self, r: float) -> Optional[float]:
        # dr/dt = (dr/dτ)/(dt/dτ) = -sqrt(2M/r) * f
        require(r > 0.0, "r must be > 0.")
        if r <= self.rh():
            return None
        return self.dr_dtau(r) * self.f(r)

    # --- Proper time from r0 to r (analytic) ---
    def tau_of_r(self, r: float) -> Optional[float]:
        """
        τ(r) = (2/3) * (r0^(3/2) - r^(3/2)) / sqrt(2M)
        Only meaningful for 0 < r <= r0 (infall direction). For r>r0, return negative (or null).
        We return null if r>r0 (outside intended infall segment).
        """
        require(r > 0.0, "r must be > 0.")
        if r > self.r0:
            return None
        return (2.0 / 3.0) * (self.r0 ** 1.5 - r ** 1.5) / math.sqrt(2.0 * self.M)

    # --- Schwarzschild coordinate time from r0 to r (analytic; valid for r>2M, r0>2M) ---
    def t_schwarzschild_of_r(self, r: float) -> Optional[float]:
        """
        t(r) = 4M[ (u0^3-u^3)/3 + (u0-u) + (1/2) ln| (u0-1)/(u0+1) * (u+1)/(u-1) | ]
        u = sqrt(r/(2M)), u0 = sqrt(r0/(2M))
        Diverges as r -> 2M+ (u -> 1+).
        Return null if r<=2M or r0<=2M.
        """
        require(r > 0.0, "r must be > 0.")
        if self.r0 <= self.rh():
            return None
        if r <= self.rh():
            return None
        if r > self.r0:
            return None  # we only model infall segment downward

        u = math.sqrt(r / self.rh())
        u0 = math.sqrt(self.r0 / self.rh())

        # log argument positive for u>1; use abs for robustness.
        log_arg = abs((u0 - 1.0) / (u0 + 1.0) * (u + 1.0) / (u - 1.0))
        term = (u0 ** 3 - u ** 3) / 3.0 + (u0 - u) + 0.5 * math.log(log_arg)
        return 4.0 * self.M * term

    # --- PG time along this specific infall ---
    def t_pg_of_r(self, r: float) -> Optional[float]:
        """
        For infall from rest at infinity ("rain observers"), PG time equals proper time along the infaller:
          Δt_PG = Δτ
        We export t_PG(r) = τ(r) with same zero at r0.
        """
        return self.tau_of_r(r)

    # --- Observables summaries ---
    def proper_time_to_horizon(self) -> Optional[float]:
        if self.r0 <= self.rh():
            return None
        return self.tau_of_r(self.rh())

    def coordinate_time_to_horizon(self) -> None:
        # Diverges; export null and note.
        return None

    # --- Canonical export payload ---
    def build_payload(self, r_values: List[float]) -> Dict[str, Any]:
        sample_points: List[Dict[str, Any]] = []
        rh = self.rh()

        for r in r_values:
            r = float(r)
            require(r > 0.0, "All r must be > 0.")

            coordinates = {"t": None, "r": r, "theta": None, "phi": None, "tau": None, "t_pg": None}

            curvature_invariants = {
                "ricci_scalar": self.ricci_scalar(r),
                "kretschmann": self.kretschmann(r),
            }

            tau = self.tau_of_r(r)
            t_s = self.t_schwarzschild_of_r(r)
            t_pg = self.t_pg_of_r(r)

            local_observables: Dict[str, Any] = {
                "constants_of_motion": {
                    "E": 1.0,
                    "interpretation": "rest at infinity (specific energy)",
                },
                "kinematics": {
                    "dr_dtau": self.dr_dtau(r),
                    "dt_dtau_schwarzschild": self.dt_dtau_schwarzschild(r),
                    "dr_dt_schwarzschild": self.dr_dt_schwarzschild(r),
                },
                "times_from_r0": {
                    "r0": self.r0,
                    "tau_proper": tau,
                    "t_schwarzschild": t_s,
                    "t_painleve_gullstrand": t_pg,
                    "note": "For this E=1 infall, Δt_PG = Δτ (rain frame).",
                },
            }

            causal_structure: Dict[str, Any] = {
                "radial_null_cone_dr_dt": None,
                "horizon_radius": rh,
                "region": (
                    "exterior (r>2M)" if r > rh else
                    ("horizon (r=2M)" if r == rh else
                     "interior (r<2M)")
                ),
                "coordinate_pathology_flag": {
                    "schwarzschild_time_breaks_at_horizon": (r <= rh),
                    "proper_time_finite_through_horizon": True,
                    "pg_time_regular_at_horizon_for_this_infall": True,
                },
            }

            sample_points.append({
                "coordinates": coordinates,
                "curvature_invariants": curvature_invariants,
                "local_observables": local_observables,
                "causal_structure": causal_structure,
            })

        payload: Dict[str, Any] = {
            "toy_id": self.toy_id,
            "theory": "General Relativity (exact geodesics in Schwarzschild)",
            "spacetime": "Schwarzschild (radial timelike geodesic, E=1), compared in Schwarzschild t vs PG time",
            "units": {"G": 1, "c": 1},
            "parameters": {
                "M": self.M,
                "r0": self.r0,
                "E": 1.0,
                "geodesic_type": "radial infall from rest at infinity",
            },
            "notes": {
                "pressure_point": (
                    "Proper time to reach/cross the horizon is finite, but Schwarzschild coordinate time diverges. "
                    "PG time remains finite and (for this specific infall) equals proper time along the infaller. "
                    "This cleanly separates physical vs coordinate notions of 'time to fall in'."
                ),
                "key_formulas": {
                    "dr_dtau": "dr/dτ = -sqrt(2M/r)",
                    "dt_dtau": "dt/dτ = 1/(1-2M/r) (E=1)",
                    "tau_of_r": "τ(r)=(2/3)(r0^(3/2)-r^(3/2))/sqrt(2M)",
                    "t_of_r": "t(r)=4M[(u0^3-u^3)/3 + (u0-u) + (1/2)ln|(u0-1)/(u0+1)*(u+1)/(u-1)|], u=sqrt(r/2M)",
                },
            },
            "sample_points": sample_points,
            "observables": {
                "time_to_horizon": {
                    "r_horizon": rh,
                    "tau_proper_from_r0": self.proper_time_to_horizon(),
                    "t_schwarzschild_from_r0": None,
                    "t_schwarzschild_note": "Diverges as r -> 2M+ (coordinate).",
                    "t_pg_from_r0": self.proper_time_to_horizon(),
                    "t_pg_note": "For E=1 infall, PG time equals proper time along the infaller.",
                }
            },
        }

        return payload

    def export_json(self, r_values: List[float], out_path: Optional[str] = None) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)
        payload = self.build_payload(r_values=r_values)
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2, sort_keys=True)
        return out_path


# ----------------------------
# CLI
# ----------------------------

def main() -> None:
    ap = argparse.ArgumentParser(description="Toy 009: Radial infall geodesic (E=1) exporter.")
    ap.add_argument("--M", type=float, default=1.0, help="Mass parameter M (geometric units)")
    ap.add_argument("--r0", type=float, default=10.0, help="Starting radius r0 (>0), with t=τ=0 there")
    ap.add_argument("--r", type=str, default="10,8,6,4,3,2.5,2.2,2.1,2.01,2.001,2,1.5,1",
                    help="Comma-separated radii r>0 to sample (include near 2M to see divergence in Schwarzschild t)")
    ap.add_argument("--out", type=str, default="",
                    help="Optional output path. If omitted, uses <this_script_name>.json")
    args = ap.parse_args()

    toy = Toy009RadialInfall(M=float(args.M), r0=float(args.r0))
    r_values = parse_csv_floats(args.r)

    out_path = args.out.strip() or None
    json_path = toy.export_json(r_values=r_values, out_path=out_path)

    print(f"Wrote {json_path}")
    print(f"Notes:")
    print(f"- Horizon at r=2M={toy.rh():g}. Schwarzschild t is null for r<=2M and grows large as r->2M+.")
    print(f"- Proper time to reach horizon from r0 is finite: proper_time_to_horizon={toy.proper_time_to_horizon()}")


if __name__ == "__main__":
    main()
