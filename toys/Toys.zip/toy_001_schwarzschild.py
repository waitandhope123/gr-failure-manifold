#!/usr/bin/env python3
"""
Toy 001 — Schwarzschild baseline (exact GR vacuum solution).

What it probes (weak points / pressure points):
- True vs coordinate singularities:
  * Kretschmann scalar diverges at r -> 0 (true curvature blow-up).
  * Coordinate-time observables become ill-behaved at r -> 2M (horizon in Schwarzschild coords).
- Observable predictions:
  * gravitational redshift, time dilation, radial null cone slopes, round-trip coordinate light time.
- Local physics (frame-invariant diagnostics):
  * tidal eigenvalues in an orthonormal static frame.

STRICT EXPORT RULE:
- Writes JSON named exactly like this .py file (toy_001_schwarzschild.json).
- JSON follows the canonical schema with required keys and required subkeys.
- Undefined quantities are exported as null (JSON null).
"""

from __future__ import annotations

import argparse
import json
import math
import os
from typing import Any, Dict, List, Optional, Tuple


# ----------------------------
# Helpers
# ----------------------------

def py_to_json_name(py_path: str) -> str:
    """Return a JSON filename that matches the Python filename."""
    base = os.path.splitext(os.path.basename(py_path))[0]
    return base + ".json"


def parse_csv_floats(s: str) -> List[float]:
    return [float(x.strip()) for x in s.split(",") if x.strip()]


def parse_round_trip_cases(s: str) -> List[Dict[str, float]]:
    """
    Parse cases like: "10:6,20:6" -> [{"r_start":10,"r_turn":6}, ...]
    """
    out: List[Dict[str, float]] = []
    if not s.strip():
        return out
    for chunk in s.split(","):
        chunk = chunk.strip()
        if not chunk:
            continue
        a, b = chunk.split(":")
        out.append({"r_start": float(a), "r_turn": float(b)})
    return out


def require(cond: bool, msg: str) -> None:
    if not cond:
        raise ValueError(msg)


# ----------------------------
# Toy 001: Schwarzschild
# ----------------------------

class Toy001Schwarzschild:
    """
    Schwarzschild metric (geometric units G=c=1):
      ds^2 = -(1-2M/r) dt^2 + (1-2M/r)^(-1) dr^2 + r^2 dΩ^2

    This toy computes:
    - curvature invariants: Ricci scalar (0), Kretschmann (48 M^2 / r^6)
    - local observables: tidal eigenvalues (orthonormal static frame)
    - time dilation dτ/dt for static observer (valid only for r > 2M)
    - radial null cone slopes dr/dt = ±(1 - 2M/r) (valid only for r > 2M in these coords)
    - observables:
        * redshift to infinity: 1+z = 1/sqrt(1-2M/r_emit) (r_emit > 2M)
        * round-trip coordinate light time (r_start,r_turn > 2M)
    """

    toy_id = "001"

    def __init__(self, M: float = 1.0) -> None:
        require(M > 0.0, "M must be > 0.")
        self.M = float(M)

    # --- Core functions ---

    def f(self, r: float) -> float:
        require(r > 0.0, "r must be > 0.")
        return 1.0 - 2.0 * self.M / r

    def horizon_radius(self) -> float:
        return 2.0 * self.M

    # --- Invariants ---

    def ricci_scalar(self, r: float) -> float:
        # Vacuum solution: R = 0 for r>0 (source is distributional at r=0 if you interpret M as point mass).
        require(r > 0.0, "r must be > 0.")
        return 0.0

    def kretschmann_scalar(self, r: float) -> float:
        # K = R_{abcd}R^{abcd} = 48 M^2 / r^6
        require(r > 0.0, "r must be > 0.")
        return 48.0 * (self.M ** 2) / (r ** 6)

    # --- Local observables (frame-invariant meaning; computed in an orthonormal static frame) ---

    def tidal_eigenvalues_static_orthonormal(self, r: float) -> Dict[str, float]:
        """
        Electric part of Weyl tensor eigenvalues for a static observer:
          lambda_radial     = -2M / r^3
          lambda_transverse = + M / r^3  (degenerate, two transverse directions)
        """
        require(r > 0.0, "r must be > 0.")
        return {
            "radial": -2.0 * self.M / (r ** 3),
            "transverse": self.M / (r ** 3),
        }

    def time_dilation_dtaudt_static(self, r: float) -> float:
        """
        For a static observer at r in Schwarzschild coords (requires r>2M):
          dτ/dt = sqrt(1 - 2M/r)
        """
        require(r > self.horizon_radius(), "static time dilation requires r > 2M.")
        return math.sqrt(self.f(r))

    def radial_null_cone_slopes_dr_dt(self, r: float) -> Dict[str, float]:
        """
        Radial null geodesics in Schwarzschild coords:
          dr/dt = ±(1 - 2M/r)
        """
        require(r > self.horizon_radius(), "radial null cone slopes dr/dt require r > 2M in these coords.")
        val = self.f(r)
        return {"outgoing": val, "ingoing": -val}

    # --- Experiment-style observables ---

    def redshift_emitter_to_infinity(self, r_emit: float) -> float:
        """
        Photon emitted by static observer at r_emit and received at infinity:
          1 + z = 1 / sqrt(1 - 2M/r_emit)
        """
        require(r_emit > self.horizon_radius(), "redshift to infinity requires r_emit > 2M.")
        return (1.0 / math.sqrt(self.f(r_emit))) - 1.0

    def round_trip_light_time_coordinate(self, r_start: float, r_turn: float) -> float:
        """
        Coordinate time for radial light down-and-back:
          Δt = 2 * ∫_{r_turn}^{r_start} dr / (1 - 2M/r)

        Antiderivative:
          r + 2M ln|r - 2M|
        So:
          Δt = 2 * [(r_start - r_turn) + 2M ln((r_start-2M)/(r_turn-2M))]
        """
        require(r_start > self.horizon_radius() and r_turn > self.horizon_radius(),
                "round-trip coordinate light time requires r_start, r_turn > 2M.")
        require(r_turn < r_start, "require r_turn < r_start.")
        term_linear = (r_start - r_turn)
        term_log = 2.0 * self.M * math.log((r_start - 2.0 * self.M) / (r_turn - 2.0 * self.M))
        return 2.0 * (term_linear + term_log)

    # --- Canonical export payload ---

    def build_payload(
        self,
        r_values: List[float],
        redshift_emitters: List[float],
        round_trip_cases: List[Dict[str, float]],
    ) -> Dict[str, Any]:

        sample_points: List[Dict[str, Any]] = []
        for r in r_values:
            r = float(r)
            require(r > 0.0, "All sample radii must be > 0.")

            # Always provide required subkeys; use null when undefined
            coordinates = {"r": r, "theta": None, "phi": None, "t": None}

            curvature_invariants = {
                "ricci_scalar": self.ricci_scalar(r),
                "kretschmann": self.kretschmann_scalar(r),
            }

            local_observables: Dict[str, Any] = {
                "tidal_eigenvalues_static_orthonormal": self.tidal_eigenvalues_static_orthonormal(r),
                "time_dilation_dtaudt_static_relative_to_infinity": None,
            }

            causal_structure: Dict[str, Any] = {
                "radial_null_cone_dr_dt": None,
                "horizon_radius": self.horizon_radius(),
                "region": None,
            }

            if r > self.horizon_radius():
                local_observables["time_dilation_dtaudt_static_relative_to_infinity"] = self.time_dilation_dtaudt_static(r)
                causal_structure["radial_null_cone_dr_dt"] = self.radial_null_cone_slopes_dr_dt(r)
                causal_structure["region"] = "exterior (r > 2M)"
            elif r == self.horizon_radius():
                causal_structure["region"] = "horizon (r = 2M)"
            else:
                causal_structure["region"] = "interior (r < 2M) — Schwarzschild coordinate-time outputs undefined"

            sample_points.append({
                "coordinates": coordinates,
                "curvature_invariants": curvature_invariants,
                "local_observables": local_observables,
                "causal_structure": causal_structure,
            })

        # Observables
        obs_redshift: List[Dict[str, Any]] = []
        for r_emit in redshift_emitters:
            r_emit = float(r_emit)
            entry = {
                "r_emitter": r_emit,
                "r_receiver": "infinity",
                "z": None,
            }
            if r_emit > self.horizon_radius():
                entry["z"] = self.redshift_emitter_to_infinity(r_emit)
            obs_redshift.append(entry)

        obs_round_trip: List[Dict[str, Any]] = []
        for case in round_trip_cases:
            r_start = float(case["r_start"])
            r_turn = float(case["r_turn"])
            entry = {
                "r_start": r_start,
                "r_turn": r_turn,
                "delta_t_coordinate": None,
                "valid": None,
            }
            if r_start > self.horizon_radius() and r_turn > self.horizon_radius() and r_turn < r_start:
                entry["delta_t_coordinate"] = self.round_trip_light_time_coordinate(r_start, r_turn)
                entry["valid"] = True
            else:
                entry["valid"] = False
            obs_round_trip.append(entry)

        payload: Dict[str, Any] = {
            # REQUIRED TOP-LEVEL KEYS
            "toy_id": self.toy_id,
            "theory": "General Relativity",
            "spacetime": "Schwarzschild (vacuum, static, spherical)",
            "units": {"G": 1, "c": 1},
            "parameters": {"M": self.M},
            "notes": {
                "assumptions": [
                    "Vacuum: T_{μν}=0 (outside r=0 idealization)",
                    "Test particles/light only (no backreaction)",
                    "Geometric units G=c=1",
                    "Schwarzschild coordinates for coordinate-time outputs",
                ],
                "horizon_radius": self.horizon_radius(),
                "true_singularity_indicator": "Kretschmann -> ∞ as r -> 0",
                "coordinate_pathology_indicator": "Schwarzschild coordinate-time expressions become ill-behaved at r=2M",
            },
            "sample_points": sample_points,
            "observables": {
                "gravitational_redshift_to_infinity": obs_redshift,
                "round_trip_coordinate_light_time": obs_round_trip,
            },
        }

        return payload

    def export_json(
        self,
        r_values: List[float],
        redshift_emitters: List[float],
        round_trip_cases: List[Dict[str, float]],
        out_path: Optional[str] = None,
    ) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)

        payload = self.build_payload(r_values, redshift_emitters, round_trip_cases)
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2, sort_keys=True)
        return out_path


# ----------------------------
# CLI
# ----------------------------

def main() -> None:
    ap = argparse.ArgumentParser(description="Toy 001: Schwarzschild baseline exporter (GR).")
    ap.add_argument("--M", type=float, default=1.0, help="Mass parameter M (geometric units)")
    ap.add_argument("--r", type=str, default="3,4,6,10,20,50",
                    help="Comma-separated radii for sample points (r>0)")
    ap.add_argument("--redshift_emitters", type=str, default="6,10,20",
                    help="Comma-separated r_emit values for redshift-to-infinity observable")
    ap.add_argument("--round_trip", type=str, default="10:6,20:6",
                    help="Comma-separated cases r_start:r_turn for round-trip coordinate light time")
    ap.add_argument("--out", type=str, default="",
                    help="Optional output path. If omitted, uses <this_script_name>.json")

    args = ap.parse_args()

    r_values = parse_csv_floats(args.r)
    redshift_emitters = parse_csv_floats(args.redshift_emitters)
    round_trip_cases = parse_round_trip_cases(args.round_trip)

    toy = Toy001Schwarzschild(M=args.M)

    out_path = args.out.strip() or None
    json_path = toy.export_json(
        r_values=r_values,
        redshift_emitters=redshift_emitters,
        round_trip_cases=round_trip_cases,
        out_path=out_path,
    )

    print(f"Wrote {json_path}")
    print(f"Note: coordinate-time quantities are null at/inside the horizon r <= {toy.horizon_radius():g}.")


if __name__ == "__main__":
    main()
