#!/usr/bin/env python3
"""
Toy 074 — Quantum observer superposition on curved spacetime (operationally undefined metric readout)

Classification (lab axes):
- Failure Trigger: observer (quantum)
- Failure Mode: operational_undefined
- Failure Sharpness: contextual
- Repairable Within Classical GR: no

What it probes (pressure point):
- Classical GR assumes observers follow definite worldlines and make measurements at definite events.
- If an "observer" (or detector/clock) is in a quantum superposition of two spacetime locations,
  GR does not supply a unique rule for what geometric quantity is "measured" without specifying an
  additional measurement/branching model.

Model (controlled approximation; G=c=1):
- Use a fixed Schwarzschild geometry with mass M.
- Consider two possible observer locations r_A and r_B (both outside the horizon).
- For a static observer at radius r, proper time rate is:
    dτ/dt = sqrt(f(r)),   f(r)=1-2M/r
- A quantum superposed observer state |ψ> = (|r_A> + e^{iφ}|r_B>)/sqrt(2).

Operational ambiguity (what we compute):
- "Branch values" exist: each location has a well-defined clock rate and redshift.
- But to define a single number for the superposed observer, you must choose a rule.
  Two reasonable-but-different prescriptions:
  (1) Incoherent mixture (post-decoherence):   rate_mix = (rate_A + rate_B)/2
  (2) Coherent amplitude average (phase-sensitive proxy): rate_coh = |(rate_A + e^{iφ} rate_B)/sqrt(2)|^2
      (interpretable as a toy "transition probability weight" rather than a clock rate).
  These differ and depend on the unobservable phase φ unless a measurement model is specified.

Observed Results (what breaks and why it matters):
- Geometry provides definite outcomes on each branch (r_A, r_B), but does not provide a unique,
  observer-independent way to reduce a superposed observer to a single geometric readout.
- The "measured" time dilation/redshift becomes model- and phase-dependent: operationally undefined
  within classical GR alone.

Export:
- Strict JSON schema per lab protocol; writes <script_name>.json.
- Undefined quantities exported as null; keys never omitted.
"""

from __future__ import annotations

import argparse
import json
import math
import os
from typing import Any, Dict, List, Optional


# ----------------------------
# Helpers
# ----------------------------

def py_to_json_name(py_path: str) -> str:
    base = os.path.splitext(os.path.basename(py_path))[0]
    return base + ".json"


def require(cond: bool, msg: str) -> None:
    if not cond:
        raise ValueError(msg)


def parse_csv_floats(s: str) -> List[float]:
    return [float(x.strip()) for x in s.split(",") if x.strip()]


def finite_or_none(x: float) -> Optional[float]:
    return x if (isinstance(x, (int, float)) and math.isfinite(x)) else None


# ----------------------------
# Physics: Schwarzschild static observers
# ----------------------------

class Toy074QuantumObserverSuperposition:
    toy_id = "074"

    def __init__(self, *, M: float, r_obs: float) -> None:
        require(M > 0.0, "M must be > 0.")
        require(r_obs > 2.0 * M, "r_obs must be outside the horizon.")
        self.M = float(M)
        self.r_obs = float(r_obs)

    def horizon(self) -> float:
        return 2.0 * self.M

    def f(self, r: float) -> float:
        return 1.0 - 2.0 * self.M / r

    def rate_static(self, r: float) -> Optional[float]:
        # dτ/dt = sqrt(f(r)) for a static observer (r>2M)
        fr = self.f(r)
        if fr <= 0.0:
            return None
        return math.sqrt(fr)

    def redshift_to_obs(self, r_emit: float) -> Optional[float]:
        # z = sqrt(f(r_obs)/f(r_emit)) - 1
        fe = self.f(r_emit)
        fo = self.f(self.r_obs)
        if fe <= 0.0 or fo <= 0.0:
            return None
        return math.sqrt(fo / fe) - 1.0

    def curvature_invariants(self, r: float) -> Dict[str, Optional[float]]:
        if r <= 0.0:
            return {"ricci_scalar": None, "kretschmann": None}
        # Schwarzschild vacuum
        return {"ricci_scalar": 0.0, "kretschmann": 48.0 * (self.M ** 2) / (r ** 6)}

    def coherent_proxy(self, a: float, b: float, phi: float) -> Optional[float]:
        # A simple phase-sensitive proxy: |(a + e^{iφ} b)/sqrt(2)|^2
        # This is not a clock rate; it's a minimal demonstration that any "single-number"
        # reduction can become phase-sensitive without a measurement model.
        if a is None or b is None:
            return None
        return 0.5 * (a*a + b*b + 2.0*a*b*math.cos(phi))

    def sample_point(self, *, r_A: float, r_B: float, delta_t: float, phi: float) -> Dict[str, Any]:
        require(r_A > self.horizon(), "r_A must be outside the horizon.")
        require(r_B > self.horizon(), "r_B must be outside the horizon.")
        require(delta_t > 0.0, "delta_t must be > 0.")

        rate_A = self.rate_static(r_A)
        rate_B = self.rate_static(r_B)

        tau_A = None if rate_A is None else rate_A * delta_t
        tau_B = None if rate_B is None else rate_B * delta_t

        # Two non-equivalent reduction prescriptions
        rate_mix = None
        if rate_A is not None and rate_B is not None:
            rate_mix = 0.5 * (rate_A + rate_B)

        # Coherent, phase-sensitive proxy (not a clock rate)
        rate_coh_proxy = self.coherent_proxy(rate_A, rate_B, phi)

        z_A = self.redshift_to_obs(r_A)
        z_B = self.redshift_to_obs(r_B)
        z_mix = None
        if z_A is not None and z_B is not None:
            z_mix = 0.5 * (z_A + z_B)

        # A simple "ambiguity magnitude" diagnostic
        ambiguity = None
        if rate_mix is not None and rate_A is not None and rate_B is not None:
            ambiguity = abs(rate_A - rate_B)

        curvA = self.curvature_invariants(r_A)

        return {
            "coordinates": {
                "t": None,
                "r_A": r_A,
                "r_B": r_B,
                "phi_phase_radians": phi,
                "delta_t_coordinate": delta_t,
                "r_obs": self.r_obs,
            },
            "curvature_invariants": {
                "ricci_scalar": finite_or_none(curvA["ricci_scalar"]) if curvA["ricci_scalar"] is not None else None,
                "kretschmann_at_r_A": finite_or_none(curvA["kretschmann"]) if curvA["kretschmann"] is not None else None,
                "note": "Curvature shown at r_A as a representative local invariant; ambiguity arises from quantum superposition, not curvature pathology.",
            },
            "local_observables": {
                "schwarzschild_f_A": finite_or_none(self.f(r_A)),
                "schwarzschild_f_B": finite_or_none(self.f(r_B)),
                "branch_values": {
                    "rate_dtau_over_dt_A": finite_or_none(rate_A) if rate_A is not None else None,
                    "rate_dtau_over_dt_B": finite_or_none(rate_B) if rate_B is not None else None,
                    "proper_time_over_delta_t_A": finite_or_none(tau_A) if tau_A is not None else None,
                    "proper_time_over_delta_t_B": finite_or_none(tau_B) if tau_B is not None else None,
                    "redshift_to_r_obs_A": finite_or_none(z_A) if z_A is not None else None,
                    "redshift_to_r_obs_B": finite_or_none(z_B) if z_B is not None else None,
                },
                "superposed_observer_reductions": {
                    "mixture_rate_mean": finite_or_none(rate_mix) if rate_mix is not None else None,
                    "coherent_phase_sensitive_proxy": finite_or_none(rate_coh_proxy) if rate_coh_proxy is not None else None,
                    "mixture_redshift_mean": finite_or_none(z_mix) if z_mix is not None else None,
                    "uniqueness_status": False,
                    "note": (
                        "Classical GR provides branch values but not a unique rule to combine them for a superposed observer. "
                        "The coherent proxy depends on phase φ, illustrating measurement-model dependence."
                    ),
                },
                "ambiguity_diagnostics": {
                    "branch_rate_separation_abs": finite_or_none(ambiguity) if ambiguity is not None else None,
                },
            },
            "causal_structure": {
                "horizon_radius": self.horizon(),
                "region_A": "exterior (r>2M)" if r_A > self.horizon() else "nonstatic",
                "region_B": "exterior (r>2M)" if r_B > self.horizon() else "nonstatic",
                "note": "Both branches are chosen outside the horizon so classical clock rates are well-defined on each branch.",
            },
        }

    def build_payload(self, *, rA_values: List[float], rB_values: List[float], delta_t: float, phi_values: List[float]) -> Dict[str, Any]:
        require(len(rA_values) >= 1 and len(rB_values) >= 1, "Need rA and rB samples.")
        require(len(phi_values) >= 1, "Need at least one phase sample.")
        require(delta_t > 0.0, "delta_t must be > 0.")

        sample_points: List[Dict[str, Any]] = []
        for rA in rA_values:
            for rB in rB_values:
                for phi in phi_values:
                    sample_points.append(self.sample_point(r_A=rA, r_B=rB, delta_t=delta_t, phi=phi))

        # Summaries: max branch separation across samples
        max_sep = None
        for sp in sample_points:
            sep = sp["local_observables"]["ambiguity_diagnostics"]["branch_rate_separation_abs"]
            if sep is not None:
                max_sep = sep if max_sep is None else max(max_sep, sep)

        return {
            "toy_id": self.toy_id,
            "theory": "General Relativity (fixed Schwarzschild) + quantum-superposed observer (operational diagnostic)",
            "spacetime": "Schwarzschild (static observers) with observer location superposition (|r_A>+e^{iφ}|r_B>)/√2",
            "units": {"G": 1, "c": 1},
            "parameters": {
                "M": self.M,
                "r_obs": self.r_obs,
                "r_A_samples": rA_values,
                "r_B_samples": rB_values,
                "delta_t_coordinate": delta_t,
                "phi_phase_samples_radians": phi_values,
            },
            "notes": {
                "pressure_point": (
                    "GR defines geometric observables along definite worldlines. A quantum superposition of observer locations "
                    "forces a choice of reduction/measurement rule not supplied by classical GR, making 'the metric measured by the observer' operationally undefined."
                ),
                "key_formulas": {
                    "f": "f(r)=1-2M/r",
                    "rate": "dτ/dt = sqrt(f(r)) for static observer (r>2M)",
                    "redshift": "z = sqrt(f(r_obs)/f(r_emit)) - 1",
                    "mixture_rule": "rate_mix = (rate_A + rate_B)/2",
                    "coherent_proxy": "|(rate_A + e^{iφ} rate_B)/√2|^2 = 0.5(rate_A^2+rate_B^2+2 rate_A rate_B cosφ)",
                },
                "domain_of_validity": (
                    "Fixed-background Schwarzschild with simple static-clock observables; the 'coherent proxy' is an intentionally minimal phase-sensitive diagnostic, "
                    "not a full QFT detector calculation."
                ),
            },
            "sample_points": sample_points,
            "observables": {
                "summary": {
                    "horizon_radius_2M": self.horizon(),
                    "max_branch_rate_separation_over_samples": finite_or_none(max_sep) if max_sep is not None else None,
                    "operational_uniqueness": False,
                    "note": "Nonzero branch separation + phase-sensitive proxy illustrates that a 'single measured geometry' is not defined without extra measurement postulates.",
                }
            },
        }

    def export_json(self, *, rA_values: List[float], rB_values: List[float], delta_t: float, phi_values: List[float], out_path: Optional[str] = None) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)
        payload = self.build_payload(rA_values=rA_values, rB_values=rB_values, delta_t=delta_t, phi_values=phi_values)
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2, sort_keys=True)
        return out_path


def main() -> None:
    ap = argparse.ArgumentParser(description="Toy 074: quantum-superposed observer locations in Schwarzschild (operational undefinedness).")
    ap.add_argument("--M", type=float, default=1.0, help="Schwarzschild mass M (G=c=1).")
    ap.add_argument("--r_obs", type=float, default=20.0, help="Reference observer radius for redshift comparison (r_obs>2M).")
    ap.add_argument("--rA", type=str, default="6,10", help="Comma-separated r_A values (must be >2M).")
    ap.add_argument("--rB", type=str, default="8,14", help="Comma-separated r_B values (must be >2M).")
    ap.add_argument("--delta_t", type=float, default=1.0, help="Coordinate time interval Δt used for τ=rate*Δt.")
    ap.add_argument("--phi", type=str, default="0,1.57079632679,3.14159265359",
                    help="Comma-separated phases φ in radians (e.g., 0, π/2, π).")
    ap.add_argument("--out", type=str, default="", help="Optional output JSON path; default is <script>.json")
    args = ap.parse_args()

    toy = Toy074QuantumObserverSuperposition(M=float(args.M), r_obs=float(args.r_obs))
    rA_values = parse_csv_floats(args.rA)
    rB_values = parse_csv_floats(args.rB)
    phi_values = parse_csv_floats(args.phi)

    out_path = args.out.strip() or None
    json_path = toy.export_json(rA_values=rA_values, rB_values=rB_values, delta_t=float(args.delta_t), phi_values=phi_values, out_path=out_path)

    print(f"Wrote {json_path}")
    print("Toy 074 complete: branch observables defined, superposed reduction operationally non-unique.")


if __name__ == "__main__":
    main()
