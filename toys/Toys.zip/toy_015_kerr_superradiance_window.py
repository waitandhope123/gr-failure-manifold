#!/usr/bin/env python3
"""
Toy 015 — Kerr superradiance condition + negative-energy states (ergoregion kinematics)

What it probes (pressure point):
- In Kerr, energy at infinity E = -p_t can be negative *outside the horizon* (in the ergoregion),
  enabling energy extraction (Penrose process) and wave amplification (superradiance).
- The superradiance condition for a bosonic wave mode:
      0 < ω < m Ω_H
  is a clean inequality tying a global horizon property (Ω_H) to observable amplification windows.

This toy does NOT solve the Teukolsky equation (full scattering). Instead it catalogs:
- Whether a sampled (r, θ) point is in the ergoregion (g_tt > 0)
- Horizon angular velocity Ω_H(a)
- For given mode numbers m and sampled frequencies ω, whether the superradiance inequality holds
- A proxy "negative-energy-allowed" flag for equatorial geodesics based on E = -u_t for circular motion:
  we compute the circular-orbit specific energy E(r) (equatorial) and report if E<0 is possible
  (it typically requires ergoregion and sufficiently large counter-rotation / L).

Assumptions / setup:
- Kerr vacuum, Boyer–Lindquist coordinates, geometric units G=c=1.
- Horizon exists only if |a|<=M; otherwise export nulls for horizon-linked quantities.
- Ergoregion test uses g_tt(r,θ) = -(1 - 2Mr/Σ). Ergoregion where g_tt > 0.
- For circular equatorial orbits, we use standard specific energy formula E(r) for aligned/antialigned
  circular geodesics as in Toy 013 (valid where orbit exists).

Key definitions:
  Σ = r^2 + a^2 cos^2θ
  g_tt = -(1 - 2Mr/Σ)
  Ergoregion: g_tt > 0
  r_+ = M + sqrt(M^2 - a^2)  (if |a|<=M)
  Ω_H = a / (r_+^2 + a^2) = a / (2 M r_+)

Superradiance window:
  superradiant = (horizon exists) AND (m > 0) AND (0 < ω < m Ω_H)

STRICT EXPORT RULE:
- Writes JSON named exactly like this .py file (toy_015_kerr_superradiance_window.json).
- JSON follows the canonical schema with required keys and required subkeys.
- Undefined quantities are exported as null (JSON null).
"""

from __future__ import annotations

import argparse
import json
import math
import os
from typing import Any, Dict, List, Optional


# ----------------------------
# Helpers
# ----------------------------

def py_to_json_name(py_path: str) -> str:
    base = os.path.splitext(os.path.basename(py_path))[0]
    return base + ".json"


def parse_csv_floats(s: str) -> List[float]:
    return [float(x.strip()) for x in s.split(",") if x.strip()]


def parse_csv_ints(s: str) -> List[int]:
    return [int(x.strip()) for x in s.split(",") if x.strip()]


def parse_csv_angles_deg(s: str) -> List[float]:
    return [float(x.strip()) for x in s.split(",") if x.strip()]


def require(cond: bool, msg: str) -> None:
    if not cond:
        raise ValueError(msg)


# ----------------------------
# Toy 015
# ----------------------------

class Toy015KerrSuperradianceWindow:
    toy_id = "015"

    def __init__(self, M: float = 1.0, a: float = 0.9) -> None:
        require(M > 0.0, "M must be > 0.")
        self.M = float(M)
        self.a = float(a)

    # Kerr functions
    def Sigma(self, r: float, th: float) -> float:
        return r * r + self.a * self.a * (math.cos(th) ** 2)

    def g_tt(self, r: float, th: float) -> float:
        Sig = self.Sigma(r, th)
        return -(1.0 - (2.0 * self.M * r) / Sig)

    def is_bh(self) -> bool:
        return abs(self.a) <= self.M

    def r_plus(self) -> Optional[float]:
        if not self.is_bh():
            return None
        return self.M + math.sqrt(self.M * self.M - self.a * self.a)

    def Omega_H(self) -> Optional[float]:
        rp = self.r_plus()
        if rp is None:
            return None
        denom = rp * rp + self.a * self.a
        if denom == 0.0:
            return None
        return self.a / denom

    def ergoregion(self, r: float, th: float) -> bool:
        # ergoregion where g_tt > 0
        return self.g_tt(r, th) > 0.0

    # Equatorial circular-orbit energy proxy (as in Toy 013)
    def E_circular_equatorial(self, r: float, aligned: bool) -> Optional[float]:
        """
        Specific energy E for equatorial circular orbit at radius r.
        aligned=True means orbit angular momentum aligned with BH spin.
        Returns null if not real/defined.
        """
        require(r > 0.0, "r must be > 0.")
        M = self.M
        a = abs(self.a)  # use magnitude; aligned/antialigned encoded by ±
        s = +1.0 if aligned else -1.0

        num = (r ** 1.5) - 2.0 * M * (r ** 0.5) + s * a * (M ** 0.5)
        rad = (r ** 1.5) - 3.0 * M * (r ** 0.5) + s * 2.0 * a * (M ** 0.5)
        if rad <= 0.0:
            return None
        den = (r ** 0.75) * math.sqrt(rad)
        if den == 0.0:
            return None
        return num / den

    def superradiant(self, omega: float, m: int) -> Optional[bool]:
        OmH = self.Omega_H()
        if OmH is None:
            return None
        if m <= 0:
            return False
        return (omega > 0.0) and (omega < m * OmH)

    def build_payload(
        self,
        r_values: List[float],
        theta_deg_values: List[float],
        m_values: List[int],
        omega_values: List[float],
    ) -> Dict[str, Any]:
        sample_points: List[Dict[str, Any]] = []

        rp = self.r_plus()
        OmH = self.Omega_H()

        for r in r_values:
            require(r > 0.0, "All r must be > 0.")
            for th_deg in theta_deg_values:
                th = math.radians(th_deg)
                require(0.0 <= th <= math.pi, "theta must be in [0, pi].")

                gtt = self.g_tt(r, th)
                in_ergo = self.ergoregion(r, th)

                # Equatorial circular energy proxy only meaningful at theta=90 deg
                E_aligned = None
                E_antialigned = None
                negE_possible_proxy = None
                if abs(th_deg - 90.0) < 1e-12:
                    E_aligned = self.E_circular_equatorial(r, aligned=True)
                    E_antialigned = self.E_circular_equatorial(r, aligned=False)
                    # "Negative energy allowed" is subtle; as a proxy, flag if any computed E is < 0
                    # (if undefined, leave null)
                    if E_aligned is None and E_antialigned is None:
                        negE_possible_proxy = None
                    else:
                        negE_possible_proxy = ((E_aligned is not None and E_aligned < 0.0) or
                                               (E_antialigned is not None and E_antialigned < 0.0))

                # Evaluate superradiance window flags for provided (m, omega) grids
                sr_grid: List[Dict[str, Any]] = []
                for m in m_values:
                    for w in omega_values:
                        sr_grid.append({
                            "m": m,
                            "omega": w,
                            "superradiant_0_lt_omega_lt_mOmegaH": self.superradiant(w, m),
                            "mOmegaH": None if OmH is None else (m * OmH),
                        })

                coordinates = {"t": None, "r": r, "theta_deg": th_deg, "phi": None}

                curvature_invariants = {
                    "ricci_scalar": 0.0,
                    "kretschmann": None,  # omitted here deliberately? No: must not omit keys, but can be null.
                    "note": "This toy focuses on ergoregion kinematics & inequalities; K can be added later if desired.",
                }

                local_observables = {
                    "kerr_parameters": {
                        "M": self.M,
                        "a": self.a,
                        "a_over_M": (self.a / self.M),
                        "horizon_exists_abs_a_le_M": self.is_bh(),
                    },
                    "horizon": {
                        "r_plus": rp,
                        "Omega_H": OmH,
                        "Omega_H_formula": "Ω_H = a/(r_+^2+a^2)",
                    },
                    "ergoregion": {
                        "g_tt": gtt,
                        "in_ergoregion_gtt_positive": in_ergo,
                        "meaning": "Static observers require g_tt<0; impossible where g_tt>0.",
                    },
                    "negative_energy_proxy_equator": {
                        "only_defined_at_theta_90deg": (abs(th_deg - 90.0) < 1e-12),
                        "E_circular_aligned": E_aligned,
                        "E_circular_antialigned": E_antialigned,
                        "any_E_negative_proxy": negE_possible_proxy,
                        "note": "Penrose negative-energy states are more general than circular geodesics; this is a conservative proxy.",
                    },
                    "superradiance_window": {
                        "condition": "0 < ω < m Ω_H (with m>0)",
                        "grid": sr_grid,
                    },
                }

                causal_structure = {
                    "region": (
                        "ergoregion" if in_ergo else "outside_ergoregion"
                    ),
                    "horizon_exists": (rp is not None),
                    "inside_outer_horizon": None if rp is None else (r < rp),
                    "radial_null_cone_dr_dt": None,
                    "key_point": (
                        "Ergoregion (g_tt>0) enables negative-energy-at-infinity trajectories. "
                        "Superradiance is the wave analog: modes with 0<ω<mΩ_H can be amplified."
                    ),
                }

                sample_points.append({
                    "coordinates": coordinates,
                    "curvature_invariants": curvature_invariants,
                    "local_observables": local_observables,
                    "causal_structure": causal_structure,
                })

        payload: Dict[str, Any] = {
            "toy_id": self.toy_id,
            "theory": "General Relativity (Kerr ergoregion energetics, kinematic conditions)",
            "spacetime": "Kerr: superradiance inequality and ergoregion test via g_tt",
            "units": {"G": 1, "c": 1},
            "parameters": {
                "M": self.M,
                "a": self.a,
                "r_values": r_values,
                "theta_deg_values": theta_deg_values,
                "m_values": m_values,
                "omega_values": omega_values,
            },
            "notes": {
                "pressure_point": (
                    "Energy extraction hinges on the sign of conserved energy at infinity. "
                    "Kerr allows negative-energy states in the ergoregion, enabling Penrose "
                    "process and wave superradiance (0<ω<mΩ_H)."
                ),
                "key_formulas": {
                    "Sigma": "Σ = r^2 + a^2 cos^2θ",
                    "g_tt": "g_tt = -(1 - 2Mr/Σ); ergoregion if g_tt>0",
                    "horizon": "r_+ = M + sqrt(M^2 - a^2) (if |a|<=M)",
                    "Omega_H": "Ω_H = a/(r_+^2 + a^2) = a/(2Mr_+)",
                    "superradiance": "0 < ω < m Ω_H (m>0)",
                },
                "domain_of_validity": (
                    "Exact Kerr kinematics. Does not compute scattering amplitudes; "
                    "only catalogs when superradiance is allowed in principle."
                ),
            },
            "sample_points": sample_points,
            "observables": {
                "global": {
                    "r_plus": rp,
                    "Omega_H": OmH,
                    "horizon_exists": (rp is not None),
                }
            },
        }
        return payload

    def export_json(
        self,
        r_values: List[float],
        theta_deg_values: List[float],
        m_values: List[int],
        omega_values: List[float],
        out_path: Optional[str] = None,
    ) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)
        payload = self.build_payload(
            r_values=r_values,
            theta_deg_values=theta_deg_values,
            m_values=m_values,
            omega_values=omega_values,
        )
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2, sort_keys=True)
        return out_path


# ----------------------------
# CLI
# ----------------------------

def main() -> None:
    ap = argparse.ArgumentParser(description="Toy 015: Kerr superradiance window + ergoregion negative-energy proxy.")
    ap.add_argument("--M", type=float, default=1.0, help="Mass M (geometric units)")
    ap.add_argument("--a", type=float, default=0.9, help="Spin a (|a|<=M for BH)")
    ap.add_argument("--r", type=str, default="1.2,1.4,1.6,2.0,2.5,3.0,4.0,6.0",
                    help="Comma-separated radii r to sample")
    ap.add_argument("--theta_deg", type=str, default="0,30,60,90",
                    help="Comma-separated θ in degrees to sample")
    ap.add_argument("--m", type=str, default="1,2,3",
                    help="Comma-separated azimuthal mode numbers m to test")
    ap.add_argument("--omega", type=str, default="0.01,0.05,0.1,0.2,0.3",
                    help="Comma-separated frequencies ω to test (geometric units)")
    ap.add_argument("--out", type=str, default="", help="Optional output path; default is <script>.json")
    args = ap.parse_args()

    toy = Toy015KerrSuperradianceWindow(M=float(args.M), a=float(args.a))
    r_values = parse_csv_floats(args.r)
    th_values = parse_csv_angles_deg(args.theta_deg)
    m_values = parse_csv_ints(args.m)
    omega_values = parse_csv_floats(args.omega)

    out_path = args.out.strip() or None
    json_path = toy.export_json(r_values=r_values, theta_deg_values=th_values,
                               m_values=m_values, omega_values=omega_values, out_path=out_path)

    print(f"Wrote {json_path}")
    print(f"Horizon exists: {toy.is_bh()}; r_+={toy.r_plus()}; Omega_H={toy.Omega_H()}")
    print("Superradiance condition: 0 < omega < m * Omega_H (m>0)")

if __name__ == "__main__":
    main()
