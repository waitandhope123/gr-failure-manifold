#!/usr/bin/env python3
"""
Toy 018 — Morris–Thorne traversable wormhole: exact stress-energy + NEC violation

What it probes (pressure point):
- Traversable wormholes in GR require “exotic matter” that violates standard energy conditions.
- This toy computes the *actual* stress-energy components (in an orthonormal static frame)
  for a classic Morris–Thorne wormhole and exports explicit NEC diagnostics.

Assumptions / setup:
- Static, spherically symmetric traversable wormhole metric (Morris–Thorne):
    ds^2 = -e^{2Φ(r)} dt^2 + dr^2 / (1 - b(r)/r) + r^2(dθ^2 + sin^2θ dφ^2)
- Choose a standard minimal model:
    Φ(r) = 0  (no horizon; finite redshift everywhere)
    b(r) = r0^2 / r  (throat at r=r0, flare-out satisfied)
- Geometric units: G=c=1. Einstein equations: G_{μν} = 8π T_{μν}.

Stress-energy in orthonormal basis (static observers) for general Φ(r), b(r):
  ρ(r)   = (1/8π) * b'(r) / r^2
  p_r(r) = (1/8π) * [ - b(r)/r^3 + 2(1 - b(r)/r) Φ'(r)/r ]
  p_t(r) = (1/8π) * (1 - b/r) * [ Φ'' + (Φ')^2 - (b'r - b)/(2r(r-b)) Φ' - (b'r - b)/(2r^2(r-b)) + Φ'/r ]
For Φ=0 these simplify drastically:
  ρ(r)   = (1/8π) * b'(r)/r^2
  p_r(r) = -(1/8π) * b(r)/r^3
  p_t(r) = (1/16π) * [b(r) - b'(r) r]/r^3

For b(r)=r0^2/r:
  b'(r) = -r0^2/r^2
  ρ(r)   = -(1/8π) * r0^2 / r^4   (negative everywhere)
  p_r(r) = -(1/8π) * r0^2 / r^4   (also negative)
  NEC_radial: ρ + p_r = -(1/4π) * r0^2 / r^4 < 0  (violated everywhere)

Geometry diagnostics:
- Throat at r=r0 where b(r0)=r0.
- Flare-out at throat: b'(r0) < 1 (here b'(r0) = -1).
- Proper radial distance from throat:
    l(r) = ± ∫_{r0}^{r} dr' / sqrt(1 - b(r')/r')
  For b=r0^2/r, integral is analytic:
    l(r) = ± sqrt(r^2 - r0^2)

Embedding of equatorial slice (t=const, θ=π/2) into Euclidean 3-space:
  dz/dr = ± sqrt( b(r) / (r - b(r)) )
  For b=r0^2/r:
    dz/dr = ± r0 / sqrt(r^2 - r0^2)
    z(r) = ± r0 arcosh(r/r0)

STRICT EXPORT RULE:
- Writes JSON named exactly like this .py file (toy_018_traversable_wormhole_nec.json).
- JSON follows the canonical schema with required keys and required subkeys.
- Undefined quantities are exported as null (JSON null).
"""

from __future__ import annotations

import argparse
import json
import math
import os
from typing import Any, Dict, List, Optional


# ----------------------------
# Helpers
# ----------------------------

def py_to_json_name(py_path: str) -> str:
    base = os.path.splitext(os.path.basename(py_path))[0]
    return base + ".json"


def parse_csv_floats(s: str) -> List[float]:
    return [float(x.strip()) for x in s.split(",") if x.strip()]


def require(cond: bool, msg: str) -> None:
    if not cond:
        raise ValueError(msg)


# ----------------------------
# Toy 018
# ----------------------------

class Toy018TraversableWormholeNEC:
    toy_id = "018"

    def __init__(self, r0: float = 1.0) -> None:
        require(r0 > 0.0, "r0 must be > 0.")
        self.r0 = float(r0)

    # Morris–Thorne choices
    def Phi(self, r: float) -> float:
        # Φ(r)=0
        return 0.0

    def b(self, r: float) -> float:
        # b(r)=r0^2/r
        require(r > 0.0, "r must be > 0.")
        return (self.r0 * self.r0) / r

    def bprime(self, r: float) -> float:
        # b'(r) = -r0^2/r^2
        require(r > 0.0, "r must be > 0.")
        return -(self.r0 * self.r0) / (r * r)

    # Stress-energy in orthonormal static frame (Φ=0 simplified)
    def rho(self, r: float) -> float:
        # ρ = (1/8π) * b'(r)/r^2
        return (1.0 / (8.0 * math.pi)) * self.bprime(r) / (r * r)

    def p_r(self, r: float) -> float:
        # p_r = -(1/8π) * b(r)/r^3
        return -(1.0 / (8.0 * math.pi)) * self.b(r) / (r ** 3)

    def p_t(self, r: float) -> float:
        # p_t = (1/16π) * [b - b' r]/r^3
        return (1.0 / (16.0 * math.pi)) * (self.b(r) - self.bprime(r) * r) / (r ** 3)

    # Energy conditions
    def nec_radial(self, r: float) -> float:
        # NEC along radial null direction: ρ + p_r
        return self.rho(r) + self.p_r(r)

    def wec(self, r: float) -> bool:
        # Weak energy condition requires ρ >= 0 (already violated here)
        return self.rho(r) >= 0.0

    # Proper radial distance l(r) = ± sqrt(r^2 - r0^2)
    def proper_distance_from_throat(self, r: float) -> Optional[float]:
        if r < self.r0:
            return None
        return math.sqrt(r * r - self.r0 * self.r0)

    # Embedding z(r) = ± r0 arcosh(r/r0)
    def embedding_z(self, r: float) -> Optional[float]:
        if r < self.r0:
            return None
        x = r / self.r0
        if x < 1.0:
            return None
        return self.r0 * math.acosh(x)

    def dz_dr(self, r: float) -> Optional[float]:
        # dz/dr = ± r0 / sqrt(r^2 - r0^2)
        if r <= self.r0:
            return None
        return self.r0 / math.sqrt(r * r - self.r0 * self.r0)

    # Curvature invariants: not computed in this minimal stress-energy-focused toy
    def ricci_scalar(self, r: float) -> Optional[float]:
        return None

    def kretschmann(self, r: float) -> Optional[float]:
        return None

    def build_payload(self, r_values: List[float]) -> Dict[str, Any]:
        sample_points: List[Dict[str, Any]] = []
        r0 = self.r0

        for r in r_values:
            r = float(r)
            require(r > 0.0, "All radii must be > 0.")
            require(r >= r0, "For this chart, sample r >= r0 (throat radius).")

            br = self.b(r)
            bpr = self.bprime(r)
            one_minus = 1.0 - br / r

            rho = self.rho(r)
            pr = self.p_r(r)
            pt = self.p_t(r)
            nec = self.nec_radial(r)

            l = self.proper_distance_from_throat(r)
            z = self.embedding_z(r)
            dzdr = self.dz_dr(r)

            # Flare-out at throat: b(r0)=r0 and b'(r0) < 1
            flare_out = (self.bprime(r0) < 1.0)

            coordinates = {"t": None, "r": r, "theta": None, "phi": None}

            curvature_invariants = {
                "ricci_scalar": self.ricci_scalar(r),
                "kretschmann": self.kretschmann(r),
                "note": "This toy emphasizes stress-energy + energy conditions; invariants left null.",
            }

            local_observables = {
                "metric_functions": {
                    "Phi(r)": self.Phi(r),
                    "b(r)": br,
                    "bprime(r)": bpr,
                    "one_minus_b_over_r": one_minus,
                    "throat_r0": r0,
                },
                "stress_energy_orthonormal_static": {
                    "rho_energy_density": rho,
                    "p_r_radial_pressure": pr,
                    "p_t_transverse_pressure": pt,
                    "units_note": "Geometric units; T components via G=8πT.",
                },
                "energy_conditions": {
                    "NEC_radial_rho_plus_p_r": nec,
                    "NEC_radial_satisfied": (nec >= 0.0),
                    "WEC_rho_ge_0": (rho >= 0.0),
                    "comment": "For this classic wormhole, NEC is violated everywhere (ρ+p_r<0).",
                },
                "geometry_diagnostics": {
                    "throat_condition_b_equals_r_at_r0": (abs(self.b(r0) - r0) < 1e-12),
                    "flare_out_bprime_less_than_1_at_throat": flare_out,
                    "proper_distance_from_throat_l": l,
                    "embedding_equatorial_z": z,
                    "embedding_slope_dz_dr_abs": dzdr,
                    "embedding_notes": "z(r)=r0 arcosh(r/r0), dz/dr=r0/sqrt(r^2-r0^2) (sign ± not stored).",
                },
            }

            causal_structure = {
                "horizon": None,
                "static_observers": True,
                "notes": (
                    "With Φ=0, there is no redshift divergence (no horizon). Traversability hinges on "
                    "exotic matter: NEC violation is explicit in ρ+p_r."
                ),
                "radial_null_cone_dr_dt": None,
            }

            sample_points.append({
                "coordinates": coordinates,
                "curvature_invariants": curvature_invariants,
                "local_observables": local_observables,
                "causal_structure": causal_structure,
            })

        payload: Dict[str, Any] = {
            "toy_id": self.toy_id,
            "theory": "General Relativity (static spherically symmetric wormhole)",
            "spacetime": "Morris–Thorne traversable wormhole with Φ=0, b=r0^2/r",
            "units": {"G": 1, "c": 1},
            "parameters": {
                "r0": self.r0,
                "Phi_choice": "0",
                "b_choice": "r0^2/r",
            },
            "notes": {
                "pressure_point": (
                    "Traversability in GR can require explicit energy-condition violation. "
                    "This toy computes ρ, p_r, p_t and shows NEC_radial = ρ + p_r < 0."
                ),
                "key_formulas": {
                    "rho": "ρ = (1/8π) b'(r)/r^2",
                    "p_r": "p_r = -(1/8π) b(r)/r^3 (for Φ=0)",
                    "p_t": "p_t = (1/16π) [b - b'r]/r^3 (for Φ=0)",
                    "NEC_radial": "ρ + p_r",
                    "b": "b(r)=r0^2/r, b'(r)=-r0^2/r^2",
                    "proper_distance": "l(r)=±sqrt(r^2-r0^2)",
                    "embedding": "z(r)=± r0 arcosh(r/r0)",
                },
                "domain_of_validity": (
                    "Exact within the Morris–Thorne ansatz. Matter content is whatever T_{μν} results "
                    "from the chosen Φ and b; no microphysical model is supplied."
                ),
            },
            "sample_points": sample_points,
            "observables": {
                "throat": {
                    "r0": self.r0,
                    "b_r0": self.b(self.r0),
                    "bprime_r0": self.bprime(self.r0),
                    "flare_out_bprime_lt_1": (self.bprime(self.r0) < 1.0),
                }
            },
        }
        return payload

    def export_json(self, r_values: List[float], out_path: Optional[str] = None) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)
        payload = self.build_payload(r_values=r_values)
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2, sort_keys=True)
        return out_path


# ----------------------------
# CLI
# ----------------------------

def main() -> None:
    ap = argparse.ArgumentParser(description="Toy 018: Morris–Thorne wormhole stress-energy + NEC violation.")
    ap.add_argument("--r0", type=float, default=1.0, help="Throat radius r0 (>0)")
    ap.add_argument(
        "--r",
        type=str,
        default="1.0,1.05,1.1,1.2,1.5,2.0,3.0,5.0,10.0",
        help="Comma-separated radii r to sample (must be >= r0)",
    )
    ap.add_argument("--out", type=str, default="", help="Optional output path; default is <script>.json")
    args = ap.parse_args()

    toy = Toy018TraversableWormholeNEC(r0=float(args.r0))
    r_values = parse_csv_floats(args.r)

    out_path = args.out.strip() or None
    json_path = toy.export_json(r_values=r_values, out_path=out_path)

    print(f"Wrote {json_path}")
    print(f"Throat r0={toy.r0:g}; b(r0)={toy.b(toy.r0):g}; b'(r0)={toy.bprime(toy.r0):g}")
    print("NEC_radial (energy density + radial pressure) is negative for this model (exotic matter).")


if __name__ == "__main__":
    main()
