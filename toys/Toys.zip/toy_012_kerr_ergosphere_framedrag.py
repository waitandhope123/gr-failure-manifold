#!/usr/bin/env python3
"""
Toy 012 — Kerr spacetime: horizons, ergosphere, and frame dragging (ZAMO catalog)

What it probes (pressure point):
- Rotation introduces qualitatively new causal/kinematic structure:
  * Two horizons (outer/inner) if |a|<M
  * Ergosphere (g_tt>0 region) where "static" observers cannot exist
  * Frame dragging: locally non-rotating observers (ZAMOs) have angular velocity ω = -g_{tφ}/g_{φφ}
- Distinguishes:
  * horizon (Δ=0) vs ergosurface (g_tt=0)
  * coordinate artifacts vs invariant-ish diagnostics (using scalar K and region tests)

Assumptions / setup:
- Kerr vacuum in Boyer–Lindquist coordinates (t, r, θ, φ)
- Geometric units G=c=1
- Parameters: mass M>0, spin parameter a with |a|<=M (for a BH; otherwise naked singularity)
- We sample at (r, θ) points; φ irrelevant by axisymmetry

Key definitions:
  Σ = r^2 + a^2 cos^2θ
  Δ = r^2 - 2Mr + a^2
  A = (r^2 + a^2)^2 - a^2 Δ sin^2θ

Metric components used:
  g_tt   = -(1 - 2Mr/Σ)
  g_tφ   = -2Mar sin^2θ / Σ
  g_φφ   =  A sin^2θ / Σ

ZAMO (locally non-rotating) frame-dragging angular velocity:
  ω = - g_tφ / g_φφ = 2Mar / A

Lapse (useful diagnostic for approach to horizon):
  α = sqrt(Δ Σ / A)  (vanishes at outer horizon in BL slicing)

Horizons / ergosurface:
  r_± = M ± sqrt(M^2 - a^2)
  r_erg(θ) = M + sqrt(M^2 - a^2 cos^2θ)  (outer ergosurface where g_tt=0)

Curvature invariant (Kretschmann scalar) for Kerr vacuum:
  K = 48 M^2 (r^6 - 15 a^2 r^4 cos^2θ + 15 a^4 r^2 cos^4θ - a^6 cos^6θ) / Σ^6

STRICT EXPORT RULE:
- Writes JSON named exactly like this .py file (toy_012_kerr_ergosphere_framedrag.json).
- JSON follows the canonical schema with required keys and required subkeys.
- Undefined quantities are exported as null (JSON null).
"""

from __future__ import annotations

import argparse
import json
import math
import os
from typing import Any, Dict, List, Optional, Tuple


# ----------------------------
# Helpers
# ----------------------------

def py_to_json_name(py_path: str) -> str:
    base = os.path.splitext(os.path.basename(py_path))[0]
    return base + ".json"


def parse_csv_floats(s: str) -> List[float]:
    return [float(x.strip()) for x in s.split(",") if x.strip()]


def parse_csv_angles_deg(s: str) -> List[float]:
    # store degrees; convert to radians when used
    return [float(x.strip()) for x in s.split(",") if x.strip()]


def require(cond: bool, msg: str) -> None:
    if not cond:
        raise ValueError(msg)


# ----------------------------
# Toy 012
# ----------------------------

class Toy012KerrErgosphereFrameDrag:
    toy_id = "012"

    def __init__(self, M: float = 1.0, a: float = 0.5) -> None:
        require(M > 0.0, "M must be > 0.")
        self.M = float(M)
        self.a = float(a)

    # --- Kerr functions ---
    def Sigma(self, r: float, th: float) -> float:
        return r * r + self.a * self.a * (math.cos(th) ** 2)

    def Delta(self, r: float) -> float:
        return r * r - 2.0 * self.M * r + self.a * self.a

    def Afunc(self, r: float, th: float) -> float:
        # A = (r^2+a^2)^2 - a^2 Δ sin^2θ
        s2 = math.sin(th) ** 2
        return (r * r + self.a * self.a) ** 2 - (self.a * self.a) * self.Delta(r) * s2

    def horizons(self) -> Tuple[Optional[float], Optional[float], str]:
        disc = self.M * self.M - self.a * self.a
        if disc < 0.0:
            return None, None, "naked_singularity (|a|>M)"
        root = math.sqrt(disc)
        rp = self.M + root
        rm = self.M - root
        if abs(disc) < 1e-15:
            return rp, rm, "extremal (|a|=M)"
        return rp, rm, "subextremal (|a|<M)"

    def ergosurface_outer(self, th: float) -> Optional[float]:
        disc = self.M * self.M - (self.a * self.a) * (math.cos(th) ** 2)
        if disc < 0.0:
            return None
        return self.M + math.sqrt(disc)

    # --- Metric components (BL) needed for diagnostics ---
    def g_tt(self, r: float, th: float) -> float:
        Sig = self.Sigma(r, th)
        return -(1.0 - (2.0 * self.M * r) / Sig)

    def g_tphi(self, r: float, th: float) -> float:
        Sig = self.Sigma(r, th)
        s2 = math.sin(th) ** 2
        return -(2.0 * self.M * self.a * r * s2) / Sig

    def g_phiphi(self, r: float, th: float) -> Optional[float]:
        Sig = self.Sigma(r, th)
        s2 = math.sin(th) ** 2
        A = self.Afunc(r, th)
        # On the axis, sinθ=0 -> g_phiphi=0; treat carefully
        if s2 == 0.0:
            return 0.0
        return (A * s2) / Sig

    # --- ZAMO angular velocity (frame dragging) ---
    def omega_zamo(self, r: float, th: float) -> Optional[float]:
        # ω = -g_tφ/g_φφ = 2 M a r / A  (well-defined off-axis; on axis g_phiphi->0 but limit finite)
        A = self.Afunc(r, th)
        if A == 0.0:
            return None
        return (2.0 * self.M * self.a * r) / A

    def lapse_alpha(self, r: float, th: float) -> Optional[float]:
        # α = sqrt(Δ Σ / A)
        Sig = self.Sigma(r, th)
        Del = self.Delta(r)
        A = self.Afunc(r, th)
        if A <= 0.0 or Sig <= 0.0:
            return None
        val = Del * Sig / A
        if val < 0.0:
            return None
        return math.sqrt(val)

    # --- Curvature invariants ---
    def ricci_scalar(self) -> float:
        return 0.0  # vacuum Kerr

    def kretschmann(self, r: float, th: float) -> float:
        Sig = self.Sigma(r, th)
        c = math.cos(th)
        c2 = c * c
        a2 = self.a * self.a
        r2 = r * r
        r4 = r2 * r2
        r6 = r4 * r2
        a4 = a2 * a2
        a6 = a4 * a2

        poly = r6 - 15.0 * a2 * r4 * c2 + 15.0 * a4 * r2 * (c2 ** 2) - a6 * (c2 ** 3)
        return 48.0 * (self.M ** 2) * poly / (Sig ** 6)

    # --- Region classification ---
    def region(self, r: float, th: float) -> Dict[str, Any]:
        rp, rm, kind = self.horizons()
        rerg = self.ergosurface_outer(th)

        Del = self.Delta(r)
        gtt = self.g_tt(r, th)

        # horizon tests:
        in_outer = None if rp is None else (r < rp)
        between = None
        if rp is not None and rm is not None:
            between = (r < rp) and (r > rm)

        # ergosphere (outer) is region outside outer horizon where g_tt > 0 (i.e. static impossible)
        ergo = (gtt > 0.0) if (rerg is not None) else None

        return {
            "bh_kind": kind,
            "Delta": Del,
            "g_tt": gtt,
            "outer_horizon_r_plus": rp,
            "inner_horizon_r_minus": rm,
            "outer_ergosurface_r_erg": rerg,
            "inside_outer_horizon": in_outer,
            "between_horizons": between,
            "in_ergoregion_gtt_positive": ergo,
            "notes": {
                "horizon_condition": "Δ(r)=0 (BL coordinates); outer horizon at r=r_+ if |a|<=M",
                "ergosurface_condition": "g_tt(r,θ)=0; outer ergosurface at r=r_erg(θ)",
                "static_observers": "require g_tt<0; impossible in ergoregion where g_tt>0",
            }
        }

    def build_payload(self, r_values: List[float], theta_deg_values: List[float]) -> Dict[str, Any]:
        sample_points: List[Dict[str, Any]] = []

        rp, rm, kind = self.horizons()

        # Precompute ergosurface radii for thetas (for observables summary)
        ergos: List[Dict[str, Any]] = []
        for th_deg in theta_deg_values:
            th = math.radians(th_deg)
            ergos.append({"theta_deg": th_deg, "r_erg_outer": self.ergosurface_outer(th)})

        for r in r_values:
            require(r > 0.0, "All radii must be > 0.")
            for th_deg in theta_deg_values:
                th = math.radians(th_deg)
                require(0.0 <= th <= math.pi, "theta must be in [0, pi].")

                Sig = self.Sigma(r, th)
                Del = self.Delta(r)
                A = self.Afunc(r, th)

                gtt = self.g_tt(r, th)
                gtphi = self.g_tphi(r, th)
                gpp = self.g_phiphi(r, th)

                omega = self.omega_zamo(r, th)
                alpha = self.lapse_alpha(r, th)

                curv = {
                    "ricci_scalar": self.ricci_scalar(),
                    "kretschmann": self.kretschmann(r, th),
                    "sigma": Sig,
                    "note": "Kretschmann is scalar invariant; sigma is included as Kerr shorthand (not invariant).",
                }

                local_obs: Dict[str, Any] = {
                    "kerr_functions": {
                        "Sigma": Sig,
                        "Delta": Del,
                        "A": A,
                    },
                    "metric_components_subset": {
                        "g_tt": gtt,
                        "g_tphi": gtphi,
                        "g_phiphi": gpp,
                        "interpretation": "ergosurface at g_tt=0; frame dragging from g_tphi≠0",
                    },
                    "frame_dragging": {
                        "omega_zamo": omega,
                        "omega_formula": "ω = -g_tφ/g_φφ = 2Mar / A",
                        "sign_convention_note": "ω shares sign with a for r>0; indicates dragged rotation direction.",
                    },
                    "lapse": {
                        "alpha": alpha,
                        "alpha_formula": "α = sqrt(Δ Σ / A)",
                        "note": "In BL slicing α→0 as r→r_+ (outer horizon) for |a|<=M.",
                    },
                    "surfaces": {
                        "outer_horizon_r_plus": rp,
                        "inner_horizon_r_minus": rm,
                        "outer_ergosurface_r_erg": self.ergosurface_outer(th),
                    }
                }

                causal = {
                    "region": self.region(r, th),
                    "radial_null_cone_dr_dt": None,
                    "key_point": (
                        "Rotation splits 'horizon' (Δ=0) from 'static limit' (g_tt=0). "
                        "Inside ergoregion (g_tt>0), no static observers exist."
                    ),
                }

                sample_points.append({
                    "coordinates": {"t": None, "r": r, "theta_deg": th_deg, "phi": None},
                    "curvature_invariants": curv,
                    "local_observables": local_obs,
                    "causal_structure": causal,
                })

        payload: Dict[str, Any] = {
            "toy_id": self.toy_id,
            "theory": "General Relativity (stationary axisymmetric vacuum)",
            "spacetime": "Kerr (Boyer–Lindquist): horizons, ergosphere, and ZAMO frame dragging",
            "units": {"G": 1, "c": 1},
            "parameters": {
                "M": self.M,
                "a": self.a,
                "spin_dimensionless_a_over_M": (self.a / self.M),
            },
            "notes": {
                "pressure_point": (
                    "Rotation introduces observer-dependence and new causal surfaces: "
                    "the ergosphere forces co-rotation (no static observers) even outside the horizon. "
                    "This stresses naive 'gravity as force' intuition."
                ),
                "key_formulas": {
                    "Sigma": "Σ = r^2 + a^2 cos^2θ",
                    "Delta": "Δ = r^2 - 2Mr + a^2",
                    "A": "A = (r^2+a^2)^2 - a^2 Δ sin^2θ",
                    "horizons": "r_± = M ± sqrt(M^2 - a^2)",
                    "ergosurface": "r_erg(θ)= M + sqrt(M^2 - a^2 cos^2θ)",
                    "omega_zamo": "ω = 2Mar / A",
                    "lapse": "α = sqrt(Δ Σ / A)",
                    "kretschmann": "K = 48 M^2 (r^6 - 15 a^2 r^4 cos^2θ + 15 a^4 r^2 cos^4θ - a^6 cos^6θ)/Σ^6",
                },
                "domain_of_validity": (
                    "Exact Kerr vacuum; Boyer–Lindquist coordinates. "
                    "If |a|>M, horizons are absent (naked singularity regime)."
                ),
            },
            "sample_points": sample_points,
            "observables": {
                "surfaces": {
                    "bh_kind": kind,
                    "outer_horizon_r_plus": rp,
                    "inner_horizon_r_minus": rm,
                    "outer_ergosurface_samples": ergos,
                },
                "spin": {
                    "a": self.a,
                    "a_over_M": (self.a / self.M),
                    "extremality_condition": "|a| <= M (BH); |a|=M extremal",
                }
            },
        }
        return payload

    def export_json(self, r_values: List[float], theta_deg_values: List[float], out_path: Optional[str] = None) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)
        payload = self.build_payload(r_values=r_values, theta_deg_values=theta_deg_values)
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2, sort_keys=True)
        return out_path


# ----------------------------
# CLI
# ----------------------------

def main() -> None:
    ap = argparse.ArgumentParser(description="Toy 012: Kerr horizons/ergosphere/frame dragging exporter.")
    ap.add_argument("--M", type=float, default=1.0, help="Mass M (geometric units)")
    ap.add_argument("--a", type=float, default=0.5, help="Spin parameter a (|a|<=M for BH)")
    ap.add_argument(
        "--r",
        type=str,
        default="1.2,1.5,2.0,2.5,3.0,4.0,6.0,10.0",
        help="Comma-separated radii r to sample",
    )
    ap.add_argument(
        "--theta_deg",
        type=str,
        default="0,30,60,90",
        help="Comma-separated polar angles θ in degrees to sample",
    )
    ap.add_argument("--out", type=str, default="", help="Optional output path; default is <script>.json")
    args = ap.parse_args()

    toy = Toy012KerrErgosphereFrameDrag(M=float(args.M), a=float(args.a))
    r_values = parse_csv_floats(args.r)
    th_values = parse_csv_angles_deg(args.theta_deg)

    out_path = args.out.strip() or None
    json_path = toy.export_json(r_values=r_values, theta_deg_values=th_values, out_path=out_path)

    rp, rm, kind = toy.horizons()
    print(f"Wrote {json_path}")
    print(f"Kerr kind: {kind}; M={toy.M:g}, a={toy.a:g}, a/M={toy.a/toy.M:g}")
    print(f"Horizons: r_+={None if rp is None else f'{rp:g}'}, r_-={None if rm is None else f'{rm:g}'}")
    print("Sample ergosurface radii (outer):")
    for th_deg in th_values:
        th = math.radians(th_deg)
        print(f"  theta_deg={th_deg:g}: r_erg={toy.ergosurface_outer(th)}")


if __name__ == "__main__":
    main()
