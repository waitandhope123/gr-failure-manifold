#!/usr/bin/env python3
"""
Toy 026 — Equivalence principle breakdown for extended bodies (tidal gradients)

Model (G=c=1):
Schwarzschild spacetime.
Compare ideal point-particle free fall (zero proper acceleration)
to extended bodies experiencing tidal differential acceleration.

Key idea:
- Equivalence principle holds locally for point particles.
- Extended bodies feel relative acceleration:
    Δa ~ (M / r^3) * ℓ
- This is not a violation of GR, but a limit of the EP's operational meaning.
"""

from __future__ import annotations

import argparse
import json
import math
import os
from typing import Any, Dict, List, Optional


# ----------------------------
# Helpers
# ----------------------------

def py_to_json_name(py_path: str) -> str:
    base = os.path.splitext(os.path.basename(py_path))[0]
    return base + ".json"


def parse_csv_floats(s: str) -> List[float]:
    return [float(x.strip()) for x in s.split(",") if x.strip()]


def require(cond: bool, msg: str) -> None:
    if not cond:
        raise ValueError(msg)


# ----------------------------
# Toy 026
# ----------------------------

class Toy026ExtendedBodyEP:
    toy_id = "026"

    def __init__(self, M: float = 1.0, body_size: float = 1.0) -> None:
        require(M > 0.0, "M must be > 0.")
        require(body_size > 0.0, "body_size must be > 0.")
        self.M = float(M)
        self.body_size = float(body_size)

    def horizon(self) -> float:
        return 2.0 * self.M

    def ricci_scalar(self, r: float) -> float:
        return 0.0

    def kretschmann(self, r: float) -> float:
        return 48.0 * self.M**2 / r**6

    def tidal_gradient(self, r: float) -> float:
        # Order-of-magnitude tidal gradient
        return self.M / r**3

    def build_payload(self, r_values: List[float]) -> Dict[str, Any]:
        sample_points: List[Dict[str, Any]] = []

        for r in r_values:
            require(r > 0.0, "All radii must be > 0.")
            r = float(r)

            tidal = self.tidal_gradient(r)
            delta_a = tidal * self.body_size

            sample_points.append({
                "coordinates": {"t": None, "r": r, "theta": None, "phi": None},
                "curvature_invariants": {
                    "ricci_scalar": self.ricci_scalar(r),
                    "kretschmann": self.kretschmann(r),
                },
                "local_observables": {
                    "point_particle_proper_acceleration": 0.0,
                    "extended_body_relative_acceleration": delta_a,
                    "tidal_gradient": tidal,
                    "body_size": self.body_size,
                },
                "causal_structure": {
                    "horizon_radius": self.horizon(),
                    "region": (
                        "exterior (r>2M)" if r > self.horizon() else
                        ("horizon (r=2M)" if abs(r - self.horizon()) < 1e-12 else
                         "interior (r<2M)")
                    ),
                },
            })

        payload: Dict[str, Any] = {
            "toy_id": self.toy_id,
            "theory": "General Relativity (equivalence principle limits)",
            "spacetime": "Schwarzschild (extended body diagnostics)",
            "units": {"G": 1, "c": 1},
            "parameters": {
                "M": self.M,
                "body_size": self.body_size,
            },
            "notes": {
                "pressure_point": (
                    "The equivalence principle is exact only for point particles. "
                    "Extended bodies experience size-dependent tidal effects "
                    "even in free fall."
                )
            },
            "sample_points": sample_points,
            "observables": {
                "horizon_radius": self.horizon(),
            },
        }

        return payload

    def export_json(self, r_values: List[float], out_path: Optional[str] = None) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)
        payload = self.build_payload(r_values)
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2, sort_keys=True)
        return out_path


# ----------------------------
# CLI
# ----------------------------

def main() -> None:
    ap = argparse.ArgumentParser(description="Toy 026: extended-body equivalence principle.")
    ap.add_argument("--M", type=float, default=1.0, help="Black hole mass M")
    ap.add_argument("--body_size", type=float, default=1.0, help="Proper size of body")
    ap.add_argument("--r", type=str,
                    default="10,6,4,3,2.5,2.1",
                    help="Comma-separated radii")
    ap.add_argument("--out", type=str, default="",
                    help="Optional output path")
    args = ap.parse_args()

    toy = Toy026ExtendedBodyEP(M=args.M, body_size=args.body_size)
    r_values = parse_csv_floats(args.r)

    out_path = args.out.strip() or None
    json_path = toy.export_json(r_values, out_path)

    print(f"Wrote {json_path}")
    print(f"Horizon radius: r = {toy.horizon():g}")


if __name__ == "__main__":
    main()
