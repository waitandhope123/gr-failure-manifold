#!/usr/bin/env python3
"""
Toy 008 — Painlevé–Gullstrand (PG) coordinates for Schwarzschild ("river model")

What it probes (weak points / pressure points):
- Horizon regularity via better coordinates:
  * PG coordinates cover the horizon smoothly (no g_rr blow-up).
- Physical interpretation:
  * A "river" infall velocity field v(r) = -sqrt(2M/r).
  * Radial null slopes: dr/dt = v ± 1 (c=1), so at the horizon |v|=1.
- Curvature vs coordinates:
  * Kretschmann K = 48 M^2 / r^6 is finite at r=2M and diverges only at r->0.

Metric (G=c=1), ingoing PG time t_PG:
  ds^2 = -(1-2M/r) dt^2 + 2 sqrt(2M/r) dt dr + dr^2 + r^2 dΩ^2
So components (t,r sector):
  g_tt = -(1-2M/r)
  g_tr = +sqrt(2M/r)
  g_rr = 1
Spatial slices (dt=0) are flat in r (dr^2 + r^2 dΩ^2).

Radial null curves (dΩ=0):
  0 = -(1-2M/r) dt^2 + 2 sqrt(2M/r) dt dr + dr^2
=> dr/dt = -sqrt(2M/r) ± 1 = v(r) ± 1

STRICT EXPORT RULE:
- Writes JSON named exactly like this .py file (toy_008_painleve_gullstrand.json).
- JSON follows the canonical schema with required keys and required subkeys.
- Undefined quantities are exported as null (JSON null).
"""

from __future__ import annotations

import argparse
import json
import math
import os
from typing import Any, Dict, List, Optional


# ----------------------------
# Helpers
# ----------------------------

def py_to_json_name(py_path: str) -> str:
    base = os.path.splitext(os.path.basename(py_path))[0]
    return base + ".json"


def parse_csv_floats(s: str) -> List[float]:
    return [float(x.strip()) for x in s.split(",") if x.strip()]


def require(cond: bool, msg: str) -> None:
    if not cond:
        raise ValueError(msg)


# ----------------------------
# Toy 008: Painlevé–Gullstrand
# ----------------------------

class Toy008PainleveGullstrand:
    toy_id = "008"

    def __init__(self, M: float = 1.0) -> None:
        require(M > 0.0, "M must be > 0.")
        self.M = float(M)

    def horizon_radius(self) -> float:
        return 2.0 * self.M

    def f(self, r: float) -> float:
        require(r > 0.0, "r must be > 0.")
        return 1.0 - 2.0 * self.M / r

    # River/infall speed (ingoing PG sign convention)
    def river_speed_v(self, r: float) -> float:
        """
        v(r) = -sqrt(2M/r)
        Negative means flow inward (toward decreasing r).
        """
        require(r > 0.0, "r must be > 0.")
        return -math.sqrt(2.0 * self.M / r)

    # --- Invariants (same geometry as Schwarzschild) ---
    def ricci_scalar(self, r: float) -> float:
        require(r > 0.0, "r must be > 0.")
        return 0.0

    def kretschmann(self, r: float) -> float:
        require(r > 0.0, "r must be > 0.")
        return 48.0 * (self.M ** 2) / (r ** 6)

    # --- PG metric components (t,r sector) ---
    def metric_components_pg(self, r: float) -> Dict[str, float]:
        """
        In PG coordinates (t,r):
          g_tt = -(1-2M/r) = -f
          g_tr = +sqrt(2M/r)
          g_rr = 1
        """
        require(r > 0.0, "r must be > 0.")
        return {
            "g_tt": -self.f(r),
            "g_tr": math.sqrt(2.0 * self.M / r),
            "g_rr": 1.0,
        }

    # --- Radial null slopes dr/dt in PG ---
    def radial_null_slopes_dr_dt_pg(self, r: float) -> Dict[str, float]:
        """
        dr/dt = v ± 1, where v = -sqrt(2M/r).
        This remains valid across the horizon.
        """
        v = self.river_speed_v(r)
        return {"outgoing_dr_dt": v + 1.0, "ingoing_dr_dt": v - 1.0, "river_speed_v": v}

    # --- Simple "horizon test" ---
    def horizon_condition(self, r: float) -> Dict[str, Any]:
        """
        Horizon occurs where outgoing null slope is zero:
          v + 1 = 0  <=>  |v|=1 <=> r = 2M
        """
        slopes = self.radial_null_slopes_dr_dt_pg(r)
        return {
            "outgoing_freezes": abs(slopes["outgoing_dr_dt"]) < 1e-12,
            "criterion": "outgoing_dr_dt == 0",
        }

    # --- Canonical export payload ---
    def build_payload(self, r_values: List[float]) -> Dict[str, Any]:
        sample_points: List[Dict[str, Any]] = []
        rh = self.horizon_radius()

        for r in r_values:
            r = float(r)
            require(r > 0.0, "All radii must be > 0.")

            coordinates = {"t": None, "r": r, "theta": None, "phi": None}

            curvature_invariants = {
                "ricci_scalar": self.ricci_scalar(r),
                "kretschmann": self.kretschmann(r),
            }

            pg_metric = self.metric_components_pg(r)
            slopes = self.radial_null_slopes_dr_dt_pg(r)
            hz = self.horizon_condition(r)

            local_observables: Dict[str, Any] = {
                "f": self.f(r),
                "horizon_radius_2M": rh,
                "pg_metric_tr_sector": pg_metric,
                "river_model": {
                    "river_speed_v": slopes["river_speed_v"],
                    "interpretation": "Space flows inward at speed |v|; horizon where |v|=1.",
                },
                "spatial_slice_flatness_note": "At dt=0, spatial line element is dr^2 + r^2 dΩ^2 (flat in r).",
            }

            causal_structure: Dict[str, Any] = {
                "radial_null_cone_dr_dt": {
                    "pg": {
                        "outgoing_dr_dt": slopes["outgoing_dr_dt"],
                        "ingoing_dr_dt": slopes["ingoing_dr_dt"],
                        "formula": "dr/dt = v ± 1, v=-sqrt(2M/r)",
                    }
                },
                "horizon_radius": rh,
                "region": (
                    "exterior (r>2M)" if r > rh else
                    ("horizon (r=2M)" if r == rh else
                     "interior (r<2M)")
                ),
                "horizon_test": hz,
                "coordinate_pathology_flag": {
                    "pg_regular_at_horizon": True,
                    "note": "Unlike Schwarzschild t, PG chart does not blow up at r=2M.",
                },
            }

            sample_points.append({
                "coordinates": coordinates,
                "curvature_invariants": curvature_invariants,
                "local_observables": local_observables,
                "causal_structure": causal_structure,
            })

        payload: Dict[str, Any] = {
            "toy_id": self.toy_id,
            "theory": "General Relativity (exact solution; horizon-regular slicing)",
            "spacetime": "Schwarzschild geometry in Painlevé–Gullstrand (ingoing) coordinates",
            "units": {"G": 1, "c": 1},
            "parameters": {"M": self.M},
            "notes": {
                "assumptions": [
                    "Vacuum Schwarzschild geometry (outside r=0 idealization)",
                    "Using ingoing PG coordinates (river model)",
                    "Geometric units G=c=1",
                ],
                "pressure_point": (
                    "PG shows the horizon is not a curvature singularity (K finite at r=2M) "
                    "and illustrates horizon crossing cleanly via dr/dt = v ± 1. "
                    "The horizon is where the inward flow reaches light speed (|v|=1)."
                ),
                "key_formulas": {
                    "metric_tr": "ds^2 = -(1-2M/r) dt^2 + 2 sqrt(2M/r) dt dr + dr^2 + r^2 dΩ^2",
                    "river_speed": "v(r) = -sqrt(2M/r)",
                    "null_slopes": "dr/dt = v ± 1",
                    "kretschmann": "K = 48 M^2 / r^6",
                },
                "compare_with": [
                    "Toy 001: Schwarzschild t chart (coordinate blow-up at horizon)",
                    "Toy 007: EF chart (also regular at horizon, different null parametrization)",
                ],
            },
            "sample_points": sample_points,
            "observables": {
                "summary": {
                    "horizon_radius_2M": rh,
                    "river_speed_at_horizon": self.river_speed_v(rh),
                    "outgoing_dr_dt_at_horizon": self.radial_null_slopes_dr_dt_pg(rh)["outgoing_dr_dt"],
                    "kretschmann_at_horizon": self.kretschmann(rh),
                    "note": "At r=2M: v=-1, outgoing dr/dt=0; K finite.",
                }
            },
        }

        return payload

    def export_json(self, r_values: List[float], out_path: Optional[str] = None) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)
        payload = self.build_payload(r_values=r_values)
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2, sort_keys=True)
        return out_path


# ----------------------------
# CLI
# ----------------------------

def main() -> None:
    ap = argparse.ArgumentParser(description="Toy 008: Painlevé–Gullstrand coordinates (Schwarzschild river model).")
    ap.add_argument("--M", type=float, default=1.0, help="Mass parameter M (geometric units)")
    ap.add_argument("--r", type=str, default="0.5,1,1.5,2,2.5,3,4,6,10,20",
                    help="Comma-separated radii r>0 (include inside and near 2M to see behavior)")
    ap.add_argument("--out", type=str, default="",
                    help="Optional output path. If omitted, uses <this_script_name>.json")
    args = ap.parse_args()

    r_values = parse_csv_floats(args.r)
    toy = Toy008PainleveGullstrand(M=float(args.M))

    out_path = args.out.strip() or None
    json_path = toy.export_json(r_values=r_values, out_path=out_path)

    print(f"Wrote {json_path}")
    print(f"Note: PG is regular at the horizon r=2M={toy.horizon_radius():g}. Try radii around it to see dr/dt behavior.")


if __name__ == "__main__":
    main()
