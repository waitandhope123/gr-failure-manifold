#!/usr/bin/env python3
"""
Toy 078 — Page–Wootters time emergence: different clock factorizations give different 'times'

Classification (lab axes):
- Failure Trigger: observer + state
- Failure Mode: observer_disagreement (thick; time depends on clock choice)
- Failure Sharpness: thick
- Repairable Within Classical GR: only_by_reinterpretation

What it probes (pressure point):
- In Page–Wootters / Wheeler–DeWitt style settings, the global state can be 'timeless' while
  subsystems recover an effective time parameter from correlations with a chosen clock.
- The choice of clock (i.e., subsystem factorization) is not unique; different factorizations can
  yield different conditional 'time' assignments and different effective dynamics.

Model (controlled finite-dimensional toy):
- Two-qubit Hilbert space H = H_C ⊗ H_S (dim=4).
- 'Timeless' global entangled state (Bell-like):
    |Ψ> = (|0>_C|0>_S + |1>_C|1>_S) / √2
- Factorization A (standard): clock = qubit 0, system = qubit 1.
  Conditional system states given clock outcomes (Z basis): |0> and |1>.
- Factorization B (alternative): apply a fixed global unitary U (CNOT with clock as control)
  and then *define the clock* to be qubit 0 in the transformed tensor split.
  This changes conditional system states for the same clock readout labels.

Operational output:
- Compute conditional (post-selected) system density matrices for clock outcomes {0,1} in both
  factorizations, plus summary distances showing they differ.
- This is a numerical underdetermination of 'time' from correlations: the same global state admits
  multiple relational time reconstructions.

Observed Results (what breaks and why it matters):
- 'Time slices' (conditional system states) depend on clock choice/factorization.
- Therefore, time is not uniquely defined by the global state alone; it is relational and observer/choice dependent.

Export:
- Strict JSON schema per lab protocol; writes <script_name>.json.
- Undefined quantities exported as null; keys never omitted.
"""

from __future__ import annotations

import argparse
import json
import math
import os
from typing import Any, Dict, List, Optional, Tuple

import numpy as np


# ----------------------------
# Helpers
# ----------------------------

def py_to_json_name(py_path: str) -> str:
    base = os.path.splitext(os.path.basename(py_path))[0]
    return base + ".json"


def require(cond: bool, msg: str) -> None:
    if not cond:
        raise ValueError(msg)


def finite_or_none(x: float) -> Optional[float]:
    return x if (isinstance(x, (int, float)) and math.isfinite(x)) else None


def complex_to_pair(z: complex) -> Dict[str, float]:
    return {"re": float(np.real(z)), "im": float(np.imag(z))}


def mat_to_list(m: np.ndarray) -> List[List[Dict[str, float]]]:
    # complex matrix -> list of list of {re,im}
    out: List[List[Dict[str, float]]] = []
    for i in range(m.shape[0]):
        row = []
        for j in range(m.shape[1]):
            row.append(complex_to_pair(complex(m[i, j])))
        out.append(row)
    return out


def vec_to_list(v: np.ndarray) -> List[Dict[str, float]]:
    return [complex_to_pair(complex(x)) for x in v.reshape(-1)]


def kron(a: np.ndarray, b: np.ndarray) -> np.ndarray:
    return np.kron(a, b)


def projector_on_qubit0(bit: int) -> np.ndarray:
    # |bit><bit| ⊗ I on 2-qubit space in computational basis with qubit0 most significant
    I2 = np.eye(2, dtype=complex)
    if bit == 0:
        P = np.array([[1, 0], [0, 0]], dtype=complex)
    else:
        P = np.array([[0, 0], [0, 1]], dtype=complex)
    return kron(P, I2)


def partial_trace_over_clock(rho: np.ndarray) -> np.ndarray:
    # Trace out qubit0 (clock) from 2-qubit density matrix rho (4x4), return 2x2 on system (qubit1).
    # Computational basis ordering: |00>,|01>,|10>,|11> with qubit0 as first.
    out = np.zeros((2, 2), dtype=complex)
    # sum over clock index c in {0,1}: out_{s,s'} = sum_c rho_{(c,s),(c,s')}
    for c in range(2):
        for s in range(2):
            for sp in range(2):
                i = 2*c + s
                j = 2*c + sp
                out[s, sp] += rho[i, j]
    return out


def normalize_density(rho: np.ndarray) -> Tuple[np.ndarray, float]:
    tr = float(np.real(np.trace(rho)))
    if tr <= 0:
        return rho, tr
    return rho / tr, tr


def purity(rho: np.ndarray) -> float:
    return float(np.real(np.trace(rho @ rho)))


def trace_distance(rho: np.ndarray, sigma: np.ndarray) -> float:
    # 0.5 * ||rho - sigma||_1
    # For 2x2, compute eigenvalues of Hermitian delta and sum abs.
    delta = rho - sigma
    # ensure Hermitian numerical
    deltaH = 0.5 * (delta + delta.conj().T)
    evals = np.linalg.eigvalsh(deltaH)
    return 0.5 * float(np.sum(np.abs(evals)))


# ----------------------------
# Toy 078
# ----------------------------

class Toy078PageWoottersTimeEmergence:
    toy_id = "078"

    def __init__(self) -> None:
        # Build global state |Ψ> = (|00> + |11>)/√2 in basis |q0 q1>
        psi = np.zeros((4, 1), dtype=complex)
        psi[0, 0] = 1.0 / math.sqrt(2.0)
        psi[3, 0] = 1.0 / math.sqrt(2.0)
        self.psi = psi

        # Define a global unitary U for alternative factorization (CNOT: q0 control, q1 target)
        # In computational basis |00>,|01>,|10>,|11>, CNOT matrix is:
        self.U_cnot = np.array(
            [[1, 0, 0, 0],
             [0, 1, 0, 0],
             [0, 0, 0, 1],
             [0, 0, 1, 0]], dtype=complex
        )

    def rho_global(self, psi: np.ndarray) -> np.ndarray:
        return psi @ psi.conj().T

    def conditional_system_state(self, rho: np.ndarray, clock_outcome: int) -> Dict[str, Any]:
        P = projector_on_qubit0(clock_outcome)
        rho_post = P @ rho @ P
        rho_sys_unnorm = partial_trace_over_clock(rho_post)
        rho_sys, prob = normalize_density(rho_sys_unnorm)

        return {
            "clock_outcome": int(clock_outcome),
            "probability": finite_or_none(prob),
            "rho_system": mat_to_list(rho_sys),
            "purity": finite_or_none(purity(rho_sys)) if prob > 0 else None,
        }

    def build_payload(self) -> Dict[str, Any]:
        rho = self.rho_global(self.psi)

        # Factorization A: standard split, measure clock in Z basis
        condA0 = self.conditional_system_state(rho, 0)
        condA1 = self.conditional_system_state(rho, 1)

        # Factorization B: apply global unitary U then define clock as qubit0 in transformed split
        psiB = self.U_cnot @ self.psi
        rhoB = self.rho_global(psiB)
        condB0 = self.conditional_system_state(rhoB, 0)
        condB1 = self.conditional_system_state(rhoB, 1)

        # Distances between conditional system states across factorizations (same label 0/1)
        # Extract as numpy 2x2 for computation
        def list_to_mat(L: List[List[Dict[str, float]]]) -> np.ndarray:
            m = np.zeros((2, 2), dtype=complex)
            for i in range(2):
                for j in range(2):
                    m[i, j] = complex(L[i][j]["re"], L[i][j]["im"])
            return m

        rhoA0 = list_to_mat(condA0["rho_system"])
        rhoA1 = list_to_mat(condA1["rho_system"])
        rhoB0 = list_to_mat(condB0["rho_system"])
        rhoB1 = list_to_mat(condB1["rho_system"])

        d0 = trace_distance(rhoA0, rhoB0)
        d1 = trace_distance(rhoA1, rhoB1)

        # Also show that within each factorization, the two 'time slices' differ
        dA = trace_distance(rhoA0, rhoA1)
        dB = trace_distance(rhoB0, rhoB1)

        return {
            "toy_id": self.toy_id,
            "theory": "Relational time emergence diagnostic (Page–Wootters-style; finite-dimensional proxy)",
            "spacetime": "N/A (timeless global quantum state; time from subsystem correlations)",
            "units": {"G": 1, "c": 1},
            "parameters": {
                "hilbert_space": "two qubits: H = H_C ⊗ H_S (dim=4)",
                "global_state_basis": "|q0 q1> with q0=clock label in Factorization A",
                "global_state_psi": vec_to_list(self.psi),
                "unitary_for_factorization_B": "CNOT(q0->q1)",
                "U_cnot_matrix": mat_to_list(self.U_cnot),
            },
            "notes": {
                "pressure_point": (
                    "A 'timeless' global state can yield an effective time parameter via correlations with a chosen clock. "
                    "But the clock/factorization choice is not unique, so the emergent time slicing is not unique."
                ),
                "key_steps": {
                    "conditioning": "rho_sys|c = Tr_clock[(P_c rho P_c)] / p(c)",
                    "factorization_A": "clock=qubit0, system=qubit1, measure clock in Z basis",
                    "factorization_B": "apply global U then define clock as qubit0 in transformed split",
                },
                "domain_of_validity": (
                    "Finite-dimensional proxy capturing the logical dependence of relational time on clock choice. "
                    "Not a full Wheeler–DeWitt field theory."
                ),
            },
            "sample_points": [
                {
                    "coordinates": {"case": "factorization_A"},
                    "curvature_invariants": {"ricci_scalar": None, "kretschmann": None, "note": "No classical geometry."},
                    "local_observables": {
                        "global_rho": mat_to_list(rho),
                        "clock_basis": "Z on qubit0",
                        "conditional_system_states": [condA0, condA1],
                    },
                    "causal_structure": {
                        "emergent_time_labels": [0, 1],
                        "time_uniqueness": False,
                        "note": "Time labels arise from clock outcomes; other clock choices exist.",
                    },
                },
                {
                    "coordinates": {"case": "factorization_B"},
                    "curvature_invariants": {"ricci_scalar": None, "kretschmann": None, "note": "No classical geometry."},
                    "local_observables": {
                        "global_rho_transformed": mat_to_list(rhoB),
                        "clock_basis": "Z on qubit0 after global unitary",
                        "conditional_system_states": [condB0, condB1],
                    },
                    "causal_structure": {
                        "emergent_time_labels": [0, 1],
                        "time_uniqueness": False,
                        "note": "Same abstract labels, different conditional states => different emergent 'times'.",
                    },
                },
            ],
            "observables": {
                "summary": {
                    "trace_distance_same_label_between_factorizations": {
                        "label_0": finite_or_none(d0),
                        "label_1": finite_or_none(d1),
                    },
                    "trace_distance_between_time_slices_within_factorization": {
                        "A": finite_or_none(dA),
                        "B": finite_or_none(dB),
                    },
                    "uniqueness_status": False,
                    "note": "Nonzero distances show that relational 'time slices' depend on factorization/clock choice.",
                }
            },
        }

    def export_json(self, out_path: Optional[str] = None) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)
        payload = self.build_payload()
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2, sort_keys=True)
        return out_path


def main() -> None:
    ap = argparse.ArgumentParser(description="Toy 078: Page–Wootters time emergence (clock choice dependence).")

    ap.add_argument("--out", type=str, default="", help="Optional output JSON path; default is <script>.json")
    args = ap.parse_args()

    toy = Toy078PageWoottersTimeEmergence()
    out_path = args.out.strip() or None
    json_path = toy.export_json(out_path=out_path)

    print(f"Wrote {json_path}")
    print("Toy 078 complete: different clock factorizations yield different relational time slices.")


if __name__ == "__main__":
    main()
