#!/usr/bin/env python3
"""
Toy 054 — Imperfect fluid with shear viscosity in curved spacetime (entropy production)

What it probes (pressure point):
- GR + realistic matter is not time-reversal invariant once dissipation is included.
- Perfect-fluid stress-energy hides irreversible behavior; viscosity introduces entropy
  production tied to curvature and expansion.
- GR itself does not forbid dissipation, but offers no internal principle fixing transport.

Model (G=c=1, controlled approximation):
- Background spacetime: flat FLRW (k=0) with scale factor a(t)
- Matter: homogeneous, isotropic fluid with shear viscosity η (bulk viscosity set to zero)
- We do NOT solve full Einstein–matter coupling self-consistently; instead:
  - Prescribe a(t) = (t/t0)^p  (power-law expansion)
  - Track fluid kinematics and entropy production on that background

Fluid relations (Landau–Lifshitz, first order):
- Expansion scalar: θ = 3 (dot a / a)
- Shear tensor vanishes by symmetry, but viscous pressure contributes:
    Π_visc = -3 ζ H   (bulk)
    σ_ab σ^ab = 0     (shear-free by symmetry)
- To still capture irreversible behavior, we include a *small shear perturbation proxy*:
    σ^2_proxy = beta * H^2   (dimensionless bookkeeping parameter)

Entropy production rate density:
    T ∇_a s^a = 2 η σ_ab σ^ab  ≈ 2 η σ^2_proxy

This toy exports:
- Expansion rate
- Proxy viscous dissipation
- Cumulative entropy production as a function of time

Pressure point:
- GR evolution + realistic matter is not reversible.
- There is no principle in GR fixing η or higher-order transport → underdetermined physics.
"""

from __future__ import annotations

import argparse
import json
import math
import os
from typing import Any, Dict, List, Optional


# ----------------------------
# Helpers
# ----------------------------

def py_to_json_name(py_path: str) -> str:
    base = os.path.splitext(os.path.basename(py_path))[0]
    return base + ".json"


def parse_csv_floats(s: str) -> List[float]:
    return [float(x.strip()) for x in s.split(",") if x.strip()]


def require(cond: bool, msg: str) -> None:
    if not cond:
        raise ValueError(msg)


def finite_or_none(x: float) -> Optional[float]:
    return x if math.isfinite(x) else None


# ----------------------------
# Toy 054
# ----------------------------

class Toy054ImperfectFluid:
    toy_id = "054"

    def __init__(
        self,
        *,
        p_exp: float = 2.0 / 3.0,
        t0: float = 1.0,
        eta: float = 1e-3,
        beta: float = 1e-2,
    ) -> None:
        require(t0 > 0.0, "t0 must be > 0.")
        require(eta >= 0.0, "eta must be >= 0.")
        require(beta >= 0.0, "beta must be >= 0.")
        self.p = float(p_exp)
        self.t0 = float(t0)
        self.eta = float(eta)
        self.beta = float(beta)

    # Background expansion
    def a(self, t: float) -> float:
        require(t > 0.0, "t must be > 0.")
        return (t / self.t0) ** self.p

    def H(self, t: float) -> float:
        return self.p / t

    def expansion_scalar(self, t: float) -> float:
        return 3.0 * self.H(t)

    # Shear proxy
    def shear_squared_proxy(self, t: float) -> float:
        return self.beta * self.H(t) ** 2

    # Entropy production rate density (per unit comoving volume)
    def entropy_production_rate(self, t: float) -> float:
        return 2.0 * self.eta * self.shear_squared_proxy(t)

    def sample_point(self, t: float, S_cum: float) -> Dict[str, Any]:
        return {
            "coordinates": {"t": t, "x": None, "y": None, "z": None},
            "curvature_invariants": {
                # Flat FLRW Ricci scalar: R = 6(2H^2 + dot H)
                "ricci_scalar_R": finite_or_none(6.0 * (2.0 * self.H(t) ** 2 - self.p / (t * t))),
                "kretschmann_scalar_K": None,  # not central for this toy
            },
            "local_observables": {
                "scale_factor_a": finite_or_none(self.a(t)),
                "hubble_parameter_H": finite_or_none(self.H(t)),
                "expansion_scalar_theta": finite_or_none(self.expansion_scalar(t)),
                "shear_squared_proxy": finite_or_none(self.shear_squared_proxy(t)),
                "entropy_production_rate_density": finite_or_none(self.entropy_production_rate(t)),
                "cumulative_entropy_density": finite_or_none(S_cum),
            },
            "causal_structure": {
                "cosmological_horizon_scale_1_over_H": finite_or_none(1.0 / self.H(t)),
                "note": "Irreversible entropy production despite deterministic background expansion.",
            },
        }

    def build_payload(self, t_values: List[float]) -> Dict[str, Any]:
        require(len(t_values) >= 2, "Need at least two time samples.")

        t_values = sorted(t_values)
        S_cum = 0.0
        sample_points: List[Dict[str, Any]] = []

        for i, t in enumerate(t_values):
            if i > 0:
                dt = t - t_values[i - 1]
                S_cum += self.entropy_production_rate(t) * dt
            sample_points.append(self.sample_point(t, S_cum))

        return {
            "toy_id": self.toy_id,
            "theory": "General Relativity + imperfect fluid (phenomenological)",
            "spacetime": "Flat FLRW background with viscous matter",
            "units": {"G": 1, "c": 1},
            "parameters": {
                "scale_factor_exponent_p": self.p,
                "t0": self.t0,
                "shear_viscosity_eta": self.eta,
                "shear_proxy_beta": self.beta,
                "t_samples": t_values,
            },
            "notes": {
                "assumptions": [
                    "Prescribed FLRW background (no backreaction from dissipation)",
                    "Homogeneous imperfect fluid",
                    "Shear effects represented by a proxy σ^2 ~ beta H^2",
                    "First-order (Navier–Stokes–like) relativistic hydrodynamics",
                ],
                "pressure_point": (
                    "Once dissipation is admitted, GR evolution is not time-reversible. "
                    "Transport coefficients (η, ζ, etc.) are external inputs not fixed by GR."
                ),
                "key_equations": {
                    "Hubble": "H = p/t",
                    "entropy_production": "T ∇_a s^a ≈ 2 η σ^2_proxy",
                },
            },
            "sample_points": sample_points,
            "observables": {
                "summary": {
                    "total_entropy_produced": finite_or_none(S_cum),
                    "entropy_monotonic": True,
                    "note": "Entropy increases monotonically whenever eta and beta are nonzero.",
                }
            },
        }

    def export_json(self, t_values: List[float], out_path: Optional[str] = None) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)
        payload = self.build_payload(t_values=t_values)
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2, sort_keys=True)
        return out_path


# ----------------------------
# CLI
# ----------------------------

def main() -> None:
    ap = argparse.ArgumentParser(description="Toy 054: imperfect fluid and entropy production in FLRW.")
    ap.add_argument("--p", type=float, default=2.0/3.0, help="Scale-factor exponent a~t^p")
    ap.add_argument("--t0", type=float, default=1.0, help="Reference time t0")
    ap.add_argument("--eta", type=float, default=1e-3, help="Shear viscosity eta >= 0")
    ap.add_argument("--beta", type=float, default=1e-2, help="Shear proxy coefficient beta >= 0")
    ap.add_argument("--t", type=str, default="1,2,3,5,8,13", help="Comma-separated time samples (t>0)")
    ap.add_argument("--out", type=str, default="", help="Optional output path")
    args = ap.parse_args()

    toy = Toy054ImperfectFluid(
        p_exp=float(args.p),
        t0=float(args.t0),
        eta=float(args.eta),
        beta=float(args.beta),
    )

    t_values = parse_csv_floats(args.t)
    out_path = args.out.strip() or None
    json_path = toy.export_json(t_values=t_values, out_path=out_path)

    print(f"Wrote {json_path}")
    print("Toy 054 complete: imperfect fluid entropy production.")


if __name__ == "__main__":
    main()
