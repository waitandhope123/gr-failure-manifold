#!/usr/bin/env python3
"""
Toy 076 — Causal structure from entanglement: non-unique causal orders compatible with the same entanglement pattern

Classification (lab axes):
- Failure Trigger: state
- Failure Mode: operational_undefined (causal structure underdetermined)
- Failure Sharpness: contextual
- Repairable Within Classical GR: no

What it probes (pressure point):
- If one attempts to reconstruct spacetime/causal structure from quantum entanglement data alone
  (a common emergence idea), the reconstruction can be non-unique: the same entanglement pattern
  may admit multiple inequivalent causal structures (different directed acyclic graphs / partial orders).

Model (controlled, discrete toy):
- Define an undirected "entanglement graph" on N labeled subsystems with mutual-information-like
  edge weights I_ij >= 0.
- Define an RT-like distance proxy on the graph: d_ij = 1/(I_ij + eps) for edges, and
  shortest-path distances for non-edges.
- Show two different causal DAGs (two different orientations/partial orders) that are both
  compatible with the same undirected entanglement structure (same weights and distances),
  yet imply different causal reachability relations.

Observed Results (what breaks and why it matters):
- Entanglement data here fixes an undirected weighted structure (and induced distances), but does
  not pick out a unique time orientation or causal precedence relation.
- Therefore, "causal structure is fundamental/unique" fails in an entanglement-first reconstruction:
  multiple causal structures are operationally compatible with the same entanglement pattern.

Export:
- Strict JSON schema per lab protocol; writes <script_name>.json.
- Undefined quantities exported as null; keys never omitted.
"""

from __future__ import annotations

import argparse
import json
import math
import os
from typing import Any, Dict, List, Optional


# ----------------------------
# Helpers
# ----------------------------

def py_to_json_name(py_path: str) -> str:
    base = os.path.splitext(os.path.basename(py_path))[0]
    return base + ".json"


def require(cond: bool, msg: str) -> None:
    if not cond:
        raise ValueError(msg)


def finite_or_none(x: float) -> Optional[float]:
    return x if (isinstance(x, (int, float)) and math.isfinite(x)) else None


def floyd_warshall(dist: List[List[float]]) -> List[List[float]]:
    n = len(dist)
    d = [row[:] for row in dist]
    for k in range(n):
        for i in range(n):
            dik = d[i][k]
            if not math.isfinite(dik):
                continue
            for j in range(n):
                alt = dik + d[k][j]
                if alt < d[i][j]:
                    d[i][j] = alt
    return d


def dag_reachability(adj: List[List[int]]) -> List[List[int]]:
    # transitive closure via Warshall on booleans
    n = len(adj)
    reach = [[1 if adj[i][j] else 0 for j in range(n)] for i in range(n)]
    for i in range(n):
        reach[i][i] = 1
    for k in range(n):
        for i in range(n):
            if reach[i][k]:
                for j in range(n):
                    reach[i][j] = 1 if (reach[i][j] or reach[k][j]) else 0
    return reach


def indegrees(adj: List[List[int]]) -> List[int]:
    n = len(adj)
    indeg = [0] * n
    for i in range(n):
        for j in range(n):
            indeg[j] += adj[i][j]
    return indeg


def count_topo_orders(adj: List[List[int]], limit: int = 100000) -> int:
    # backtracking; fine for small n<=6
    n = len(adj)
    indeg0 = indegrees(adj)
    used = [False] * n

    def rec(indeg: List[int], used_cnt: int) -> int:
        if used_cnt == n:
            return 1
        zeros = [i for i in range(n) if (not used[i]) and indeg[i] == 0]
        total = 0
        for v in zeros:
            if total >= limit:
                return total
            used[v] = True
            indeg2 = indeg[:]
            for w in range(n):
                if adj[v][w]:
                    indeg2[w] -= 1
            total += rec(indeg2, used_cnt + 1)
            used[v] = False
        return total

    return rec(indeg0, 0)


# ----------------------------
# Toy 076
# ----------------------------

class Toy076EntanglementCausalAmbiguity:
    toy_id = "076"

    def __init__(self, *, eps: float = 1e-6) -> None:
        require(eps > 0.0, "eps must be > 0.")
        self.eps = float(eps)

        # Fixed 4-node entanglement structure (symmetric weights I_ij).
        # Nodes: A,B,C,D (0..3)
        # A--B--C--D chain with equal weights; distances are symmetric and orientation-agnostic.
        self.nodes = ["A", "B", "C", "D"]
        self.I = [
            [0.0, 3.0, 0.0, 0.0],
            [3.0, 0.0, 3.0, 0.0],
            [0.0, 3.0, 0.0, 3.0],
            [0.0, 0.0, 3.0, 0.0],
        ]

    def entanglement_distances(self) -> List[List[float]]:
        # Edge distance d = 1/(I+eps); no-edge => inf; diagonals 0; then shortest paths.
        n = len(self.nodes)
        inf = float("inf")
        dist = [[inf] * n for _ in range(n)]
        for i in range(n):
            dist[i][i] = 0.0
        for i in range(n):
            for j in range(n):
                if i == j:
                    continue
                if self.I[i][j] > 0.0:
                    dist[i][j] = 1.0 / (self.I[i][j] + self.eps)
        return floyd_warshall(dist)

    def causal_options(self) -> List[Dict[str, Any]]:
        # Two inequivalent causal DAGs on the same undirected chain graph:
        # Option 1: A -> B -> C -> D
        # Option 2: D -> C -> B -> A  (time-reversed)
        n = len(self.nodes)
        adj1 = [[0]*n for _ in range(n)]
        adj2 = [[0]*n for _ in range(n)]

        adj1[0][1] = 1
        adj1[1][2] = 1
        adj1[2][3] = 1

        adj2[3][2] = 1
        adj2[2][1] = 1
        adj2[1][0] = 1

        opts: List[Dict[str, Any]] = []
        for name, adj in [("forward_chain", adj1), ("reverse_chain", adj2)]:
            reach = dag_reachability(adj)
            topo_count = count_topo_orders(adj)
            opts.append({
                "option_id": name,
                "dag_adjacency": adj,
                "reachability": reach,
                "topological_order_count": topo_count,
                "note": "Same undirected entanglement edges; different time orientation/causal precedence.",
            })
        return opts

    def sample_point(self, option: Dict[str, Any], dist: List[List[float]]) -> Dict[str, Any]:
        return {
            "coordinates": {"option_id": option["option_id"]},
            "curvature_invariants": {
                "ricci_scalar": None,
                "kretschmann": None,
                "note": "Discrete emergence toy: no continuum curvature computed.",
            },
            "local_observables": {
                "nodes": self.nodes,
                "entanglement_weights_I": self.I,
                "distance_proxy_shortest_paths": dist,
                "distance_definition": "edge d_ij=1/(I_ij+eps), no-edge=inf; all-pairs shortest paths",
                "eps": self.eps,
            },
            "causal_structure": {
                "dag_adjacency": option["dag_adjacency"],
                "reachability": option["reachability"],
                "topological_order_count": option["topological_order_count"],
                "compatibility_statement": "DAG uses only edges where I_ij>0 (same undirected support).",
                "note": option["note"],
            },
        }

    def build_payload(self) -> Dict[str, Any]:
        dist = self.entanglement_distances()
        options = self.causal_options()
        sample_points = [self.sample_point(opt, dist) for opt in options]

        reach0 = options[0]["reachability"]
        reach1 = options[1]["reachability"]
        different = any(reach0[i][j] != reach1[i][j] for i in range(len(self.nodes)) for j in range(len(self.nodes)))

        finite_vals: List[float] = []
        for i in range(len(self.nodes)):
            for j in range(len(self.nodes)):
                if math.isfinite(dist[i][j]):
                    finite_vals.append(dist[i][j])
        d_min = min(finite_vals) if finite_vals else None
        d_max = max(finite_vals) if finite_vals else None

        return {
            "toy_id": self.toy_id,
            "theory": "Entanglement-first emergence diagnostic (discrete proxy; not classical GR)",
            "spacetime": "Discrete entanglement graph with RT-like distance proxy; multiple compatible causal DAGs",
            "units": {"G": 1, "c": 1},
            "parameters": {
                "N": len(self.nodes),
                "nodes": self.nodes,
                "eps": self.eps,
                "I_edges": "I_ij>0 define undirected adjacency support",
            },
            "notes": {
                "pressure_point": (
                    "Entanglement pattern fixes an undirected weighted structure (and induced distances) but does not uniquely fix "
                    "a causal orientation/partial order. Multiple inequivalent causal structures can fit the same entanglement data."
                ),
                "key_definitions": {
                    "distance_proxy": "d_ij = 1/(I_ij+eps) on edges; shortest-path extension",
                    "causal_structure": "represented as a DAG adjacency + reachability (transitive closure)",
                },
                "domain_of_validity": (
                    "Minimal discrete illustration. Shows underdetermination at the level of causal ordering/orientation, "
                    "independent of continuum details."
                ),
            },
            "sample_points": sample_points,
            "observables": {
                "summary": {
                    "causal_structure_options": [opt["option_id"] for opt in options],
                    "reachability_differs_across_options": bool(different),
                    "uniqueness_status": False,
                    "distance_proxy_range": {
                        "min": finite_or_none(d_min) if d_min is not None else None,
                        "max": finite_or_none(d_max) if d_max is not None else None,
                    },
                    "note": "Same entanglement weights/distances, different reachability => causal order underdetermined.",
                }
            },
        }

    def export_json(self, out_path: Optional[str] = None) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)
        payload = self.build_payload()
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2, sort_keys=True)
        return out_path


def main() -> None:
    ap = argparse.ArgumentParser(description="Toy 076: causal structure underdetermined by entanglement pattern (discrete).")
    ap.add_argument("--eps", type=float, default=1e-6, help="Small epsilon in distance proxy d=1/(I+eps).")
    ap.add_argument("--out", type=str, default="", help="Optional output JSON path; default is <script>.json")
    args = ap.parse_args()

    toy = Toy076EntanglementCausalAmbiguity(eps=float(args.eps))
    out_path = args.out.strip() or None
    json_path = toy.export_json(out_path=out_path)

    print(f"Wrote {json_path}")
    print("Toy 076 complete: same entanglement graph admits multiple causal DAGs (non-unique).")


if __name__ == "__main__":
    main()
