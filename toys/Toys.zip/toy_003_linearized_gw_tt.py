#!/usr/bin/env python3
"""
Toy 003 — Linearized gravitational wave (plane wave, TT gauge)

What it probes (weak points / pressure points):
- Gauge vs observables:
  * h_ij^TT (strain) depends on gauge choice, but
  * tidal tensor R_{0i0j} and geodesic deviation are physical.
- "Invariants can miss waves":
  * For plane waves (and their exact pp-wave cousins), many scalar invariants can be zero.
  * Here we export Ricci=0 and Kretschmann=0 at linear order, with notes.
- Causal structure:
  * Background is Minkowski => light cone slopes are ±1 (in c=1 units).

Model:
- Plane GW propagating in +z direction:
    h_plus(t,z)  = A_plus  * cos( omega*(t - z) + phase_plus )
    h_cross(t,z) = A_cross * cos( omega*(t - z) + phase_cross )
- TT gauge metric perturbation (transverse x,y only):
    h_xx =  h_plus
    h_yy = -h_plus
    h_xy =  h_cross = h_yx

Physical tidal tensor (linearized):
    R_{0i0j} = -1/2 * d^2/dt^2 (h_ij^TT)

Geodesic deviation for nearby freely falling particles (in TT gauge, small separations):
    d^2 ξ^i / dt^2 = - R^i_{0j0} ξ^j
For a particle separation initially along x or y, a handy "fractional displacement" proxy is:
    ΔL/L ≈ 1/2 * h_plus  (for x-arm with cross=0, etc.)
We export both strain and tidal acceleration predictions.

STRICT EXPORT RULE:
- Writes JSON named exactly like this .py file (toy_003_linearized_gw_tt.json).
- JSON follows the canonical schema with required keys and required subkeys.
- Undefined quantities are null (JSON null).
"""

from __future__ import annotations

import argparse
import json
import math
import os
from typing import Any, Dict, List, Optional


# ----------------------------
# Helpers
# ----------------------------

def py_to_json_name(py_path: str) -> str:
    base = os.path.splitext(os.path.basename(py_path))[0]
    return base + ".json"


def parse_csv_floats(s: str) -> List[float]:
    return [float(x.strip()) for x in s.split(",") if x.strip()]


def require(cond: bool, msg: str) -> None:
    if not cond:
        raise ValueError(msg)


# ----------------------------
# Toy 003: Linearized GW (TT gauge)
# ----------------------------

class Toy003LinearizedGWTT:
    toy_id = "003"

    def __init__(
        self,
        A_plus: float = 1e-3,
        A_cross: float = 0.0,
        omega: float = 1.0,
        phase_plus: float = 0.0,
        phase_cross: float = 0.0,
    ) -> None:
        require(omega > 0.0, "omega must be > 0.")
        self.A_plus = float(A_plus)
        self.A_cross = float(A_cross)
        self.omega = float(omega)
        self.phase_plus = float(phase_plus)
        self.phase_cross = float(phase_cross)

    # --- Wave phase variable ---
    def u(self, t: float, z: float) -> float:
        # Retarded time u = t - z (c=1)
        return t - z

    # --- Strain ---
    def h_plus(self, t: float, z: float) -> float:
        return self.A_plus * math.cos(self.omega * self.u(t, z) + self.phase_plus)

    def h_cross(self, t: float, z: float) -> float:
        return self.A_cross * math.cos(self.omega * self.u(t, z) + self.phase_cross)

    # --- Second time derivatives (for tidal tensor) ---
    def ddot_h_plus(self, t: float, z: float) -> float:
        # d^2/dt^2 cos(omega*(t-z)+phi) = -omega^2 cos(...)
        return - (self.omega ** 2) * self.h_plus(t, z)

    def ddot_h_cross(self, t: float, z: float) -> float:
        return - (self.omega ** 2) * self.h_cross(t, z)

    # --- Linearized tidal tensor R_{0i0j} in TT gauge ---
    def tidal_R0i0j(self, t: float, z: float) -> Dict[str, float]:
        """
        In TT gauge (linearized):
          R_{0i0j} = -1/2 * d^2/dt^2 (h_ij^TT)
        with nonzero components in x,y plane:
          h_xx =  h_plus
          h_yy = -h_plus
          h_xy =  h_cross
        """
        ddp = self.ddot_h_plus(t, z)
        ddc = self.ddot_h_cross(t, z)

        R_xx = -0.5 * ddp
        R_yy = -0.5 * (-ddp)  # because h_yy = -h_plus
        R_xy = -0.5 * ddc

        return {
            "R0x0x": R_xx,
            "R0y0y": R_yy,
            "R0x0y": R_xy,
            "R0y0x": R_xy,
            "R0z0z": 0.0,
        }

    # --- Simple geodesic deviation predictions for two canonical separations ---
    def relative_acceleration(self, t: float, z: float, xi: List[float]) -> List[float]:
        """
        Compute a^i = - R^i_{0j0} xi^j.
        In this linearized TT setup, raising indices is trivial at this order.
        We use the tidal matrix components in x,y only.
        """
        require(len(xi) == 3, "xi must be a 3-vector [x,y,z].")

        T = self.tidal_R0i0j(t, z)
        # a_x = - (R0x0x xi_x + R0x0y xi_y)
        ax = - (T["R0x0x"] * xi[0] + T["R0x0y"] * xi[1])
        ay = - (T["R0y0x"] * xi[0] + T["R0y0y"] * xi[1])
        az = - (T["R0z0z"] * xi[2])
        return [ax, ay, az]

    # --- "Curvature invariants" ---
    def curvature_invariants_linear_order(self) -> Dict[str, Any]:
        """
        For a plane GW in vacuum at linear order:
          Ricci scalar R = 0.
        Scalar polynomial invariants are subtle: plane waves often have vanishing invariants.
        We export Kretschmann=0 at linear order and document the limitation in notes.
        """
        return {
            "ricci_scalar": 0.0,
            "kretschmann": 0.0,
        }

    # --- Causal structure (background Minkowski) ---
    def causal_structure_minkowski(self) -> Dict[str, Any]:
        return {
            "radial_null_cone_dr_dt": {"outgoing": 1.0, "ingoing": -1.0},
            "horizon_radius": None,
            "region": "Minkowski background (linearized GW); no horizons",
        }

    # --- Canonical export payload ---
    def build_payload(
        self,
        t_values: List[float],
        z: float,
        separation_L: float,
    ) -> Dict[str, Any]:

        sample_points: List[Dict[str, Any]] = []
        for t in t_values:
            t = float(t)

            hp = self.h_plus(t, z)
            hc = self.h_cross(t, z)
            tidal = self.tidal_R0i0j(t, z)

            # Two canonical separation vectors: along x and along y with magnitude L
            xi_x = [separation_L, 0.0, 0.0]
            xi_y = [0.0, separation_L, 0.0]
            a_x = self.relative_acceleration(t, z, xi_x)
            a_y = self.relative_acceleration(t, z, xi_y)

            # Simple fractional length-change proxies (small strain, TT gauge):
            # For an x-arm and y-arm:
            #   ΔLx/L ≈ +0.5 h_plus (if cross=0; with cross, orientation matters)
            #   ΔLy/L ≈ -0.5 h_plus
            # We export these labeled as TT-frame proxies.
            frac = {
                "deltaL_over_L_x_arm_TT_proxy": 0.5 * hp,
                "deltaL_over_L_y_arm_TT_proxy": -0.5 * hp,
                "note": "These are TT-frame small-strain proxies; general orientation requires rotation.",
            }

            coordinates = {"t": t, "x": None, "y": None, "z": z}

            curvature_invariants = self.curvature_invariants_linear_order()

            local_observables = {
                "strain_TT": {
                    "h_plus": hp,
                    "h_cross": hc,
                    "h_xx": hp,
                    "h_yy": -hp,
                    "h_xy": hc,
                },
                "tidal_tensor_R0i0j": tidal,
                "geodesic_deviation": {
                    "separation_L": separation_L,
                    "xi_x": xi_x,
                    "relative_acceleration_for_x_separation": a_x,
                    "xi_y": xi_y,
                    "relative_acceleration_for_y_separation": a_y,
                    "fractional_length_change_proxies": frac,
                },
            }

            causal_structure = self.causal_structure_minkowski()

            sample_points.append({
                "coordinates": coordinates,
                "curvature_invariants": curvature_invariants,
                "local_observables": local_observables,
                "causal_structure": causal_structure,
            })

        # “Observables” section: summarize a few derived amplitudes
        # Peak tidal scale ~ (omega^2 * A)/2
        peak_tidal_plus = 0.5 * (self.omega ** 2) * abs(self.A_plus)
        peak_tidal_cross = 0.5 * (self.omega ** 2) * abs(self.A_cross)

        observables = {
            "gw_parameters": {
                "propagation_direction": "+z",
                "omega": self.omega,
                "A_plus": self.A_plus,
                "A_cross": self.A_cross,
                "phase_plus": self.phase_plus,
                "phase_cross": self.phase_cross,
            },
            "peak_scales": {
                "approx_peak_strain_plus": abs(self.A_plus),
                "approx_peak_strain_cross": abs(self.A_cross),
                "approx_peak_tidal_component_scale_plus": peak_tidal_plus,
                "approx_peak_tidal_component_scale_cross": peak_tidal_cross,
                "note": "Tidal scale uses R0i0j amplitude ≈ (omega^2 * A)/2.",
            },
        }

        payload: Dict[str, Any] = {
            "toy_id": self.toy_id,
            "theory": "General Relativity (linearized)",
            "spacetime": "Minkowski + TT-gauge plane gravitational wave",
            "units": {"G": 1, "c": 1},
            "parameters": {
                "A_plus": self.A_plus,
                "A_cross": self.A_cross,
                "omega": self.omega,
                "phase_plus": self.phase_plus,
                "phase_cross": self.phase_cross,
                "z_sample_plane": z,
                "separation_L": separation_L,
            },
            "notes": {
                "assumptions": [
                    "Linearized gravity around Minkowski",
                    "Plane GW propagating in +z",
                    "TT gauge",
                    "Valid for |h| << 1",
                ],
                "invariants_warning": (
                    "For plane GWs, many scalar curvature invariants can vanish; "
                    "here Ricci=0 and Kretschmann=0 are exported at linear order. "
                    "Physical effect is captured by R0i0j and geodesic deviation."
                ),
                "what_to_compare": [
                    "Compare tidal eigen-structure vs Toy 001 (Schwarzschild) in weak field",
                    "Compare 'invariant silence' vs nonzero tidal response",
                    "Probe gauge dependence by later toys using different gauges (future Toy)",
                ],
            },
            "sample_points": sample_points,
            "observables": observables,
        }

        return payload

    def export_json(
        self,
        t_values: List[float],
        z: float,
        separation_L: float,
        out_path: Optional[str] = None,
    ) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)

        payload = self.build_payload(t_values=t_values, z=z, separation_L=separation_L)
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2, sort_keys=True)
        return out_path


# ----------------------------
# CLI
# ----------------------------

def main() -> None:
    ap = argparse.ArgumentParser(description="Toy 003: Linearized GW (TT gauge) exporter (GR).")
    ap.add_argument("--A_plus", type=float, default=1e-3, help="Plus polarization amplitude")
    ap.add_argument("--A_cross", type=float, default=0.0, help="Cross polarization amplitude")
    ap.add_argument("--omega", type=float, default=1.0, help="Angular frequency omega")
    ap.add_argument("--phase_plus", type=float, default=0.0, help="Phase for plus polarization")
    ap.add_argument("--phase_cross", type=float, default=0.0, help="Phase for cross polarization")
    ap.add_argument("--z", type=float, default=0.0, help="Sample plane z (wave travels in +z)")
    ap.add_argument("--t", type=str, default="0,0.5,1,1.5,2,2.5,3",
                    help="Comma-separated times to sample")
    ap.add_argument("--L", type=float, default=1.0, help="Separation length L for geodesic deviation samples")
    ap.add_argument("--out", type=str, default="",
                    help="Optional output path. If omitted, uses <this_script_name>.json")
    args = ap.parse_args()

    t_values = parse_csv_floats(args.t)

    toy = Toy003LinearizedGWTT(
        A_plus=args.A_plus,
        A_cross=args.A_cross,
        omega=args.omega,
        phase_plus=args.phase_plus,
        phase_cross=args.phase_cross,
    )

    out_path = args.out.strip() or None
    json_path = toy.export_json(t_values=t_values, z=float(args.z), separation_L=float(args.L), out_path=out_path)

    print(f"Wrote {json_path}")
    print("Note: Ricci and Kretschmann are exported as 0 at linear order; physical effect appears in R0i0j and deviation.")


if __name__ == "__main__":
    main()
