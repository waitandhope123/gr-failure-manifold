#!/usr/bin/env python3
"""
Toy 004 — FLRW Cosmology (flat k=0) with analytic scale factors

What it probes (weak points / pressure points):
- Global structure & horizons (particle horizon, event horizon in de Sitter)
- Redshift as geometry (1+z = a(t_obs)/a(t_emit))
- Curvature invariants in cosmology (R, Kretschmann K) without localized sources
- Domain-of-validity & singularities (Big Bang in radiation/matter models)

Models (choose with --model):
- radiation: a(t) = (t/t0)^(1/2)
- matter:    a(t) = (t/t0)^(2/3)
- desitter:  a(t) = exp(H0*(t - t0)) with a(t0)=1

Units:
- Geometric units: G=c=1. Time and distance are in the same units.
- This is a toy: it is not calibrated to real cosmological parameters unless you choose them.

STRICT EXPORT RULE:
- Writes JSON named exactly like this .py file (toy_004_flrw_flat.json).
- JSON follows the canonical schema with required keys and required subkeys.
- Undefined quantities are exported as null (JSON null).
"""

from __future__ import annotations

import argparse
import json
import math
import os
from typing import Any, Dict, List, Optional, Tuple


# ----------------------------
# Helpers
# ----------------------------

def py_to_json_name(py_path: str) -> str:
    base = os.path.splitext(os.path.basename(py_path))[0]
    return base + ".json"


def parse_csv_floats(s: str) -> List[float]:
    return [float(x.strip()) for x in s.split(",") if x.strip()]


def require(cond: bool, msg: str) -> None:
    if not cond:
        raise ValueError(msg)


def trapz(y: List[float], x: List[float]) -> float:
    require(len(y) == len(x) and len(y) >= 2, "trapz needs same-length arrays with >=2 points.")
    acc = 0.0
    for i in range(len(y) - 1):
        acc += 0.5 * (y[i] + y[i + 1]) * (x[i + 1] - x[i])
    return acc


def integrate_trapz(f, a: float, b: float, n: int = 2000) -> float:
    require(n >= 2, "n must be >=2")
    require(b >= a, "integration requires b >= a")
    if b == a:
        return 0.0
    xs = [a + (b - a) * i / (n - 1) for i in range(n)]
    ys = [f(x) for x in xs]
    return trapz(ys, xs)


# ----------------------------
# Toy 004: FLRW (k=0)
# ----------------------------

class Toy004FLRWFlat:
    toy_id = "004"

    def __init__(self, model: str = "matter", t0: float = 1.0, H0: float = 1.0) -> None:
        model = model.strip().lower()
        require(model in {"radiation", "matter", "desitter"}, "model must be radiation, matter, or desitter.")
        require(t0 > 0.0, "t0 must be > 0 (used for normalization and avoiding t=0 in power-laws).")
        require(H0 > 0.0, "H0 must be > 0 (used for de Sitter).")
        self.model = model
        self.t0 = float(t0)
        self.H0 = float(H0)

    # --- Scale factor and derivatives (analytic) ---

    def a(self, t: float) -> float:
        require(t > 0.0, "t must be > 0.")
        if self.model == "radiation":
            return (t / self.t0) ** 0.5
        if self.model == "matter":
            return (t / self.t0) ** (2.0 / 3.0)
        # de Sitter with a(t0)=1
        return math.exp(self.H0 * (t - self.t0))

    def adot(self, t: float) -> float:
        require(t > 0.0, "t must be > 0.")
        if self.model == "radiation":
            # a = (t/t0)^(1/2) -> adot = (1/2) t^{-1/2} t0^{-1/2}
            return 0.5 * (t / self.t0) ** (-0.5) * (1.0 / self.t0)
        if self.model == "matter":
            # a = (t/t0)^(2/3) -> adot = (2/3) t^{-1/3} t0^{-2/3}
            return (2.0 / 3.0) * (t / self.t0) ** (-1.0 / 3.0) * (1.0 / self.t0)
        # de Sitter
        return self.H0 * self.a(t)

    def addot(self, t: float) -> float:
        require(t > 0.0, "t must be > 0.")
        if self.model == "radiation":
            # adot = 0.5 * t^{-1/2} * t0^{-1/2}
            # addot = -0.25 * t^{-3/2} * t0^{-1/2}
            return -0.25 * (t / self.t0) ** (-1.5) * (1.0 / (self.t0 ** 2))
        if self.model == "matter":
            # adot = (2/3) * t^{-1/3} * t0^{-2/3}
            # addot = -(2/9) * t^{-4/3} * t0^{-2/3}
            return -(2.0 / 9.0) * (t / self.t0) ** (-4.0 / 3.0) * (1.0 / (self.t0 ** 2))
        # de Sitter
        return (self.H0 ** 2) * self.a(t)

    def H(self, t: float) -> float:
        return self.adot(t) / self.a(t)

    def Hdot(self, t: float) -> float:
        # Hdot = (ä/a) - (ȧ/a)^2
        a = self.a(t)
        return (self.addot(t) / a) - (self.adot(t) / a) ** 2

    def q(self, t: float) -> float:
        # deceleration parameter q = - (a ä) / ȧ^2
        ad = self.adot(t)
        require(ad != 0.0, "adot is zero; q undefined.")
        return - (self.a(t) * self.addot(t)) / (ad ** 2)

    # --- Curvature invariants (k=0) ---

    def ricci_scalar(self, t: float) -> float:
        # For flat FLRW: R = 6( Hdot + 2H^2 )
        H = self.H(t)
        Hd = self.Hdot(t)
        return 6.0 * (Hd + 2.0 * H * H)

    def kretschmann(self, t: float) -> float:
        # For flat FLRW: K = 12 * [ (ä/a)^2 + (ȧ/a)^4 ]
        a = self.a(t)
        term1 = (self.addot(t) / a) ** 2
        term2 = (self.adot(t) / a) ** 4
        return 12.0 * (term1 + term2)

    # --- Horizon diagnostics (flat) ---

    def conformal_time(self, t_min: float, t: float, n: int = 4000) -> float:
        """
        η(t) = ∫_{t_min}^{t} dt'/a(t')
        For radiation/matter, t_min must be >0 to avoid the Big Bang singularity.
        """
        require(t > t_min > 0.0, "Need t > t_min > 0.")
        return integrate_trapz(lambda tp: 1.0 / self.a(tp), t_min, t, n=n)

    def event_horizon_comoving(self, t: float, t_max: float, n: int = 4000) -> Optional[float]:
        """
        χ_event(t) = ∫_{t}^{∞} dt'/a(t')
        We approximate with finite t_max. Converges nicely for de Sitter.
        For matter/radiation this diverges (no event horizon), so we return null.
        """
        require(t_max > t > 0.0, "Need t_max > t > 0.")
        if self.model != "desitter":
            return None
        return integrate_trapz(lambda tp: 1.0 / self.a(tp), t, t_max, n=n)

    # --- Observables in flat FLRW ---

    def redshift(self, t_emit: float, t_obs: float) -> float:
        require(t_emit > 0.0 and t_obs > 0.0, "times must be > 0.")
        require(t_obs >= t_emit, "need t_obs >= t_emit.")
        return self.a(t_obs) / self.a(t_emit) - 1.0

    def comoving_distance(self, t_emit: float, t_obs: float, n: int = 4000) -> float:
        # χ = ∫_{t_emit}^{t_obs} dt/a(t)
        require(t_obs >= t_emit > 0.0, "need t_obs >= t_emit > 0.")
        return integrate_trapz(lambda tp: 1.0 / self.a(tp), t_emit, t_obs, n=n)

    def luminosity_distance(self, t_emit: float, t_obs: float, n: int = 4000) -> float:
        # flat: d_L = (1+z) * χ
        z = self.redshift(t_emit, t_obs)
        chi = self.comoving_distance(t_emit, t_obs, n=n)
        return (1.0 + z) * chi

    # --- Canonical export payload ---

    def build_payload(
        self,
        t_values: List[float],
        t_min_horizon: float,
        t_obs: float,
        emit_times: List[float],
        t_max_event: float,
    ) -> Dict[str, Any]:

        # Sample points
        sample_points: List[Dict[str, Any]] = []
        for t in t_values:
            t = float(t)
            require(t > 0.0, "All sample times must be > 0.")

            a_t = self.a(t)
            H_t = self.H(t)
            Hd_t = self.Hdot(t)

            # Particle horizon (comoving) via conformal time from t_min_horizon
            particle_horizon = None
            if t > t_min_horizon > 0.0:
                particle_horizon = self.conformal_time(t_min_horizon, t)

            # Event horizon (comoving) only for de Sitter (else None)
            event_h = None
            if t_max_event > t > 0.0:
                event_h = self.event_horizon_comoving(t, t_max_event)

            coordinates = {"t": t, "x": None, "y": None, "z": None}

            curvature_invariants = {
                "ricci_scalar": self.ricci_scalar(t),
                "kretschmann": self.kretschmann(t),
            }

            local_observables: Dict[str, Any] = {
                "scale_factor_a": a_t,
                "hubble_H": H_t,
                "hubble_Hdot": Hd_t,
                "deceleration_q": self.q(t),
                "hubble_radius": (1.0 / H_t) if H_t != 0.0 else None,
            }

            causal_structure: Dict[str, Any] = {
                "radial_null_cone_dr_dt": {"outgoing": 1.0, "ingoing": -1.0},  # local light speed c=1
                "horizon_radius": None,  # not a Schwarzschild horizon; horizons are global here
                "region": "flat FLRW (k=0)",
                "particle_horizon_comoving_chi": particle_horizon,
                "event_horizon_comoving_chi_approx": event_h,
                "horizon_notes": {
                    "particle_horizon_integral": f"chi_p(t)=∫_{{t_min}}^t dt'/a(t'), with t_min={t_min_horizon}",
                    "event_horizon_integral": (
                        "chi_e(t)=∫_t^∞ dt'/a(t'); approximated with t_max"
                        if self.model == "desitter" else
                        "diverges for matter/radiation in this toy (no event horizon) => null"
                    ),
                    "t_max_used_for_event_horizon": t_max_event if self.model == "desitter" else None,
                },
            }

            sample_points.append({
                "coordinates": coordinates,
                "curvature_invariants": curvature_invariants,
                "local_observables": local_observables,
                "causal_structure": causal_structure,
            })

        # Observables: redshift + distances from emit_times to t_obs
        obs_list: List[Dict[str, Any]] = []
        for te in emit_times:
            te = float(te)
            entry: Dict[str, Any] = {
                "t_emit": te,
                "t_obs": t_obs,
                "z": None,
                "comoving_distance_chi": None,
                "luminosity_distance_dL": None,
                "valid": None,
            }
            if 0.0 < te <= t_obs:
                entry["z"] = self.redshift(te, t_obs)
                entry["comoving_distance_chi"] = self.comoving_distance(te, t_obs)
                entry["luminosity_distance_dL"] = self.luminosity_distance(te, t_obs)
                entry["valid"] = True
            else:
                entry["valid"] = False
            obs_list.append(entry)

        payload: Dict[str, Any] = {
            "toy_id": self.toy_id,
            "theory": "General Relativity (exact symmetry-reduced cosmology)",
            "spacetime": "Flat FLRW (k=0) with analytic a(t)",
            "units": {"G": 1, "c": 1},
            "parameters": {
                "model": self.model,
                "t0": self.t0,
                "H0": self.H0 if self.model == "desitter" else None,
                "t_min_horizon": t_min_horizon,
                "t_obs": t_obs,
                "t_max_event": t_max_event if self.model == "desitter" else None,
            },
            "notes": {
                "assumptions": [
                    "Homogeneous, isotropic (FLRW)",
                    "Spatial curvature k=0 (flat)",
                    "Analytic scale factor chosen by model",
                    "Geometric units G=c=1",
                ],
                "model_definitions": {
                    "radiation": "a(t)=(t/t0)^(1/2)",
                    "matter": "a(t)=(t/t0)^(2/3)",
                    "desitter": "a(t)=exp(H0*(t-t0)) with a(t0)=1",
                },
                "singularity_notes": (
                    "radiation/matter models have a(t)->0 as t->0 (Big Bang). "
                    "This toy avoids t=0 by using t_min_horizon > 0 for horizon integrals."
                ),
                "invariants_formulas_k0": {
                    "R": "R = 6( Hdot + 2 H^2 )",
                    "K": "K = 12[ (ä/a)^2 + (ȧ/a)^4 ]",
                },
            },
            "sample_points": sample_points,
            "observables": {
                "redshift_and_distances": obs_list
            },
        }

        return payload

    def export_json(
        self,
        t_values: List[float],
        t_min_horizon: float,
        t_obs: float,
        emit_times: List[float],
        t_max_event: float,
        out_path: Optional[str] = None,
    ) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)

        payload = self.build_payload(
            t_values=t_values,
            t_min_horizon=t_min_horizon,
            t_obs=t_obs,
            emit_times=emit_times,
            t_max_event=t_max_event,
        )
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2, sort_keys=True)
        return out_path


# ----------------------------
# CLI
# ----------------------------

def main() -> None:
    ap = argparse.ArgumentParser(description="Toy 004: Flat FLRW exporter (GR).")
    ap.add_argument("--model", type=str, default="matter", help="radiation | matter | desitter")
    ap.add_argument("--t0", type=float, default=1.0, help="Normalization time t0 (>0)")
    ap.add_argument("--H0", type=float, default=1.0, help="de Sitter H0 (>0), only used if model=desitter")
    ap.add_argument("--t", type=str, default="0.5,1,2,3,5,10", help="Comma-separated sample times (>0)")
    ap.add_argument("--t_min_horizon", type=float, default=0.01,
                    help="Lower cutoff (>0) for particle horizon integral (avoids t=0 singularity)")
    ap.add_argument("--t_obs", type=float, default=10.0, help="Observation time for redshift/distances")
    ap.add_argument("--emit_times", type=str, default="0.5,1,2,3,5",
                    help="Comma-separated emission times for observables")
    ap.add_argument("--t_max_event", type=float, default=200.0,
                    help="Upper cutoff for event horizon integral (used if model=desitter)")
    ap.add_argument("--out", type=str, default="",
                    help="Optional output path. If omitted, uses <this_script_name>.json")
    args = ap.parse_args()

    t_values = parse_csv_floats(args.t)
    emit_times = parse_csv_floats(args.emit_times)

    toy = Toy004FLRWFlat(model=args.model, t0=args.t0, H0=args.H0)

    out_path = args.out.strip() or None
    json_path = toy.export_json(
        t_values=t_values,
        t_min_horizon=float(args.t_min_horizon),
        t_obs=float(args.t_obs),
        emit_times=emit_times,
        t_max_event=float(args.t_max_event),
        out_path=out_path,
    )

    print(f"Wrote {json_path}")
    print("Notes:")
    print("- radiation/matter have Big Bang at t->0; use t_min_horizon>0 to avoid divergence in integrals.")
    if args.model.strip().lower() == "desitter":
        print("- event horizon integral is approximated with t_max_event; increase it to check convergence.")


if __name__ == "__main__":
    main()
