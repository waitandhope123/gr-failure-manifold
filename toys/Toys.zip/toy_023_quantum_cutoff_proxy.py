#!/usr/bin/env python3
"""
Toy 023 — Classical curvature vs quantum length cutoff (Planck proxy)

Model (G=c=1):
Schwarzschild spacetime.
Compare classical curvature scale to an imposed minimum length ℓ_min.

Curvature length scale:
  L_curv ~ K^{-1/4},  where K = Kretschmann scalar

Diagnostic:
- If L_curv < ℓ_min, classical GR is flagged as unreliable.
"""

from __future__ import annotations

import argparse
import json
import math
import os
from typing import Any, Dict, List, Optional


# ----------------------------
# Helpers
# ----------------------------

def py_to_json_name(py_path: str) -> str:
    base = os.path.splitext(os.path.basename(py_path))[0]
    return base + ".json"


def parse_csv_floats(s: str) -> List[float]:
    return [float(x.strip()) for x in s.split(",") if x.strip()]


def require(cond: bool, msg: str) -> None:
    if not cond:
        raise ValueError(msg)


# ----------------------------
# Toy 023
# ----------------------------

class Toy023QuantumCutoffProxy:
    toy_id = "023"

    def __init__(self, M: float = 1.0, l_min: float = 1.0) -> None:
        require(M > 0.0, "M must be > 0.")
        require(l_min > 0.0, "l_min must be > 0.")
        self.M = float(M)
        self.l_min = float(l_min)

    def horizon(self) -> float:
        return 2.0 * self.M

    def ricci_scalar(self, r: float) -> float:
        return 0.0

    def kretschmann(self, r: float) -> float:
        return 48.0 * (self.M ** 2) / (r ** 6)

    def curvature_length(self, r: float) -> float:
        K = self.kretschmann(r)
        return K ** (-0.25)

    def build_payload(self, r_values: List[float]) -> Dict[str, Any]:
        sample_points: List[Dict[str, Any]] = []
        rh = self.horizon()

        for r in r_values:
            require(r > 0.0, "All radii must be > 0.")
            r = float(r)

            K = self.kretschmann(r)
            Lc = self.curvature_length(r)

            sample_points.append({
                "coordinates": {"t": None, "r": r, "theta": None, "phi": None},
                "curvature_invariants": {
                    "ricci_scalar": self.ricci_scalar(r),
                    "kretschmann": K,
                },
                "local_observables": {
                    "curvature_length_scale": Lc,
                    "minimum_length_cutoff": self.l_min,
                    "classical_gr_valid": Lc > self.l_min,
                },
                "causal_structure": {
                    "horizon_radius": rh,
                    "region": (
                        "exterior (r>2M)" if r > rh else
                        ("horizon (r=2M)" if abs(r - rh) < 1e-12 else
                         "interior (r<2M)")
                    ),
                },
            })

        payload: Dict[str, Any] = {
            "toy_id": self.toy_id,
            "theory": "General Relativity with quantum-length proxy",
            "spacetime": "Schwarzschild (classical vs cutoff comparison)",
            "units": {"G": 1, "c": 1},
            "parameters": {
                "M": self.M,
                "l_min": self.l_min,
            },
            "notes": {
                "pressure_point": (
                    "GR contains no intrinsic length cutoff. "
                    "Comparing curvature scales to a minimum length "
                    "shows where classical predictivity is expected to fail."
                )
            },
            "sample_points": sample_points,
            "observables": {
                "horizon_radius": rh,
            },
        }

        return payload

    def export_json(self, r_values: List[float], out_path: Optional[str] = None) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)
        payload = self.build_payload(r_values)
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2, sort_keys=True)
        return out_path


# ----------------------------
# CLI
# ----------------------------

def main() -> None:
    ap = argparse.ArgumentParser(description="Toy 023: curvature vs quantum cutoff proxy.")
    ap.add_argument("--M", type=float, default=1.0, help="Black hole mass M")
    ap.add_argument("--l_min", type=float, default=1.0, help="Minimum length cutoff")
    ap.add_argument("--r", type=str, default="10,6,4,3,2.5,2,1.5,1",
                    help="Comma-separated radii")
    ap.add_argument("--out", type=str, default="",
                    help="Optional output path")
    args = ap.parse_args()

    toy = Toy023QuantumCutoffProxy(M=args.M, l_min=args.l_min)
    r_values = parse_csv_floats(args.r)

    out_path = args.out.strip() or None
    json_path = toy.export_json(r_values, out_path)

    print(f"Wrote {json_path}")


if __name__ == "__main__":
    main()
