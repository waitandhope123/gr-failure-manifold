#!/usr/bin/env python3
"""
Toy 046 — Gravitational energy definition comparator (ADM / Komar / quasi-local)

What it probes (weak points / pressure points):
- "Energy of gravity" is not uniquely defined in GR.
- Even in simple spacetimes, different well-motivated mass/energy notions can:
  * coincide in special limits (e.g., asymptotic infinity),
  * differ quasi-locally (finite radius),
  * depend on symmetry/assumptions.

Spacetime:
- Schwarzschild vacuum, geometric units G=c=1.

Mass definitions included (all standard):
1) ADM mass (asymptotically flat): M_ADM = M  (global)
2) Komar mass (stationary with timelike Killing, vacuum): M_Komar = M  (global)
3) Misner–Sharp mass (spherically symmetric, quasi-local): M_MS(r) = M (for Schwarzschild)
4) Brown–York quasilocal energy for a 2-sphere of areal radius r (in time-symmetric slicing):
     E_BY(r) = r * (1 - sqrt(1 - 2M/r))   for r > 2M
   This differs from M at finite r, but tends to M as r -> infinity.
   Undefined for r <= 2M in this simple static-slice expression.

Exports:
- For each radius r: masses/energies (with null where undefined), plus deltas from M.
- Summary: convergence of E_BY -> M at large r and divergence/undefined at/inside horizon.

Note:
- This toy is not about "which is correct". It quantifies ambiguity numerically.
"""

from __future__ import annotations

import argparse
import json
import math
import os
from typing import Any, Dict, List, Optional


# ----------------------------
# Helpers
# ----------------------------

def py_to_json_name(py_path: str) -> str:
    base = os.path.splitext(os.path.basename(py_path))[0]
    return base + ".json"


def require(cond: bool, msg: str) -> None:
    if not cond:
        raise ValueError(msg)


def parse_csv_floats(s: str) -> List[float]:
    return [float(x.strip()) for x in s.split(",") if x.strip()]


def finite_or_none(x: float) -> Optional[float]:
    return x if math.isfinite(x) else None


# ----------------------------
# Toy 046
# ----------------------------

class Toy046EnergyComparator:
    toy_id = "046"

    def __init__(self, M: float = 1.0) -> None:
        require(M > 0.0, "M must be > 0.")
        self.M = float(M)

    def horizon_radius(self) -> float:
        return 2.0 * self.M

    def f(self, r: float) -> float:
        require(r > 0.0, "r must be > 0.")
        return 1.0 - 2.0 * self.M / r

    # Global masses (for Schwarzschild vacuum)
    def adm_mass(self) -> float:
        return self.M

    def komar_mass(self) -> float:
        return self.M

    def misner_sharp_mass(self, r: float) -> float:
        # In Schwarzschild: M_MS(r) = M for all r>0 (areal radius).
        require(r > 0.0, "r must be > 0.")
        return self.M

    def brown_york_energy(self, r: float) -> Optional[float]:
        """
        Brown–York quasilocal energy on a 2-sphere of areal radius r for the
        usual time-symmetric (static) reference choice:
            E_BY(r) = r (1 - sqrt(1 - 2M/r))
        Defined only for r > 2M in this simple real-valued form.
        """
        require(r > 0.0, "r must be > 0.")
        if r <= self.horizon_radius():
            return None
        val = r * (1.0 - math.sqrt(self.f(r)))
        return finite_or_none(val)

    def evaluate_at_r(self, r: float) -> Dict[str, Any]:
        require(r > 0.0, "r must be > 0.")
        rh = self.horizon_radius()

        adm = self.adm_mass()
        komar = self.komar_mass()
        ms = self.misner_sharp_mass(r)
        eby = self.brown_york_energy(r)

        # deltas relative to parameter M
        def d(x: Optional[float]) -> Optional[float]:
            return None if x is None else (x - self.M)

        return {
            "coordinates": {"r": r},
            "curvature_invariants": {
                # Not the focus here; keep schema slot, leave empty dict for invariants.
                # (Could add Kretschmann, but this toy is about energy ambiguity.)
            },
            "local_observables": {
                "mass_definitions": {
                    "M_parameter": self.M,
                    "ADM_mass": adm,
                    "Komar_mass": komar,
                    "Misner_Sharp_mass": ms,
                    "Brown_York_energy": eby,
                },
                "deltas_from_M": {
                    "ADM_minus_M": d(adm),
                    "Komar_minus_M": d(komar),
                    "Misner_Sharp_minus_M": d(ms),
                    "Brown_York_minus_M": d(eby),
                },
            },
            "causal_structure": {
                "horizon_radius_2M": rh,
                "inside_horizon": (r < rh),
                "at_or_outside_horizon": (r >= rh),
                "brown_york_defined": (eby is not None),
            },
        }

    def build_payload(self, r_values: List[float]) -> Dict[str, Any]:
        rh = self.horizon_radius()
        sample_points = [self.evaluate_at_r(r) for r in r_values]

        # Track convergence of Brown–York energy to M at largest r where defined
        eby_defined = [
            sp["local_observables"]["mass_definitions"]["Brown_York_energy"]
            for sp in sample_points
            if sp["local_observables"]["mass_definitions"]["Brown_York_energy"] is not None
        ]
        eby_last = eby_defined[-1] if eby_defined else None
        eby_last_err = None if eby_last is None else abs(eby_last - self.M)

        return {
            "toy_id": self.toy_id,
            "theory": "General Relativity",
            "spacetime": "Schwarzschild (energy definition comparator)",
            "units": {"G": 1, "c": 1},
            "parameters": {
                "M": self.M,
                "r_samples": r_values,
            },
            "notes": {
                "assumptions": [
                    "Vacuum Schwarzschild, asymptotically flat, stationary",
                    "Areal radius r used for quasi-local spheres",
                    "Brown–York energy computed with standard static/time-symmetric reference; real-valued only for r>2M",
                ],
                "pressure_point": (
                    "Multiple well-defined mass/energy notions can coincide globally yet disagree quasi-locally. "
                    "GR does not provide a unique local gravitational energy density."
                ),
                "key_formulas": {
                    "ADM": "M_ADM = M (Schwarzschild)",
                    "Komar": "M_Komar = M (stationary vacuum)",
                    "Misner_Sharp": "M_MS(r) = M (Schwarzschild)",
                    "Brown_York": "E_BY(r)= r(1 - sqrt(1-2M/r)), defined for r>2M",
                },
            },
            "sample_points": sample_points,
            "observables": {
                "summary": {
                    "horizon_radius_2M": rh,
                    "adm_mass": self.adm_mass(),
                    "komar_mass": self.komar_mass(),
                    "brown_york_last_defined": eby_last,
                    "brown_york_abs_error_last_defined": eby_last_err,
                    "note": "E_BY approaches M as r→∞ but differs at finite r; undefined (in this form) for r<=2M.",
                }
            },
        }

    def export_json(self, r_values: List[float], out_path: Optional[str] = None) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)
        payload = self.build_payload(r_values=r_values)
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2, sort_keys=True)
        return out_path


# ----------------------------
# CLI
# ----------------------------

def main() -> None:
    ap = argparse.ArgumentParser(description="Toy 046: Compare GR energy/mass definitions (ADM/Komar/MS/Brown–York).")
    ap.add_argument("--M", type=float, default=1.0, help="Mass parameter M (geometric units)")
    ap.add_argument(
        "--r",
        type=str,
        default="2.0001,2.01,2.1,3,4,6,10,20,50,100",
        help="Comma-separated areal radii r>0 (include near and above 2M; Brown–York undefined at r<=2M)",
    )
    ap.add_argument("--out", type=str, default="", help="Optional output path. If omitted, uses <this_script_name>.json")
    args = ap.parse_args()

    r_values = parse_csv_floats(args.r)
    toy = Toy046EnergyComparator(M=float(args.M))

    out_path = args.out.strip() or None
    json_path = toy.export_json(r_values=r_values, out_path=out_path)

    print(f"Wrote {json_path}")
    print(f"Note: horizon at r=2M={toy.horizon_radius():g}. Brown–York (this form) defined only for r>2M.")


if __name__ == "__main__":
    main()
