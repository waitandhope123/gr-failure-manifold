#!/usr/bin/env python3
"""
Toy 077 — Light cone superposition (Minkowski): source in spatial superposition => ambiguous causal future

Classification (lab axes):
- Failure Trigger: causal + state
- Failure Mode: predictability_loss (causal uncertainty / non-unique future light cone)
- Failure Sharpness: sharp
- Repairable Within Classical GR: no

What it probes (pressure point):
- In classical GR, a localized event (source emission) determines a definite future light cone.
- If a source is in a quantum superposition of two spatial locations at the same coordinate time,
  there is no unique classical light cone apex, so the set of classically predictable future events
  is not uniquely defined without specifying a measurement/reduction rule.

Model (controlled approximation; c=1):
- Flat 1+1 Minkowski spacetime.
- Two possible emission events at t=0:
    A: (t=0, x=x_A)
    B: (t=0, x=x_B)
- For a classical emission at x0, the future light cone at time t>0 is the interval:
    x ∈ [x0 - t, x0 + t]

Quantum superposition:
- |ψ> = (|A> + e^{iφ}|B>)/√2

Operational ambiguity diagnostics:
- Branch future intervals are well-defined: I_A(t), I_B(t).
- "Union future" interval(s) depends on whether you take a union (both possible) or
  a single-apex cone (not definable). The union can be disconnected for small t when
  |x_A - x_B| > 2t.
- We export:
  * branch intervals,
  * union interval coverage length,
  * intersection (overlap) length,
  * disconnectedness flag,
  * and an explicit non-uniqueness status.

Observed Results (what breaks and why it matters):
- The geometry is perfectly regular, but causal prediction from a "source" becomes ambiguous
  when the source is not classically localized.
- This makes the classical notion of a unique light cone (and unique causal future) fail under
  quantum superposition of emission events.

Export:
- Strict JSON schema per lab protocol; writes <script_name>.json.
- Undefined quantities exported as null; keys never omitted.
"""

from __future__ import annotations

import argparse
import json
import math
import os
from typing import Any, Dict, List, Optional


# ----------------------------
# Helpers
# ----------------------------

def py_to_json_name(py_path: str) -> str:
    base = os.path.splitext(os.path.basename(py_path))[0]
    return base + ".json"


def require(cond: bool, msg: str) -> None:
    if not cond:
        raise ValueError(msg)


def parse_csv_floats(s: str) -> List[float]:
    return [float(x.strip()) for x in s.split(",") if x.strip()]


def finite_or_none(x: float) -> Optional[float]:
    return x if (isinstance(x, (int, float)) and math.isfinite(x)) else None


def interval(a: float, b: float) -> Dict[str, float]:
    lo = min(a, b)
    hi = max(a, b)
    return {"x_min": lo, "x_max": hi, "length": hi - lo}


def overlap_length(i1: Dict[str, float], i2: Dict[str, float]) -> float:
    lo = max(i1["x_min"], i2["x_min"])
    hi = min(i1["x_max"], i2["x_max"])
    return max(0.0, hi - lo)


def union_length(i1: Dict[str, float], i2: Dict[str, float]) -> float:
    # total length of union of two intervals (can be disconnected)
    ov = overlap_length(i1, i2)
    return i1["length"] + i2["length"] - ov


def is_disconnected(i1: Dict[str, float], i2: Dict[str, float]) -> bool:
    # disconnected if i1 max < i2 min or vice versa
    return (i1["x_max"] < i2["x_min"]) or (i2["x_max"] < i1["x_min"])


# ----------------------------
# Toy 077
# ----------------------------

class Toy077LightConeSuperposition:
    toy_id = "077"

    def __init__(self, *, x_A: float, x_B: float) -> None:
        self.x_A = float(x_A)
        self.x_B = float(x_B)

    def minkowski_invariants(self) -> Dict[str, Optional[float]]:
        # Flat spacetime: R=0, K=0
        return {"ricci_scalar": 0.0, "kretschmann": 0.0}

    def future_interval(self, x0: float, t: float) -> Optional[Dict[str, float]]:
        if t < 0.0:
            return None
        return interval(x0 - t, x0 + t)

    def sample_point(self, *, t: float) -> Dict[str, Any]:
        require(t > 0.0, "t must be > 0 for future light cone slices.")

        IA = self.future_interval(self.x_A, t)
        IB = self.future_interval(self.x_B, t)
        inv = self.minkowski_invariants()

        ov = None
        un = None
        disc = None
        if IA is not None and IB is not None:
            ov = overlap_length(IA, IB)
            un = union_length(IA, IB)
            disc = is_disconnected(IA, IB)

        # A simple ambiguity scale: separation of apices vs light travel time
        # If |Δx| >> t, futures are largely disjoint at that time slice.
        dx = abs(self.x_A - self.x_B)
        ambiguity_ratio = dx / (2.0 * t) if t > 0 else None  # >1 implies disjoint at slice

        return {
            "coordinates": {"t": t, "slice": "t=const", "x_A": self.x_A, "x_B": self.x_B},
            "curvature_invariants": {
                "ricci_scalar": finite_or_none(inv["ricci_scalar"]) if inv["ricci_scalar"] is not None else None,
                "kretschmann": finite_or_none(inv["kretschmann"]) if inv["kretschmann"] is not None else None,
                "note": "Flat Minkowski: no curvature pathologies; failure is causal predictability under quantum superposition.",
            },
            "local_observables": {
                "branch_light_cone_slices": {
                    "A": IA,
                    "B": IB,
                },
                "superposed_source_state": "(|A> + e^{iφ}|B>)/√2 (φ unspecified)",
                "nonuniqueness": {
                    "union_length": finite_or_none(un) if un is not None else None,
                    "overlap_length": finite_or_none(ov) if ov is not None else None,
                    "disconnected_union": disc,
                    "ambiguity_ratio_abs_dx_over_2t": finite_or_none(ambiguity_ratio) if ambiguity_ratio is not None else None,
                    "uniqueness_status": False,
                    "note": (
                        "Classically, a single apex defines a unique cone. In superposition, two distinct apex choices exist; "
                        "a single 'future light cone' is not uniquely defined without reduction/measurement."
                    ),
                },
            },
            "causal_structure": {
                "classical_future_light_cone": "x in [x0-t, x0+t] for each branch",
                "superposed_light_cone_status": "undefined_as_single_cone",
                "note": "Union of branch futures may be disconnected for small t if |x_A-x_B|>2t.",
            },
        }

    def build_payload(self, *, t_samples: List[float]) -> Dict[str, Any]:
        require(len(t_samples) >= 1, "Need at least one t sample.")
        require(all(t > 0.0 for t in t_samples), "All t samples must be > 0.")

        sample_points = [self.sample_point(t=t) for t in t_samples]

        # Summary: count slices with disconnected union
        disc_count = 0
        for sp in sample_points:
            disc = sp["local_observables"]["nonuniqueness"]["disconnected_union"]
            if disc is True:
                disc_count += 1

        return {
            "toy_id": self.toy_id,
            "theory": "Special Relativity limit (flat GR) + quantum-superposed source (operational causal diagnostic)",
            "spacetime": "Minkowski 1+1: source in spatial superposition => non-unique future light cone",
            "units": {"G": 1, "c": 1},
            "parameters": {
                "x_A": self.x_A,
                "x_B": self.x_B,
                "t_samples": t_samples,
                "conventions": "c=1; emission at t=0",
            },
            "notes": {
                "pressure_point": (
                    "Causal prediction in classical spacetime presumes localized events. A quantum superposition of emission locations "
                    "undermines the notion of a unique future light cone without additional measurement/reduction structure."
                ),
                "key_formulas": {
                    "light_cone_slice": "For emission at (0,x0), at time t>0: x ∈ [x0-t, x0+t]",
                    "disconnected_condition": "Union I_A(t) ∪ I_B(t) is disconnected iff |x_A-x_B| > 2t",
                },
                "domain_of_validity": (
                    "Flat spacetime with classical light propagation. Quantum aspect enters only as a superposition of source events; "
                    "toy is an operational ambiguity diagnostic, not a full QFT-in-curved-spacetime calculation."
                ),
            },
            "sample_points": sample_points,
            "observables": {
                "summary": {
                    "apex_separation_abs_dx": finite_or_none(abs(self.x_A - self.x_B)),
                    "disconnected_slices_count": disc_count,
                    "uniqueness_status": False,
                    "note": "If many slices are disconnected, the causal future is strongly branch-dependent at those times.",
                }
            },
        }

    def export_json(self, *, t_samples: List[float], out_path: Optional[str] = None) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)
        payload = self.build_payload(t_samples=t_samples)
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2, sort_keys=True)
        return out_path


def main() -> None:
    ap = argparse.ArgumentParser(description="Toy 077: light cone superposition in Minkowski (source superposition => causal ambiguity).")

    ap.add_argument("--xA", type=float, default=-1.0, help="Source location x_A at t=0")
    ap.add_argument("--xB", type=float, default=+1.0, help="Source location x_B at t=0")
    ap.add_argument("--t", type=str, default="0.25,0.5,1.0,2.0", help="Comma-separated time slices t>0")
    ap.add_argument("--out", type=str, default="", help="Optional output JSON path; default is <script>.json")
    args = ap.parse_args()

    t_samples = parse_csv_floats(args.t)
    toy = Toy077LightConeSuperposition(x_A=float(args.xA), x_B=float(args.xB))

    out_path = args.out.strip() or None
    json_path = toy.export_json(t_samples=t_samples, out_path=out_path)

    print(f"Wrote {json_path}")
    print("Toy 077 complete: branch light cones well-defined; superposed source yields non-unique causal future.")


if __name__ == "__main__":
    main()
