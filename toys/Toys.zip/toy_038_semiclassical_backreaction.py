#!/usr/bin/env python3
"""
Toy 038 — Semiclassical backreaction proxy (Hawking evaporation as effective mass loss)

Pressure point / weakness probed:
- Classical GR treats black holes as stationary solutions (e.g., Schwarzschild).
- Semiclassical physics predicts Hawking radiation: the black hole loses mass and the spacetime is not
  truly stationary. The required stress-energy violates classical energy conditions near the horizon.
- GR alone does not provide the source term; you must add <T_ab>_ren (semiclassical input).
  This toy treats that backreaction as an effective mass-loss law.

Model (controlled proxy):
- Use an evaporating Schwarzschild-like mass parameter M(t) with the standard scaling:
    dM/dt = - alpha / M^2      (alpha > 0 is an effective constant encapsulating graybody factors, species, ħ, etc.)
- Analytic solution:
    M(t) = (M0^3 - 3 alpha t)^(1/3)   for t <= t_evap = M0^3 / (3 alpha)
  For t > t_evap, M is undefined -> export nulls.

Diagnostics exported:
- Horizon radius: r_h(t) = 2 M(t)
- Hawking temperature proxy: T_H(t) = 1 / (8π M(t))    (uses ħ_eff=1 in these units; kept as a proxy)
- Luminosity proxy: L(t) = alpha / M(t)^2             (consistent with dM/dt)
- Curvature invariant at the horizon (Schwarzschild Kretschmann at r=2M):
    K_h(t) = 48 M^2 / (2M)^6 = (3/4) * 1/M(t)^4
- A dimensionless semiclassicality proxy:
    epsilon_sc(t) = 1 / M(t)^2
  (since typical quantum corrections scale like powers of 1/M in G=c=ħ=1 conventions; here treated as a proxy)

Export:
- Writes JSON named exactly like this .py file.
- Uses the mandatory schema; undefined quantities are null.
"""

from __future__ import annotations

import argparse
import json
import math
import os
from typing import Any, Dict, List, Optional


# ----------------------------
# Helpers
# ----------------------------

def py_to_json_name(py_path: str) -> str:
    base = os.path.splitext(os.path.basename(py_path))[0]
    return base + ".json"


def require(cond: bool, msg: str) -> None:
    if not cond:
        raise ValueError(msg)


def linspace(a: float, b: float, n: int) -> List[float]:
    require(n >= 2, "n must be >= 2")
    step = (b - a) / (n - 1)
    return [a + i * step for i in range(n)]


# ----------------------------
# Evaporating mass model
# ----------------------------

def evaporation_time(M0: float, alpha: float) -> float:
    # t_evap = M0^3 / (3 alpha)
    return (M0 ** 3) / (3.0 * alpha)


def M_of_t(M0: float, alpha: float, t: float) -> Optional[float]:
    # M(t) = (M0^3 - 3 alpha t)^(1/3), defined for t <= t_evap
    x = (M0 ** 3) - 3.0 * alpha * t
    if x <= 0.0:
        return None
    return x ** (1.0 / 3.0)


def horizon_radius(M: float) -> float:
    return 2.0 * M


def hawking_temperature_proxy(M: float) -> float:
    # T_H = 1 / (8π M) (proxy; assumes ħ_eff = 1 in these units)
    return 1.0 / (8.0 * math.pi * M)


def luminosity_proxy(alpha: float, M: float) -> float:
    # L ~ alpha / M^2 so that dM/dt = -L
    return alpha / (M * M)


def dMdt(alpha: float, M: float) -> float:
    return -alpha / (M * M)


def kretschmann_at_horizon(M: float) -> float:
    # Schwarzschild K = 48 M^2 / r^6; at r=2M => K_h = (3/4) * 1/M^4
    return 0.75 / (M ** 4)


def semiclassicality_proxy(M: float) -> float:
    # Proxy for "quantum-ness" growing as M shrinks (in ħ=1 conventions)
    return 1.0 / (M * M)


# ----------------------------
# Toy 038 driver
# ----------------------------

class Toy038SemiclassicalBackreaction:
    toy_id = "038"

    def __init__(self, M0: float, alpha: float, t_max: float, n: int) -> None:
        require(M0 > 0.0, "M0 must be > 0")
        require(alpha > 0.0, "alpha must be > 0")
        require(t_max > 0.0, "t_max must be > 0")
        require(n >= 2, "n must be >= 2")
        self.M0 = float(M0)
        self.alpha = float(alpha)
        self.t_max = float(t_max)
        self.n = int(n)

        self.t_evap = evaporation_time(self.M0, self.alpha)

    def build_payload(self) -> Dict[str, Any]:
        t_values = linspace(0.0, self.t_max, self.n)
        sample_points: List[Dict[str, Any]] = []

        for t in t_values:
            M = M_of_t(self.M0, self.alpha, t)

            if M is None:
                # Past evaporation endpoint in this proxy model
                sample_points.append({
                    "coordinates": {"t": t},
                    "curvature_invariants": {
                        "ricci_scalar": None,
                        "kretschmann": None
                    },
                    "local_observables": {
                        "M": None,
                        "horizon_radius_r_h": None,
                        "hawking_temperature_proxy_T_H": None,
                        "luminosity_proxy_L": None,
                        "dM_dt": None,
                        "kretschmann_at_horizon_K_h": None,
                        "semiclassicality_proxy_epsilon_sc": None,
                        "notes": "t exceeds t_evap in this proxy; classical/semi-classical description breaks down."
                    },
                    "causal_structure": {
                        "horizon_radius": None,
                        "region": None,
                        "energy_warning": (
                            "Beyond the evaporation endpoint of this proxy, the model does not define a classical horizon."
                        )
                    }
                })
                continue

            rh = horizon_radius(M)
            TH = hawking_temperature_proxy(M)
            L = luminosity_proxy(self.alpha, M)
            mdot = dMdt(self.alpha, M)
            Kh = kretschmann_at_horizon(M)
            eps_sc = semiclassicality_proxy(M)

            # Region label: in this proxy, we track the horizon itself
            region = "shrinking_horizon"

            sample_points.append({
                "coordinates": {"t": t},
                "curvature_invariants": {
                    "ricci_scalar": 0.0,     # vacuum Schwarzschild has R=0; semiclassical source not modeled explicitly
                    "kretschmann": Kh        # we export horizon curvature scale as the key invariant here
                },
                "local_observables": {
                    "M": M,
                    "horizon_radius_r_h": rh,
                    "hawking_temperature_proxy_T_H": TH,
                    "luminosity_proxy_L": L,
                    "dM_dt": mdot,
                    "kretschmann_at_horizon_K_h": Kh,
                    "semiclassicality_proxy_epsilon_sc": eps_sc,
                    "notes": (
                        "Semiclassical backreaction proxy: dM/dt = -alpha/M^2. "
                        "As M decreases, T_H increases, luminosity increases, and horizon curvature grows."
                    )
                },
                "causal_structure": {
                    "horizon_radius": rh,
                    "region": region,
                    "energy_warning": (
                        "Hawking evaporation requires a quantum <T_ab>_ren that violates classical energy conditions; "
                        "classical GR alone cannot supply this source."
                    )
                }
            })

        # Summaries
        M_end = M_of_t(self.M0, self.alpha, min(self.t_max, self.t_evap - 1e-15)) if self.t_max < self.t_evap else None

        payload: Dict[str, Any] = {
            "toy_id": self.toy_id,
            "theory": "General Relativity + semiclassical backreaction (effective model)",
            "spacetime": "Evaporating Schwarzschild (mass-loss proxy for Hawking radiation)",
            "units": {"G": 1, "c": 1},
            "parameters": {
                "M0": self.M0,
                "alpha": self.alpha,
                "t_max": self.t_max,
                "n_samples": self.n
            },
            "notes": {
                "pressure_point": (
                    "Classical GR predicts stationary black holes; semiclassical physics predicts Hawking radiation, "
                    "forcing time-dependent geometry and introducing quantum stress-energy not captured by GR alone. "
                    "This toy treats that as an effective backreaction law and tracks horizon shrinkage and curvature growth."
                ),
                "limitations": (
                    "No explicit <T_ab>_ren is computed; alpha is an effective parameter. "
                    "Temperature and semiclassicality are exported as proxies in these unit conventions."
                ),
                "definitions_used": {
                    "mass_loss_law": "dM/dt = -alpha/M^2",
                    "mass_solution": "M(t) = (M0^3 - 3 alpha t)^(1/3) for t <= t_evap",
                    "evaporation_time": "t_evap = M0^3 / (3 alpha)",
                    "temperature_proxy": "T_H = 1/(8πM)",
                    "horizon_curvature": "K_h = (3/4) * 1/M^4 at r=2M"
                }
            },
            "sample_points": sample_points,
            "observables": {
                "summary": {
                    "t_evap": self.t_evap,
                    "M_at_t_max_if_defined": M_end,
                    "key_result": (
                        "In this proxy, evaporation accelerates as M shrinks: |dM/dt| ~ 1/M^2, "
                        "T_H ~ 1/M, and horizon curvature K_h ~ 1/M^4, driving the system toward a regime "
                        "where semiclassical and then quantum-gravity effects dominate."
                    )
                }
            }
        }
        return payload

    def export_json(self, out_path: Optional[str] = None) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)
        payload = self.build_payload()
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2, sort_keys=True)
        return out_path


def main() -> None:
    ap = argparse.ArgumentParser(description="Toy 038: Semiclassical backreaction proxy (evaporating BH).")
    ap.add_argument("--M0", type=float, default=10.0, help="Initial BH mass M0 > 0")
    ap.add_argument("--alpha", type=float, default=1e-3, help="Effective evaporation constant alpha > 0")
    ap.add_argument("--tmax", type=float, default=3e5, help="Max time to sample")
    ap.add_argument("--n", type=int, default=21, help="Number of time samples (>=2)")
    ap.add_argument("--out", type=str, default="", help="Optional output path; default is <script>.json")
    args = ap.parse_args()

    toy = Toy038SemiclassicalBackreaction(
        M0=float(args.M0),
        alpha=float(args.alpha),
        t_max=float(args.tmax),
        n=int(args.n),
    )
    out_path = args.out.strip() or None
    json_path = toy.export_json(out_path=out_path)
    print(f"Wrote {json_path}")
    print("Notes:")
    print(f"- Evaporation time in this proxy: t_evap = {toy.t_evap}")


if __name__ == "__main__":
    main()
