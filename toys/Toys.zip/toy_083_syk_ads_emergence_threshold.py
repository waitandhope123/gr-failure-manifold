#!/usr/bin/env python3
"""
Toy 083 — SYK/AdS geometry emergence (proxy): quantify an entanglement→effective-geometry threshold

Classification (lab axes):
- Failure Trigger: state (entanglement / thermal correlations)
- Failure Mode: operational_undefined (no unique "geometry" from state until diagnostics stabilize)
- Failure Sharpness: thick (crossover with N, coupling, temperature)
- Repairable Within Classical GR: only_by_reinterpretation

What it probes (pressure point):
In SYK/AdS lore, certain strongly entangled, strongly interacting quantum states exhibit
low-energy correlators with approximate conformal structure, often interpreted as "emergent geometry".
This toy does NOT claim a bulk derivation. It provides a diff-able numerical threshold based on:
  (i) how well thermal two-point functions match the conformal kernel, and
  (ii) how close ground-state entanglement is to maximal for a half-system bipartition.

Model (deterministic, no randomness; ħ=k_B=1):
- n complex fermion modes, full Fock space dim = 2^n.
- SYK-like q=4 interaction with number conservation:
    H = Σ_{i<j, k<l, all distinct} J_{ij;kl} c_i^† c_j^† c_k c_l + h.c.
  Couplings J_{ij;kl} are deterministic functions of indices (sin hash), scaled by J_strength / n^{3/2}
  (a standard SYK-like scaling to keep energies extensive-ish).

Observables:
1) Thermal correlator (mode-averaged):
    G(τ) = (1/n) Σ_i ⟨ c_i(τ) c_i^†(0) ⟩_β
   computed from exact diagonalization via spectral sums.

2) Conformal fit error:
   For fixed Δ=1/4, fit amplitude b (least-squares) to the conformal kernel:
      K(τ) = ( (π/β) / sin(π τ/β) )^{2Δ}
   and report relative RMSE over sampled τ points.

3) Ground-state half-system entanglement:
   Take the ground state |ψ0⟩, bipartition modes into A and B (first n/2 vs last n/2),
   compute S_A = -Tr(ρ_A log ρ_A) from Schmidt singular values. Report fraction of maximal entropy:
      S_A / ( (n/2) ln 2 )

Threshold proxy:
- geometry_emergent_proxy = (fit_error < fit_tol) AND (entanglement_fraction > ent_tol)

Export:
- Strict JSON schema per lab protocol; writes <script_name>.json.
- Undefined quantities -> null; keys never omitted.

NOTE:
- This is an operational toy: "geometry" is not computed; stability of conformal correlators + high entanglement
  is used as a quantitative emergence proxy.
"""

from __future__ import annotations

import argparse
import json
import math
import os
from itertools import combinations
from typing import Any, Dict, List, Optional, Tuple

import numpy as np


# ----------------------------
# Helpers
# ----------------------------

def py_to_json_name(py_path: str) -> str:
    base = os.path.splitext(os.path.basename(py_path))[0]
    return base + ".json"


def require(cond: bool, msg: str) -> None:
    if not cond:
        raise ValueError(msg)


def parse_csv_ints(s: str) -> List[int]:
    return [int(x.strip()) for x in s.split(",") if x.strip()]


def parse_csv_floats(s: str) -> List[float]:
    return [float(x.strip()) for x in s.split(",") if x.strip()]


def finite_or_none(x: float) -> Optional[float]:
    return x if (isinstance(x, (int, float)) and math.isfinite(x)) else None


def rel_rmse(y: np.ndarray, yhat: np.ndarray) -> float:
    denom = np.sqrt(np.mean(y ** 2)) + 1e-30
    return float(np.sqrt(np.mean((y - yhat) ** 2)) / denom)


# ----------------------------
# Fermion operator construction (Jordan–Wigner)
# ----------------------------

def jw_ops(n: int) -> Tuple[List[np.ndarray], List[np.ndarray]]:
    """
    Returns lists [c_i], [c_i^dagger] as (2^n x 2^n) dense matrices for complex fermions.
    Jordan–Wigner: c_i = (Z⊗...⊗Z) ⊗ σ^- ⊗ I⊗...⊗I
    """
    require(n >= 1, "n must be >= 1")
    I = np.eye(2, dtype=complex)
    Z = np.array([[1, 0], [0, -1]], dtype=complex)
    sm = np.array([[0, 1], [0, 0]], dtype=complex)  # sigma-
    sp = np.array([[0, 0], [1, 0]], dtype=complex)  # sigma+

    cs: List[np.ndarray] = []
    cds: List[np.ndarray] = []

    for i in range(n):
        factors_c = []
        factors_cd = []
        for j in range(n):
            if j < i:
                factors_c.append(Z)
                factors_cd.append(Z)
            elif j == i:
                factors_c.append(sm)
                factors_cd.append(sp)
            else:
                factors_c.append(I)
                factors_cd.append(I)
        op_c = factors_c[0]
        op_cd = factors_cd[0]
        for k in range(1, n):
            op_c = np.kron(op_c, factors_c[k])
            op_cd = np.kron(op_cd, factors_cd[k])
        cs.append(op_c)
        cds.append(op_cd)
    return cs, cds


# ----------------------------
# Deterministic SYK-like Hamiltonian (complex fermion q=4)
# ----------------------------

def deterministic_J(i: int, j: int, k: int, l: int) -> float:
    """
    Deterministic "hash" into (-1,1) using sines of integer combinations.
    This is NOT randomness; output is deterministic and reproducible.
    """
    x = (13 * (i + 1) + 17 * (j + 1) + 19 * (k + 1) + 23 * (l + 1))
    return math.sin(x)


def build_csyk_hamiltonian(n: int, J_strength: float) -> np.ndarray:
    """
    H = sum_{i<j, k<l, all distinct} J_{ij;kl} c_i^† c_j^† c_k c_l + h.c.
    with scaling J_strength / n^{3/2}.
    """
    require(n >= 4, "Need n>=4 for q=4 interactions.")
    require(J_strength >= 0.0, "J_strength must be >= 0.")

    cs, cds = jw_ops(n)
    dim = 2 ** n
    H = np.zeros((dim, dim), dtype=complex)

    scale = (J_strength / (n ** 1.5)) if J_strength != 0.0 else 0.0

    # Choose unordered pairs (i<j) and (k<l), all indices distinct
    pairs = list(combinations(range(n), 2))
    for (i, j) in pairs:
        for (k, l) in pairs:
            # all distinct indices
            if len({i, j, k, l}) < 4:
                continue
            Jij_kl = scale * deterministic_J(i, j, k, l)
            if Jij_kl == 0.0:
                continue

            term = Jij_kl * (cds[i] @ cds[j] @ cs[k] @ cs[l])
            H += term
            H += term.conj().T  # ensure Hermitian

    # Sanity: Hermitian numerical symmetrization
    H = 0.5 * (H + H.conj().T)
    return H


# ----------------------------
# Thermal correlator G(tau) via spectral sums
# ----------------------------

def thermal_G_tau(H: np.ndarray, cs: List[np.ndarray], beta: float, taus: np.ndarray) -> Dict[str, Any]:
    """
    Computes G(τ) = (1/n) Σ_i Tr( e^{-βH} c_i(τ) c_i^† ) / Z
    with c_i(τ) = e^{τH} c_i e^{-τH} (Euclidean).
    Spectral form:
      G_i(τ) = (1/Z) Σ_{m,n} e^{-β E_n} e^{τ(E_n - E_m)} |<m|c_i^†|n>|^2
    (equivalently with c_i and index swap; careful but consistent here).
    """
    require(beta > 0.0, "beta must be > 0.")
    require(taus.ndim == 1 and len(taus) >= 2, "taus must be 1D with len>=2")

    # Diagonalize
    E, V = np.linalg.eigh(H)
    # Shift energies for numerical stability
    Emin = float(np.min(E))
    w = np.exp(-beta * (E - Emin))
    Z = float(np.sum(w))
    if not math.isfinite(Z) or Z <= 0.0:
        return {"G_tau": None, "Z": None, "E": None}

    # Precompute exponentials for tau
    # exp_tau[m,n] = exp(tau*(E_n - E_m))
    # We'll compute per tau to keep memory modest
    n_modes = len(cs)
    dim = H.shape[0]

    # Average over i of |<m|c_i^†|n>|^2
    # In eigenbasis: Cdi = V^† c_i^† V
    Gvals = []
    for tau in taus:
        # build exp factor matrix via outer differences
        dE = (E[None, :] - E[:, None])  # E_n - E_m
        exp_tau = np.exp(float(tau) * dE)

        Gi_sum = 0.0
        for i in range(n_modes):
            cdi = cs[i].conj().T  # c_i^†
            Cdi = V.conj().T @ cdi @ V
            # |Cdi_{m n}|^2
            M = np.abs(Cdi) ** 2
            # Σ_{m,n} e^{-β E_n} e^{τ(E_n-E_m)} |Cdi_{m n}|^2
            # weights on n index: w_n
            weighted = (exp_tau * M) @ w
            Gi = float(np.sum(weighted) / Z)
            Gi_sum += Gi
        Gvals.append(Gi_sum / n_modes)

    return {"G_tau": np.array(Gvals, dtype=float), "Z": Z, "E": E.tolist()}


# ----------------------------
# Ground-state half-system entanglement entropy
# ----------------------------

def half_system_entanglement_entropy(psi0: np.ndarray, n: int) -> Optional[float]:
    """
    Bipartition modes: A = first n/2 modes, B = last n/2 modes (requires even n).
    Treat |psi> as vector in (2^{n/2} x 2^{n/2}) and use Schmidt singular values.
    """
    require(psi0.ndim == 1, "psi0 must be a state vector.")
    require(n % 2 == 0, "n must be even for half-system bipartition in this toy.")
    dim = 2 ** n
    require(len(psi0) == dim, "psi0 length mismatch.")
    psi = psi0 / (np.linalg.norm(psi0) + 1e-30)

    dA = 2 ** (n // 2)
    dB = 2 ** (n // 2)
    M = psi.reshape((dA, dB))
    s = np.linalg.svd(M, compute_uv=False)
    p = (s ** 2)
    p = p / (np.sum(p) + 1e-30)
    # Von Neumann entropy
    p_safe = np.clip(p, 1e-300, 1.0)
    S = float(-np.sum(p_safe * np.log(p_safe)))
    return S


# ----------------------------
# Conformal kernel fit
# ----------------------------

def conformal_kernel(taus: np.ndarray, beta: float, Delta: float) -> np.ndarray:
    x = (math.pi / beta) / np.sin(math.pi * taus / beta)
    return x ** (2.0 * Delta)


def fit_amplitude_b(y: np.ndarray, x: np.ndarray) -> float:
    # least squares b minimizing ||y - b x||^2
    num = float(np.dot(x, y))
    den = float(np.dot(x, x)) + 1e-30
    return num / den


# ----------------------------
# Toy 083
# ----------------------------

class Toy083SYKAdSEmergenceThreshold:
    toy_id = "083"

    def __init__(
        self,
        *,
        n_list: List[int],
        J_list: List[float],
        beta: float,
        n_tau: int,
        Delta: float,
        fit_tol: float,
        ent_tol: float,
    ) -> None:
        require(len(n_list) >= 1, "Need at least one n.")
        require(len(J_list) >= 1, "Need at least one J_strength.")
        require(beta > 0.0, "beta must be > 0.")
        require(n_tau >= 4, "n_tau must be >= 4.")
        require(0.0 < Delta < 1.0, "Delta must be in (0,1).")
        require(fit_tol > 0.0, "fit_tol must be > 0.")
        require(0.0 <= ent_tol <= 1.0, "ent_tol must be in [0,1].")

        self.n_list = n_list
        self.J_list = J_list
        self.beta = float(beta)
        self.n_tau = int(n_tau)
        self.Delta = float(Delta)
        self.fit_tol = float(fit_tol)
        self.ent_tol = float(ent_tol)

    def run_case(self, n: int, J_strength: float) -> Dict[str, Any]:
        # Build H and operators
        if n < 4:
            return {
                "n": n,
                "J_strength": J_strength,
                "error": "n<4 insufficient for q=4 interaction",
            }

        H = build_csyk_hamiltonian(n, J_strength)
        cs, _ = jw_ops(n)
        dim = 2 ** n

        # Tau grid avoiding endpoints (singular kernel there)
        taus = np.linspace(1.0 / (self.n_tau + 1), self.n_tau / (self.n_tau + 1), self.n_tau) * self.beta

        # Thermal correlator
        th = thermal_G_tau(H, cs, self.beta, taus)
        Gtau = th["G_tau"]
        if Gtau is None:
            return {
                "n": n,
                "J_strength": J_strength,
                "dim": dim,
                "beta": self.beta,
                "G_tau": None,
                "fit_error_rel_rmse": None,
                "fit_b": None,
                "entanglement_S_half": None,
                "entanglement_fraction": None,
                "geometry_emergent_proxy": None,
            }

        # Conformal fit
        K = conformal_kernel(taus, self.beta, self.Delta)
        b = fit_amplitude_b(Gtau, K)
        Ghat = b * K
        err = rel_rmse(Gtau, Ghat)

        # Ground state entanglement
        S_half = None
        ent_frac = None
        if n % 2 == 0:
            # Ground state from diagonalization
            E, V = np.linalg.eigh(H)
            psi0 = V[:, int(np.argmin(E))]
            S_half = half_system_entanglement_entropy(psi0, n)
            Smax = (n / 2.0) * math.log(2.0)
            ent_frac = float(S_half / (Smax + 1e-30)) if S_half is not None else None

        geom = None
        if ent_frac is not None:
            geom = (err < self.fit_tol) and (ent_frac > self.ent_tol)

        return {
            "n": n,
            "J_strength": J_strength,
            "dim": dim,
            "beta": self.beta,
            "tau_samples": taus.tolist(),
            "G_tau": [float(x) for x in Gtau.tolist()],
            "conformal_kernel_Delta": self.Delta,
            "fit_b": float(b),
            "fit_error_rel_rmse": float(err),
            "entanglement_S_half": float(S_half) if S_half is not None else None,
            "entanglement_fraction": float(ent_frac) if ent_frac is not None else None,
            "geometry_emergent_proxy": bool(geom) if geom is not None else None,
        }

    def sample_point(self, n: int, J_strength: float) -> Dict[str, Any]:
        res = self.run_case(n, J_strength)

        coords = {"n_modes": n, "J_strength": J_strength, "beta": self.beta}
        curv = {
            "ricci_scalar": None,
            "kretschmann": None,
            "note": "Quantum-many-body toy; no spacetime curvature computed. 'Geometry' is an operational proxy from correlator form + entanglement.",
        }

        local = {
            "hilbert_dim": res.get("dim", None),
            "thermal_correlator": {
                "Delta": self.Delta,
                "tau_samples": res.get("tau_samples", None),
                "G_tau": res.get("G_tau", None),
                "fit_amplitude_b": finite_or_none(res["fit_b"]) if res.get("fit_b") is not None else None,
                "fit_error_rel_rmse": finite_or_none(res["fit_error_rel_rmse"]) if res.get("fit_error_rel_rmse") is not None else None,
                "fit_tolerance": self.fit_tol,
            },
            "entanglement": {
                "S_half": finite_or_none(res["entanglement_S_half"]) if res.get("entanglement_S_half") is not None else None,
                "fraction_of_max": finite_or_none(res["entanglement_fraction"]) if res.get("entanglement_fraction") is not None else None,
                "entanglement_tolerance": self.ent_tol,
                "note": "Half-system entanglement uses a mode bipartition (first n/2 vs last n/2).",
            },
        }

        causal = {
            "geometry_emergent_proxy": res.get("geometry_emergent_proxy", None),
            "failure_mode_if_not_emergent": (
                "operational_undefined_geometry_proxy_unstable"
                if res.get("geometry_emergent_proxy", None) is False else None
            ),
            "note": (
                "Proxy declares 'emergent' only when both conformal-correlator fit and high entanglement are satisfied. "
                "This does not produce a unique bulk metric; it quantifies a threshold where geometric interpretation becomes more stable."
            ),
        }

        return {
            "coordinates": coords,
            "curvature_invariants": curv,
            "local_observables": local,
            "causal_structure": causal,
        }

    def build_payload(self) -> Dict[str, Any]:
        sample_points: List[Dict[str, Any]] = []
        emergent_count = 0
        total_count = 0
        best_case = None

        for n in self.n_list:
            for J in self.J_list:
                sp = self.sample_point(n, J)
                sample_points.append(sp)
                total_count += 1
                flag = sp["causal_structure"]["geometry_emergent_proxy"]
                if flag is True:
                    emergent_count += 1

                # track best (lowest fit error) among those with entanglement available
                fe = sp["local_observables"]["thermal_correlator"]["fit_error_rel_rmse"]
                ef = sp["local_observables"]["entanglement"]["fraction_of_max"]
                if fe is not None and ef is not None:
                    score = float(fe) - 0.1 * float(ef)  # prefer low error, high ent
                    if best_case is None or score < best_case["score"]:
                        best_case = {
                            "score": score,
                            "n": n,
                            "J": J,
                            "fit_error": fe,
                            "ent_frac": ef,
                            "emergent": sp["causal_structure"]["geometry_emergent_proxy"],
                        }

        return {
            "toy_id": self.toy_id,
            "theory": "Quantum many-body SYK-like model (deterministic) as an operational emergence test",
            "spacetime": "No explicit spacetime; emergent-geometry proxy from conformal correlators + entanglement",
            "units": {"G": 1, "c": 1},
            "parameters": {
                "n_modes_list": self.n_list,
                "J_strength_list": self.J_list,
                "beta": self.beta,
                "n_tau": self.n_tau,
                "Delta": self.Delta,
                "fit_tol": self.fit_tol,
                "ent_tol": self.ent_tol,
                "couplings": "deterministic_sine_hash_scaled_by_J/n^(3/2)",
            },
            "notes": {
                "pressure_point": (
                    "Entanglement data do not uniquely determine geometry; a geometric interpretation becomes more stable only when "
                    "low-energy correlators approach a conformal form and the state is highly entangled/scrambling-like."
                ),
                "key_formulas": {
                    "Hamiltonian": "H = Σ J_{ij;kl} c_i^† c_j^† c_k c_l + h.c. (deterministic J)",
                    "thermal_correlator": "G(τ)= (1/n)Σ_i ⟨c_i(τ)c_i^†(0)⟩_β",
                    "conformal_kernel": "K(τ) = ((π/β)/sin(π τ/β))^{2Δ}, fit amplitude b",
                    "entanglement": "S_A = -Tr(ρ_A log ρ_A), compare S_A / ((n/2) ln 2)",
                },
                "domain_of_validity": (
                    "Exact diagonalization limits n to modest sizes. "
                    "Toy is an operational emergence proxy; it does not reconstruct a bulk metric."
                ),
            },
            "sample_points": sample_points,
            "observables": {
                "summary": {
                    "cases_total": total_count,
                    "cases_emergent_proxy_true": emergent_count,
                    "best_case_proxy": best_case,
                    "note": "Emergence proxy is thresholded by (fit_error < fit_tol) AND (entanglement_fraction > ent_tol).",
                }
            },
        }

    def export_json(self, out_path: Optional[str] = None) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)
        payload = self.build_payload()
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2, sort_keys=True)
        return out_path


# ----------------------------
# CLI
# ----------------------------

def main() -> None:
    ap = argparse.ArgumentParser(description="Toy 083: SYK/AdS emergence threshold proxy (deterministic ED).")
    ap.add_argument("--n_list", type=str, default="4,6,8", help="Comma-separated complex-fermion mode counts n (ED cost ~2^n).")
    ap.add_argument("--J_list", type=str, default="0.5,1.0,2.0", help="Comma-separated coupling strengths J.")
    ap.add_argument("--beta", type=float, default=10.0, help="Inverse temperature β.")
    ap.add_argument("--n_tau", type=int, default=24, help="Number of τ samples in (0,β).")
    ap.add_argument("--Delta", type=float, default=0.25, help="Conformal exponent Δ (SYK q=4 expectation is 1/4).")
    ap.add_argument("--fit_tol", type=float, default=0.15, help="Relative RMSE tolerance for conformal fit.")
    ap.add_argument("--ent_tol", type=float, default=0.70, help="Entanglement fraction threshold for 'high entanglement'.")
    ap.add_argument("--out", type=str, default="", help="Optional output JSON path; default is <script>.json")
    args = ap.parse_args()

    n_list = parse_csv_ints(args.n_list)
    J_list = parse_csv_floats(args.J_list)

    toy = Toy083SYKAdSEmergenceThreshold(
        n_list=n_list,
        J_list=J_list,
        beta=float(args.beta),
        n_tau=int(args.n_tau),
        Delta=float(args.Delta),
        fit_tol=float(args.fit_tol),
        ent_tol=float(args.ent_tol),
    )

    out_path = args.out.strip() or None
    json_path = toy.export_json(out_path=out_path)

    print(f"Wrote {json_path}")
    print("Toy 083 complete: conformal correlator fit + entanglement threshold proxy exported.")


if __name__ == "__main__":
    main()
