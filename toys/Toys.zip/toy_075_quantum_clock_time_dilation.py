#!/usr/bin/env python3
"""
Toy 075 — Quantum clock time dilation (Schwarzschild): superposed height => ambiguous proper time

Classification (lab axes):
- Failure Trigger: observer (quantum)
- Failure Mode: observer_disagreement (proper-time ambiguity)
- Failure Sharpness: contextual
- Repairable Within Classical GR: no

What it probes (pressure point):
- In classical GR, once a worldline is specified, proper time is well-defined.
- If a physical clock is in a quantum superposition of two different gravitational potentials
  (two radii), GR alone does not provide a unique "elapsed proper time" without adding a
  measurement/reduction model.

Model (controlled approximation; G=c=1):
- Fixed Schwarzschild geometry with mass M.
- Two clock locations (r1, r2) outside the horizon. For a static clock at radius r:
    dτ/dt = sqrt(f(r)),  f(r)=1-2M/r
  So for a coordinate time interval Δt:  Δτ(r) = Δt * sqrt(f(r))

Quantum clock superposition:
- |ψ> = (|r1> + e^{iφ}|r2>)/√2

Operational ambiguity diagnostics:
- Branch proper times: Δτ1, Δτ2 (well-defined)
- Mixture rule (post-decoherence):      Δτ_mix = (Δτ1 + Δτ2)/2
- Phase-sensitive coherent proxy:       P_proxy = |(Δτ1 + e^{iφ}Δτ2)/√2|^2
  (not a proper time; minimal illustration that "single-number" reductions can become phase-dependent)

Observed Results (what breaks and why it matters):
- The same spacetime and the same preparation time Δt yield two distinct proper times on the
  superposed branches.
- Any attempt to assign one elapsed time to the clock requires extra postulates (decoherence,
  collapse, operational readout), and can become phase-dependent.
- This stresses the classical assumption that "proper time is observer-independent once the path is fixed"—
  because in quantum settings the path may not be fixed.

Export:
- Strict JSON schema per lab protocol; writes <script_name>.json.
- Undefined quantities exported as null; keys never omitted.
"""

from __future__ import annotations

import argparse
import json
import math
import os
from typing import Any, Dict, List, Optional


# ----------------------------
# Helpers
# ----------------------------

def py_to_json_name(py_path: str) -> str:
    base = os.path.splitext(os.path.basename(py_path))[0]
    return base + ".json"


def require(cond: bool, msg: str) -> None:
    if not cond:
        raise ValueError(msg)


def parse_csv_floats(s: str) -> List[float]:
    return [float(x.strip()) for x in s.split(",") if x.strip()]


def finite_or_none(x: float) -> Optional[float]:
    return x if (isinstance(x, (int, float)) and math.isfinite(x)) else None


# ----------------------------
# Toy 075
# ----------------------------

class Toy075QuantumClockTimeDilation:
    toy_id = "075"

    def __init__(self, *, M: float, R: float) -> None:
        require(M > 0.0, "M must be > 0.")
        require(R > 0.0, "Reference radius R must be > 0.")
        self.M = float(M)
        self.R = float(R)

    def horizon(self) -> float:
        return 2.0 * self.M

    def f(self, r: float) -> float:
        return 1.0 - 2.0 * self.M / r

    def rate_static(self, r: float) -> Optional[float]:
        fr = self.f(r)
        if fr <= 0.0:
            return None
        return math.sqrt(fr)

    def delta_tau(self, r: float, delta_t: float) -> Optional[float]:
        rate = self.rate_static(r)
        if rate is None:
            return None
        return rate * delta_t

    def coherent_proxy(self, x1: float, x2: float, phi: float) -> Optional[float]:
        # |(x1 + e^{iφ} x2)/√2|^2 = 0.5(x1^2 + x2^2 + 2 x1 x2 cosφ)
        if x1 is None or x2 is None:
            return None
        return 0.5 * (x1*x1 + x2*x2 + 2.0*x1*x2*math.cos(phi))

    def curvature_invariants(self, r: float) -> Dict[str, Optional[float]]:
        if r <= 0.0:
            return {"ricci_scalar": None, "kretschmann": None}
        return {"ricci_scalar": 0.0, "kretschmann": 48.0 * (self.M ** 2) / (r ** 6)}

    def sample_point(self, *, h1: float, h2: float, delta_t: float, phi: float) -> Dict[str, Any]:
        require(delta_t > 0.0, "delta_t must be > 0.")
        r1 = self.R + h1
        r2 = self.R + h2
        require(r1 > self.horizon(), "r1 must be outside the horizon (R+h1 > 2M).")
        require(r2 > self.horizon(), "r2 must be outside the horizon (R+h2 > 2M).")

        rate1 = self.rate_static(r1)
        rate2 = self.rate_static(r2)

        dtau1 = self.delta_tau(r1, delta_t)
        dtau2 = self.delta_tau(r2, delta_t)

        dtau_mix = None
        if dtau1 is not None and dtau2 is not None:
            dtau_mix = 0.5 * (dtau1 + dtau2)

        proxy = self.coherent_proxy(dtau1, dtau2, phi)

        # Proper-time ambiguity scale
        amb = None
        if dtau1 is not None and dtau2 is not None:
            amb = abs(dtau1 - dtau2)

        curv = self.curvature_invariants(r1)

        return {
            "coordinates": {
                "t": None,
                "R_reference": self.R,
                "h1": h1,
                "h2": h2,
                "r1": r1,
                "r2": r2,
                "delta_t_coordinate": delta_t,
                "phi_phase_radians": phi,
            },
            "curvature_invariants": {
                "ricci_scalar": finite_or_none(curv["ricci_scalar"]) if curv["ricci_scalar"] is not None else None,
                "kretschmann_at_r1": finite_or_none(curv["kretschmann"]) if curv["kretschmann"] is not None else None,
                "note": "Invariant shown at r1 as reference; ambiguity is from superposed clock location, not curvature singularity.",
            },
            "local_observables": {
                "schwarzschild_f_r1": finite_or_none(self.f(r1)),
                "schwarzschild_f_r2": finite_or_none(self.f(r2)),
                "branch_values": {
                    "rate_dtau_over_dt_r1": finite_or_none(rate1) if rate1 is not None else None,
                    "rate_dtau_over_dt_r2": finite_or_none(rate2) if rate2 is not None else None,
                    "delta_tau_r1": finite_or_none(dtau1) if dtau1 is not None else None,
                    "delta_tau_r2": finite_or_none(dtau2) if dtau2 is not None else None,
                },
                "superposed_clock_reductions": {
                    "mixture_delta_tau_mean": finite_or_none(dtau_mix) if dtau_mix is not None else None,
                    "coherent_phase_sensitive_proxy": finite_or_none(proxy) if proxy is not None else None,
                    "uniqueness_status": False,
                    "note": (
                        "Classical GR gives Δτ on each branch. A single Δτ for the superposed clock "
                        "requires a measurement/reduction model; coherent proxies can depend on φ."
                    ),
                },
                "ambiguity_diagnostics": {
                    "delta_tau_separation_abs": finite_or_none(amb) if amb is not None else None,
                },
            },
            "causal_structure": {
                "horizon_radius": self.horizon(),
                "region_r1": "exterior (r>2M)" if r1 > self.horizon() else "nonstatic",
                "region_r2": "exterior (r>2M)" if r2 > self.horizon() else "nonstatic",
                "note": "Both branches are outside the horizon so static-clock rates exist on each branch.",
            },
        }

    def build_payload(self, *, h1_values: List[float], h2_values: List[float], delta_t: float, phi_values: List[float]) -> Dict[str, Any]:
        require(len(h1_values) >= 1 and len(h2_values) >= 1, "Need h1 and h2 samples.")
        require(len(phi_values) >= 1, "Need at least one phase sample.")
        require(delta_t > 0.0, "delta_t must be > 0.")

        sample_points: List[Dict[str, Any]] = []
        for h1 in h1_values:
            for h2 in h2_values:
                for phi in phi_values:
                    sample_points.append(self.sample_point(h1=h1, h2=h2, delta_t=delta_t, phi=phi))

        # Summary: max Δτ separation across samples
        max_sep = None
        for sp in sample_points:
            sep = sp["local_observables"]["ambiguity_diagnostics"]["delta_tau_separation_abs"]
            if sep is not None:
                max_sep = sep if max_sep is None else max(max_sep, sep)

        return {
            "toy_id": self.toy_id,
            "theory": "General Relativity (fixed Schwarzschild) + quantum-superposed clock location (operational diagnostic)",
            "spacetime": "Schwarzschild (static clocks) with clock position superposition (|r1>+e^{iφ}|r2>)/√2",
            "units": {"G": 1, "c": 1},
            "parameters": {
                "M": self.M,
                "R_reference": self.R,
                "h1_samples": h1_values,
                "h2_samples": h2_values,
                "delta_t_coordinate": delta_t,
                "phi_phase_samples_radians": phi_values,
            },
            "notes": {
                "pressure_point": (
                    "Proper time is well-defined along a definite worldline. If the clock's location is quantum-superposed, "
                    "GR supplies branch times but not a unique single elapsed time without extra measurement postulates."
                ),
                "key_formulas": {
                    "f": "f(r)=1-2M/r",
                    "rate": "dτ/dt = sqrt(f(r)) for static clock (r>2M)",
                    "delta_tau": "Δτ(r) = Δt * sqrt(f(r))",
                    "mixture_rule": "Δτ_mix = (Δτ1 + Δτ2)/2",
                    "coherent_proxy": "|(Δτ1 + e^{iφ}Δτ2)/√2|^2 = 0.5(Δτ1^2+Δτ2^2+2Δτ1Δτ2 cosφ)",
                },
                "domain_of_validity": (
                    "Fixed-background Schwarzschild; static-clock formula. The coherent proxy is a minimal phase-sensitive diagnostic, "
                    "not a full quantum time-of-arrival/clock readout theory."
                ),
            },
            "sample_points": sample_points,
            "observables": {
                "summary": {
                    "horizon_radius_2M": self.horizon(),
                    "max_delta_tau_separation_over_samples": finite_or_none(max_sep) if max_sep is not None else None,
                    "operational_uniqueness": False,
                    "note": "Nonzero branch Δτ separation illustrates proper-time ambiguity for a superposed clock location.",
                }
            },
        }

    def export_json(self, *, h1_values: List[float], h2_values: List[float], delta_t: float, phi_values: List[float], out_path: Optional[str] = None) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)
        payload = self.build_payload(h1_values=h1_values, h2_values=h2_values, delta_t=delta_t, phi_values=phi_values)
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2, sort_keys=True)
        return out_path


def main() -> None:
    ap = argparse.ArgumentParser(description="Toy 075: quantum clock superposition at two heights in Schwarzschild (proper-time ambiguity).")
    ap.add_argument("--M", type=float, default=1.0, help="Schwarzschild mass M (G=c=1).")
    ap.add_argument("--R", type=float, default=20.0, help="Reference radius R (e.g., a 'surface'); must satisfy R>2M.")
    ap.add_argument("--h1", type=str, default="0.0,1.0", help="Comma-separated heights h1 so r1=R+h1 > 2M.")
    ap.add_argument("--h2", type=str, default="2.0,5.0", help="Comma-separated heights h2 so r2=R+h2 > 2M.")
    ap.add_argument("--delta_t", type=float, default=1.0, help="Coordinate time interval Δt.")
    ap.add_argument("--phi", type=str, default="0,1.57079632679,3.14159265359", help="Comma-separated phases φ (radians).")
    ap.add_argument("--out", type=str, default="", help="Optional output JSON path; default is <script>.json")
    args = ap.parse_args()

    toy = Toy075QuantumClockTimeDilation(M=float(args.M), R=float(args.R))
    h1_values = parse_csv_floats(args.h1)
    h2_values = parse_csv_floats(args.h2)
    phi_values = parse_csv_floats(args.phi)

    out_path = args.out.strip() or None
    json_path = toy.export_json(h1_values=h1_values, h2_values=h2_values, delta_t=float(args.delta_t), phi_values=phi_values, out_path=out_path)

    print(f"Wrote {json_path}")
    print("Toy 075 complete: branch proper times defined, superposed clock proper time operationally non-unique.")


if __name__ == "__main__":
    main()
