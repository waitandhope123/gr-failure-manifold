#!/usr/bin/env python3
"""
Toy 065 — Geometry saturation without resolution: quasilocal energy ambiguity
in fully specified Schwarzschild spacetime

What it probes (pressure point):
- Even when spacetime geometry is completely fixed (Schwarzschild metric + invariants),
  quasilocal "energy inside radius r" is not uniquely defined.
- Two standard GR quasilocal energies on the same 2-sphere generally disagree.

Model:
- Exact Schwarzschild spacetime with mass M (G=c=1).
- Evaluate on coordinate 2-spheres of areal radius r.

Energies compared:
1) Misner–Sharp mass (for Schwarzschild):      M_MS(r) = M
2) Brown–York quasilocal energy (subtracted): E_BY(r) = r * (1 - sqrt(1 - 2M/r))
   Defined for r > 2M (real-valued). At/inside horizon, this simple static-slice BY expression
   is not used here -> return null.

Curvature diagnostics:
- Ricci scalar: R = 0 (vacuum)
- Kretschmann scalar: K = 48 M^2 / r^6

Export:
- Strict JSON schema per lab protocol.
- Undefined quantities encoded as null; keys never omitted.
"""

from __future__ import annotations

import argparse
import json
import math
import os
from typing import Any, Dict, List, Optional


# ----------------------------
# Helpers
# ----------------------------

def py_to_json_name(py_path: str) -> str:
    base = os.path.splitext(os.path.basename(py_path))[0]
    return base + ".json"


def require(cond: bool, msg: str) -> None:
    if not cond:
        raise ValueError(msg)


def finite_or_none(x: float) -> Optional[float]:
    return x if (isinstance(x, (int, float)) and math.isfinite(x)) else None


def parse_csv_floats(s: str) -> List[float]:
    return [float(x.strip()) for x in s.split(",") if x.strip()]


# ----------------------------
# Toy 065
# ----------------------------

class Toy065GeometrySaturationQuasilocalEnergy:
    toy_id = "065"

    def __init__(self, M: float) -> None:
        require(M > 0.0, "M must be > 0.")
        self.M = float(M)

    def horizon(self) -> float:
        return 2.0 * self.M

    def f(self, r: float) -> float:
        # Schwarzschild lapse squared in standard coordinates
        return 1.0 - 2.0 * self.M / r

    # Curvature invariants
    def ricci_scalar(self) -> float:
        return 0.0

    def kretschmann(self, r: float) -> Optional[float]:
        if r <= 0.0:
            return None
        return 48.0 * (self.M ** 2) / (r ** 6)

    # Quasilocal energies
    def misner_sharp_mass(self, r: float) -> Optional[float]:
        # For Schwarzschild, Misner–Sharp mass equals M (vacuum, spherical symmetry)
        if r <= 0.0:
            return None
        return self.M

    def brown_york_energy(self, r: float) -> Optional[float]:
        # E_BY(r) = r (1 - sqrt(1 - 2M/r)) for r > 2M in this static-slice form
        if r <= 0.0:
            return None
        f = self.f(r)
        if f <= 0.0:
            # Outside the regime where the simple static-slice expression is real
            return None
        return r * (1.0 - math.sqrt(f))

    def region_label(self, r: float) -> str:
        rh = self.horizon()
        if r > rh:
            return "exterior (r>2M)"
        if abs(r - rh) < 1e-12:
            return "horizon (r=2M)"
        return "interior (r<2M)"

    def sample_point(self, r: float) -> Dict[str, Any]:
        ms = self.misner_sharp_mass(r)
        by = self.brown_york_energy(r)

        disagreement = None
        if (ms is not None) and (by is not None):
            disagreement = by - ms

        return {
            "coordinates": {"t": None, "r": r, "theta": None, "phi": None},
            "curvature_invariants": {
                "ricci_scalar": self.ricci_scalar(),
                "kretschmann": finite_or_none(self.kretschmann(r)),
                "note": "Schwarzschild vacuum: R=0; K fixed by M and r."
            },
            "local_observables": {
                "misner_sharp_mass_M_MS": finite_or_none(ms) if ms is not None else None,
                "brown_york_energy_E_BY": finite_or_none(by) if by is not None else None,
                "E_BY_minus_M_MS": finite_or_none(disagreement) if disagreement is not None else None,
                "note": (
                    "M_MS is constant (=M) in Schwarzschild. E_BY depends on r; "
                    "comparison shows quasilocal energy is not unique even for fixed geometry."
                ),
            },
            "causal_structure": {
                "horizon_radius": self.horizon(),
                "region": self.region_label(r),
            },
        }

    def build_payload(self, r_values: List[float]) -> Dict[str, Any]:
        require(len(r_values) >= 1, "Need at least one radius.")

        sample_points = [self.sample_point(r) for r in r_values]

        # Summary metrics over valid exterior radii
        diffs: List[float] = []
        for r in r_values:
            ms = self.misner_sharp_mass(r)
            by = self.brown_york_energy(r)
            if ms is not None and by is not None:
                diffs.append(by - ms)

        max_abs_diff = max((abs(x) for x in diffs), default=None)

        return {
            "toy_id": self.toy_id,
            "theory": "General Relativity (exact Schwarzschild; quasilocal energy diagnostics)",
            "spacetime": "Schwarzschild vacuum spacetime (mass parameter M fully specifies geometry)",
            "units": {"G": 1, "c": 1},
            "parameters": {
                "M": self.M,
                "r_samples": r_values,
            },
            "notes": {
                "pressure_point": (
                    "Even with geometry fully specified (Schwarzschild), quasilocal energy is not unique: "
                    "different standard definitions assign different energies to the same 2-sphere."
                ),
                "energies_compared": {
                    "misner_sharp": "M_MS(r) = M (Schwarzschild)",
                    "brown_york": "E_BY(r) = r * (1 - sqrt(1 - 2M/r))  (static-slice, subtracted, r>2M)",
                },
                "domain_of_validity": (
                    "E_BY formula used here is real-valued for r>2M on standard static slices. "
                    "At/inside horizon, this toy returns null for E_BY (not evaluated in this form)."
                ),
            },
            "sample_points": sample_points,
            "observables": {
                "summary": {
                    "geometry_fully_specified": True,
                    "energy_unique": False,
                    "max_abs_E_BY_minus_M_MS_over_valid_samples": finite_or_none(max_abs_diff) if max_abs_diff is not None else None,
                    "note": "Nonzero disagreement indicates non-uniqueness of quasilocal energy even in fixed Schwarzschild geometry."
                }
            },
        }

    def export_json(self, r_values: List[float], out_path: Optional[str] = None) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)
        payload = self.build_payload(r_values)
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2, sort_keys=True)
        return out_path


def main() -> None:
    ap = argparse.ArgumentParser(description="Toy 065: quasilocal energy ambiguity in Schwarzschild (geometry saturation test).")
    ap.add_argument("--M", type=float, default=1.0, help="Black hole mass M (G=c=1)")
    ap.add_argument(
        "--r",
        type=str,
        default="10,6,4,3,2.5,2.1",
        help="Comma-separated areal radii r (include some near 2M to show domain limits)",
    )
    ap.add_argument("--out", type=str, default="", help="Optional output JSON path")
    args = ap.parse_args()

    r_values = parse_csv_floats(args.r)
    toy = Toy065GeometrySaturationQuasilocalEnergy(M=float(args.M))

    out_path = args.out.strip() or None
    json_path = toy.export_json(r_values=r_values, out_path=out_path)

    print(f"Wrote {json_path}")
    print("Toy 065 complete: Misner–Sharp vs Brown–York (quasilocal energy non-uniqueness).")


if __name__ == "__main__":
    main()
