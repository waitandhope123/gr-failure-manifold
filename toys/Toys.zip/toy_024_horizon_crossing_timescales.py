#!/usr/bin/env python3
"""
Toy 024 — Horizon crossing timescales (proper vs Schwarzschild coordinate time)

What it probes:
- Proper time to the horizon is finite for infalling observers.
- Schwarzschild coordinate time diverges as r -> 2M.
- Demonstrates observer-dependent time descriptions without invoking new physics.

Model (G=c=1):
Radial infall from rest at infinity in Schwarzschild spacetime.

Equations:
  dr/dτ = -sqrt(2M/r)
  dt/dr = (1 - 2M/r)^(-1) * sqrt(r / (2M))

Notes:
- Proper time τ is finite to r=2M.
- Coordinate time t diverges logarithmically at the horizon.
"""

from __future__ import annotations

import argparse
import json
import math
import os
from typing import Any, Dict, List, Optional


# ----------------------------
# Helpers
# ----------------------------

def py_to_json_name(py_path: str) -> str:
    base = os.path.splitext(os.path.basename(py_path))[0]
    return base + ".json"


def parse_csv_floats(s: str) -> List[float]:
    return [float(x.strip()) for x in s.split(",") if x.strip()]


def require(cond: bool, msg: str) -> None:
    if not cond:
        raise ValueError(msg)


def integrate_trapezoid(xs: List[float], ys: List[float]) -> float:
    total = 0.0
    for i in range(len(xs) - 1):
        dx = xs[i+1] - xs[i]
        total += 0.5 * dx * (ys[i] + ys[i+1])
    return total


# ----------------------------
# Toy 024
# ----------------------------

class Toy024HorizonTimescales:
    toy_id = "024"

    def __init__(self, M: float = 1.0) -> None:
        require(M > 0.0, "M must be > 0.")
        self.M = float(M)

    def horizon(self) -> float:
        return 2.0 * self.M

    def dtaudr(self, r: float) -> float:
        return -1.0 / math.sqrt(2.0 * self.M / r)

    def dtdr(self, r: float) -> float:
        f = 1.0 - 2.0 * self.M / r
        if f <= 0.0:
            return math.inf
        return math.sqrt(r / (2.0 * self.M)) / f

    def build_payload(self, r_values: List[float]) -> Dict[str, Any]:
        require(len(r_values) >= 2, "Need at least two radii.")
        r_values = sorted(r_values, reverse=True)

        taus: List[float] = []
        ts: List[float] = []

        tau_vals = [self.dtaudr(r) for r in r_values]
        t_vals = [self.dtdr(r) for r in r_values]

        tau_total = integrate_trapezoid(r_values, tau_vals)
        t_total = integrate_trapezoid(
            r_values,
            [v if math.isfinite(v) else 1e12 for v in t_vals]
        )

        sample_points: List[Dict[str, Any]] = []

        for r, dtaudr, dtdr in zip(r_values, tau_vals, t_vals):
            sample_points.append({
                "coordinates": {"t": None, "r": r, "theta": None, "phi": None},
                "curvature_invariants": {
                    "ricci_scalar": 0.0,
                    "kretschmann": 48.0 * self.M**2 / r**6,
                },
                "local_observables": {
                    "d_tau_dr": dtaudr,
                    "d_t_dr": None if not math.isfinite(dtdr) else dtdr,
                },
                "causal_structure": {
                    "horizon_radius": self.horizon(),
                    "region": (
                        "exterior (r>2M)" if r > self.horizon() else
                        ("horizon (r=2M)" if abs(r - self.horizon()) < 1e-12 else
                         "interior (r<2M)")
                    ),
                },
            })

        payload: Dict[str, Any] = {
            "toy_id": self.toy_id,
            "theory": "General Relativity (radial infall timing)",
            "spacetime": "Schwarzschild (proper vs coordinate time)",
            "units": {"G": 1, "c": 1},
            "parameters": {
                "M": self.M,
            },
            "notes": {
                "pressure_point": (
                    "Horizon crossing occurs in finite proper time but "
                    "requires infinite Schwarzschild coordinate time."
                )
            },
            "sample_points": sample_points,
            "observables": {
                "total_proper_time_tau": tau_total,
                "total_coordinate_time_t": None if not math.isfinite(t_total) else t_total,
                "horizon_radius": self.horizon(),
            },
        }

        return payload

    def export_json(self, r_values: List[float], out_path: Optional[str] = None) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)
        payload = self.build_payload(r_values)
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2, sort_keys=True)
        return out_path


# ----------------------------
# CLI
# ----------------------------

def main() -> None:
    ap = argparse.ArgumentParser(description="Toy 024: horizon crossing timescales.")
    ap.add_argument("--M", type=float, default=1.0, help="Black hole mass M")
    ap.add_argument("--r", type=str,
                    default="10,6,4,3,2.5,2.1,2.01,2.001",
                    help="Comma-separated radii (descending)")
    ap.add_argument("--out", type=str, default="",
                    help="Optional output path")
    args = ap.parse_args()

    toy = Toy024HorizonTimescales(M=args.M)
    r_values = parse_csv_floats(args.r)

    out_path = args.out.strip() or None
    json_path = toy.export_json(r_values, out_path)

    print(f"Wrote {json_path}")
    print(f"Horizon radius: r = {toy.horizon():g}")


if __name__ == "__main__":
    main()
