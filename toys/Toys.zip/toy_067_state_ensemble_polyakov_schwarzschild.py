#!/usr/bin/env python3
"""
Toy 067 — State ensemble spread on fixed geometry: Polyakov stress tensor on 2D Schwarzschild

What it probes (pressure point):
- Same classical geometry (Schwarzschild, fully fixed by M) does NOT uniquely determine
  physical stress-energy observables in semiclassical settings.
- Different quantum states (vacua) on the same metric produce different <T_ab>.
- This operationalizes "state-dependence" as an ensemble spread diagnostic.

Model (controlled approximation; geometric units G=c=1, and ħ=k_B=1 for QFT conventions):
- Consider the 2D reduction of Schwarzschild:
    ds^2 = -f(r) dt^2 + f(r)^{-1} dr^2   with f(r) = 1 - 2M/r
  and use null coordinates u=t-r*, v=t+r* with dr*/dr = 1/f.
- For a massless conformal scalar in 2D, the renormalized stress tensor takes Polyakov form:
    <T_uu> = (1/192π) f'^2 - (1/96π) f f'' + t_u
    <T_vv> = (1/192π) f'^2 - (1/96π) f f'' + t_v
    <T_uv> = (1/96π) f f''

  where t_u, t_v encode the quantum state (vacuum choice).

State choices (standard):
- Surface gravity κ = 1/(4M)
- Hawking flux constant in 2D: F = κ^2/(48π)

We take:
- Boulware:       t_u=0,  t_v=0
- Hartle-Hawking: t_u=F,  t_v=F
- Unruh:          t_u=F,  t_v=0   (outgoing flux only)

Diagnostics exported:
- <T_uu>, <T_vv>, <T_uv> for each state
- Static-frame energy density proxy: rho_static = <T_tt>/f, where <T_tt> = <T_uu>+<T_vv>+2<T_uv>
- Outgoing flux at infinity proxy: <T_uu> as r -> large
- Ensemble spread (variance across states) at each radius

Notes:
- This is a controlled semiclassical toy (QFT on fixed background), not full backreaction.
- Deterministic, numerical, minimal.

Export:
- Strict JSON schema per lab protocol.
- Undefined quantities => null; keys never omitted.
"""

from __future__ import annotations

import argparse
import json
import math
import os
from typing import Any, Dict, List, Optional, Tuple


# ----------------------------
# Helpers
# ----------------------------

def py_to_json_name(py_path: str) -> str:
    base = os.path.splitext(os.path.basename(py_path))[0]
    return base + ".json"


def require(cond: bool, msg: str) -> None:
    if not cond:
        raise ValueError(msg)


def finite_or_none(x: float) -> Optional[float]:
    return x if (isinstance(x, (int, float)) and math.isfinite(x)) else None


def parse_csv_floats(s: str) -> List[float]:
    return [float(x.strip()) for x in s.split(",") if x.strip()]


def mean(xs: List[float]) -> float:
    return sum(xs) / len(xs)


def variance(xs: List[float]) -> float:
    if len(xs) < 2:
        return 0.0
    m = mean(xs)
    return sum((x - m) ** 2 for x in xs) / (len(xs) - 1)


# ----------------------------
# Physics: 2D Schwarzschild + Polyakov stress tensor
# ----------------------------

class Toy067StateEnsemblePolyakov:
    toy_id = "067"

    def __init__(self, M: float) -> None:
        require(M > 0.0, "M must be > 0.")
        self.M = float(M)

    def horizon(self) -> float:
        return 2.0 * self.M

    def f(self, r: float) -> float:
        return 1.0 - 2.0 * self.M / r

    def fp(self, r: float) -> float:
        # derivative wrt r
        return 2.0 * self.M / (r ** 2)

    def fpp(self, r: float) -> float:
        return -4.0 * self.M / (r ** 3)

    def surface_gravity(self) -> float:
        # κ = 1/(4M)
        return 1.0 / (4.0 * self.M)

    def hawking_flux_2d(self) -> float:
        # F = κ^2 / (48π)
        k = self.surface_gravity()
        return (k * k) / (48.0 * math.pi)

    def polyakov_T_components(self, r: float, t_u: float, t_v: float) -> Dict[str, Optional[float]]:
        """
        Return <T_uu>, <T_vv>, <T_uv>, <T_tt>, rho_static = <T_tt>/f (for f>0).
        """
        if r <= 0.0:
            return {"T_uu": None, "T_vv": None, "T_uv": None, "T_tt": None, "rho_static": None}

        f = self.f(r)
        fp = self.fp(r)
        fpp = self.fpp(r)

        # Polyakov components (see docstring)
        geom = (fp * fp) / (192.0 * math.pi) - (f * fpp) / (96.0 * math.pi)
        Tuu = geom + t_u
        Tvv = geom + t_v
        Tuv = (f * fpp) / (96.0 * math.pi)

        Ttt = Tuu + Tvv + 2.0 * Tuv

        rho_static = None
        if f > 0.0:
            rho_static = Ttt / f

        return {
            "T_uu": Tuu,
            "T_vv": Tvv,
            "T_uv": Tuv,
            "T_tt": Ttt,
            "rho_static": rho_static,
        }

    def curvature_invariants(self, r: float) -> Dict[str, Optional[float]]:
        # For 4D Schwarzschild vacuum: Ricci=0 and Kretschmann=48 M^2 / r^6.
        # We export these as geometric diagnostics even though stress tensor is a 2D QFT toy.
        if r <= 0.0:
            return {"ricci_scalar": None, "kretschmann": None}
        K = 48.0 * (self.M ** 2) / (r ** 6)
        return {"ricci_scalar": 0.0, "kretschmann": K}

    def sample_point(self, r: float) -> Dict[str, Any]:
        f = self.f(r)
        F = self.hawking_flux_2d()

        # Define the three states
        states = {
            "boulware": (0.0, 0.0),
            "hartle_hawking": (F, F),
            "unruh": (F, 0.0),
        }

        per_state: Dict[str, Any] = {}
        # Collect ensemble lists for variance stats
        Tuu_list: List[float] = []
        Tvv_list: List[float] = []
        rho_list: List[float] = []
        Ttt_list: List[float] = []

        for name, (tu, tv) in states.items():
            comps = self.polyakov_T_components(r, tu, tv)
            per_state[name] = {
                "t_u": tu,
                "t_v": tv,
                "T_uu": finite_or_none(comps["T_uu"]) if comps["T_uu"] is not None else None,
                "T_vv": finite_or_none(comps["T_vv"]) if comps["T_vv"] is not None else None,
                "T_uv": finite_or_none(comps["T_uv"]) if comps["T_uv"] is not None else None,
                "T_tt": finite_or_none(comps["T_tt"]) if comps["T_tt"] is not None else None,
                "rho_static": finite_or_none(comps["rho_static"]) if comps["rho_static"] is not None else None,
            }

            # For ensemble stats: only include finite numbers
            if comps["T_uu"] is not None and math.isfinite(comps["T_uu"]):
                Tuu_list.append(comps["T_uu"])
            if comps["T_vv"] is not None and math.isfinite(comps["T_vv"]):
                Tvv_list.append(comps["T_vv"])
            if comps["T_tt"] is not None and math.isfinite(comps["T_tt"]):
                Ttt_list.append(comps["T_tt"])
            if comps["rho_static"] is not None and math.isfinite(comps["rho_static"]):
                rho_list.append(comps["rho_static"])

        # Ensemble spread diagnostics (variance across states)
        ens = {
            "T_uu_variance": finite_or_none(variance(Tuu_list)) if len(Tuu_list) >= 2 else None,
            "T_vv_variance": finite_or_none(variance(Tvv_list)) if len(Tvv_list) >= 2 else None,
            "T_tt_variance": finite_or_none(variance(Ttt_list)) if len(Ttt_list) >= 2 else None,
            "rho_static_variance": finite_or_none(variance(rho_list)) if len(rho_list) >= 2 else None,
            "note": "Variance computed across {Boulware, Hartle-Hawking, Unruh} for finite entries only.",
        }

        curv = self.curvature_invariants(r)

        return {
            "coordinates": {"t": None, "r": r, "theta": None, "phi": None},
            "curvature_invariants": {
                "ricci_scalar": finite_or_none(curv["ricci_scalar"]) if curv["ricci_scalar"] is not None else None,
                "kretschmann": finite_or_none(curv["kretschmann"]) if curv["kretschmann"] is not None else None,
                "note": "Geometry fixed by M. Stress tensor differences come from state parameters (t_u, t_v).",
            },
            "local_observables": {
                "schwarzschild_f": finite_or_none(f),
                "surface_gravity_kappa": finite_or_none(self.surface_gravity()),
                "hawking_flux_constant_F_2d": finite_or_none(F),
                "state_family": per_state,
                "ensemble_spread": ens,
            },
            "causal_structure": {
                "horizon_radius": self.horizon(),
                "region": (
                    "exterior (r>2M)" if r > self.horizon()
                    else "horizon (r=2M)" if abs(r - self.horizon()) < 1e-12
                    else "interior (r<2M)"
                ),
                "note": "Toy reports stress tensor components on the fixed background; interior values may be non-static.",
            },
        }

    def build_payload(self, r_values: List[float]) -> Dict[str, Any]:
        require(len(r_values) >= 1, "Need at least one radius.")
        sample_points = [self.sample_point(r) for r in r_values]

        # Global summary: find max ensemble variance over radii (for exterior points with finite f)
        max_rho_var = None
        max_Tuu_var = None

        for sp in sample_points:
            ens = sp["local_observables"]["ensemble_spread"]
            rv = ens.get("rho_static_variance")
            tv = ens.get("T_uu_variance")
            if rv is not None:
                max_rho_var = rv if max_rho_var is None else max(max_rho_var, rv)
            if tv is not None:
                max_Tuu_var = tv if max_Tuu_var is None else max(max_Tuu_var, tv)

        return {
            "toy_id": self.toy_id,
            "theory": "General Relativity (fixed Schwarzschild) + semiclassical QFT (2D Polyakov stress tensor)",
            "spacetime": "Schwarzschild (geometry fixed by M) with state-dependent <T_ab> (Boulware/Unruh/Hartle-Hawking)",
            "units": {"G": 1, "c": 1},
            "parameters": {
                "M": self.M,
                "r_samples": r_values,
                "conventions": "ħ = k_B = 1; 2D conformal scalar Polyakov stress tensor with state constants (t_u, t_v).",
            },
            "notes": {
                "pressure_point": (
                    "Geometry alone does not determine physical stress-energy observables: "
                    "on the same Schwarzschild metric, different quantum states yield different <T_ab>."
                ),
                "key_equations": {
                    "f": "f(r) = 1 - 2M/r",
                    "Tuu_Tvv": "<T_uu>= (f'^2)/(192π) - (f f'')/(96π) + t_u ; <T_vv>= same + t_v",
                    "Tuv": "<T_uv>= (f f'')/(96π)",
                    "hawking_flux": "F = κ^2/(48π), κ=1/(4M)",
                    "state_constants": "Boulware:(0,0) Hartle-Hawking:(F,F) Unruh:(F,0)",
                },
                "domain_of_validity": (
                    "Semiclassical 2D conformal field theory approximation on fixed background; "
                    "captures state-dependence cleanly without backreaction."
                ),
            },
            "sample_points": sample_points,
            "observables": {
                "summary": {
                    "geometry_fully_specified": True,
                    "state_family_size": 3,
                    "max_T_uu_variance_over_samples": finite_or_none(max_Tuu_var) if max_Tuu_var is not None else None,
                    "max_rho_static_variance_over_samples": finite_or_none(max_rho_var) if max_rho_var is not None else None,
                    "note": "Nonzero variance indicates state-dependent physics on fixed geometry (ensemble spread).",
                }
            },
        }

    def export_json(self, r_values: List[float], out_path: Optional[str] = None) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)
        payload = self.build_payload(r_values=r_values)
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2, sort_keys=True)
        return out_path


def main() -> None:
    ap = argparse.ArgumentParser(description="Toy 067: state ensemble spread (Polyakov stress tensor) on fixed Schwarzschild geometry.")
    ap.add_argument("--M", type=float, default=1.0, help="Mass parameter M > 0 (G=c=1)")
    ap.add_argument("--r", type=str, default="50,20,10,6,4,3,2.5,2.2,2.1",
                    help="Comma-separated radii to sample (include large r and near-horizon r~2M+)")
    ap.add_argument("--out", type=str, default="", help="Optional output JSON path")
    args = ap.parse_args()

    r_values = parse_csv_floats(args.r)
    toy = Toy067StateEnsemblePolyakov(M=float(args.M))

    out_path = args.out.strip() or None
    json_path = toy.export_json(r_values=r_values, out_path=out_path)

    print(f"Wrote {json_path}")
    print("Toy 067 complete: fixed geometry, state-dependent <T_ab> ensemble spread exported.")


if __name__ == "__main__":
    main()
