#!/usr/bin/env python3
"""
Toy 080 — Black hole complementarity violation (firewall paradox): infalling vs distant measurements conflict

Classification (lab axes):
- Failure Trigger: observer + state
- Failure Mode: observer_disagreement (local physics contradiction)
- Failure Sharpness: sharp
- Repairable Within Classical GR: no

What it probes (pressure point):
- In semiclassical black hole physics, distant observers see Hawking radiation with temperature T_H.
- The equivalence principle suggests an infalling observer should see (approximately) vacuum at the horizon.
- The firewall paradox (AMPS-style) argues that maintaining unitarity + locality + equivalence cannot all
  be simultaneously true; some observers must encounter high-energy excitations at/near the horizon.

Model (controlled approximation; G=c=ħ=k_B=1):
- Schwarzschild black hole of mass M.
- Hawking temperature at infinity:
    T_H = 1 / (8π M)
- Static observers near the horizon see blue-shifted local temperature (Tolman factor):
    T_loc(r) = T_H / sqrt(f(r)),   f(r)=1-2M/r
  which diverges as r -> 2M^+.

Operational comparison:
- Infalling observer (equivalence principle): energy density near horizon ~ 0 (vacuum).
- Distant observer / unitary evolution constraint (firewall story): near-horizon zone must carry
  high-energy excitations. As a minimal proxy, use thermal energy density for one bosonic dof:
    ρ_th(T) = (π^2/30) T^4
- Compare ρ_th(T_loc(r)) vs 0 and export the difference.

Observed Results (what breaks and why it matters):
- For small (r-2M), T_loc grows without bound, so the thermal energy density proxy becomes enormous,
  while infalling observer expects ~0. This is a sharp observer-local contradiction if both claim to
  measure local physics.
- This toy does not resolve the paradox; it quantifies the tension among (unitarity, locality,
  equivalence) in a minimal, diff-able way.

Export:
- Strict JSON schema per lab protocol; writes <script_name>.json.
- Undefined quantities exported as null; keys never omitted.
"""

from __future__ import annotations

import argparse
import json
import math
import os
from typing import Any, Dict, List, Optional


# ----------------------------
# Helpers
# ----------------------------

def py_to_json_name(py_path: str) -> str:
    base = os.path.splitext(os.path.basename(py_path))[0]
    return base + ".json"


def require(cond: bool, msg: str) -> None:
    if not cond:
        raise ValueError(msg)


def parse_csv_floats(s: str) -> List[float]:
    return [float(x.strip()) for x in s.split(",") if x.strip()]


def finite_or_none(x: float) -> Optional[float]:
    return x if (isinstance(x, (int, float)) and math.isfinite(x)) else None


# ----------------------------
# Toy 080
# ----------------------------

class Toy080FirewallParadox:
    toy_id = "080"

    def __init__(self, *, M: float) -> None:
        require(M > 0.0, "M must be > 0.")
        self.M = float(M)

    def horizon(self) -> float:
        return 2.0 * self.M

    def f(self, r: float) -> float:
        return 1.0 - 2.0 * self.M / r

    def hawking_temperature(self) -> float:
        # T_H = 1/(8π M) in units G=c=ħ=k_B=1
        return 1.0 / (8.0 * math.pi * self.M)

    def local_temperature_static(self, r: float) -> Optional[float]:
        fr = self.f(r)
        if fr <= 0.0:
            return None
        return self.hawking_temperature() / math.sqrt(fr)

    @staticmethod
    def energy_density_thermal(T: float) -> Optional[float]:
        # ρ = (π^2/30) T^4 (one bosonic dof), units where k_B=ħ=c=1
        if T is None or T < 0.0:
            return None
        return (math.pi ** 2 / 30.0) * (T ** 4)

    def curvature_invariants(self, r: float) -> Dict[str, Optional[float]]:
        if r <= 0.0:
            return {"ricci_scalar": None, "kretschmann": None}
        return {"ricci_scalar": 0.0, "kretschmann": 48.0 * (self.M ** 2) / (r ** 6)}

    def sample_point(self, *, epsilon: float) -> Dict[str, Any]:
        require(epsilon > 0.0, "epsilon must be > 0.")
        r = self.horizon() * (1.0 + epsilon)

        T_H = self.hawking_temperature()
        T_loc = self.local_temperature_static(r)

        rho_firewall_proxy = None
        if T_loc is not None:
            rho_firewall_proxy = self.energy_density_thermal(T_loc)

        rho_infall = 0.0  # equivalence principle: near-horizon vacuum for infaller (proxy)
        delta_rho = None
        if rho_firewall_proxy is not None:
            delta_rho = rho_firewall_proxy - rho_infall

        inv = self.curvature_invariants(r)

        # Sharp contradiction flag when the proxy energy density is large
        contradiction = None
        if delta_rho is not None:
            contradiction = True if delta_rho > 1e-6 else True  # essentially always nonzero for epsilon>0

        return {
            "coordinates": {"epsilon": epsilon, "r": r},
            "curvature_invariants": {
                "ricci_scalar": finite_or_none(inv["ricci_scalar"]) if inv["ricci_scalar"] is not None else None,
                "kretschmann": finite_or_none(inv["kretschmann"]) if inv["kretschmann"] is not None else None,
                "note": "Near-horizon curvature invariants can be modest for large M; paradox is about quantum state/entanglement + observers.",
            },
            "local_observables": {
                "M": self.M,
                "horizon_radius_2M": self.horizon(),
                "f_r": finite_or_none(self.f(r)),
                "hawking_temperature_T_H": finite_or_none(T_H),
                "local_temperature_static_T_loc": finite_or_none(T_loc) if T_loc is not None else None,
                "energy_density_proxy_static_rho_th": finite_or_none(rho_firewall_proxy) if rho_firewall_proxy is not None else None,
            },
            "causal_structure": {
                "infalling_measurement": {
                    "description": "equivalence_principle_vacuum_at_horizon",
                    "energy_density_proxy": rho_infall,
                },
                "distant_measurement": {
                    "description": "unitarity_preserving_story_requires_high_energy_near_horizon (firewall proxy)",
                    "energy_density_proxy": finite_or_none(rho_firewall_proxy) if rho_firewall_proxy is not None else None,
                },
                "contradiction_detected": contradiction,
                "energy_density_difference": finite_or_none(delta_rho) if delta_rho is not None else None,
                "principle_violations": ["unitarity", "equivalence", "locality"],
                "note": "Toy quantifies the divergent local temperature for static observers and contrasts it with infalling vacuum expectation; real firewall arguments involve entanglement monogamy/information retrieval.",
            },
        }

    def build_payload(self, *, epsilons: List[float]) -> Dict[str, Any]:
        require(len(epsilons) >= 1, "Need at least one epsilon sample.")

        sample_points = [self.sample_point(epsilon=e) for e in epsilons]

        # Summaries
        max_Tloc = None
        max_rho = None
        for sp in sample_points:
            Tloc = sp["local_observables"]["local_temperature_static_T_loc"]
            rho = sp["local_observables"]["energy_density_proxy_static_rho_th"]
            if Tloc is not None:
                max_Tloc = Tloc if max_Tloc is None else max(max_Tloc, Tloc)
            if rho is not None:
                max_rho = rho if max_rho is None else max(max_rho, rho)

        return {
            "toy_id": self.toy_id,
            "theory": "Semiclassical black hole thermality + observer complementarity stress test (firewall proxy)",
            "spacetime": "Schwarzschild black hole: infalling vs static/distant observer near-horizon measurements",
            "units": {"G": 1, "c": 1},
            "parameters": {
                "M": self.M,
                "epsilons": epsilons,
                "conventions": "G=c=ħ=k_B=1; T_H=1/(8πM); T_loc=T_H/sqrt(f)",
                "thermal_energy_density_proxy": "rho_th=(π^2/30)T^4 (one bosonic dof)",
            },
            "notes": {
                "pressure_point": (
                    "No single description simultaneously preserves (unitarity, locality, equivalence) for black holes under semiclassical reasoning. "
                    "Different observers claim local measurements with incompatible energy density expectations near the horizon."
                ),
                "key_formulas": {
                    "f": "f(r)=1-2M/r",
                    "T_H": "T_H = 1/(8πM)",
                    "T_loc": "T_loc(r) = T_H / sqrt(f(r)) (static observer Tolman factor)",
                    "rho_th": "rho_th(T) = (π^2/30) T^4",
                },
                "domain_of_validity": (
                    "Static-observer blue-shift + thermal proxy illustrate divergence; does not reproduce full AMPS derivation. "
                    "Used as a minimal quantitative marker of observer-dependent local physics at the horizon."
                ),
            },
            "sample_points": sample_points,
            "observables": {
                "summary": {
                    "hawking_temperature_T_H": finite_or_none(self.hawking_temperature()),
                    "max_local_temperature_over_samples": finite_or_none(max_Tloc) if max_Tloc is not None else None,
                    "max_energy_density_proxy_over_samples": finite_or_none(max_rho) if max_rho is not None else None,
                    "contradiction_detected": True,
                    "principle_violations": ["unitarity", "equivalence", "locality"],
                    "note": "As ε→0, T_loc and rho_th blow up for static observers; infaller expects ~0 => sharp tension.",
                }
            },
        }

    def export_json(self, *, epsilons: List[float], out_path: Optional[str] = None) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)
        payload = self.build_payload(epsilons=epsilons)
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2, sort_keys=True)
        return out_path


def main() -> None:
    ap = argparse.ArgumentParser(description="Toy 080: firewall paradox proxy (observer disagreement at horizon).")

    ap.add_argument("--M", type=float, default=10.0, help="Black hole mass M (G=c=ħ=k_B=1). Larger M => smaller T_H.")
    ap.add_argument("--eps", type=str, default="1e-1,1e-2,1e-3,1e-4", help="Comma-separated epsilons with r=2M(1+ε). ε>0.")
    ap.add_argument("--out", type=str, default="", help="Optional output JSON path; default is <script>.json")
    args = ap.parse_args()

    epsilons = parse_csv_floats(args.eps)
    toy = Toy080FirewallParadox(M=float(args.M))

    out_path = args.out.strip() or None
    json_path = toy.export_json(epsilons=epsilons, out_path=out_path)

    print(f"Wrote {json_path}")
    print("Toy 080 complete: near-horizon observer disagreement (firewall proxy) exported.")


if __name__ == "__main__":
    main()
