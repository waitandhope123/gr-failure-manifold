#!/usr/bin/env python3
"""
Toy 002 — Newtonian point-mass gravity (weak-field limit reference)

What it probes (weak points / pressure points):
- Separates "spacetime curvature" (GR) from "potential-based gravity" (Newtonian).
- Provides Newtonian tidal tensor eigenvalues (Hessian of Φ) to compare with GR tidal eigenvalues.
- Provides weak-field clock-rate and redshift predictions derived from Φ (standard weak-field results).
- Highlights what Newtonian cannot represent: curvature invariants, horizons, true causal structure.

STRICT EXPORT RULE:
- Writes JSON named exactly like this .py file (toy_002_newtonian_point_mass.json).
- JSON follows the canonical schema with required keys and required subkeys.
- Undefined / inapplicable GR-only quantities are exported as null (JSON null).

Units:
- Default geometric units: G = c = 1.
- Newtonian potential: Φ(r) = - M / r  (dimensionless in these units).
"""

from __future__ import annotations

import argparse
import json
import math
import os
from typing import Any, Dict, List, Optional


# ----------------------------
# Helpers
# ----------------------------

def py_to_json_name(py_path: str) -> str:
    base = os.path.splitext(os.path.basename(py_path))[0]
    return base + ".json"


def parse_csv_floats(s: str) -> List[float]:
    return [float(x.strip()) for x in s.split(",") if x.strip()]


def parse_round_trip_cases(s: str) -> List[Dict[str, float]]:
    """
    Parse cases like: "10:6,20:6" -> [{"r_start":10,"r_turn":6}, ...]
    These are used for a Newtonian-approx "light travel time" baseline
    (flat-space coordinate time with an optional first-order potential correction).
    """
    out: List[Dict[str, float]] = []
    if not s.strip():
        return out
    for chunk in s.split(","):
        chunk = chunk.strip()
        if not chunk:
            continue
        a, b = chunk.split(":")
        out.append({"r_start": float(a), "r_turn": float(b)})
    return out


def require(cond: bool, msg: str) -> None:
    if not cond:
        raise ValueError(msg)


# ----------------------------
# Toy 002: Newtonian point mass
# ----------------------------

class Toy002NewtonianPointMass:
    """
    Newtonian gravity of a point mass M:

      Φ(r) = - M / r

    Weak-field clock and redshift (standard result):
      - Proper time rate relative to far away (in weak field):
          dτ/dt ≈ 1 + Φ    (first order in |Φ| << 1)
        (More "GR-like" weak-field form sometimes written as sqrt(1 + 2Φ) ≈ 1 + Φ.)

      - Gravitational redshift between static observers:
          z ≈ Φ_receiver - Φ_emitter   (first order)

    Newtonian tidal tensor:
      E_ij = ∂i∂j Φ
    For a point mass in vacuum (r>0), eigenvalues are:
      λ_radial     = +2M / r^3
      λ_transverse = - M / r^3  (degenerate, two directions)
    Note: GR tidal eigenvalues in an orthonormal static frame have opposite signs
    under some conventions; this toy exports the Newtonian Hessian eigenvalues as stated.
    """

    toy_id = "002"

    def __init__(self, M: float = 1.0) -> None:
        require(M > 0.0, "M must be > 0.")
        self.M = float(M)

    # --- Core potential ---

    def phi(self, r: float) -> float:
        require(r > 0.0, "r must be > 0.")
        return -self.M / r

    # --- "Curvature invariants" (not defined in Newtonian theory) ---

    def curvature_invariants(self, r: float) -> Dict[str, Any]:
        # Newtonian gravity does not define spacetime curvature scalars.
        # Keep keys but set to null.
        require(r > 0.0, "r must be > 0.")
        return {
            "ricci_scalar": None,
            "kretschmann": None,
        }

    # --- Local observables derived from Φ (weak-field) ---

    def time_dilation_weak_field(self, r: float) -> float:
        """
        First-order weak-field time dilation relative to infinity:
          dτ/dt ≈ 1 + Φ(r)
        Valid only for |Φ| << 1 (weak field).
        """
        require(r > 0.0, "r must be > 0.")
        return 1.0 + self.phi(r)

    def tidal_eigenvalues_newtonian(self, r: float) -> Dict[str, float]:
        """
        Eigenvalues of Hessian of Φ for point mass:
          radial: +2M/r^3
          transverse: -M/r^3 (degenerate)
        """
        require(r > 0.0, "r must be > 0.")
        return {
            "radial": 2.0 * self.M / (r ** 3),
            "transverse": -1.0 * self.M / (r ** 3),
        }

    # --- Causal structure (Newtonian has no light cones) ---

    def causal_structure(self, r: float) -> Dict[str, Any]:
        require(r > 0.0, "r must be > 0.")
        return {
            "radial_null_cone_dr_dt": None,  # not a Newtonian concept
            "horizon_radius": None,          # not a Newtonian concept
            "region": "Newtonian gravity has no horizons; singular source at r=0",
        }

    # --- Experiment-style observables ---

    def redshift_weak_field(self, r_emitter: float, r_receiver: float) -> float:
        """
        First-order gravitational redshift:
          z ≈ Φ(receiver) - Φ(emitter)
        """
        require(r_emitter > 0.0 and r_receiver > 0.0, "r_emitter and r_receiver must be > 0.")
        return self.phi(r_receiver) - self.phi(r_emitter)

    def round_trip_light_time_flat(self, r_start: float, r_turn: float) -> float:
        """
        Newtonian baseline for a 'light-like' round trip in flat space (c=1):
          Δt_flat = 2 * (r_start - r_turn)

        This is NOT a GR Shapiro delay; it's a control baseline that Newtonian gives you.
        """
        require(r_start > 0.0 and r_turn > 0.0, "r_start and r_turn must be > 0.")
        require(r_turn < r_start, "require r_turn < r_start.")
        return 2.0 * (r_start - r_turn)

    def round_trip_light_time_with_first_order_potential(self, r_start: float, r_turn: float) -> float:
        """
        Optional heuristic first-order correction often used in weak-field 'effective metric' discussions:
          dt ≈ (1 - 2Φ) dr  (schematic)
        This is NOT Newtonian physics strictly; it's a weak-field relativistic add-on.
        We include it as a labeled 'heuristic' output to compare trends.

        We model:
          Δt ≈ 2 * ∫_{r_turn}^{r_start} (1 - 2Φ(r)) dr
             = 2 * [(r_start - r_turn) - 2∫Φ dr]
        With Φ = -M/r:
          ∫Φ dr = ∫(-M/r) dr = -M ln r
        So:
          Δt ≈ 2 * [(r_start - r_turn) + 2M ln(r_start/r_turn)]
        """
        require(r_start > 0.0 and r_turn > 0.0, "r_start and r_turn must be > 0.")
        require(r_turn < r_start, "require r_turn < r_start.")
        return 2.0 * ((r_start - r_turn) + 2.0 * self.M * math.log(r_start / r_turn))

    # --- Canonical export payload ---

    def build_payload(
        self,
        r_values: List[float],
        redshift_pairs: List[Dict[str, Any]],
        round_trip_cases: List[Dict[str, float]],
        include_heuristic_light_time: bool,
    ) -> Dict[str, Any]:

        sample_points: List[Dict[str, Any]] = []
        for r in r_values:
            r = float(r)
            require(r > 0.0, "All sample radii must be > 0.")

            coordinates = {"r": r, "theta": None, "phi": None, "t": None}

            curvature_invariants = self.curvature_invariants(r)

            local_observables = {
                "potential_phi": self.phi(r),
                "time_dilation_dtaudt_weak_field_relative_to_infinity": self.time_dilation_weak_field(r),
                "tidal_eigenvalues_newtonian_hessian": self.tidal_eigenvalues_newtonian(r),
                "validity": {
                    "weak_field_recommended_if": "|Phi| << 1",
                    "phi_value": self.phi(r),
                },
            }

            causal_structure = self.causal_structure(r)

            sample_points.append({
                "coordinates": coordinates,
                "curvature_invariants": curvature_invariants,
                "local_observables": local_observables,
                "causal_structure": causal_structure,
            })

        obs_redshift: List[Dict[str, Any]] = []
        for pair in redshift_pairs:
            r_emit = float(pair["r_emitter"])
            r_recv = pair["r_receiver"]
            if r_recv == "infinity":
                # In this toy, "infinity" means Φ=0
                require(r_emit > 0.0, "r_emitter must be > 0.")
                z = 0.0 - self.phi(r_emit)
                obs_redshift.append({
                    "r_emitter": r_emit,
                    "r_receiver": "infinity",
                    "z_weak_field": z,
                })
            else:
                r_recv_f = float(r_recv)
                z = self.redshift_weak_field(r_emit, r_recv_f)
                obs_redshift.append({
                    "r_emitter": r_emit,
                    "r_receiver": r_recv_f,
                    "z_weak_field": z,
                })

        obs_round_trip: List[Dict[str, Any]] = []
        for case in round_trip_cases:
            r_start = float(case["r_start"])
            r_turn = float(case["r_turn"])
            entry: Dict[str, Any] = {
                "r_start": r_start,
                "r_turn": r_turn,
                "delta_t_flat_c_equals_1": None,
                "delta_t_heuristic_first_order_potential": None,
                "valid": None,
            }
            if r_start > 0.0 and r_turn > 0.0 and r_turn < r_start:
                entry["delta_t_flat_c_equals_1"] = self.round_trip_light_time_flat(r_start, r_turn)
                if include_heuristic_light_time:
                    entry["delta_t_heuristic_first_order_potential"] = self.round_trip_light_time_with_first_order_potential(
                        r_start, r_turn
                    )
                entry["valid"] = True
            else:
                entry["valid"] = False
            obs_round_trip.append(entry)

        payload: Dict[str, Any] = {
            # REQUIRED TOP-LEVEL KEYS
            "toy_id": self.toy_id,
            "theory": "Newtonian Gravity (weak-field reference)",
            "spacetime": "None (absolute time; Euclidean space)",
            "units": {"G": 1, "c": 1},
            "parameters": {"M": self.M},
            "notes": {
                "assumptions": [
                    "Point mass potential Φ(r) = -M/r",
                    "No spacetime curvature; absolute time",
                    "Weak-field relativistic relations used only where explicitly labeled",
                ],
                "singularity": "r = 0 (potential diverges; point source idealization)",
                "cannot_represent": [
                    "event horizons",
                    "light cones / causal structure as in relativity",
                    "spacetime curvature invariants (Ricci, Kretschmann, etc.)",
                ],
                "weak_field_guidance": "Compare with GR when |Phi| << 1; near r ~ M the approximation degrades.",
            },
            "sample_points": sample_points,
            "observables": {
                "gravitational_redshift_weak_field": obs_redshift,
                "round_trip_light_time_baseline": obs_round_trip,
            },
        }

        return payload

    def export_json(
        self,
        r_values: List[float],
        redshift_pairs: List[Dict[str, Any]],
        round_trip_cases: List[Dict[str, float]],
        include_heuristic_light_time: bool,
        out_path: Optional[str] = None,
    ) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)

        payload = self.build_payload(r_values, redshift_pairs, round_trip_cases, include_heuristic_light_time)
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2, sort_keys=True)
        return out_path


# ----------------------------
# CLI
# ----------------------------

def main() -> None:
    ap = argparse.ArgumentParser(description="Toy 002: Newtonian point mass exporter (weak-field reference).")
    ap.add_argument("--M", type=float, default=1.0, help="Mass parameter M (geometric units)")
    ap.add_argument("--r", type=str, default="3,4,6,10,20,50",
                    help="Comma-separated radii for sample points (r>0)")
    ap.add_argument("--redshift_emitters", type=str, default="6,10,20",
                    help="Comma-separated r_emit values; receiver defaults to infinity (Phi=0)")
    ap.add_argument("--round_trip", type=str, default="10:6,20:6",
                    help="Comma-separated cases r_start:r_turn for round-trip time baseline")
    ap.add_argument("--include_heuristic_light_time", action="store_true",
                    help="Include labeled first-order potential heuristic for light time (NOT pure Newtonian)")
    ap.add_argument("--out", type=str, default="",
                    help="Optional output path. If omitted, uses <this_script_name>.json")

    args = ap.parse_args()

    r_values = parse_csv_floats(args.r)
    emitters = parse_csv_floats(args.redshift_emitters)
    round_trip_cases = parse_round_trip_cases(args.round_trip)

    # Build redshift pairs: emitter -> infinity
    redshift_pairs = [{"r_emitter": r_e, "r_receiver": "infinity"} for r_e in emitters]

    toy = Toy002NewtonianPointMass(M=args.M)

    out_path = args.out.strip() or None
    json_path = toy.export_json(
        r_values=r_values,
        redshift_pairs=redshift_pairs,
        round_trip_cases=round_trip_cases,
        include_heuristic_light_time=bool(args.include_heuristic_light_time),
        out_path=out_path,
    )

    print(f"Wrote {json_path}")
    print("Note: curvature invariants and relativistic causal structure are null by design (Newtonian theory).")
    print("Weak-field guidance: use regions where |Phi| << 1 for best comparison to GR.")


if __name__ == "__main__":
    main()
