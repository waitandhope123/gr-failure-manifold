#!/usr/bin/env python3
"""
Toy 058 — Thin-shell junction (Israel conditions): Minkowski interior ↔ Schwarzschild exterior

What it probes (pressure point):
- “Gluing spacetimes” is not free: junction conditions enforce distributional stress-energy.
- Curvature invariants can be perfectly regular on each side, while the shell carries a delta-function
  stress-energy and induces a jump in extrinsic curvature.
- Operationally: the dynamics are encoded in the extrinsic curvature jump, not local scalars.

Model (G=c=1):
- Spherically symmetric, pressureless (dust) thin shell at areal radius R(τ).
- Interior: Minkowski (M_in = 0) => f_in(R)=1
- Exterior: Schwarzschild mass M (M_out = M) => f_out(R)=1-2M/R
- Shell rest mass m0 (a constant): m0 = 4π R^2 σ  where σ is surface energy density.

Israel junction condition for a spherical dust shell:
    sqrt(Rdot^2 + f_out) - sqrt(Rdot^2 + f_in) = - m0 / R

With f_in=1, this yields the standard energy equation:
    sqrt(Rdot^2 + 1) = M/m0 + m0/(2R)
=>  Rdot^2 = (M/m0 + m0/(2R))^2 - 1

Extrinsic curvature (angular component) on each side:
    K^θ_θ(±) = + sqrt(Rdot^2 + f_±) / R    (sign choice fixed for outward normal conventions)
Jump:
    [K^θ_θ] = K^θ_θ(out) - K^θ_θ(in) = - m0 / R^2   (equivalent to -4π σ)

Numerics:
- Integrate R(τ) using RK4 on the collapsing branch (Rdot = -sqrt(...)).
- Supports two modes:
  (A) "compute_M_for_rest": choose R0,m0 and set M so that Rdot(τ0)=0 at R0.
      From Rdot=0 at R0 => M/m0 + m0/(2R0) = 1 => M = m0 (1 - m0/(2R0)).
  (B) "use_given_M": choose R0,m0,M and integrate with Rdot from the energy equation
      (may start with inward/outward motion depending on parameters).

Exports:
- Sample points along τ with R, Rdot, σ, K jumps, and horizon crossing diagnostics.
"""

from __future__ import annotations

import argparse
import json
import math
import os
from typing import Any, Dict, List, Optional


# ----------------------------
# Helpers
# ----------------------------

def py_to_json_name(py_path: str) -> str:
    base = os.path.splitext(os.path.basename(py_path))[0]
    return base + ".json"


def require(cond: bool, msg: str) -> None:
    if not cond:
        raise ValueError(msg)


def finite_or_none(x: float) -> Optional[float]:
    return x if math.isfinite(x) else None


def parse_csv_floats(s: str) -> List[float]:
    return [float(x.strip()) for x in s.split(",") if x.strip()]


# ----------------------------
# Toy 058
# ----------------------------

class Toy058ThinShellJunction:
    toy_id = "058"

    def __init__(
        self,
        *,
        R0: float = 10.0,
        m0: float = 1.0,
        M: Optional[float] = None,
        mode: str = "compute_M_for_rest",   # or "use_given_M"
        dtao: float = 0.01,
        tau_max: float = 50.0,
        R_stop: float = 2.0,               # stop before singularity / extremely small R
    ) -> None:
        require(R0 > 0.0, "R0 must be > 0.")
        require(m0 > 0.0, "m0 must be > 0.")
        require(dtao > 0.0 and tau_max > 0.0, "dtao and tau_max must be > 0.")
        require(R_stop > 0.0, "R_stop must be > 0.")
        require(mode in ("compute_M_for_rest", "use_given_M"), "mode must be compute_M_for_rest|use_given_M")

        self.R0 = float(R0)
        self.m0 = float(m0)
        self.mode = mode
        self.dtao = float(dtao)
        self.tau_max = float(tau_max)
        self.R_stop = float(R_stop)

        if mode == "compute_M_for_rest":
            # From Rdot(R0)=0:  M = m0 (1 - m0/(2R0))
            self.M = self.m0 * (1.0 - self.m0 / (2.0 * self.R0))
        else:
            require(M is not None, "M must be provided for mode=use_given_M")
            self.M = float(M)

        require(self.M >= 0.0, "M must be >= 0.")
        # For a physical exterior BH horizon, need M>0
        # Also avoid pathological rest-mass larger than 2R0 in rest-mode (would make M negative)
        if self.mode == "compute_M_for_rest":
            require(self.m0 < 2.0 * self.R0, "For compute_M_for_rest, require m0 < 2R0 so M>=0.")

    def horizon(self) -> Optional[float]:
        return 2.0 * self.M if self.M > 0.0 else None

    def f_in(self, R: float) -> float:
        # Minkowski interior
        return 1.0

    def f_out(self, R: float) -> float:
        # Schwarzschild exterior
        return 1.0 - 2.0 * self.M / R

    def Rdot_sq(self, R: float) -> Optional[float]:
        if R <= 0.0:
            return None
        term = (self.M / self.m0) + (self.m0 / (2.0 * R))
        val = term * term - 1.0
        return val if math.isfinite(val) else None

    def Rdot(self, R: float) -> Optional[float]:
        v2 = self.Rdot_sq(R)
        if v2 is None:
            return None
        if v2 < 0.0:
            # no real motion with these parameters at this R (turning point region)
            return None
        return -math.sqrt(v2)  # collapsing branch

    def sigma(self, R: float) -> Optional[float]:
        # m0 = 4π R^2 σ
        if R <= 0.0:
            return None
        return self.m0 / (4.0 * math.pi * R * R)

    def K_theta_theta(self, R: float, side: str) -> Optional[float]:
        """
        K^θ_θ for spherical shell embedding in each side geometry.
        Use K^θ_θ = sqrt(Rdot^2 + f)/R.
        """
        require(side in ("in", "out"), "side must be 'in' or 'out'")
        v2 = self.Rdot_sq(R)
        if v2 is None:
            return None
        f = self.f_in(R) if side == "in" else self.f_out(R)
        inside = v2 + f
        if inside < 0.0:
            return None
        return math.sqrt(inside) / R

    def jump_K_theta_theta(self, R: float) -> Optional[float]:
        Kin = self.K_theta_theta(R, "in")
        Kout = self.K_theta_theta(R, "out")
        if Kin is None or Kout is None:
            return None
        return Kout - Kin

    def integrate(self) -> Dict[str, Any]:
        tau = 0.0
        R = self.R0

        traj: List[Dict[str, float]] = []

        def record() -> None:
            v = self.Rdot(R)
            v2 = self.Rdot_sq(R)
            sig = self.sigma(R)
            Kin = self.K_theta_theta(R, "in")
            Kout = self.K_theta_theta(R, "out")
            dK = self.jump_K_theta_theta(R)

            # Invariants: interior Minkowski (0), exterior Schwarzschild at shell (vacuum)
            Kext = 48.0 * (self.M ** 2) / (R ** 6) if (self.M > 0.0 and R > 0.0) else 0.0

            rh = self.horizon()
            inside_h = (R < rh) if rh is not None else False

            traj.append({
                "tau": tau,
                "R": R,
                "Rdot": v if v is not None else float("nan"),
                "Rdot_sq": v2 if v2 is not None else float("nan"),
                "sigma": sig if sig is not None else float("nan"),
                "Ktheta_in": Kin if Kin is not None else float("nan"),
                "Ktheta_out": Kout if Kout is not None else float("nan"),
                "jump_Ktheta": dK if dK is not None else float("nan"),
                "Kretschmann_exterior_at_shell": Kext,
                "inside_horizon": 1.0 if inside_h else 0.0,
            })

        record()

        steps = int(round(self.tau_max / self.dtao))
        stopped_reason = "tau_max_reached"
        crossed_horizon_tau: Optional[float] = None

        for _ in range(steps):
            if R <= self.R_stop:
                stopped_reason = "R_stop_reached"
                break

            rh = self.horizon()
            if rh is not None and crossed_horizon_tau is None and R <= rh:
                crossed_horizon_tau = tau

            # RK4 for dR/dtau = Rdot(R)
            def f(r: float) -> float:
                v = self.Rdot(r)
                # If undefined (no real motion), stop by returning NaN
                return v if v is not None else float("nan")

            k1 = f(R)
            k2 = f(R + 0.5 * self.dtao * k1)
            k3 = f(R + 0.5 * self.dtao * k2)
            k4 = f(R + self.dtao * k3)

            if not (math.isfinite(k1) and math.isfinite(k2) and math.isfinite(k3) and math.isfinite(k4)):
                stopped_reason = "turning_point_or_invalid_region"
                break

            R_next = R + (self.dtao / 6.0) * (k1 + 2.0 * k2 + 2.0 * k3 + k4)
            tau += self.dtao
            R = R_next

            if R <= 0.0:
                stopped_reason = "nonphysical_R_le_0"
                break

            record()

        return {
            "traj": traj,
            "stopped_reason": stopped_reason,
            "crossed_horizon_tau": crossed_horizon_tau,
        }

    def build_payload(self, tau_samples: Optional[List[float]] = None, n_samples: int = 80) -> Dict[str, Any]:
        require(n_samples >= 10, "n_samples must be >= 10.")
        sol = self.integrate()
        traj = sol["traj"]

        # Choose sample indices along the trajectory
        idxs: List[int] = []
        if len(traj) <= n_samples:
            idxs = list(range(len(traj)))
        else:
            for i in range(n_samples):
                j = int(round(i * (len(traj) - 1) / (n_samples - 1)))
                idxs.append(j)
            idxs = sorted(set(idxs))

        sample_points: List[Dict[str, Any]] = []
        for j in idxs:
            row = traj[j]
            tau = float(row["tau"])
            R = float(row["R"])

            sig = row["sigma"]
            Kin = row["Ktheta_in"]
            Kout = row["Ktheta_out"]
            dK = row["jump_Ktheta"]

            # Expectation from Israel: jump ≈ -m0/R^2
            dK_expected = -self.m0 / (R * R) if R > 0.0 else None
            dK_residual = (dK - dK_expected) if (math.isfinite(dK) and dK_expected is not None) else None

            sample_points.append({
                "coordinates": {"tau": tau, "R": R},
                "curvature_invariants": {
                    "ricci_scalar_interior": 0.0,
                    "kretschmann_interior": 0.0,
                    "ricci_scalar_exterior": 0.0,
                    "kretschmann_exterior_at_shell": finite_or_none(float(row["Kretschmann_exterior_at_shell"])),
                },
                "local_observables": {
                    "Rdot": finite_or_none(float(row["Rdot"])) if math.isfinite(row["Rdot"]) else None,
                    "shell_rest_mass_m0": self.m0,
                    "shell_surface_density_sigma": finite_or_none(float(sig)) if math.isfinite(sig) else None,
                    "Ktheta_in": finite_or_none(float(Kin)) if math.isfinite(Kin) else None,
                    "Ktheta_out": finite_or_none(float(Kout)) if math.isfinite(Kout) else None,
                    "jump_Ktheta_out_minus_in": finite_or_none(float(dK)) if math.isfinite(dK) else None,
                    "jump_Ktheta_expected_minus_m0_over_R2": finite_or_none(dK_expected) if dK_expected is not None else None,
                    "jump_Ktheta_residual": finite_or_none(dK_residual) if dK_residual is not None else None,
                },
                "causal_structure": {
                    "horizon_radius_2M": self.horizon(),
                    "inside_horizon": bool(row["inside_horizon"] > 0.5),
                    "note": (
                        "Both sides can have perfectly regular vacuum invariants, while the shell’s "
                        "distributional stress-energy appears through the extrinsic curvature jump."
                    ),
                },
            })

        # Global summary
        R_start = traj[0]["R"]
        R_end = traj[-1]["R"]
        tau_end = traj[-1]["tau"]

        # Horizon crossing
        rh = self.horizon()
        crossed = sol["crossed_horizon_tau"]

        # Diagnostic: max relative residual of Israel jump among sampled points
        max_rel_resid = 0.0
        for sp in sample_points:
            dK = sp["local_observables"]["jump_Ktheta_out_minus_in"]
            dKexp = sp["local_observables"]["jump_Ktheta_expected_minus_m0_over_R2"]
            resid = sp["local_observables"]["jump_Ktheta_residual"]
            if dK is None or dKexp is None or resid is None:
                continue
            denom = abs(dKexp) if abs(dKexp) > 0 else 1.0
            max_rel_resid = max(max_rel_resid, abs(resid) / denom)

        return {
            "toy_id": self.toy_id,
            "theory": "General Relativity (Israel junction conditions)",
            "spacetime": "Minkowski interior matched to Schwarzschild exterior across a dust thin shell",
            "units": {"G": 1, "c": 1},
            "parameters": {
                "mode": self.mode,
                "R0": self.R0,
                "m0": self.m0,
                "M_exterior": self.M,
                "d_tau": self.dtao,
                "tau_max": self.tau_max,
                "R_stop": self.R_stop,
                "n_samples_exported": len(sample_points),
            },
            "notes": {
                "assumptions": [
                    "Spherical symmetry",
                    "Pressureless dust shell (surface pressure = 0)",
                    "Interior is exact Minkowski (M_in=0)",
                    "Exterior is exact Schwarzschild (M_out=M)",
                    "Shell dynamics from Israel junction condition",
                    "Collapsing branch chosen (Rdot <= 0 when real)",
                ],
                "pressure_point": (
                    "Junction conditions encode distributional matter: spacetimes do not glue smoothly. "
                    "The physical content appears in extrinsic curvature jumps even when local invariants "
                    "are vacuum-like on either side."
                ),
                "key_equations": {
                    "israel_shell": "sqrt(Rdot^2+f_out) - sqrt(Rdot^2+f_in) = -m0/R",
                    "energy_eq": "Rdot^2 = (M/m0 + m0/(2R))^2 - 1 (for Minkowski interior)",
                    "Ktheta": "K^θ_θ(±) = sqrt(Rdot^2 + f_±)/R",
                    "jump_relation": "[K^θ_θ]=Kout-Kin = -m0/R^2 = -4πσ",
                },
            },
            "sample_points": sample_points,
            "observables": {
                "global": {
                    "R_start": finite_or_none(float(R_start)),
                    "R_end": finite_or_none(float(R_end)),
                    "tau_end": finite_or_none(float(tau_end)),
                    "stopped_reason": sol["stopped_reason"],
                    "horizon_radius_2M": rh,
                    "horizon_crossed_tau": crossed,
                    "max_relative_israel_jump_residual_over_samples": finite_or_none(max_rel_resid),
                    "note": (
                        "Residuals should be ~0 up to floating error because jump_K is computed from the same equation "
                        "used to evolve R(τ). If you modify K definitions or sign conventions, this becomes a strong "
                        "sanity test for junction implementation."
                    ),
                }
            },
        }

    def export_json(self, out_path: Optional[str] = None, n_samples: int = 80) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)
        payload = self.build_payload(n_samples=n_samples)
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2, sort_keys=True)
        return out_path


# ----------------------------
# CLI
# ----------------------------

def main() -> None:
    ap = argparse.ArgumentParser(description="Toy 058: thin-shell Israel junction (Minkowski interior ↔ Schwarzschild exterior).")
    ap.add_argument("--mode", type=str, default="compute_M_for_rest",
                    choices=["compute_M_for_rest", "use_given_M"],
                    help="Compute M for rest-at-R0 or use provided M")
    ap.add_argument("--R0", type=float, default=10.0, help="Initial areal radius R0 > 0")
    ap.add_argument("--m0", type=float, default=1.0, help="Shell rest mass m0 > 0")
    ap.add_argument("--M", type=float, default=0.8, help="Exterior Schwarzschild mass M (used only in mode=use_given_M)")
    ap.add_argument("--d_tau", type=float, default=0.01, help="Proper-time step dτ")
    ap.add_argument("--tau_max", type=float, default=50.0, help="Max proper time to integrate")
    ap.add_argument("--R_stop", type=float, default=2.0, help="Stop integration when R <= R_stop")
    ap.add_argument("--n_samples", type=int, default=80, help="Number of sample_points to export (>=10)")
    ap.add_argument("--out", type=str, default="", help="Optional output path")
    args = ap.parse_args()

    toy = Toy058ThinShellJunction(
        R0=float(args.R0),
        m0=float(args.m0),
        M=float(args.M) if args.mode == "use_given_M" else None,
        mode=str(args.mode),
        dtao=float(args.d_tau),
        tau_max=float(args.tau_max),
        R_stop=float(args.R_stop),
    )

    out_path = args.out.strip() or None
    json_path = toy.export_json(out_path=out_path, n_samples=int(args.n_samples))

    print(f"Wrote {json_path}")
    print("Toy 058 complete: thin-shell Israel junction.")


if __name__ == "__main__":
    main()
