#!/usr/bin/env python3
"""
Toy 028 — Singularity approach timescales (proper time remaining to r=0)

Model (G=c=1):
Schwarzschild spacetime.
Radial infall from rest at infinity (energy per unit mass E=1).

Key relations:
  dr/dτ = -sqrt(2M/r)
  => τ_remaining_to_r0 = ∫_r^r0 dr / sqrt(2M/r)
  => Δτ(r0->r) = (2/3) * (r0^(3/2) - r^(3/2)) / sqrt(2M)
  => τ_to_singularity_from_r = (2/3) * r^(3/2) / sqrt(2M)

Notes:
- Proper time to r=0 is finite for any finite starting radius r0.
- Schwarzschild coordinate time t is only exported via dt/dr in the exterior (r>2M);
  inside the horizon we return null for dt/dr (since Schwarzschild t is not a good time there).
"""

from __future__ import annotations

import argparse
import json
import math
import os
from typing import Any, Dict, List, Optional


# ----------------------------
# Helpers
# ----------------------------

def py_to_json_name(py_path: str) -> str:
    base = os.path.splitext(os.path.basename(py_path))[0]
    return base + ".json"


def parse_csv_floats(s: str) -> List[float]:
    return [float(x.strip()) for x in s.split(",") if x.strip()]


def require(cond: bool, msg: str) -> None:
    if not cond:
        raise ValueError(msg)


# ----------------------------
# Toy 028
# ----------------------------

class Toy028SingularityApproachTimescales:
    toy_id = "028"

    def __init__(self, M: float = 1.0) -> None:
        require(M > 0.0, "M must be > 0.")
        self.M = float(M)

    def horizon(self) -> float:
        return 2.0 * self.M

    def f(self, r: float) -> float:
        require(r > 0.0, "r must be > 0.")
        return 1.0 - 2.0 * self.M / r

    # Curvature invariants (Schwarzschild vacuum)
    def ricci_scalar(self, r: float) -> float:
        return 0.0

    def kretschmann(self, r: float) -> float:
        return 48.0 * (self.M ** 2) / (r ** 6)

    # Infall kinematics for E=1
    def dr_dtau(self, r: float) -> float:
        # dr/dτ = -sqrt(2M/r)
        return -math.sqrt(2.0 * self.M / r)

    def dt_dr_exterior(self, r: float) -> Optional[float]:
        # For E=1 radial infall, exterior only:
        # dt/dr = sqrt(r/(2M)) / (1-2M/r)
        f = self.f(r)
        if f <= 0.0:
            return None
        return math.sqrt(r / (2.0 * self.M)) / f

    def tau_to_singularity_from_r(self, r: float) -> float:
        # τ(r -> 0) = (2/3) r^(3/2) / sqrt(2M)
        return (2.0 / 3.0) * (r ** 1.5) / math.sqrt(2.0 * self.M)

    def delta_tau_r0_to_r(self, r0: float, r: float) -> float:
        # Δτ(r0->r) = (2/3) (r0^(3/2) - r^(3/2)) / sqrt(2M)
        return (2.0 / 3.0) * ((r0 ** 1.5) - (r ** 1.5)) / math.sqrt(2.0 * self.M)

    def build_payload(self, r_values: List[float]) -> Dict[str, Any]:
        require(len(r_values) >= 1, "Need at least one radius.")
        for r in r_values:
            require(r > 0.0, "All radii must be > 0.")

        # Define a reference starting radius r0 as the maximum provided radius
        r0 = max(r_values)

        sample_points: List[Dict[str, Any]] = []

        for r in r_values:
            r = float(r)

            coordinates = {"t": None, "r": r, "theta": None, "phi": None}

            curvature_invariants = {
                "ricci_scalar": self.ricci_scalar(r),
                "kretschmann": self.kretschmann(r),
            }

            local_observables = {
                "reference_start_radius_r0": r0,
                "dr_dtau": self.dr_dtau(r),
                "dt_dr_exterior_only": self.dt_dr_exterior(r),
                "proper_time_from_r0_to_r": self.delta_tau_r0_to_r(r0, r) if r <= r0 else None,
                "proper_time_remaining_to_singularity_from_r": self.tau_to_singularity_from_r(r),
                "proper_time_from_r0_to_singularity": self.tau_to_singularity_from_r(r0),
            }

            rh = self.horizon()
            causal_structure = {
                "horizon_radius": rh,
                "region": (
                    "exterior (r>2M)" if r > rh else
                    ("horizon (r=2M)" if abs(r - rh) < 1e-12 else
                     "interior (r<2M)")
                ),
                "singularity_radius": 0.0,
            }

            sample_points.append({
                "coordinates": coordinates,
                "curvature_invariants": curvature_invariants,
                "local_observables": local_observables,
                "causal_structure": causal_structure,
            })

        payload: Dict[str, Any] = {
            "toy_id": self.toy_id,
            "theory": "General Relativity (radial infall proper-time timescales)",
            "spacetime": "Schwarzschild (proper time to r=0 for E=1 infall)",
            "units": {"G": 1, "c": 1},
            "parameters": {
                "M": self.M,
                "reference_start_radius_r0": r0,
            },
            "notes": {
                "pressure_point": (
                    "Finite proper time to the singularity contrasts with coordinate-time pathologies. "
                    "Even where curvature is moderate (e.g., large M horizons), the interior evolution "
                    "to r=0 is unavoidable once inside."
                ),
                "key_formulas": {
                    "dr_dtau": "dr/dτ = -sqrt(2M/r)",
                    "tau_to_singularity": "τ(r->0) = (2/3) r^(3/2) / sqrt(2M)",
                    "delta_tau": "Δτ(r0->r) = (2/3)(r0^(3/2)-r^(3/2))/sqrt(2M)",
                    "dt_dr_exterior": "dt/dr = sqrt(r/(2M)) / (1-2M/r)  (r>2M only)",
                },
            },
            "sample_points": sample_points,
            "observables": {
                "horizon_radius": self.horizon(),
                "reference_start_radius_r0": r0,
                "proper_time_from_r0_to_singularity": self.tau_to_singularity_from_r(r0),
            },
        }

        return payload

    def export_json(self, r_values: List[float], out_path: Optional[str] = None) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)
        payload = self.build_payload(r_values=r_values)
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2, sort_keys=True)
        return out_path


# ----------------------------
# CLI
# ----------------------------

def main() -> None:
    ap = argparse.ArgumentParser(description="Toy 028: proper-time approach to Schwarzschild singularity (E=1 infall).")
    ap.add_argument("--M", type=float, default=1.0, help="Mass parameter M (geometric units)")
    ap.add_argument(
        "--r",
        type=str,
        default="6,4,3,2.5,2.1,1.5,1.0",
        help="Comma-separated radii (positive; can include interior radii <2M)",
    )
    ap.add_argument("--out", type=str, default="",
                    help="Optional output path. If omitted, uses <this_script_name>.json")
    args = ap.parse_args()

    toy = Toy028SingularityApproachTimescales(M=float(args.M))
    r_values = parse_csv_floats(args.r)

    out_path = args.out.strip() or None
    json_path = toy.export_json(r_values=r_values, out_path=out_path)

    print(f"Wrote {json_path}")
    print(f"Horizon radius: r = {toy.horizon():g}")
    print(f"Reference start radius r0 = {max(r_values):g}")


if __name__ == "__main__":
    main()
