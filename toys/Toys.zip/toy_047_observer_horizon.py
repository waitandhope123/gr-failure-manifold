#!/usr/bin/env python3
"""
Toy 047 — Observer-dependent "horizon" detection (operational vs global)

What it probes (weak points / pressure points):
- Event horizons are global causal structures, not locally measurable "surfaces."
- Different observers can define different operational "horizons" based on what they
  can actually receive/send, with finite resources and finite time.

Spacetime:
- Schwarzschild vacuum, geometric units G=c=1.

Observers modeled (outside horizon):
1) Static observer at fixed areal radius r_obs > 2M
   - Measures gravitational redshift for photons emitted from radius r_emit to r_obs:
       (nu_obs/nu_emit) = sqrt( f(r_emit) / f(r_obs) ), where f(r)=1-2M/r.
   - As r_emit -> 2M+, nu_obs -> 0: signals redshift away.
   - Operational "horizon" for this observer is where nu_obs/nu_emit < z_min (instrument cutoff).

2) Infalling observer from rest at infinity (E=1)
   - In a local freely-falling frame, horizon crossing is not locally singular.
   - Operationally, define "no-return surface" as the radius where even outgoing null rays
     have non-positive PG coordinate slope:
       dr/dt_PG (outgoing) = 1 - sqrt(2M/r)  (ingoing PG)
     Outgoing slope <= 0 when r <= 2M. This reproduces the true event horizon in this model.

3) Uniformly accelerated (Rindler-like) observer (flat-spacetime proxy)
   - Included to show horizons can appear without curvature.
   - Operational horizon distance in Minkowski: x_h = 1/a (with c=1).
   - This is NOT a Schwarzschild horizon; it is an observer horizon.

Outputs:
- For each sample radius r_emit:
  * redshift ratio to a static observer at r_obs
  * operational cutoff flag based on z_min
  * PG outgoing slope and "no-return" flag
- Also includes an accelerated-observer proxy horizon scale.

Notes:
- This toy does NOT claim to compute the event horizon locally.
  It shows how operational definitions depend on observer and detector thresholds.
"""

from __future__ import annotations

import argparse
import json
import math
import os
from typing import Any, Dict, List, Optional


# ----------------------------
# Helpers
# ----------------------------

def py_to_json_name(py_path: str) -> str:
    base = os.path.splitext(os.path.basename(py_path))[0]
    return base + ".json"


def require(cond: bool, msg: str) -> None:
    if not cond:
        raise ValueError(msg)


def parse_csv_floats(s: str) -> List[float]:
    return [float(x.strip()) for x in s.split(",") if x.strip()]


def finite_or_none(x: float) -> Optional[float]:
    return x if math.isfinite(x) else None


# ----------------------------
# Toy 047
# ----------------------------

class Toy047ObserverHorizon:
    toy_id = "047"

    def __init__(self, M: float = 1.0, r_obs: float = 10.0, z_min: float = 1e-6, a: float = 1.0) -> None:
        require(M > 0.0, "M must be > 0.")
        require(r_obs > 0.0, "r_obs must be > 0.")
        require(z_min > 0.0, "z_min must be > 0.")
        require(a > 0.0, "a (acceleration) must be > 0.")
        self.M = float(M)
        self.r_obs = float(r_obs)
        self.z_min = float(z_min)
        self.a = float(a)

    def horizon_radius(self) -> float:
        return 2.0 * self.M

    def f(self, r: float) -> float:
        require(r > 0.0, "r must be > 0.")
        return 1.0 - 2.0 * self.M / r

    # Static observer redshift: nu_obs/nu_emit
    def redshift_ratio_static(self, r_emit: float) -> Optional[float]:
        """
        For static emitter at r_emit and static observer at r_obs:
          nu_obs/nu_emit = sqrt( f(r_emit) / f(r_obs) )
        Defined for r_emit>2M and r_obs>2M (static region).
        """
        rh = self.horizon_radius()
        if r_emit <= rh or self.r_obs <= rh:
            return None
        fr_e = self.f(r_emit)
        fr_o = self.f(self.r_obs)
        if fr_e <= 0.0 or fr_o <= 0.0:
            return None
        return finite_or_none(math.sqrt(fr_e / fr_o))

    # Ingoing PG "river speed" and outgoing null slope dr/dt = 1 - sqrt(2M/r)
    def pg_outgoing_slope(self, r: float) -> Optional[float]:
        if r <= 0.0:
            return None
        return finite_or_none(1.0 - math.sqrt(2.0 * self.M / r))

    # Accelerated observer horizon distance in Minkowski proxy: x_h = 1/a
    def rindler_horizon_scale(self) -> float:
        return 1.0 / self.a

    def evaluate_at_r(self, r_emit: float) -> Dict[str, Any]:
        require(r_emit > 0.0, "r_emit must be > 0.")
        rh = self.horizon_radius()

        # Static operational horizon via detector cutoff
        ratio = self.redshift_ratio_static(r_emit)
        below_cutoff = None if ratio is None else (ratio < self.z_min)

        # Infall operational "no-return" via PG outgoing slope
        slope = self.pg_outgoing_slope(r_emit)
        no_return = None if slope is None else (slope <= 0.0)

        return {
            "coordinates": {"r_emit": r_emit, "r_obs": self.r_obs},
            "curvature_invariants": {
                # Keep schema slot; toy focuses on operational/observer metrics.
            },
            "local_observables": {
                "static_observer": {
                    "nu_obs_over_nu_emit": ratio,
                    "detector_min_ratio_z_min": self.z_min,
                    "below_detector_cutoff": below_cutoff,
                    "static_defined": (ratio is not None),
                },
                "infalling_observer": {
                    "pg_outgoing_dr_dt": slope,
                    "no_return_surface_flag": no_return,
                    "note": "Using PG outgoing null slope criterion (<=0) as an operational no-return condition.",
                },
                "accelerated_observer_proxy": {
                    "proper_acceleration_a": self.a,
                    "rindler_horizon_distance_1_over_a": self.rindler_horizon_scale(),
                    "note": "This horizon is observer-induced in flat spacetime (not curvature).",
                },
            },
            "causal_structure": {
                "event_horizon_radius_2M": rh,
                "inside_event_horizon": (r_emit < rh),
                "at_or_outside_event_horizon": (r_emit >= rh),
            },
        }

    def build_payload(self, r_emits: List[float]) -> Dict[str, Any]:
        rh = self.horizon_radius()
        sample_points = [self.evaluate_at_r(r) for r in r_emits]

        # Small summaries:
        # - closest r_emit above horizon where static observer still "sees" above cutoff
        seen = []
        lost = []
        for sp in sample_points:
            r_emit = sp["coordinates"]["r_emit"]
            st = sp["local_observables"]["static_observer"]
            if st["static_defined"] is True:
                if st["below_detector_cutoff"] is True:
                    lost.append(r_emit)
                else:
                    seen.append(r_emit)

        min_seen_r = min(seen) if seen else None
        max_lost_r = max(lost) if lost else None

        # - PG no-return flags: should turn True at/below 2M
        pg_no_return_rs = [
            sp["coordinates"]["r_emit"]
            for sp in sample_points
            if sp["local_observables"]["infalling_observer"]["no_return_surface_flag"] is True
        ]
        min_no_return_r = min(pg_no_return_rs) if pg_no_return_rs else None

        return {
            "toy_id": self.toy_id,
            "theory": "General Relativity (plus observer horizon proxy)",
            "spacetime": "Schwarzschild + operational observer horizons",
            "units": {"G": 1, "c": 1},
            "parameters": {
                "M": self.M,
                "r_obs": self.r_obs,
                "z_min": self.z_min,
                "acceleration_a": self.a,
                "r_emit_samples": r_emits,
            },
            "notes": {
                "assumptions": [
                    "Vacuum Schwarzschild, geometric units G=c=1",
                    "Static observer exists only for r_obs>2M",
                    "Static operational horizon defined by detector cutoff on redshift ratio",
                    "Infall operational no-return defined by PG outgoing null slope <= 0",
                    "Accelerated observer horizon included as flat-spacetime proxy",
                ],
                "pressure_point": (
                    "Event horizons are global, but operational detectability depends on observer and instrument thresholds. "
                    "Different observers yield different 'horizon-like' surfaces."
                ),
                "key_formulas": {
                    "f(r)": "1 - 2M/r",
                    "static_redshift": "nu_obs/nu_emit = sqrt(f(r_emit)/f(r_obs))",
                    "pg_outgoing_slope": "dr/dt_PG(out) = 1 - sqrt(2M/r)",
                    "rindler_scale": "x_h = 1/a (flat spacetime observer horizon)",
                },
            },
            "sample_points": sample_points,
            "observables": {
                "summary": {
                    "event_horizon_radius_2M": rh,
                    "static_min_r_emit_seen_above_cutoff": min_seen_r,
                    "static_max_r_emit_lost_below_cutoff": max_lost_r,
                    "pg_min_r_emit_flagged_no_return": min_no_return_r,
                    "rindler_horizon_distance_1_over_a": self.rindler_horizon_scale(),
                    "note": "Static detectability depends on z_min; PG no-return reproduces r<=2M condition in this setup.",
                }
            },
        }

    def export_json(self, r_emits: List[float], out_path: Optional[str] = None) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)
        payload = self.build_payload(r_emits=r_emits)
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2, sort_keys=True)
        return out_path


# ----------------------------
# CLI
# ----------------------------

def main() -> None:
    ap = argparse.ArgumentParser(description="Toy 047: Observer-dependent operational horizon detection.")
    ap.add_argument("--M", type=float, default=1.0, help="Mass parameter M")
    ap.add_argument("--r_obs", type=float, default=10.0, help="Static observer radius r_obs (>2M)")
    ap.add_argument("--z_min", type=float, default=1e-6, help="Detector cutoff for nu_obs/nu_emit")
    ap.add_argument("--a", type=float, default=1.0, help="Acceleration for Rindler proxy horizon (x_h=1/a)")
    ap.add_argument(
        "--r_emit",
        type=str,
        default="100,20,10,6,4,3,2.5,2.2,2.1,2.05,2.01,2.001,2.0001,1.9,1.0",
        help="Comma-separated emission radii r_emit>0 (include near 2M)",
    )
    ap.add_argument("--out", type=str, default="", help="Optional output path. If omitted, uses <this_script_name>.json")
    args = ap.parse_args()

    r_emits = parse_csv_floats(args.r_emit)
    toy = Toy047ObserverHorizon(M=float(args.M), r_obs=float(args.r_obs), z_min=float(args.z_min), a=float(args.a))

    out_path = args.out.strip() or None
    json_path = toy.export_json(r_emits=r_emits, out_path=out_path)

    print(f"Wrote {json_path}")
    print(f"Event horizon at r=2M={toy.horizon_radius():g}. Static observer exists only for r_obs>2M.")


if __name__ == "__main__":
    main()
