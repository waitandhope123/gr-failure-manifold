#!/usr/bin/env python3
"""
Toy 013 — Kerr ISCO + accretion efficiency (prograde vs retrograde)

What it probes (pressure point):
- Rotation changes the innermost stable circular orbit (ISCO), which changes the
  maximum thin-disk accretion efficiency η = 1 - E_ISCO.
- This is a sharp, numerical, observationally relevant difference from Schwarzschild:
  spin changes the stability boundary and energy budget without adding matter.

Assumptions / setup:
- Kerr vacuum, equatorial circular geodesics (θ = π/2) in Boyer–Lindquist coordinates.
- Geometric units: G = c = 1.
- Thin-disk heuristic: radiative efficiency approximated by η = 1 - E_ISCO
  (ignores photon capture, magnetic stresses, disk thickness, etc.).

Key formulas (dimensionless a_* = |a|/M, 0<=a_*<=1 for BH):
- Horizons: r_+ = M + sqrt(M^2 - a^2)  (if |a|<=M)
- Equatorial ergosurface: r_erg(π/2) = 2M (independent of a)

ISCO radius (Bardeen, Press, Teukolsky 1972):
  Z1 = 1 + (1 - a_*^2)^(1/3) [ (1+a_*)^(1/3) + (1-a_*)^(1/3) ]
  Z2 = sqrt(3 a_*^2 + Z1^2)
  r_ISCO_aligned    = M [ 3 + Z2 - sqrt((3-Z1)(3+Z1+2Z2)) ]
  r_ISCO_antialigned= M [ 3 + Z2 + sqrt((3-Z1)(3+Z1+2Z2)) ]

Specific energy for equatorial circular orbit at radius r:
  E = (r^(3/2) - 2 M r^(1/2) ± a M^(1/2)) /
      (r^(3/4) * sqrt(r^(3/2) - 3 M r^(1/2) ± 2 a M^(1/2)))

We evaluate E at r_ISCO for aligned (+) and anti-aligned (-) branches relative to the spin.

Curvature invariant (Kretschmann) in equatorial plane (cosθ=0, Σ=r^2):
  K(θ=π/2) = 48 M^2 / r^6   (same functional form as Schwarzschild on the equator)

STRICT EXPORT RULE:
- Writes JSON named exactly like this .py file (toy_013_kerr_isco_efficiency.json).
- JSON follows the canonical schema with required keys and required subkeys.
- Undefined quantities are exported as null (JSON null).
"""

from __future__ import annotations

import argparse
import json
import math
import os
from typing import Any, Dict, List, Optional


# ----------------------------
# Helpers
# ----------------------------

def py_to_json_name(py_path: str) -> str:
    base = os.path.splitext(os.path.basename(py_path))[0]
    return base + ".json"


def parse_csv_floats(s: str) -> List[float]:
    return [float(x.strip()) for x in s.split(",") if x.strip()]


def require(cond: bool, msg: str) -> None:
    if not cond:
        raise ValueError(msg)


def cbrt(x: float) -> float:
    # real cube root
    if x >= 0:
        return x ** (1.0 / 3.0)
    return -((-x) ** (1.0 / 3.0))


# ----------------------------
# Toy 013
# ----------------------------

class Toy013KerrISCOEfficiency:
    toy_id = "013"

    def __init__(self, M: float = 1.0, a: float = 0.7) -> None:
        require(M > 0.0, "M must be > 0.")
        self.M = float(M)
        self.a = float(a)

    def a_star(self) -> float:
        return abs(self.a) / self.M

    def is_black_hole(self) -> bool:
        return abs(self.a) <= self.M

    def r_plus(self) -> Optional[float]:
        if not self.is_black_hole():
            return None
        return self.M + math.sqrt(self.M * self.M - self.a * self.a)

    def r_erg_equator(self) -> float:
        # equatorial static limit: r = 2M (outer ergosurface at theta=pi/2)
        return 2.0 * self.M

    def isco_radii(self) -> Dict[str, Optional[float]]:
        """
        Returns aligned / anti-aligned ISCO radii (relative to spin direction).
        For |a|>M, returns nulls.
        """
        if not self.is_black_hole():
            return {"aligned": None, "antialigned": None}

        a_s = self.a_star()
        # BPT formula in terms of a_* in [0,1]
        term = 1.0 - a_s * a_s
        Z1 = 1.0 + cbrt(term) * (cbrt(1.0 + a_s) + cbrt(1.0 - a_s))
        Z2 = math.sqrt(3.0 * a_s * a_s + Z1 * Z1)

        under = (3.0 - Z1) * (3.0 + Z1 + 2.0 * Z2)
        under = max(under, 0.0)
        S = math.sqrt(under)

        r_aligned = self.M * (3.0 + Z2 - S)
        r_antialigned = self.M * (3.0 + Z2 + S)
        return {"aligned": r_aligned, "antialigned": r_antialigned}

    def E_circular_equatorial(self, r: float, aligned: bool) -> Optional[float]:
        """
        Specific energy E for equatorial circular orbit at radius r.
        'aligned' means orbit angular momentum aligned with BH spin.
        Returns null if expression is not real/defined.
        """
        require(r > 0.0, "r must be > 0.")
        M = self.M
        a = abs(self.a)  # magnitude; aligned/antialigned captured by sign choice
        s = +1.0 if aligned else -1.0

        # Numerator and denominator in standard form
        num = (r ** 1.5) - 2.0 * M * (r ** 0.5) + s * a * (M ** 0.5)
        rad = (r ** 1.5) - 3.0 * M * (r ** 0.5) + s * 2.0 * a * (M ** 0.5)
        den = (r ** 0.75) * math.sqrt(rad) if rad > 0.0 else None
        if den is None or den == 0.0:
            return None
        return num / den

    def efficiency_from_E(self, E: Optional[float]) -> Optional[float]:
        if E is None:
            return None
        return 1.0 - E

    def kretschmann_equator(self, r: float) -> float:
        # Kerr equator has Σ=r^2, giving same r-dependence as Schwarzschild:
        return 48.0 * (self.M ** 2) / (r ** 6)

    def build_payload(self, a_values: List[float]) -> Dict[str, Any]:
        sample_points: List[Dict[str, Any]] = []

        for a in a_values:
            a = float(a)
            require(self.M > 0.0, "M must be > 0.")
            # Temporarily set spin for this sample
            self.a = a

            bh = self.is_black_hole()
            rp = self.r_plus()
            rerg_eq = self.r_erg_equator()
            iscos = self.isco_radii()

            for branch in ["aligned", "antialigned"]:
                r_isco = iscos[branch]
                E_isco = None if r_isco is None else self.E_circular_equatorial(r_isco, aligned=(branch == "aligned"))
                eta = self.efficiency_from_E(E_isco)
                K = None if r_isco is None else self.kretschmann_equator(r_isco)

                # Coordinates: treat (a, branch) as the sampling "location" in parameter space
                coordinates = {"a": a, "a_over_M": (a / self.M), "branch": branch, "theta": math.pi / 2}

                curvature_invariants = {
                    "ricci_scalar": 0.0 if bh else 0.0,  # Kerr is vacuum; still "vacuum" though no horizon if |a|>M
                    "kretschmann_at_isco_equator": K,
                    "note": "K evaluated at ISCO on equator (θ=π/2). If ISCO undefined, null.",
                }

                local_observables = {
                    "spin": {
                        "M": self.M,
                        "a": a,
                        "a_over_M": (a / self.M),
                        "black_hole_condition_abs_a_le_M": bh,
                    },
                    "surfaces": {
                        "outer_horizon_r_plus": rp,
                        "equatorial_ergosurface_r_erg": rerg_eq,
                    },
                    "isco": {
                        "r_isco": r_isco,
                        "branch_definition": "aligned=prograde relative to spin; antialigned=retrograde relative to spin",
                        "E_isco_specific_energy": E_isco,
                        "thin_disk_efficiency_eta_approx_1_minus_E": eta,
                        "notes": "η here is the ideal geodesic binding-energy estimate (ignores photon capture, MHD stresses).",
                    },
                }

                causal_structure = {
                    "region_tests": {
                        "isco_outside_outer_horizon": None if (r_isco is None or rp is None) else (r_isco > rp),
                        "isco_outside_equatorial_ergosurface": None if r_isco is None else (r_isco > rerg_eq),
                        "isco_minus_r_plus": None if (r_isco is None or rp is None) else (r_isco - rp),
                        "isco_minus_r_erg_eq": None if r_isco is None else (r_isco - rerg_eq),
                    },
                    "interpretation": (
                        "Spin moves the stability boundary (ISCO). For large |a|, aligned ISCO approaches the horizon; "
                        "antialigned ISCO moves outward. Efficiency tracks E_ISCO."
                    ),
                    "radial_null_cone_dr_dt": None,
                }

                sample_points.append({
                    "coordinates": coordinates,
                    "curvature_invariants": curvature_invariants,
                    "local_observables": local_observables,
                    "causal_structure": causal_structure,
                })

        payload: Dict[str, Any] = {
            "toy_id": self.toy_id,
            "theory": "General Relativity (Kerr equatorial circular geodesics)",
            "spacetime": "Kerr: ISCO shift and thin-disk efficiency proxy η≈1−E_ISCO",
            "units": {"G": 1, "c": 1},
            "parameters": {
                "M": self.M,
                "a_values_sampled": a_values,
                "theta_fixed": "pi/2 (equator)",
            },
            "notes": {
                "pressure_point": (
                    "Rotation changes the innermost stable orbit and thus the maximum available binding energy. "
                    "This maps a geometric parameter (a/M) into an observational proxy (efficiency)."
                ),
                "key_formulas": {
                    "isco_radii": "Bardeen-Press-Teukolsky analytic r_ISCO(a_*) via Z1, Z2",
                    "E_circular": "E(r) = (r^(3/2)-2Mr^(1/2) ± aM^(1/2)) / (r^(3/4)*sqrt(r^(3/2)-3Mr^(1/2) ± 2aM^(1/2)))",
                    "efficiency": "η ≈ 1 - E_ISCO",
                    "horizon": "r_+ = M + sqrt(M^2 - a^2) (if |a|<=M)",
                    "ergosphere_equator": "r_erg(π/2)=2M",
                },
                "domain_of_validity": (
                    "Exact Kerr vacuum geodesics; thin-disk efficiency is an idealized proxy "
                    "(ignores radiation capture, disk thickness, magnetic torques, etc.)."
                ),
            },
            "sample_points": sample_points,
            "observables": {
                "summary": {
                    "comment": "Compare η(aligned) vs η(antialigned) across a/M samples to see spin-driven energy budget shift."
                }
            },
        }
        return payload

    def export_json(self, a_values: List[float], out_path: Optional[str] = None) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)
        payload = self.build_payload(a_values=a_values)
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2, sort_keys=True)
        return out_path


# ----------------------------
# CLI
# ----------------------------

def main() -> None:
    ap = argparse.ArgumentParser(description="Toy 013: Kerr ISCO + thin-disk efficiency proxy η≈1−E_ISCO.")
    ap.add_argument("--M", type=float, default=1.0, help="Mass M (geometric units)")
    ap.add_argument(
        "--a_values",
        type=str,
        default="-0.99,-0.9,-0.7,-0.5,0.0,0.5,0.7,0.9,0.99",
        help="Comma-separated Kerr spin values a to sample (can include negative)",
    )
    ap.add_argument("--out", type=str, default="", help="Optional output path; default is <script>.json")
    args = ap.parse_args()

    toy = Toy013KerrISCOEfficiency(M=float(args.M), a=0.0)
    a_values = parse_csv_floats(args.a_values)

    out_path = args.out.strip() or None
    json_path = toy.export_json(a_values=a_values, out_path=out_path)

    print(f"Wrote {json_path}")
    print("Note: results include BOTH aligned and antialigned branches for each a value (alignment is relative to spin magnitude).")


if __name__ == "__main__":
    main()
