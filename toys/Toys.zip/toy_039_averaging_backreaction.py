#!/usr/bin/env python3
"""
Toy 039 — Cosmological backreaction and the averaging problem (Buchert-style two-domain toy)

Pressure point / weakness probed:
- In GR, "average the universe" is not unique: averaging and time evolution do not commute.
- Even if each region is exactly FLRW-like, the *domain-averaged* expansion can behave differently.
- Backreaction appears via variance in expansion (and shear), modifying the effective Friedmann equations.

Controlled toy model:
- Two disjoint comoving domains (1 and 2), each treated as k=0 FLRW-like with power-law scale factors:
    a_i(t) = (t/t0)^{n_i},  t>0
    H_i(t) = n_i / t
    Hdot_i(t) = -n_i / t^2
- Fixed initial volume fractions at t0:
    f0 = V1(t0) / (V1(t0)+V2(t0)),  0<=f0<=1
  with V_i(t) ∝ a_i(t)^3.

Domain-averaged scale factor a_D (Buchert volume average):
- V_D(t) = f0 a1(t)^3 + (1-f0) a2(t)^3
- a_D(t) = [V_D(t)]^{1/3}   (since we set V_D(t0)=1 by choosing a1(t0)=a2(t0)=1)

Domain-averaged Hubble rate:
- H_D = (1/3) (d/dt ln V_D)

Backreaction term (shear-free proxy, sigma=0):
- theta_i = 3 H_i
- <theta> = f(t) theta_1 + (1-f(t)) theta_2, with *time-dependent* volume fraction
    f(t) = V1(t)/V_D(t) = f0 a1^3 / (f0 a1^3 + (1-f0) a2^3)
- Q_D = (2/3)(<theta^2> - <theta>^2)
  where <theta^2> = f(t) theta_1^2 + (1-f(t)) theta_2^2

Matter (optional dust proxy):
- Each domain has dust-like density rho_i(t)=rho_i0/a_i^3
- Domain average: <rho>_D = f(t) rho1 + (1-f(t)) rho2

Effective acceleration (Buchert-like; k=0, shear-free proxy):
- 3 (a_D¨/a_D) = -4π <rho>_D + Q_D
We compute both sides as a consistency diagnostic within the toy assumptions.

Curvature invariants:
- This is not a single exact spacetime metric; we export *proxies* derived from each domain’s k=0 FLRW formulas
  and volume-average them:
    R_i = 6(Hdot_i + 2H_i^2)
    K_i = 12[(Hdot_i + H_i^2)^2 + H_i^4]
  Then <R>_D = f(t)R1 + (1-f(t))R2 (same for K).
"""

from __future__ import annotations

import argparse
import json
import math
import os
from typing import Any, Dict, List, Optional


# ----------------------------
# Helpers
# ----------------------------

def py_to_json_name(py_path: str) -> str:
    return os.path.splitext(os.path.basename(py_path))[0] + ".json"


def require(cond: bool, msg: str) -> None:
    if not cond:
        raise ValueError(msg)


def parse_csv_floats(s: str) -> List[float]:
    return [float(x.strip()) for x in s.split(",") if x.strip()]


# ----------------------------
# Two-domain FLRW-like model
# ----------------------------

def a_powerlaw(t: float, t0: float, n: float) -> float:
    require(t > 0.0 and t0 > 0.0, "t>0 and t0>0 required")
    # normalized so a(t0)=1
    return (t / t0) ** n


def H_powerlaw(t: float, n: float) -> float:
    require(t > 0.0, "t>0 required")
    return n / t


def Hdot_powerlaw(t: float, n: float) -> float:
    require(t > 0.0, "t>0 required")
    return -n / (t * t)


def R_flrw_k0(H: float, Hdot: float) -> float:
    # Ricci scalar proxy for k=0 FLRW
    return 6.0 * (Hdot + 2.0 * H * H)


def K_flrw_k0(H: float, Hdot: float) -> float:
    # Kretschmann proxy for k=0 FLRW
    return 12.0 * ((Hdot + H * H) ** 2 + (H ** 4))


def volume_D(f0: float, a1: float, a2: float) -> float:
    return f0 * (a1 ** 3) + (1.0 - f0) * (a2 ** 3)


def vol_fraction_t(f0: float, a1: float, a2: float) -> float:
    VD = volume_D(f0, a1, a2)
    if VD == 0.0:
        return 0.0
    return (f0 * (a1 ** 3)) / VD


def H_domain(f0: float, a1: float, a2: float, H1: float, H2: float) -> float:
    """
    H_D = (1/3) d/dt ln(V_D)
    with V_D = f0 a1^3 + (1-f0) a2^3
    dV_D/dt = 3 f0 a1^3 H1 + 3 (1-f0) a2^3 H2
    => H_D = (f0 a1^3 H1 + (1-f0) a2^3 H2) / (f0 a1^3 + (1-f0) a2^3)
         = f(t) H1 + (1-f(t)) H2
    """
    f = vol_fraction_t(f0, a1, a2)
    return f * H1 + (1.0 - f) * H2


def Q_backreaction_shearfree(f: float, H1: float, H2: float) -> float:
    """
    Shear-free proxy (sigma=0):
      theta_i = 3 H_i
      Q = (2/3)(<theta^2> - <theta>^2)
    """
    th1 = 3.0 * H1
    th2 = 3.0 * H2
    mean_th = f * th1 + (1.0 - f) * th2
    mean_th2 = f * (th1 ** 2) + (1.0 - f) * (th2 ** 2)
    return (2.0 / 3.0) * (mean_th2 - mean_th ** 2)


def rho_dust(t: float, t0: float, n: float, rho0: float) -> float:
    a = a_powerlaw(t, t0, n)
    return rho0 / (a ** 3)


def second_derivative_lnV_numeric(times: List[float], lnV: List[float], i: int) -> Optional[float]:
    """
    Central second derivative for lnV with nonuniform step not supported (we assume uniform sampling in t).
    Return None at edges.
    """
    if i == 0 or i == len(times) - 1:
        return None
    dt1 = times[i] - times[i - 1]
    dt2 = times[i + 1] - times[i]
    if abs(dt1 - dt2) > 1e-12:
        return None
    dt = dt1
    return (lnV[i + 1] - 2.0 * lnV[i] + lnV[i - 1]) / (dt * dt)


# ----------------------------
# Toy 039 driver
# ----------------------------

class Toy039AveragingBackreaction:
    toy_id = "039"

    def __init__(
        self,
        n1: float,
        n2: float,
        f0: float,
        t0: float,
        t_values: List[float],
        rho1_0: float,
        rho2_0: float,
    ) -> None:
        require(t0 > 0.0, "t0 must be > 0")
        require(0.0 <= f0 <= 1.0, "f0 must be in [0,1]")
        require(len(t_values) >= 3, "t_values must have at least 3 points (for second-derivative diagnostics)")
        for t in t_values:
            require(t > 0.0, "all t must be > 0")
        require(rho1_0 >= 0.0 and rho2_0 >= 0.0, "rho*_0 must be >= 0")
        self.n1 = float(n1)
        self.n2 = float(n2)
        self.f0 = float(f0)
        self.t0 = float(t0)
        self.t_values = [float(t) for t in t_values]
        self.rho1_0 = float(rho1_0)
        self.rho2_0 = float(rho2_0)

    def build_payload(self) -> Dict[str, Any]:
        t_vals = self.t_values

        # Precompute V_D and ln V_D for numeric acceleration diagnostics
        V_list: List[float] = []
        lnV_list: List[float] = []
        for t in t_vals:
            a1 = a_powerlaw(t, self.t0, self.n1)
            a2 = a_powerlaw(t, self.t0, self.n2)
            V = volume_D(self.f0, a1, a2)
            V_list.append(V)
            lnV_list.append(math.log(V) if V > 0.0 else float("nan"))

        sample_points: List[Dict[str, Any]] = []

        for i, t in enumerate(t_vals):
            a1 = a_powerlaw(t, self.t0, self.n1)
            a2 = a_powerlaw(t, self.t0, self.n2)
            V = V_list[i]
            aD = V ** (1.0 / 3.0) if V > 0.0 else None

            H1 = H_powerlaw(t, self.n1)
            H2 = H_powerlaw(t, self.n2)
            Hd1 = Hdot_powerlaw(t, self.n1)
            Hd2 = Hdot_powerlaw(t, self.n2)

            f = vol_fraction_t(self.f0, a1, a2)
            HD = H_domain(self.f0, a1, a2, H1, H2)

            QD = Q_backreaction_shearfree(f, H1, H2)

            # Dust proxy densities (optional; rho0=0 means "no matter" limit)
            rho1 = rho_dust(t, self.t0, self.n1, self.rho1_0) if self.rho1_0 > 0.0 else 0.0
            rho2 = rho_dust(t, self.t0, self.n2, self.rho2_0) if self.rho2_0 > 0.0 else 0.0
            rhoD = f * rho1 + (1.0 - f) * rho2

            # Proxy invariants: volume-average of each domain's FLRW k=0 invariants
            R1 = R_flrw_k0(H1, Hd1)
            R2 = R_flrw_k0(H2, Hd2)
            K1 = K_flrw_k0(H1, Hd1)
            K2 = K_flrw_k0(H2, Hd2)
            RD = f * R1 + (1.0 - f) * R2
            KD = f * K1 + (1.0 - f) * K2

            # Effective acceleration diagnostic:
            # Compute a_D¨/a_D via ln V:
            # a_D = V^(1/3) => ln a_D = (1/3) ln V
            # (a¨/a) = d²/dt²(ln a) + (d/dt ln a)^2
            # with d/dt ln a = H_D
            d2_lnV = second_derivative_lnV_numeric(t_vals, lnV_list, i)
            accel_a_over_a = None
            if d2_lnV is not None and math.isfinite(d2_lnV):
                d2_ln_a = (1.0 / 3.0) * d2_lnV
                accel_a_over_a = d2_ln_a + (HD ** 2)

            lhs = (3.0 * accel_a_over_a) if accel_a_over_a is not None else None
            rhs = (-4.0 * math.pi * rhoD + QD) if accel_a_over_a is not None else None
            mismatch = (lhs - rhs) if (lhs is not None and rhs is not None) else None

            # Regime tag
            tag = "no_backreaction" if abs(QD) < 1e-12 else ("backreaction_dominant" if abs(QD) > 4.0 * math.pi * max(rhoD, 1e-30) else "mixed")

            sample_points.append({
                "coordinates": {
                    "t": t
                },
                "curvature_invariants": {
                    "ricci_scalar": RD,     # proxy (domain-averaged)
                    "kretschmann": KD       # proxy (domain-averaged)
                },
                "local_observables": {
                    "a1": a1,
                    "a2": a2,
                    "a_domain": aD,
                    "H1": H1,
                    "H2": H2,
                    "H_domain": HD,
                    "volume_fraction_f(t)": f,
                    "Q_backreaction": QD,
                    "rho1_dust": rho1,
                    "rho2_dust": rho2,
                    "rho_domain_avg": rhoD,
                    "accel_aDD_over_aD": accel_a_over_a,
                    "buchert_accel_lhs_3aDD/aD": lhs,
                    "buchert_accel_rhs_-4pi<rho>+Q": rhs,
                    "buchert_accel_mismatch": mismatch,
                    "tag": tag,
                    "notes": (
                        "Two-region averaging toy: even if each region is FLRW-like, the domain-averaged expansion "
                        "includes a backreaction term Q from variance in expansion. This exposes the noncommutativity "
                        "of averaging and evolution in GR cosmology."
                    )
                },
                "causal_structure": {
                    "radial_null_cone_dr_dt": {"outgoing": 1.0, "ingoing": -1.0},
                    "horizon_radius": None,
                    "region": "Buchert-style two-domain average (not a single exact metric)",
                    "energy_warning": (
                        "Cosmological observables depend on averaging/gauge choices; 'the average universe' is not unique."
                    )
                }
            })

        # Summary diagnostics
        Q_vals = [sp["local_observables"]["Q_backreaction"] for sp in sample_points]
        Q_max = max(abs(q) for q in Q_vals) if Q_vals else None

        payload: Dict[str, Any] = {
            "toy_id": self.toy_id,
            "theory": "General Relativity (cosmological averaging / backreaction)",
            "spacetime": "Two-domain FLRW-like patchwork (Buchert-style averaging toy; k=0 per domain)",
            "units": {"G": 1, "c": 1},
            "parameters": {
                "n1": self.n1,
                "n2": self.n2,
                "f0": self.f0,
                "t0": self.t0,
                "t_values": self.t_values,
                "rho1_0": self.rho1_0,
                "rho2_0": self.rho2_0
            },
            "notes": {
                "pressure_point": (
                    "In GR cosmology, averaging is not unique and does not commute with evolution. "
                    "Backreaction terms (like Q_D) appear from inhomogeneity/variance even when each region is locally FLRW-like."
                ),
                "definitions_used": {
                    "a_i": "a_i(t)=(t/t0)^{n_i}, normalized so a_i(t0)=1",
                    "V_D": "V_D=f0 a1^3 + (1-f0) a2^3",
                    "a_D": "a_D = V_D^{1/3}",
                    "H_D": "H_D = (1/3) d/dt ln V_D = f(t)H1 + (1-f(t))H2",
                    "Q_D": "Q_D=(2/3)(<theta^2>-<theta>^2) with theta_i=3H_i (shear-free proxy)",
                    "rho_i": "rho_i=rho_i0/a_i^3 (dust proxy)"
                },
                "limitations": (
                    "This is a controlled averaging toy, not an exact stitched spacetime solution. "
                    "Curvature invariants are exported as domain-averaged FLRW proxies for comparability."
                )
            },
            "sample_points": sample_points,
            "observables": {
                "summary": {
                    "max_abs_Q_backreaction": Q_max,
                    "key_result": (
                        "If n1 != n2 and 0<f0<1, Q_D is generically nonzero due to expansion variance. "
                        "Thus averaged dynamics can differ from naive FLRW fitted to averaged density alone."
                    )
                }
            }
        }
        return payload

    def export_json(self, out_path: Optional[str] = None) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)
        payload = self.build_payload()
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2, sort_keys=True)
        return out_path


def main() -> None:
    ap = argparse.ArgumentParser(description="Toy 039: Cosmological averaging/backreaction (two-domain Buchert toy).")
    ap.add_argument("--n1", type=float, default=0.70, help="Power-law exponent n1 (domain 1)")
    ap.add_argument("--n2", type=float, default=0.55, help="Power-law exponent n2 (domain 2)")
    ap.add_argument("--f0", type=float, default=0.5, help="Initial volume fraction f0 in [0,1]")
    ap.add_argument("--t0", type=float, default=1.0, help="Normalization time t0>0 (a_i(t0)=1)")
    ap.add_argument("--t", type=str, default="1,2,3,4,5,6,7,8,9,10",
                    help="Comma-separated times t>0 (>=3 points recommended)")
    ap.add_argument("--rho1_0", type=float, default=0.01, help="Dust proxy rho1(t0) >= 0")
    ap.add_argument("--rho2_0", type=float, default=0.01, help="Dust proxy rho2(t0) >= 0")
    ap.add_argument("--out", type=str, default="", help="Optional output path; default is <script>.json")
    args = ap.parse_args()

    toy = Toy039AveragingBackreaction(
        n1=float(args.n1),
        n2=float(args.n2),
        f0=float(args.f0),
        t0=float(args.t0),
        t_values=parse_csv_floats(args.t),
        rho1_0=float(args.rho1_0),
        rho2_0=float(args.rho2_0),
    )
    out_path = args.out.strip() or None
    json_path = toy.export_json(out_path=out_path)
    print(f"Wrote {json_path}")
    print("Notes:")
    print("- Backreaction Q_D is nonzero when expansion rates differ across domains.")


if __name__ == "__main__":
    main()
