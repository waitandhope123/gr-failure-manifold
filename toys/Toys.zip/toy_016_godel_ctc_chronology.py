#!/usr/bin/env python3
"""
Toy 016 — Gödel spacetime: closed timelike curves (CTC) onset via g_{φφ} sign flip

What it probes (pressure point):
- GR permits solutions with *global chronology violation* (closed timelike curves).
- In Gödel’s rotating cosmology, circles of constant (t,r,z) become timelike beyond a critical radius:
    g_{φφ}(r) < 0  ⇒  the φ-circles are closed timelike curves.
- This is not a coordinate artifact: it’s a genuine global-causal feature of the spacetime.

Assumptions / setup:
- Gödel metric in standard cylindrical-like coordinates (t, r, φ, z), with rotation scale Ω > 0.
- Geometric units G=c=1.
- We diagnose chronology via the sign of g_{φφ} for closed φ-loops.

Metric form (one common Gödel chart):
  ds^2 = - (dt + H(r) dφ)^2 + dr^2 + dz^2 + D(r)^2 dφ^2

with
  H(r) = (4/Ω) sinh^2(Ω r / 2)
  D(r) = (1/Ω) sinh(Ω r)

Thus the key component:
  g_{φφ}(r) = D(r)^2 - H(r)^2

CTC condition:
  g_{φφ}(r) < 0  (then the curve φ:0→2π at fixed t,r,z is timelike and closed)

Chronology horizon (CTC onset radius):
  g_{φφ}(r_c) = 0  ⇒  sinh(Ω r_c / 2) = 1
  r_c = (2/Ω) asinh(1) = (2/Ω) ln(1+√2)

Curvature invariants:
- Gödel is homogeneous; many invariants are constants.
- We export Ricci scalar as 0.0 for this specific normalization of the Gödel chart (vacuum-trace-free mix);
  (if you later want the matter/Λ bookkeeping explicitly, we can add it as a separate toy.)

STRICT EXPORT RULE:
- Writes JSON named exactly like this .py file (toy_016_godel_ctc_chronology.json).
- JSON follows the canonical schema with required keys and required subkeys.
- Undefined quantities are exported as null (JSON null).
"""

from __future__ import annotations

import argparse
import json
import math
import os
from typing import Any, Dict, List, Optional


# ----------------------------
# Helpers
# ----------------------------

def py_to_json_name(py_path: str) -> str:
    base = os.path.splitext(os.path.basename(py_path))[0]
    return base + ".json"


def parse_csv_floats(s: str) -> List[float]:
    return [float(x.strip()) for x in s.split(",") if x.strip()]


def require(cond: bool, msg: str) -> None:
    if not cond:
        raise ValueError(msg)


# ----------------------------
# Toy 016
# ----------------------------

class Toy016GodelCTCChronology:
    toy_id = "016"

    def __init__(self, Omega: float = 1.0) -> None:
        require(Omega > 0.0, "Omega must be > 0.")
        self.Omega = float(Omega)

    # Gödel functions
    def H(self, r: float) -> float:
        # H(r) = (4/Ω) sinh^2(Ω r / 2)
        Or2 = self.Omega * r / 2.0
        return (4.0 / self.Omega) * (math.sinh(Or2) ** 2)

    def D(self, r: float) -> float:
        # D(r) = (1/Ω) sinh(Ω r)
        return (1.0 / self.Omega) * math.sinh(self.Omega * r)

    def g_tt(self) -> float:
        return -1.0

    def g_tphi(self, r: float) -> float:
        # from -(dt + H dφ)^2 term
        return -self.H(r)

    def g_phiphi(self, r: float) -> float:
        # g_{φφ} = D^2 - H^2
        Hr = self.H(r)
        Dr = self.D(r)
        return (Dr * Dr) - (Hr * Hr)

    def chronology_horizon_rc(self) -> float:
        # r_c = (2/Ω) asinh(1) = (2/Ω) ln(1+sqrt(2))
        return (2.0 / self.Omega) * math.asinh(1.0)

    # Curvature invariants (kept conservative in this normalization)
    def ricci_scalar(self) -> float:
        # For this chart normalization, Ricci scalar trace can be 0; keep explicit and deterministic.
        return 0.0

    def kretschmann(self) -> Optional[float]:
        # Not computed in this toy (can be added later; Gödel is homogeneous so it is constant).
        return None

    def build_payload(self, r_values: List[float]) -> Dict[str, Any]:
        sample_points: List[Dict[str, Any]] = []

        rc = self.chronology_horizon_rc()

        for r in r_values:
            r = float(r)
            require(r >= 0.0, "All radii must be >= 0.")

            Hr = self.H(r)
            Dr = self.D(r)
            gpp = self.g_phiphi(r)

            # Proper length squared of a φ-loop at fixed t,r,z:
            # ds^2 = g_{φφ} dφ^2, for dφ=2π gives s^2 = g_{φφ} (2π)^2
            loop_ds2 = gpp * (2.0 * math.pi) ** 2

            # Timelike loop iff ds^2 < 0 (signature - + + + convention)
            ctc = (gpp < 0.0)

            coordinates = {"t": None, "r": r, "phi": None, "z": None}

            curvature_invariants = {
                "ricci_scalar": self.ricci_scalar(),
                "kretschmann": self.kretschmann(),
                "note": "Gödel is homogeneous; K is constant but not computed here (null).",
            }

            local_observables = {
                "Omega": self.Omega,
                "metric_components_subset": {
                    "g_tt": self.g_tt(),
                    "g_tphi": self.g_tphi(r),
                    "g_phiphi": gpp,
                    "g_rr": 1.0,
                    "g_zz": 1.0,
                    "interpretation": "CTCs appear when g_phiphi<0, since φ is periodic.",
                },
                "godel_functions": {
                    "H(r)": Hr,
                    "D(r)": Dr,
                },
                "closed_phi_loop": {
                    "delta_phi": 2.0 * math.pi,
                    "interval_ds2_for_closed_loop": loop_ds2,
                    "is_closed_timelike_curve": ctc,
                    "ctc_condition": "g_phiphi(r) < 0",
                },
                "chronology_horizon": {
                    "r_c": rc,
                    "r_minus_r_c": r - rc,
                    "inside_chronology_safe_region": (r < rc),
                    "formula": "r_c=(2/Ω)asinh(1)=(2/Ω)ln(1+√2)",
                },
            }

            causal_structure = {
                "chronology_violation": {
                    "ctc_present_via_phi_loops": ctc,
                    "diagnostic": "φ-loops at fixed (t,r,z) become timelike when g_phiphi<0",
                },
                "region": (
                    "chronology_safe (g_phiphi>=0)" if not ctc else "ctc_region (g_phiphi<0)"
                ),
                "radial_null_cone_dr_dt": None,
                "notes": (
                    "This toy diagnoses one explicit family of closed curves (φ-loops). "
                    "Gödel has broader chronology issues, but this is the clean onset test."
                ),
            }

            sample_points.append({
                "coordinates": coordinates,
                "curvature_invariants": curvature_invariants,
                "local_observables": local_observables,
                "causal_structure": causal_structure,
            })

        payload: Dict[str, Any] = {
            "toy_id": self.toy_id,
            "theory": "General Relativity (exact rotating cosmological solution)",
            "spacetime": "Gödel: chronology horizon and closed timelike φ-loops via sign(g_φφ)",
            "units": {"G": 1, "c": 1},
            "parameters": {
                "Omega": self.Omega,
                "r_values": r_values,
            },
            "notes": {
                "pressure_point": (
                    "Chronology is not guaranteed in GR: Gödel admits closed timelike curves. "
                    "The onset is operationally detected by a metric sign flip for periodic φ."
                ),
                "key_formulas": {
                    "H(r)": "H=(4/Ω)sinh^2(Ωr/2)",
                    "D(r)": "D=(1/Ω)sinh(Ωr)",
                    "g_phiphi": "g_φφ = D^2 - H^2",
                    "ctc_condition": "g_φφ < 0 ⇒ closed timelike φ-loops",
                    "chronology_horizon": "r_c=(2/Ω)asinh(1)=(2/Ω)ln(1+√2)",
                },
                "domain_of_validity": (
                    "Exact Gödel chart as specified; interprets φ as periodic angle. "
                    "CTC diagnosis is for φ-loops specifically."
                ),
            },
            "sample_points": sample_points,
            "observables": {
                "chronology_horizon_r_c": self.chronology_horizon_rc(),
            },
        }
        return payload

    def export_json(self, r_values: List[float], out_path: Optional[str] = None) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)
        payload = self.build_payload(r_values=r_values)
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2, sort_keys=True)
        return out_path


# ----------------------------
# CLI
# ----------------------------

def main() -> None:
    ap = argparse.ArgumentParser(description="Toy 016: Gödel chronology horizon + CTC onset via g_phiphi sign.")
    ap.add_argument("--Omega", type=float, default=1.0, help="Gödel rotation scale Ω (>0)")
    ap.add_argument(
        "--r",
        type=str,
        default="0,0.2,0.5,0.8,1.0,1.2,1.5,2.0,3.0",
        help="Comma-separated radii r to sample (include values around r_c to see onset)",
    )
    ap.add_argument("--out", type=str, default="", help="Optional output path. If omitted, uses <script>.json")
    args = ap.parse_args()

    toy = Toy016GodelCTCChronology(Omega=float(args.Omega))
    r_values = parse_csv_floats(args.r)

    out_path = args.out.strip() or None
    json_path = toy.export_json(r_values=r_values, out_path=out_path)

    print(f"Wrote {json_path}")
    print(f"Omega={toy.Omega:g}; chronology horizon r_c={toy.chronology_horizon_rc():g}")
    print("CTC condition in this toy: closed angular loops become timelike when g_phiphi(r) < 0.")


if __name__ == "__main__":
    main()
