#!/usr/bin/env python3
"""
Run all GR toy models in the current directory.

Behavior:
- Finds all files named toy_*.py
- Runs each with the system Python
- Continues even if a toy fails
- Captures stdout/stderr into logs/
- Prints a final summary

This script does NOT:
- modify any toy
- assume arguments
- assume ordering beyond filename sort
"""

import subprocess
import sys
import pathlib
import time

ROOT = pathlib.Path(__file__).resolve().parent
LOG_DIR = ROOT / "logs"
LOG_DIR.mkdir(exist_ok=True)

def main() -> None:
    toy_files = sorted(p for p in ROOT.glob("toy_*.py") if p.name != pathlib.Path(__file__).name)

    if not toy_files:
        print("No toy_*.py files found.")
        sys.exit(1)

    print(f"Found {len(toy_files)} toys.")
    print("-" * 60)

    results = []
    t_start = time.time()

    for toy in toy_files:
        log_path = LOG_DIR / f"{toy.stem}.log"
        print(f"Running {toy.name} ...", end=" ", flush=True)

        with log_path.open("w", encoding="utf-8") as log:
            proc = subprocess.run(
                [sys.executable, str(toy)],
                stdout=log,
                stderr=subprocess.STDOUT,
                cwd=ROOT,
            )

        ok = (proc.returncode == 0)
        results.append((toy.name, ok, log_path))

        print("OK" if ok else "FAIL")

    elapsed = time.time() - t_start
    print("-" * 60)
    print(f"Finished in {elapsed:.2f} s\n")

    failed = [r for r in results if not r[1]]

    if failed:
        print("FAILED TOYS:")
        for name, _, log in failed:
            print(f"  {name}  (see {log})")
        sys.exit(1)
    else:
        print("All toys completed successfully.")
        sys.exit(0)

if __name__ == "__main__":
    main()
