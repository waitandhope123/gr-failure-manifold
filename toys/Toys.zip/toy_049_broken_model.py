#!/usr/bin/env python3
"""
Toy 049 — Deliberately broken gravity model (test-suite sanity check)

What it probes (weak points / pressure points):
- Your suite must be able to detect a subtly wrong "theory" / implementation.
- This toy intentionally introduces a controlled error and exports side-by-side
  comparisons against the correct GR baseline so downstream tools (Toy 50) can
  confirm they flag it.

Spacetime baseline:
- Schwarzschild vacuum (GR), geometric units G=c=1.

Deliberate break:
- Wrong Kretschmann scaling: K_broken = 48 M^2 / r^5   (INCORRECT; should be r^6)
- Ricci scalar kept at 0 to make the break subtle (only one invariant is wrong).

Exports:
- For each r: K_correct, K_broken, relative_error, pass/fail against tolerance.
"""

from __future__ import annotations

import argparse
import json
import math
import os
from typing import Any, Dict, List, Optional


# ----------------------------
# Helpers
# ----------------------------

def py_to_json_name(py_path: str) -> str:
    base = os.path.splitext(os.path.basename(py_path))[0]
    return base + ".json"


def require(cond: bool, msg: str) -> None:
    if not cond:
        raise ValueError(msg)


def parse_csv_floats(s: str) -> List[float]:
    return [float(x.strip()) for x in s.split(",") if x.strip()]


def finite_or_none(x: float) -> Optional[float]:
    return x if math.isfinite(x) else None


def rel_error(a: float, b: float) -> Optional[float]:
    # relative error |a-b|/|a|, with safe handling if a==0
    if not (math.isfinite(a) and math.isfinite(b)):
        return None
    if a == 0.0:
        return None if b == 0.0 else math.inf
    return abs(a - b) / abs(a)


# ----------------------------
# Toy 049
# ----------------------------

class Toy049BrokenModel:
    toy_id = "049"

    def __init__(self, M: float = 1.0, tol_rel: float = 1e-12) -> None:
        require(M > 0.0, "M must be > 0.")
        require(tol_rel > 0.0, "tol_rel must be > 0.")
        self.M = float(M)
        self.tol_rel = float(tol_rel)

    def horizon_radius(self) -> float:
        return 2.0 * self.M

    # Correct GR invariants (Schwarzschild vacuum)
    def ricci_scalar_correct(self, r: float) -> float:
        require(r > 0.0, "r must be > 0.")
        return 0.0

    def kretschmann_correct(self, r: float) -> float:
        require(r > 0.0, "r must be > 0.")
        return 48.0 * (self.M ** 2) / (r ** 6)

    # DELIBERATELY WRONG invariant (subtle bug: wrong power of r)
    def kretschmann_broken(self, r: float) -> float:
        require(r > 0.0, "r must be > 0.")
        return 48.0 * (self.M ** 2) / (r ** 5)  # WRONG ON PURPOSE

    def evaluate_at_r(self, r: float) -> Dict[str, Any]:
        require(r > 0.0, "r must be > 0.")
        rh = self.horizon_radius()

        R_ok = self.ricci_scalar_correct(r)
        K_ok = self.kretschmann_correct(r)
        K_bad = self.kretschmann_broken(r)

        re = rel_error(K_ok, K_bad)
        pass_rel = None if re is None else (re <= self.tol_rel)

        return {
            "coordinates": {"r": r},
            "curvature_invariants": {
                "ricci_scalar_R_correct": finite_or_none(R_ok),
                "kretschmann_K_correct": finite_or_none(K_ok),
                "kretschmann_K_broken": finite_or_none(K_bad),
                "kretschmann_relative_error": finite_or_none(re) if re is not None else None,
            },
            "local_observables": {
                "consistency_checks": {
                    "tolerance_relative": self.tol_rel,
                    "kretschmann_pass_within_tolerance": pass_rel,
                    "note": "K_broken is intentionally wrong; pass should be false except at contrived points.",
                }
            },
            "causal_structure": {
                "horizon_radius_2M": rh,
                "inside_horizon": (r < rh),
            },
        }

    def build_payload(self, r_values: List[float]) -> Dict[str, Any]:
        sample_points = [self.evaluate_at_r(r) for r in r_values]

        fails = 0
        known = 0
        worst = None
        worst_r = None

        for sp in sample_points:
            re = sp["curvature_invariants"]["kretschmann_relative_error"]
            passed = sp["local_observables"]["consistency_checks"]["kretschmann_pass_within_tolerance"]
            if re is not None:
                known += 1
                if worst is None or re > worst:
                    worst = re
                    worst_r = sp["coordinates"]["r"]
            if passed is False:
                fails += 1

        return {
            "toy_id": self.toy_id,
            "theory": "Deliberately broken model (sanity test)",
            "spacetime": "Schwarzschild-like (but with intentional invariant bug)",
            "units": {"G": 1, "c": 1},
            "parameters": {
                "M": self.M,
                "tolerance_relative": self.tol_rel,
                "r_samples": r_values,
            },
            "notes": {
                "assumptions": [
                    "Baseline intended: Schwarzschild vacuum GR",
                    "Intentional break: Kretschmann uses 1/r^5 instead of 1/r^6",
                    "Used to verify that the test harness flags incorrect physics/implementations",
                ],
                "pressure_point": (
                    "If your lab fails to detect this, your comparators/validators are not sensitive enough."
                ),
                "key_formulas": {
                    "K_correct": "48 M^2 / r^6",
                    "K_broken": "48 M^2 / r^5  (INTENTIONALLY WRONG)",
                },
            },
            "sample_points": sample_points,
            "observables": {
                "summary": {
                    "horizon_radius_2M": self.horizon_radius(),
                    "points_with_finite_error": known,
                    "num_fail_relative_tolerance": fails,
                    "worst_relative_error": worst,
                    "worst_at_r": worst_r,
                    "note": "Expect widespread failures; this is intentional.",
                }
            },
        }

    def export_json(self, r_values: List[float], out_path: Optional[str] = None) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)
        payload = self.build_payload(r_values=r_values)
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2, sort_keys=True)
        return out_path


# ----------------------------
# CLI
# ----------------------------

def main() -> None:
    ap = argparse.ArgumentParser(description="Toy 049: Deliberately broken model (sanity check).")
    ap.add_argument("--M", type=float, default=1.0, help="Mass parameter M")
    ap.add_argument("--tol_rel", type=float, default=1e-12, help="Relative tolerance for passing checks")
    ap.add_argument(
        "--r",
        type=str,
        default="0.5,1,1.5,2,2.5,3,4,6,10,20",
        help="Comma-separated radii r>0",
    )
    ap.add_argument("--out", type=str, default="", help="Optional output path. If omitted, uses <this_script_name>.json")
    args = ap.parse_args()

    r_values = parse_csv_floats(args.r)
    toy = Toy049BrokenModel(M=float(args.M), tol_rel=float(args.tol_rel))

    out_path = args.out.strip() or None
    json_path = toy.export_json(r_values=r_values, out_path=out_path)

    print(f"Wrote {json_path}")
    print("Toy 049 complete: intentionally broken invariant (K) for sanity testing.")


if __name__ == "__main__":
    main()
