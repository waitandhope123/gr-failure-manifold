#!/usr/bin/env python3
"""
Toy 031 — Global hyperbolicity and Cauchy development

Pressure point:
- GR does not guarantee global hyperbolicity.
- In non–globally hyperbolic spacetimes, initial data does NOT uniquely determine evolution.

We compare:
1) 2D Minkowski spacetime (globally hyperbolic)
2) 2D Misner spacetime (contains a Cauchy horizon)

We compute simple causal reachability from an initial spacelike slice
and flag regions not determined by that data.
"""

import json
import math
import os
from typing import Dict, Any, List


def json_name() -> str:
    return os.path.splitext(os.path.basename(__file__))[0] + ".json"


# ----------------------------
# Causal structure helpers
# ----------------------------

def minkowski_domain_of_dependence(t0: float, x_extent: float, t: float) -> bool:
    """
    In 2D Minkowski, a point (t,x) is in the domain of dependence
    of the slice t=t0, |x|<=x_extent if its past lightcone
    intersects the slice entirely within that interval.
    """
    return abs(t - t0) <= x_extent


def misner_identification(u: float, v: float, gamma: float) -> (float, float):
    """
    Misner spacetime identification:
      (u, v) ~ (e^gamma u, e^-gamma v)
    """
    return math.exp(gamma) * u, math.exp(-gamma) * v


def misner_has_unique_extension(u: float, v: float) -> bool:
    """
    In Misner spacetime, regions with uv > 0 lie beyond the Cauchy horizon.
    Evolution there is not uniquely determined.
    """
    return u * v < 0


# ----------------------------
# Toy construction
# ----------------------------

def build_payload() -> Dict[str, Any]:
    t0 = 0.0
    x_extent = 5.0
    gamma = 1.0

    sample_points: List[Dict[str, Any]] = []

    # Sample points for Minkowski
    for t in [-2, 0, 2, 4, 6]:
        x = 0.0
        in_domain = minkowski_domain_of_dependence(t0, x_extent, t)

        sample_points.append({
            "coordinates": {"t": t, "x": x},
            "curvature_invariants": {
                "ricci_scalar": 0.0,
                "kretschmann": 0.0
            },
            "local_observables": {
                "domain_of_dependence": in_domain,
                "spacetime": "Minkowski"
            },
            "causal_structure": {
                "globally_hyperbolic": True,
                "predictable_from_initial_slice": in_domain
            }
        })

    # Sample points for Misner spacetime
    for u, v in [(-1, 1), (-0.5, 0.5), (0.5, 0.5), (1, 1)]:
        unique = misner_has_unique_extension(u, v)

        sample_points.append({
            "coordinates": {"u": u, "v": v},
            "curvature_invariants": {
                "ricci_scalar": 0.0,
                "kretschmann": 0.0
            },
            "local_observables": {
                "unique_cauchy_evolution": unique,
                "spacetime": "Misner"
            },
            "causal_structure": {
                "globally_hyperbolic": False,
                "cauchy_horizon_crossed": not unique,
                "predictable_from_initial_slice": unique
            }
        })

    return {
        "toy_id": "031",
        "theory": "General Relativity (causal structure)",
        "spacetime": "Minkowski vs Misner (2D)",
        "units": {"G": 1, "c": 1},
        "parameters": {
            "initial_slice_t0": t0,
            "slice_half_width": x_extent,
            "misner_gamma": gamma
        },
        "notes": {
            "pressure_point": (
                "Global hyperbolicity is not guaranteed in GR. "
                "In non–globally hyperbolic spacetimes, classical determinism fails: "
                "initial data does not uniquely determine future evolution."
            )
        },
        "sample_points": sample_points,
        "observables": {
            "summary": {
                "minkowski_predictability": "Complete",
                "misner_predictability": "Fails beyond Cauchy horizon",
                "key_result": "GR allows loss of determinism without curvature singularities"
            }
        }
    }


def main() -> None:
    payload = build_payload()
    out = json_name()
    with open(out, "w", encoding="utf-8") as f:
        json.dump(payload, f, indent=2, sort_keys=True)
    print(f"Wrote {out}")


if __name__ == "__main__":
    main()
