#!/usr/bin/env python3
"""
Toy 011 — Thin spherical shell backreaction (Israel junction conditions, dust shell)

What it probes (pressure point):
- Breaks the "test particle in fixed background" assumption:
  a self-gravitating shell has rest mass m_shell but contributes a *different*
  energy-at-infinity ΔM = M_out - M_in (includes binding/kinetic energy).
- Horizon formation and "where the mass is" become global/boundary notions:
  exterior horizon at r = 2 M_out can exist even if interior is flat/low-mass.

Model / assumptions:
- Spherical symmetry.
- A timelike, infinitesimally thin dust shell with rest mass m_shell.
- Interior region: Schwarzschild with mass M_in (often 0).
- Exterior region: Schwarzschild with mass M_out >= M_in.
- Geometric units: G = c = 1.
- Uses standard Israel junction condition for a dust shell (no pressure):
    sqrt(Rdot^2 + f_out) - sqrt(Rdot^2 + f_in) = - m_shell / R
  where f(r) = 1 - 2M/r, R is the shell areal radius, and dot is d/dτ (shell proper time).
  Solving yields:
    Rdot^2 = (ΔM/m_shell + m_shell/(2R))^2 - f_in(R)
  with ΔM := M_out - M_in and f_in(R) = 1 - 2 M_in / R.

Notes:
- Physical validity: thin-shell idealization; ignores radiation, pressure, thickness, asphericity.
- For some parameter choices, Rdot^2 < 0 at a given R => forbidden (no real motion there)
  for the assumed conserved masses.

STRICT EXPORT RULE:
- Writes JSON named exactly like this .py file (toy_011_thin_shell_backreaction.json).
- JSON follows the canonical schema with required keys and required subkeys.
- Undefined quantities are exported as null (JSON null).
"""

from __future__ import annotations

import argparse
import json
import math
import os
from typing import Any, Dict, List, Optional


# ----------------------------
# Helpers
# ----------------------------

def py_to_json_name(py_path: str) -> str:
    base = os.path.splitext(os.path.basename(py_path))[0]
    return base + ".json"


def parse_csv_floats(s: str) -> List[float]:
    return [float(x.strip()) for x in s.split(",") if x.strip()]


def require(cond: bool, msg: str) -> None:
    if not cond:
        raise ValueError(msg)


# ----------------------------
# Toy 011
# ----------------------------

class Toy011ThinShellBackreaction:
    toy_id = "011"

    def __init__(self, M_in: float = 0.0, M_out: float = 1.0, m_shell: float = 0.5) -> None:
        require(M_in >= 0.0, "M_in must be >= 0.")
        require(M_out >= 0.0, "M_out must be >= 0.")
        require(M_out >= M_in, "Require M_out >= M_in (exterior mass must be at least interior mass).")
        require(m_shell > 0.0, "m_shell must be > 0.")

        self.M_in = float(M_in)
        self.M_out = float(M_out)
        self.m_shell = float(m_shell)

    def f(self, r: float, M: float) -> float:
        require(r > 0.0, "r must be > 0.")
        return 1.0 - 2.0 * M / r

    def horizon(self, M: float) -> float:
        return 2.0 * M

    def delta_M(self) -> float:
        return self.M_out - self.M_in

    def binding_energy(self) -> float:
        # Energy-at-infinity contribution minus rest mass.
        # Negative => bound (net gravitational binding dominates), positive => extra kinetic energy at infinity.
        return self.delta_M() - self.m_shell

    def rdot2(self, R: float) -> float:
        """
        Shell radial equation from Israel junction (dust shell):
          Rdot^2 = (ΔM/m + m/(2R))^2 - f_in(R)
        where dot is d/dτ for the shell proper time.
        """
        require(R > 0.0, "R must be > 0.")
        dM = self.delta_M()
        m = self.m_shell
        term = (dM / m) + (m / (2.0 * R))
        f_in = self.f(R, self.M_in)
        return term * term - f_in

    def classification(self, R: float) -> str:
        """
        Rough region classification for intuition (not a substitute for full causal analysis):
        - compares shell radius to interior/exterior horizon radii
        - notes if motion is kinematically allowed (Rdot^2 >= 0)
        """
        rh_in = self.horizon(self.M_in)
        rh_out = self.horizon(self.M_out)
        v2 = self.rdot2(R)

        region_bits: List[str] = []
        if R > rh_out:
            region_bits.append("outside exterior horizon (R > 2M_out)")
        elif abs(R - rh_out) < 1e-12:
            region_bits.append("on exterior horizon (R = 2M_out)")
        else:
            region_bits.append("inside exterior horizon (R < 2M_out)")

        if self.M_in > 0.0:
            if R > rh_in:
                region_bits.append("outside interior horizon (R > 2M_in)")
            elif abs(R - rh_in) < 1e-12:
                region_bits.append("on interior horizon (R = 2M_in)")
            else:
                region_bits.append("inside interior horizon (R < 2M_in)")
        else:
            region_bits.append("interior is Minkowski (M_in = 0)")

        if v2 >= 0.0:
            region_bits.append("motion allowed (Rdot^2 >= 0)")
        else:
            region_bits.append("forbidden radius for these conserved masses (Rdot^2 < 0)")

        return "; ".join(region_bits)

    def build_payload(self, R_values: List[float]) -> Dict[str, Any]:
        sample_points: List[Dict[str, Any]] = []

        rh_in = self.horizon(self.M_in)
        rh_out = self.horizon(self.M_out)
        dM = self.delta_M()
        bind = self.binding_energy()

        for R in R_values:
            R = float(R)
            require(R > 0.0, "All radii must be > 0.")

            f_in = self.f(R, self.M_in)
            f_out = self.f(R, self.M_out)
            v2 = self.rdot2(R)

            # Effective "potential" form: Rdot^2 + V_eff(R) = 0
            # => V_eff := -Rdot^2
            V_eff = -v2

            # Turning point estimate: where Rdot^2 = 0
            is_turning = abs(v2) < 1e-12

            # "Curvature invariants" for each region are Schwarzschild vacuum invariants.
            # For Schwarzschild vacuum: Ricci scalar R = 0, Kretschmann K = 48 M^2 / r^6.
            # Here we export both interior and exterior values at the shell radius.
            ricci_in = 0.0
            ricci_out = 0.0
            K_in = None if self.M_in == 0.0 else 48.0 * (self.M_in ** 2) / (R ** 6)
            K_out = 48.0 * (self.M_out ** 2) / (R ** 6)

            coordinates = {"tau_shell": None, "R": R, "t_in": None, "t_out": None}

            curvature_invariants = {
                "interior": {"ricci_scalar": ricci_in, "kretschmann": K_in},
                "exterior": {"ricci_scalar": ricci_out, "kretschmann": K_out},
                "note": "Vacuum invariants in each region evaluated at the shell areal radius; shell itself is distributional.",
            }

            local_observables = {
                "masses": {
                    "M_in": self.M_in,
                    "M_out": self.M_out,
                    "delta_M_energy_at_infinity": dM,
                    "m_shell_rest_mass": self.m_shell,
                    "binding_energy_deltaM_minus_m": bind,
                },
                "metric_functions_at_shell": {
                    "f_in": f_in,
                    "f_out": f_out,
                },
                "shell_equation_of_motion": {
                    "Rdot2": v2,
                    "Rdot": None if v2 < 0.0 else math.sqrt(max(v2, 0.0)),
                    "V_eff_defined_by_Rdot2_plus_Veff_eq_0": V_eff,
                    "turning_point_Rdot2_eq_0": is_turning,
                    "formula_used": "Rdot^2 = (ΔM/m + m/(2R))^2 - f_in(R)",
                },
                "horizons": {
                    "r_h_in_2M_in": rh_in,
                    "r_h_out_2M_out": rh_out,
                    "R_minus_r_h_out": R - rh_out,
                    "R_minus_r_h_in": None if self.M_in == 0.0 else (R - rh_in),
                },
            }

            causal_structure = {
                "region_classification": self.classification(R),
                "horizon_notes": {
                    "exterior_horizon_exists_if_M_out_gt_0": (self.M_out > 0.0),
                    "interior_horizon_exists_if_M_in_gt_0": (self.M_in > 0.0),
                    "key_point": "Exterior horizon location is set by M_out (global/boundary), not by local curvature at the shell.",
                },
                "radial_null_cone_dr_dt": None,
            }

            sample_points.append({
                "coordinates": coordinates,
                "curvature_invariants": curvature_invariants,
                "local_observables": local_observables,
                "causal_structure": causal_structure,
            })

        payload: Dict[str, Any] = {
            "toy_id": self.toy_id,
            "theory": "General Relativity (thin-shell backreaction via Israel junction)",
            "spacetime": "Two Schwarzschild regions joined across a timelike dust shell",
            "units": {"G": 1, "c": 1},
            "parameters": {
                "M_in": self.M_in,
                "M_out": self.M_out,
                "m_shell": self.m_shell,
            },
            "notes": {
                "pressure_point": (
                    "Backreaction onset: the shell's rest mass m_shell is not equal to its conserved "
                    "energy contribution at infinity ΔM=M_out-M_in. Binding energy and horizons are "
                    "global/boundary concepts, so 'small matter' can still change causal structure."
                ),
                "key_formulas": {
                    "f(r)": "f = 1 - 2M/r",
                    "junction_condition": "sqrt(Rdot^2+f_out) - sqrt(Rdot^2+f_in) = - m_shell/R",
                    "rdot2_solution": "Rdot^2 = (ΔM/m_shell + m_shell/(2R))^2 - f_in(R)",
                    "binding_energy": "E_bind = ΔM - m_shell",
                    "horizons": "r_h = 2M (each region)",
                },
                "domain_of_validity": (
                    "Idealized infinitesimally thin dust shell; ignores radiation, pressure, thickness, "
                    "and non-spherical perturbations."
                ),
            },
            "sample_points": sample_points,
            "observables": {
                "global": {
                    "M_in": self.M_in,
                    "M_out": self.M_out,
                    "delta_M_energy_at_infinity": dM,
                    "m_shell_rest_mass": self.m_shell,
                    "binding_energy_deltaM_minus_m": bind,
                    "r_h_in_2M_in": rh_in,
                    "r_h_out_2M_out": rh_out,
                }
            },
        }
        return payload

    def export_json(self, R_values: List[float], out_path: Optional[str] = None) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)
        payload = self.build_payload(R_values=R_values)
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2, sort_keys=True)
        return out_path


# ----------------------------
# CLI
# ----------------------------

def main() -> None:
    ap = argparse.ArgumentParser(
        description="Toy 011: thin dust shell backreaction via Israel junction conditions."
    )
    ap.add_argument("--M_in", type=float, default=0.0, help="Interior Schwarzschild mass (>=0)")
    ap.add_argument("--M_out", type=float, default=1.0, help="Exterior Schwarzschild mass (>= M_in)")
    ap.add_argument("--m_shell", type=float, default=0.5, help="Shell rest mass (>0)")
    ap.add_argument(
        "--R",
        type=str,
        default="0.8,1.0,1.2,1.5,2.0,2.5,3.0,4.0,6.0,10.0",
        help="Comma-separated shell radii (areal radius) at which to sample diagnostics",
    )
    ap.add_argument(
        "--out",
        type=str,
        default="",
        help="Optional output path. If omitted, uses <this_script_name>.json",
    )
    args = ap.parse_args()

    toy = Toy011ThinShellBackreaction(M_in=float(args.M_in), M_out=float(args.M_out), m_shell=float(args.m_shell))
    R_values = parse_csv_floats(args.R)

    out_path = args.out.strip() or None
    json_path = toy.export_json(R_values=R_values, out_path=out_path)

    print(f"Wrote {json_path}")
    print(
        f"Masses: "
        f"M_in={toy.M_in:g}, "
        f"M_out={toy.M_out:g}, "
        f"delta_M={toy.delta_M():g}, "
        f"m_shell={toy.m_shell:g}, "
        f"E_bind={toy.binding_energy():g}"
    )
    print(f"Horizons: r_h_in=2M_in={toy.horizon(toy.M_in):g}, r_h_out=2M_out={toy.horizon(toy.M_out):g}")


if __name__ == "__main__":
    main()
