#!/usr/bin/env python3
"""
Toy 010 — Schwarzschild circular orbits: photon sphere + ISCO (effective potential catalog)

What it probes (weak points / pressure points):
- Qualitatively new GR behavior (no Newtonian analogs):
  * Photon sphere at r = 3M (unstable null circular orbits)
  * Innermost stable circular orbit (ISCO) at r = 6M for timelike geodesics
- Stability boundary:
  * Circular timelike orbits exist for r > 3M, but stable only for r > 6M
- Uses coordinate-invariant-ish diagnostics (derived from geodesic integrals) vs coordinate artifacts

Model (G=c=1):
Schwarzschild f(r) = 1 - 2M/r

Timelike (massive particle) radial equation:
  (dr/dτ)^2 + V_eff_timelike(r; L) = E^2
  V_eff_timelike = f(r) * (1 + L^2/r^2)

Null (photon) radial equation (affine parameter λ):
  (dr/dλ)^2 + V_eff_null(r; L) = E^2
  V_eff_null = f(r) * (L^2/r^2)

Circular-orbit conditions:
  dV_eff/dr = 0

Timelike circular orbit (r>3M):
  L^2 = (M r^2) / (r - 3M)
  E^2 = (r - 2M)^2 / (r (r - 3M))
  Stability: stable iff r > 6M (ISCO at r=6M)

Null circular orbit (photon sphere):
  r = 3M
  Impact parameter b = L/E satisfies:
    b^2 = r^2 / f(r) ; at r=3M => b = 3*sqrt(3)*M

Coordinate angular frequency (as seen at infinity) for circular motion:
  Omega = sqrt(M / r^3)  (timelike circular orbits; also matches photon sphere value)

STRICT EXPORT RULE:
- Writes JSON named exactly like this .py file (toy_010_orbits_photonsphere_isco.json).
- JSON follows the canonical schema with required keys and required subkeys.
- Undefined quantities are exported as null (JSON null).
"""

from __future__ import annotations

import argparse
import json
import math
import os
from typing import Any, Dict, List, Optional


# ----------------------------
# Helpers
# ----------------------------

def py_to_json_name(py_path: str) -> str:
    base = os.path.splitext(os.path.basename(py_path))[0]
    return base + ".json"


def parse_csv_floats(s: str) -> List[float]:
    return [float(x.strip()) for x in s.split(",") if x.strip()]


def require(cond: bool, msg: str) -> None:
    if not cond:
        raise ValueError(msg)


# ----------------------------
# Toy 010
# ----------------------------

class Toy010OrbitsPhotonSphereISCO:
    toy_id = "010"

    def __init__(self, M: float = 1.0, L_probe: float = 4.0) -> None:
        require(M > 0.0, "M must be > 0.")
        self.M = float(M)
        self.L_probe = float(L_probe)

    def rh(self) -> float:
        return 2.0 * self.M

    def photon_sphere(self) -> float:
        return 3.0 * self.M

    def isco(self) -> float:
        return 6.0 * self.M

    def f(self, r: float) -> float:
        require(r > 0.0, "r must be > 0.")
        return 1.0 - 2.0 * self.M / r

    # --- Curvature invariants (Schwarzschild vacuum) ---
    def ricci_scalar(self, r: float) -> float:
        require(r > 0.0, "r must be > 0.")
        return 0.0

    def kretschmann(self, r: float) -> float:
        require(r > 0.0, "r must be > 0.")
        return 48.0 * (self.M ** 2) / (r ** 6)

    # --- Effective potentials ---
    def Veff_timelike(self, r: float, L: float) -> float:
        return self.f(r) * (1.0 + (L * L) / (r * r))

    def Veff_null(self, r: float, L: float) -> float:
        return self.f(r) * ((L * L) / (r * r))

    # For stability checks we can use analytic second derivative at circular orbit
    # Here we export stable/unstable based on known Schwarzschild result:
    # timelike circular stable iff r > 6M (r != 6M marginal), unstable for 3M < r < 6M.
    def timelike_circular_L2(self, r: float) -> Optional[float]:
        # L^2 = M r^2 / (r - 3M) for r > 3M
        if r <= 3.0 * self.M:
            return None
        return (self.M * r * r) / (r - 3.0 * self.M)

    def timelike_circular_E2(self, r: float) -> Optional[float]:
        # E^2 = (r-2M)^2 / (r (r-3M)) for r > 3M
        if r <= 3.0 * self.M:
            return None
        return ((r - 2.0 * self.M) ** 2) / (r * (r - 3.0 * self.M))

    def timelike_orbit_stability(self, r: float) -> Optional[str]:
        if r <= 3.0 * self.M:
            return None
        if abs(r - 6.0 * self.M) < 1e-12:
            return "marginal (ISCO)"
        return "stable" if r > 6.0 * self.M else "unstable"

    def omega_circular(self, r: float) -> Optional[float]:
        # Coordinate angular frequency at infinity (valid for circular geodesics where defined):
        # Omega = sqrt(M/r^3)
        if r <= 0.0:
            return None
        return math.sqrt(self.M / (r ** 3))

    def null_circular_b(self) -> float:
        # b = 3 sqrt(3) M at r = 3M
        return 3.0 * math.sqrt(3.0) * self.M

    def build_payload(self, r_values: List[float]) -> Dict[str, Any]:
        sample_points: List[Dict[str, Any]] = []
        rh = self.rh()
        rph = self.photon_sphere()
        risco = self.isco()

        # Using a fixed probe angular momentum for plotting/comparison of potentials
        Lp = self.L_probe

        for r in r_values:
            r = float(r)
            require(r > 0.0, "All radii must be > 0.")

            coordinates = {"t": None, "r": r, "theta": None, "phi": None}

            curvature_invariants = {
                "ricci_scalar": self.ricci_scalar(r),
                "kretschmann": self.kretschmann(r),
            }

            # Effective potentials at probe L
            Vt = None
            Vn = None
            if r > 0.0:
                Vt = self.Veff_timelike(r, Lp)
                Vn = self.Veff_null(r, Lp)

            # Circular-orbit derived quantities (timelike)
            L2_circ = self.timelike_circular_L2(r)
            E2_circ = self.timelike_circular_E2(r)
            stability = self.timelike_orbit_stability(r)

            # Null circular orbit exists only at r=3M (photon sphere)
            null_circular = None
            if abs(r - rph) < 1e-12:
                null_circular = {
                    "r_photon_sphere": rph,
                    "impact_parameter_b": self.null_circular_b(),
                    "omega_coordinate": self.omega_circular(rph),
                    "stability": "unstable",
                }

            local_observables: Dict[str, Any] = {
                "f": self.f(r),
                "special_radii": {"horizon_2M": rh, "photon_sphere_3M": rph, "isco_6M": risco},
                "effective_potentials_at_L_probe": {
                    "L_probe": Lp,
                    "Veff_timelike": Vt,
                    "Veff_null": Vn,
                    "interpretation": "(dr/dτ)^2 + Veff = E^2 (timelike); (dr/dλ)^2 + Veff = E^2 (null)",
                },
                "timelike_circular_orbit_if_exists": {
                    "exists_for_r_gt_3M": (r > 3.0 * self.M),
                    "L2": L2_circ,
                    "E2": E2_circ,
                    "E": None if E2_circ is None else math.sqrt(E2_circ),
                    "L": None if L2_circ is None else math.sqrt(L2_circ),
                    "omega_coordinate": None if (r <= 0.0) else self.omega_circular(r),
                    "stability": stability,
                },
                "null_circular_orbit_if_photon_sphere": null_circular,
            }

            causal_structure: Dict[str, Any] = {
                "radial_null_cone_dr_dt": None,
                "horizon_radius": rh,
                "region": (
                    "exterior (r>2M)" if r > rh else
                    ("horizon (r=2M)" if abs(r - rh) < 1e-12 else
                     "interior (r<2M)")
                ),
                "orbit_structure_notes": {
                    "timelike_circular_exist": "r > 3M",
                    "timelike_stable": "r > 6M",
                    "photon_sphere": "r = 3M (null, unstable)",
                },
            }

            sample_points.append({
                "coordinates": coordinates,
                "curvature_invariants": curvature_invariants,
                "local_observables": local_observables,
                "causal_structure": causal_structure,
            })

        payload: Dict[str, Any] = {
            "toy_id": self.toy_id,
            "theory": "General Relativity (geodesic structure in Schwarzschild)",
            "spacetime": "Schwarzschild: circular orbits, photon sphere, ISCO via effective potentials",
            "units": {"G": 1, "c": 1},
            "parameters": {
                "M": self.M,
                "L_probe": self.L_probe,
            },
            "notes": {
                "pressure_point": (
                    "GR introduces a photon sphere (r=3M) and an ISCO (r=6M) — qualitative features "
                    "absent in Newtonian gravity. Stability changes at r=6M even though spacetime is "
                    "smooth there (no curvature singularity)."
                ),
                "key_formulas": {
                    "Veff_timelike": "V = (1-2M/r)(1 + L^2/r^2)",
                    "Veff_null": "V = (1-2M/r)(L^2/r^2)",
                    "timelike_L2": "L^2 = M r^2 / (r-3M) (r>3M)",
                    "timelike_E2": "E^2 = (r-2M)^2 / (r(r-3M)) (r>3M)",
                    "isco": "r_ISCO = 6M",
                    "photon_sphere": "r_ph = 3M, b = 3 sqrt(3) M",
                    "omega": "Omega = sqrt(M/r^3)",
                },
            },
            "sample_points": sample_points,
            "observables": {
                "special_radii": {
                    "horizon_2M": self.rh(),
                    "photon_sphere_3M": self.photon_sphere(),
                    "isco_6M": self.isco(),
                    "impact_parameter_b_photon_sphere": self.null_circular_b(),
                    "omega_photon_sphere": self.omega_circular(self.photon_sphere()),
                }
            },
        }

        return payload

    def export_json(self, r_values: List[float], out_path: Optional[str] = None) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)
        payload = self.build_payload(r_values=r_values)
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2, sort_keys=True)
        return out_path


# ----------------------------
# CLI
# ----------------------------

def main() -> None:
    ap = argparse.ArgumentParser(description="Toy 010: Schwarzschild orbit structure exporter (photon sphere + ISCO).")
    ap.add_argument("--M", type=float, default=1.0, help="Mass parameter M (geometric units)")
    ap.add_argument("--L_probe", type=float, default=4.0, help="Probe angular momentum used for Veff sampling")
    ap.add_argument(
        "--r",
        type=str,
        default="2.2,2.5,3,3.5,4,5,6,7,8,10,20",
        help="Comma-separated radii (include 3M and 6M to see photon sphere and ISCO)",
    )
    ap.add_argument("--out", type=str, default="",
                    help="Optional output path. If omitted, uses <this_script_name>.json")
    args = ap.parse_args()

    toy = Toy010OrbitsPhotonSphereISCO(M=float(args.M), L_probe=float(args.L_probe))
    r_values = parse_csv_floats(args.r)

    out_path = args.out.strip() or None
    json_path = toy.export_json(r_values=r_values, out_path=out_path)

    print(f"Wrote {json_path}")
    print(f"Special radii: horizon=2M={toy.rh():g}, photon sphere=3M={toy.photon_sphere():g}, ISCO=6M={toy.isco():g}")


if __name__ == "__main__":
    main()
