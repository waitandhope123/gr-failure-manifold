#!/usr/bin/env python3
"""
Toy 066 — Unruh detector: thermal response from acceleration (observer as coarse-grainer)

What it probes (pressure point):
- In flat Minkowski spacetime (all curvature invariants = 0), an accelerated observer
  detects a thermal spectrum (Unruh effect) while an inertial observer does not.
- Same geometry, different operational physics depending on observer worldline and causal access.

Model (controlled QFT-in-curved-spacetime result; G=c=1, k_B=ħ=1):
- Use the standard Unruh temperature:
    T_U = a / (2π)
- For an Unruh–DeWitt detector with energy gap omega > 0 coupled to a massless scalar field,
  the excitation ("up") transition rate per unit proper time has Planck form:
    Γ_up(a) = (omega / (2π)) * 1 / (exp(2π omega / a) - 1)      for a > 0
  For inertial motion in Minkowski vacuum (a = 0), idealized Γ_up = 0.

- De-excitation ("down") includes spontaneous + stimulated:
    Γ_down(a) = (omega / (2π)) * (1 + 1/(exp(2π omega / a) - 1))   for a > 0
  For a=0: Γ_down = omega/(2π) (spontaneous emission term in this normalization).

Notes:
- This toy is operational/thermodynamic: it does not compute Wightman functions explicitly;
  it uses the standard closed-form response for uniform acceleration.
- Deterministic outputs; no randomness.

Export:
- Strict JSON schema per lab protocol.
- Undefined quantities => null; keys never omitted.
"""

from __future__ import annotations

import argparse
import json
import math
import os
from typing import Any, Dict, List, Optional


# ----------------------------
# Helpers
# ----------------------------

def py_to_json_name(py_path: str) -> str:
    base = os.path.splitext(os.path.basename(py_path))[0]
    return base + ".json"


def require(cond: bool, msg: str) -> None:
    if not cond:
        raise ValueError(msg)


def finite_or_none(x: float) -> Optional[float]:
    return x if (isinstance(x, (int, float)) and math.isfinite(x)) else None


def parse_csv_floats(s: str) -> List[float]:
    return [float(x.strip()) for x in s.split(",") if x.strip()]


# ----------------------------
# Toy 066
# ----------------------------

class Toy066UnruhDetector:
    toy_id = "066"

    def __init__(self, omega: float) -> None:
        require(omega > 0.0, "Detector gap omega must be > 0.")
        self.omega = float(omega)

    # Minkowski invariants
    def ricci_scalar(self) -> float:
        return 0.0

    def kretschmann(self) -> float:
        return 0.0

    def unruh_temperature(self, a: float) -> Optional[float]:
        if a < 0.0 or not math.isfinite(a):
            return None
        if a == 0.0:
            return 0.0
        return a / (2.0 * math.pi)

    def gamma_up(self, a: float) -> Optional[float]:
        # Excitation rate Γ_up
        if a < 0.0 or not math.isfinite(a):
            return None
        if a == 0.0:
            return 0.0
        x = 2.0 * math.pi * self.omega / a
        # Avoid overflow for huge x: exp(x) is enormous -> Γ_up ~ 0
        if x > 700.0:
            return 0.0
        denom = math.expm1(x)  # exp(x) - 1
        if denom <= 0.0:
            return None
        return (self.omega / (2.0 * math.pi)) * (1.0 / denom)

    def gamma_down(self, a: float) -> Optional[float]:
        # De-excitation rate Γ_down = spontaneous + stimulated
        if a < 0.0 or not math.isfinite(a):
            return None
        base = self.omega / (2.0 * math.pi)
        if a == 0.0:
            return base
        gup = self.gamma_up(a)
        if gup is None:
            return None
        return base + gup

    def detailed_balance_ratio(self, a: float) -> Optional[float]:
        # Γ_up / Γ_down should equal exp(-omega/T) = exp(-2π omega / a) for a>0
        if a <= 0.0 or not math.isfinite(a):
            return None
        gup = self.gamma_up(a)
        gdn = self.gamma_down(a)
        if gup is None or gdn is None or gdn == 0.0:
            return None
        return gup / gdn

    def expected_boltzmann(self, a: float) -> Optional[float]:
        if a <= 0.0 or not math.isfinite(a):
            return None
        x = 2.0 * math.pi * self.omega / a
        if x > 700.0:
            return 0.0
        return math.exp(-x)

    def sample_point(self, a: float) -> Dict[str, Any]:
        Tu = self.unruh_temperature(a)
        gup = self.gamma_up(a)
        gdn = self.gamma_down(a)
        ratio = self.detailed_balance_ratio(a)
        boltz = self.expected_boltzmann(a)

        # A simple "horizon scale" proxy for Rindler motion: ~1/a
        horizon_scale = None
        if a > 0.0:
            horizon_scale = 1.0 / a

        return {
            "coordinates": {
                "t": None,
                "x": None,
                "y": None,
                "z": None,
                "proper_acceleration_a": a,
            },
            "curvature_invariants": {
                "ricci_scalar": self.ricci_scalar(),
                "kretschmann": self.kretschmann(),
                "note": "Minkowski spacetime: invariants identically zero for all a."
            },
            "local_observables": {
                "detector_gap_omega": self.omega,
                "unruh_temperature_T": finite_or_none(Tu) if Tu is not None else None,
                "excitation_rate_Gamma_up": finite_or_none(gup) if gup is not None else None,
                "deexcitation_rate_Gamma_down": finite_or_none(gdn) if gdn is not None else None,
                "detailed_balance_ratio_up_over_down": finite_or_none(ratio) if ratio is not None else None,
                "expected_boltzmann_factor_exp_minus_omega_over_T": finite_or_none(boltz) if boltz is not None else None,
                "note": (
                    "Uniform acceleration gives thermal response (Unruh). "
                    "Inertial case (a=0): Γ_up=0 in idealized vacuum; Γ_down=omega/(2π) here."
                ),
            },
            "causal_structure": {
                "rindler_horizon_present": (a > 0.0),
                "rindler_horizon_scale_approx_1_over_a": finite_or_none(horizon_scale) if horizon_scale is not None else None,
                "note": "Acceleration introduces a Rindler horizon (restricted causal access) even though curvature is zero.",
            },
        }

    def build_payload(self, a_values: List[float]) -> Dict[str, Any]:
        require(len(a_values) >= 1, "Need at least one acceleration sample.")
        for a in a_values:
            require(a >= 0.0, "Accelerations must be >= 0 for this toy.")

        sample_points = [self.sample_point(a) for a in a_values]

        # Summary: check how well detailed balance matches Boltzmann for a>0
        max_abs_mismatch = None
        mismatches: List[float] = []
        for a in a_values:
            r = self.detailed_balance_ratio(a)
            b = self.expected_boltzmann(a)
            if r is not None and b is not None:
                mismatches.append(abs(r - b))
        if mismatches:
            max_abs_mismatch = max(mismatches)

        return {
            "toy_id": self.toy_id,
            "theory": "General Relativity (flat spacetime) + QFT-in-curved-spacetime detector response (Unruh)",
            "spacetime": "Minkowski; inertial vs uniformly accelerated (Rindler) observers",
            "units": {"G": 1, "c": 1},
            "parameters": {
                "omega_detector_gap": self.omega,
                "acceleration_samples_a": a_values,
                "conventions": "ħ = k_B = 1 (natural units for detector response)",
            },
            "notes": {
                "pressure_point": (
                    "Same geometry (Minkowski, invariants zero) yet accelerated observers measure a thermal bath (Unruh). "
                    "Operational physics depends on observer worldline and causal access, not curvature."
                ),
                "key_equations": {
                    "unruh_temperature": "T_U = a / (2π)",
                    "excitation_rate": "Γ_up = (omega/2π) * 1/(exp(2π omega / a) - 1)  (a>0)",
                    "deexcitation_rate": "Γ_down = (omega/2π) + Γ_up  (a>=0 in this normalization)",
                    "detailed_balance": "Γ_up/Γ_down = exp(-2π omega / a)  (a>0)",
                },
                "domain_of_validity": (
                    "Uniform acceleration, idealized eternal coupling, massless scalar field response in standard approximation. "
                    "Toy is operational/diagnostic; does not model switching transients."
                ),
            },
            "sample_points": sample_points,
            "observables": {
                "summary": {
                    "curvature_invariants_zero": True,
                    "thermal_response_present_for_a_gt_0": True,
                    "max_abs_detailed_balance_minus_boltzmann_over_valid_samples": finite_or_none(max_abs_mismatch)
                    if max_abs_mismatch is not None else None,
                    "note": "For a>0, detector satisfies thermal detailed balance at Unruh temperature."
                }
            },
        }

    def export_json(self, a_values: List[float], out_path: Optional[str] = None) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)
        payload = self.build_payload(a_values=a_values)
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2, sort_keys=True)
        return out_path


def main() -> None:
    ap = argparse.ArgumentParser(description="Toy 066: Unruh detector response (inertial vs accelerated observers in Minkowski).")
    ap.add_argument("--omega", type=float, default=1.0, help="Detector energy gap omega > 0")
    ap.add_argument("--a", type=str, default="0,0.2,0.5,1,2,5", help="Comma-separated accelerations a >= 0")
    ap.add_argument("--out", type=str, default="", help="Optional output JSON path")
    args = ap.parse_args()

    a_values = parse_csv_floats(args.a)
    toy = Toy066UnruhDetector(omega=float(args.omega))

    out_path = args.out.strip() or None
    json_path = toy.export_json(a_values=a_values, out_path=out_path)

    print(f"Wrote {json_path}")
    print("Toy 066 complete: thermal detector response emerges from acceleration in flat spacetime.")


if __name__ == "__main__":
    main()
