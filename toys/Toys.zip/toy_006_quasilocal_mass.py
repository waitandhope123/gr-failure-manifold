#!/usr/bin/env python3
"""
Toy 006 — Energy/Mass in GR via quasi-local mass (Misner–Sharp) + ADM/Komar where applicable

What it probes (weak points / pressure points):
- GR has no unique local gravitational energy density (not gauge-invariant / not a tensor).
- But in special settings you can define useful global / quasi-local masses.
- Misner–Sharp mass M_MS exists for spherically symmetric spacetimes and is quasi-local.
- ADM mass (asymptotic) and Komar mass (stationary) exist under additional conditions.

This toy supports two modes (one toy, selectable scenario):
  --mode schwarzschild
    * Schwarzschild vacuum: ADM = Komar = Misner–Sharp = M (for r>0).
  --mode flrw
    * Flat FLRW (k=0) with analytic scale factor models:
        radiation: a(t)=(t/t0)^(1/2)
        matter:    a(t)=(t/t0)^(2/3)
        desitter:  a(t)=exp(H0*(t-t0)) with a(t0)=1
    * Misner–Sharp mass inside areal radius R=a(t)*r:
        M_MS = (R^3 / 2) * H(t)^2    (for k=0, G=c=1)
    * Effective energy density from Friedmann (k=0):
        rho = 3 H^2 / (8*pi)

STRICT EXPORT RULE:
- Writes JSON named exactly like this .py file (toy_006_quasilocal_mass.json).
- JSON follows the canonical schema with required keys and required subkeys.
- Undefined quantities are exported as null (JSON null).
"""

from __future__ import annotations

import argparse
import json
import math
import os
from typing import Any, Dict, List, Optional


# ----------------------------
# Helpers
# ----------------------------

def py_to_json_name(py_path: str) -> str:
    base = os.path.splitext(os.path.basename(py_path))[0]
    return base + ".json"


def parse_csv_floats(s: str) -> List[float]:
    return [float(x.strip()) for x in s.split(",") if x.strip()]


def require(cond: bool, msg: str) -> None:
    if not cond:
        raise ValueError(msg)


# ----------------------------
# Schwarzschild (for mass notions)
# ----------------------------

class SchwarzschildMasses:
    """
    Schwarzschild vacuum in geometric units (G=c=1).
    For Schwarzschild:
      - ADM mass = M
      - Komar mass (stationary) = M
      - Misner–Sharp mass (spherical symmetry) = M (for r>0 in vacuum)
    Curvature invariants:
      R = 0
      K = 48 M^2 / r^6
    """

    def __init__(self, M: float) -> None:
        require(M > 0.0, "M must be > 0.")
        self.M = float(M)

    def horizon_radius(self) -> float:
        return 2.0 * self.M

    def ricci_scalar(self, r: float) -> float:
        require(r > 0.0, "r must be > 0.")
        return 0.0

    def kretschmann(self, r: float) -> float:
        require(r > 0.0, "r must be > 0.")
        return 48.0 * (self.M ** 2) / (r ** 6)

    def misner_sharp_mass(self, r: float) -> float:
        require(r > 0.0, "r must be > 0.")
        return self.M

    def adm_mass(self) -> float:
        return self.M

    def komar_mass(self) -> float:
        return self.M


# ----------------------------
# Flat FLRW (k=0) analytic models
# ----------------------------

class FLRWFlatAnalytic:
    """
    Flat FLRW (k=0) with analytic scale factors.

    Misner–Sharp mass for spherical symmetry:
      Areal radius: R = a(t) * r
      For k=0: M_MS = (R^3 / 2) * H(t)^2   (G=c=1)

    Effective energy density from Friedmann (k=0):
      H^2 = (8π/3) rho  => rho = 3H^2 / (8π)
    """

    def __init__(self, model: str, t0: float, H0: float) -> None:
        model = model.strip().lower()
        require(model in {"radiation", "matter", "desitter"}, "model must be radiation|matter|desitter")
        require(t0 > 0.0, "t0 must be > 0")
        require(H0 > 0.0, "H0 must be > 0 (for desitter)")
        self.model = model
        self.t0 = float(t0)
        self.H0 = float(H0)

    def a(self, t: float) -> float:
        require(t > 0.0, "t must be > 0.")
        if self.model == "radiation":
            return (t / self.t0) ** 0.5
        if self.model == "matter":
            return (t / self.t0) ** (2.0 / 3.0)
        return math.exp(self.H0 * (t - self.t0))

    def H(self, t: float) -> float:
        require(t > 0.0, "t must be > 0.")
        if self.model == "radiation":
            return 1.0 / (2.0 * t)
        if self.model == "matter":
            return 2.0 / (3.0 * t)
        return self.H0

    def Hdot(self, t: float) -> float:
        require(t > 0.0, "t must be > 0.")
        if self.model == "radiation":
            return -1.0 / (2.0 * t * t)
        if self.model == "matter":
            return -2.0 / (3.0 * t * t)
        return 0.0

    def ricci_scalar(self, t: float) -> float:
        # R = 6(Hdot + 2H^2) for k=0
        H = self.H(t)
        Hd = self.Hdot(t)
        return 6.0 * (Hd + 2.0 * H * H)

    def kretschmann(self, t: float) -> float:
        # K = 12[(ä/a)^2 + (ȧ/a)^4] = 12[(Hdot + H^2)^2 + H^4] for k=0
        H = self.H(t)
        Hd = self.Hdot(t)
        term1 = (Hd + H * H) ** 2
        term2 = (H ** 4)
        return 12.0 * (term1 + term2)

    def areal_radius(self, t: float, r: float) -> float:
        require(t > 0.0 and r >= 0.0, "t>0 and r>=0 required.")
        return self.a(t) * r

    def misner_sharp_mass(self, t: float, r: float) -> float:
        """
        For flat FLRW:
          M_MS = (R^3 / 2) * H^2
        """
        R = self.areal_radius(t, r)
        H = self.H(t)
        return 0.5 * (R ** 3) * (H ** 2)

    def rho_effective(self, t: float) -> float:
        """
        From Friedmann (k=0) in geometric units:
          rho = 3 H^2 / (8π)
        """
        H = self.H(t)
        return 3.0 * (H ** 2) / (8.0 * math.pi)


# ----------------------------
# Toy 006 driver / exporter
# ----------------------------

class Toy006QuasiLocalMass:
    toy_id = "006"

    def __init__(
        self,
        mode: str,
        M: float = 1.0,
        flrw_model: str = "matter",
        t0: float = 1.0,
        H0: float = 1.0,
    ) -> None:
        mode = mode.strip().lower()
        require(mode in {"schwarzschild", "flrw"}, "mode must be schwarzschild or flrw")
        self.mode = mode
        self.M = float(M)
        self.flrw_model = flrw_model
        self.t0 = float(t0)
        self.H0 = float(H0)

        self._sch = SchwarzschildMasses(M=self.M) if self.mode == "schwarzschild" else None
        self._flrw = FLRWFlatAnalytic(model=self.flrw_model, t0=self.t0, H0=self.H0) if self.mode == "flrw" else None

    def build_payload(
        self,
        r_values: List[float],
        t_values: List[float],
        flrw_r_comoving_values: List[float],
    ) -> Dict[str, Any]:

        sample_points: List[Dict[str, Any]] = []

        if self.mode == "schwarzschild":
            sch = self._sch
            assert sch is not None

            for r in r_values:
                r = float(r)
                require(r > 0.0, "Schwarzschild sample r must be > 0.")

                coordinates = {"t": None, "r": r, "theta": None, "phi": None}

                curvature_invariants = {
                    "ricci_scalar": sch.ricci_scalar(r),
                    "kretschmann": sch.kretschmann(r),
                }

                local_observables = {
                    "areal_radius_R": r,
                    "misner_sharp_mass_M_MS": sch.misner_sharp_mass(r),
                    "komar_mass_M_K": sch.komar_mass(),
                    "adm_mass_M_ADM": sch.adm_mass(),
                    "notes": "In vacuum Schwarzschild, ADM=Komar=Misner–Sharp=M (away from r=0 idealization).",
                }

                causal_structure = {
                    "radial_null_cone_dr_dt": None,
                    "horizon_radius": sch.horizon_radius(),
                    "region": "exterior" if r > sch.horizon_radius() else ("horizon" if r == sch.horizon_radius() else "interior"),
                    "energy_warning": "Local gravitational energy density is not a tensor; use global/quasi-local masses.",
                }

                sample_points.append({
                    "coordinates": coordinates,
                    "curvature_invariants": curvature_invariants,
                    "local_observables": local_observables,
                    "causal_structure": causal_structure,
                })

            observables = {
                "mass_summary": {
                    "adm_mass_M_ADM": sch.adm_mass(),
                    "komar_mass_M_K": sch.komar_mass(),
                    "misner_sharp_mass_M_MS": sch.misner_sharp_mass(r_values[0]) if r_values else sch.adm_mass(),
                    "comment": "All coincide for Schwarzschild (stationary, asymptotically flat, spherical vacuum).",
                }
            }

            spacetime = "Schwarzschild vacuum (asymptotically flat, stationary, spherical)"

        else:
            flrw = self._flrw
            assert flrw is not None

            # sample over (t, r_comoving)
            for t in t_values:
                t = float(t)
                require(t > 0.0, "FLRW sample t must be > 0.")
                for rcom in flrw_r_comoving_values:
                    rcom = float(rcom)
                    require(rcom >= 0.0, "FLRW comoving r must be >= 0.")

                    R = flrw.areal_radius(t, rcom)
                    Mms = flrw.misner_sharp_mass(t, rcom)

                    coordinates = {"t": t, "r_comoving": rcom, "areal_radius_R": R, "theta": None, "phi": None}

                    curvature_invariants = {
                        "ricci_scalar": flrw.ricci_scalar(t),
                        "kretschmann": flrw.kretschmann(t),
                    }

                    local_observables = {
                        "scale_factor_a": flrw.a(t),
                        "hubble_H": flrw.H(t),
                        "rho_effective_from_friedmann": flrw.rho_effective(t),
                        "misner_sharp_mass_M_MS_inside_R": Mms,
                        "komar_mass_M_K": None,   # not stationary
                        "adm_mass_M_ADM": None,   # not asymptotically flat
                        "notes": "In FLRW, Misner–Sharp is meaningful quasi-locally; ADM/Komar typically not applicable.",
                    }

                    causal_structure = {
                        "radial_null_cone_dr_dt": {"outgoing": 1.0, "ingoing": -1.0},  # local c=1
                        "horizon_radius": None,
                        "region": "flat FLRW (k=0)",
                        "energy_warning": "Energy concepts depend on symmetry/boundaries; here use M_MS and rho from Friedmann.",
                    }

                    sample_points.append({
                        "coordinates": coordinates,
                        "curvature_invariants": curvature_invariants,
                        "local_observables": local_observables,
                        "causal_structure": causal_structure,
                    })

            observables = {
                "model_summary": {
                    "flrw_model": flrw.model,
                    "t0": flrw.t0,
                    "H0": flrw.H0 if flrw.model == "desitter" else None,
                    "comment": "M_MS grows with enclosed areal radius R and depends on H(t).",
                },
                "why_no_ADM_or_Komar": (
                    "ADM requires asymptotic flatness; Komar requires stationarity. "
                    "FLRW generally has neither, so those are exported as null."
                )
            }

            spacetime = "Flat FLRW (k=0) analytic a(t) (spherical symmetry for M_MS only)"

        payload: Dict[str, Any] = {
            "toy_id": self.toy_id,
            "theory": "General Relativity (energy/mass diagnostics)",
            "spacetime": spacetime,
            "units": {"G": 1, "c": 1},
            "parameters": {
                "mode": self.mode,
                "M": self.M if self.mode == "schwarzschild" else None,
                "flrw_model": self.flrw_model if self.mode == "flrw" else None,
                "t0": self.t0 if self.mode == "flrw" else None,
                "H0": self.H0 if (self.mode == "flrw" and self.flrw_model == "desitter") else None,
            },
            "notes": {
                "pressure_point": (
                    "GR does not provide a unique local gravitational energy density. "
                    "Useful 'mass/energy' notions depend on symmetry (spherical), stationarity (Komar), "
                    "or asymptotics (ADM). Misner–Sharp provides a quasi-local mass in spherical symmetry."
                ),
                "definitions_used": {
                    "Misner-Sharp (k=0 FLRW)": "M_MS = (R^3/2) * H^2, where R=a(t)r",
                    "Effective rho (k=0 FLRW)": "rho = 3H^2/(8π)",
                    "Schwarzschild": "ADM=Komar=M_MS=M",
                },
            },
            "sample_points": sample_points,
            "observables": observables,
        }

        return payload

    def export_json(
        self,
        r_values: List[float],
        t_values: List[float],
        flrw_r_comoving_values: List[float],
        out_path: Optional[str] = None,
    ) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)

        payload = self.build_payload(r_values=r_values, t_values=t_values, flrw_r_comoving_values=flrw_r_comoving_values)
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2, sort_keys=True)
        return out_path


# ----------------------------
# CLI
# ----------------------------

def main() -> None:
    ap = argparse.ArgumentParser(description="Toy 006: Quasi-local mass (Misner–Sharp) + ADM/Komar where applicable.")
    ap.add_argument("--mode", type=str, default="schwarzschild", help="schwarzschild | flrw")

    # Schwarzschild parameters
    ap.add_argument("--M", type=float, default=1.0, help="Schwarzschild mass parameter M (mode=schwarzschild)")

    # FLRW parameters
    ap.add_argument("--flrw_model", type=str, default="matter", help="radiation | matter | desitter (mode=flrw)")
    ap.add_argument("--t0", type=float, default=1.0, help="Normalization time t0>0 (mode=flrw)")
    ap.add_argument("--H0", type=float, default=1.0, help="de Sitter H0>0 (mode=flrw, model=desitter)")

    # Sampling
    ap.add_argument("--r", type=str, default="3,4,6,10,20", help="Schwarzschild sample radii r>0")
    ap.add_argument("--t", type=str, default="0.5,1,2,5,10", help="FLRW sample times t>0")
    ap.add_argument("--rcom", type=str, default="0,0.5,1,2", help="FLRW comoving radii r>=0")

    ap.add_argument("--out", type=str, default="",
                    help="Optional output path. If omitted, uses <this_script_name>.json")

    args = ap.parse_args()

    toy = Toy006QuasiLocalMass(
        mode=args.mode,
        M=float(args.M),
        flrw_model=args.flrw_model,
        t0=float(args.t0),
        H0=float(args.H0),
    )

    r_values = parse_csv_floats(args.r)
    t_values = parse_csv_floats(args.t)
    rcom_values = parse_csv_floats(args.rcom)

    out_path = args.out.strip() or None
    json_path = toy.export_json(r_values=r_values, t_values=t_values, flrw_r_comoving_values=rcom_values, out_path=out_path)

    print(f"Wrote {json_path}")
    print("Notes:")
    print("- Schwarzschild: ADM=Komar=Misner–Sharp=M.")
    print("- FLRW: ADM/Komar not generally defined; Misner–Sharp is quasi-local in spherical symmetry.")


if __name__ == "__main__":
    main()
