#!/usr/bin/env python3
"""
Toy 007 — Schwarzschild vs ingoing Eddington–Finkelstein (EF) coordinates

What it probes (weak points / pressure points):
- Coordinate singularity vs curvature singularity:
  * Schwarzschild g_rr = 1/f diverges at r=2M (coordinate issue).
  * EF metric is regular at r=2M (same geometry, better coordinates).
  * Kretschmann K = 48 M^2 / r^6 is finite at r=2M and diverges only at r->0.
- Causal structure across the horizon:
  * Schwarzschild coordinate null slopes dr/dt = ±f become ill-defined at r<=2M.
  * Ingoing EF coordinates extend smoothly across r=2M.

Definitions (G=c=1):
- f(r) = 1 - 2M/r
- Schwarzschild metric (t,r):
    ds^2 = -f dt^2 + f^{-1} dr^2 + r^2 dΩ^2
- Ingoing EF coordinates v = t + r*, with tortoise:
    r* = r + 2M ln| r/(2M) - 1 |
  EF metric (v,r):
    ds^2 = -f dv^2 + 2 dv dr + r^2 dΩ^2

Radial null directions:
- Schwarzschild (r>2M): dr/dt = ± f
- Ingoing EF:
    outgoing: dr/dv = f/2
    ingoing: v = const (i.e., dv=0 defines ingoing null rays)

STRICT EXPORT RULE:
- Writes JSON named exactly like this .py file (toy_007_schwarzschild_ef_coordinates.json).
- JSON follows the canonical schema with required keys and required subkeys.
- Undefined quantities are exported as null (JSON null).
"""

from __future__ import annotations

import argparse
import json
import math
import os
from typing import Any, Dict, List, Optional


# ----------------------------
# Helpers
# ----------------------------

def py_to_json_name(py_path: str) -> str:
    base = os.path.splitext(os.path.basename(py_path))[0]
    return base + ".json"


def parse_csv_floats(s: str) -> List[float]:
    return [float(x.strip()) for x in s.split(",") if x.strip()]


def require(cond: bool, msg: str) -> None:
    if not cond:
        raise ValueError(msg)


# ----------------------------
# Toy 007: Schwarzschild vs EF
# ----------------------------

class Toy007SchwarzschildEF:
    toy_id = "007"

    def __init__(self, M: float = 1.0) -> None:
        require(M > 0.0, "M must be > 0.")
        self.M = float(M)

    def horizon_radius(self) -> float:
        return 2.0 * self.M

    def f(self, r: float) -> float:
        require(r > 0.0, "r must be > 0.")
        return 1.0 - 2.0 * self.M / r

    # --- Invariants ---
    def ricci_scalar(self, r: float) -> float:
        require(r > 0.0, "r must be > 0.")
        return 0.0  # vacuum outside r=0 idealization

    def kretschmann(self, r: float) -> float:
        require(r > 0.0, "r must be > 0.")
        return 48.0 * (self.M ** 2) / (r ** 6)

    # --- Tortoise coordinate ---
    def tortoise_rstar(self, r: float) -> Optional[float]:
        """
        r* = r + 2M ln|r/(2M) - 1|
        Diverges at r = 2M.
        """
        require(r > 0.0, "r must be > 0.")
        if r == self.horizon_radius():
            return None
        # Use absolute value in the log to allow interior r<2M too.
        x = abs(r / self.horizon_radius() - 1.0)
        # If extremely close to horizon, log can be huge; that's fine numerically.
        return r + 2.0 * self.M * math.log(x)

    # --- Metric components in each chart ---
    def metric_components_schwarzschild(self, r: float) -> Dict[str, Any]:
        """
        (t,r,theta,phi) chart:
          g_tt = -f
          g_rr = 1/f  (diverges at horizon)
        Only meaningful as a coordinate representation; divergence is coordinate.
        """
        require(r > 0.0, "r must be > 0.")
        f = self.f(r)
        g_tt = -f
        g_rr = None
        if f != 0.0:
            g_rr = 1.0 / f
        else:
            g_rr = None  # infinite; represent as null
        return {"g_tt": g_tt, "g_rr": g_rr, "g_tr": 0.0}

    def metric_components_ingoing_ef(self, r: float) -> Dict[str, Any]:
        """
        (v,r,theta,phi) chart:
          g_vv = -f
          g_vr = +1
          g_rr = 0
        Regular at r=2M.
        """
        require(r > 0.0, "r must be > 0.")
        f = self.f(r)
        return {"g_vv": -f, "g_vr": 1.0, "g_rr": 0.0}

    # --- Null slopes (coordinate-dependent) ---
    def radial_null_slopes_schwarzschild(self, r: float) -> Optional[Dict[str, float]]:
        """
        Radial null in Schwarzschild coordinates:
          dr/dt = ± f
        For r<=2M, Schwarzschild t is not a good global time; export null.
        """
        require(r > 0.0, "r must be > 0.")
        if r <= self.horizon_radius():
            return None
        f = self.f(r)
        return {"outgoing_dr_dt": f, "ingoing_dr_dt": -f}

    def radial_null_slopes_ingoing_ef(self, r: float) -> Dict[str, Any]:
        """
        Ingoing EF radial null curves satisfy:
          0 = -f dv^2 + 2 dv dr
        Solutions:
          - ingoing null rays: v = const  (dv = 0)
          - outgoing null rays: dr/dv = f/2
        This remains valid through the horizon.
        """
        require(r > 0.0, "r must be > 0.")
        f = self.f(r)
        return {
            "ingoing": {"type": "v=const", "dr_dv": None},
            "outgoing": {"type": "dr/dv = f/2", "dr_dv": 0.5 * f},
        }

    # --- Export payload ---
    def build_payload(self, r_values: List[float]) -> Dict[str, Any]:
        sample_points: List[Dict[str, Any]] = []
        rh = self.horizon_radius()

        for r in r_values:
            r = float(r)
            require(r > 0.0, "All radii must be > 0.")

            # Required schema subkeys
            coordinates = {"t": None, "r": r, "theta": None, "phi": None, "v": None}

            curvature_invariants = {
                "ricci_scalar": self.ricci_scalar(r),
                "kretschmann": self.kretschmann(r),
            }

            # Coordinate comparison bundle (local_observables)
            rstar = self.tortoise_rstar(r)

            local_observables: Dict[str, Any] = {
                "f": self.f(r),
                "horizon_radius_2M": rh,
                "tortoise_rstar": rstar,
                "coordinate_maps": {
                    "ingoing_ef_definition": "v = t + r*",
                    "t_from_v_and_rstar": None if rstar is None else "t = v - r*",
                    "note": "r* diverges at r=2M; mapping between t and v becomes singular there (coordinate issue).",
                },
                "metric_schwarzschild": self.metric_components_schwarzschild(r),
                "metric_ingoing_ef": self.metric_components_ingoing_ef(r),
            }

            causal_structure: Dict[str, Any] = {
                "radial_null_cone_dr_dt": self.radial_null_slopes_schwarzschild(r),
                "radial_null_cone_in_ingoing_ef": self.radial_null_slopes_ingoing_ef(r),
                "horizon_radius": rh,
                "region": (
                    "exterior (r>2M)" if r > rh else
                    ("horizon (r=2M)" if r == rh else
                     "interior (r<2M)")
                ),
                "coordinate_pathology_flag": {
                    "schwarzschild_chart_breaks_down_for_r_le_2M": (r <= rh),
                    "ef_chart_regular_at_horizon": True,
                },
            }

            sample_points.append({
                "coordinates": coordinates,
                "curvature_invariants": curvature_invariants,
                "local_observables": local_observables,
                "causal_structure": causal_structure,
            })

        payload: Dict[str, Any] = {
            "toy_id": self.toy_id,
            "theory": "General Relativity (exact solution; coordinate comparison)",
            "spacetime": "Schwarzschild geometry in (t,r) vs ingoing Eddington–Finkelstein (v,r)",
            "units": {"G": 1, "c": 1},
            "parameters": {"M": self.M},
            "notes": {
                "assumptions": [
                    "Vacuum Schwarzschild geometry (outside r=0 idealization)",
                    "Comparing two coordinate charts on the same spacetime",
                    "Geometric units G=c=1",
                ],
                "pressure_point": (
                    "The Schwarzschild chart has a coordinate singularity at r=2M (g_rr -> ∞, "
                    "and t becomes ill-behaved). Ingoing EF coordinates are regular at r=2M. "
                    "Curvature invariants (e.g., Kretschmann) remain finite at r=2M, proving the "
                    "horizon is not a curvature singularity."
                ),
                "recommended_diffs": [
                    "Compare metric_schwarzschild.g_rr vs metric_ingoing_ef components near r=2M",
                    "Compare radial null slopes: Schwarzschild outputs null at r<=2M, EF continues",
                    "Compare Kretschmann at r=2M vs r->0",
                ],
            },
            "sample_points": sample_points,
            "observables": {
                "summary": {
                    "horizon_radius_2M": rh,
                    "kretschmann_at_horizon": self.kretschmann(rh),
                    "ricci_scalar_everywhere_r_gt_0": 0.0,
                    "note": "Kretschmann finite at r=2M, diverges as r->0.",
                }
            },
        }

        return payload

    def export_json(self, r_values: List[float], out_path: Optional[str] = None) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)
        payload = self.build_payload(r_values=r_values)
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2, sort_keys=True)
        return out_path


# ----------------------------
# CLI
# ----------------------------

def main() -> None:
    ap = argparse.ArgumentParser(description="Toy 007: Schwarzschild vs ingoing EF coordinate comparison (GR).")
    ap.add_argument("--M", type=float, default=1.0, help="Mass parameter M (geometric units)")
    ap.add_argument("--r", type=str, default="1,1.5,2,2.5,3,4,6,10,20",
                    help="Comma-separated radii r>0 (include values near 2M to see coordinate effects)")
    ap.add_argument("--out", type=str, default="",
                    help="Optional output path. If omitted, uses <this_script_name>.json")
    args = ap.parse_args()

    r_values = parse_csv_floats(args.r)
    toy = Toy007SchwarzschildEF(M=float(args.M))

    out_path = args.out.strip() or None
    json_path = toy.export_json(r_values=r_values, out_path=out_path)

    print(f"Wrote {json_path}")
    print(f"Note: Schwarzschild chart quantities that rely on t are null for r <= 2M = {toy.horizon_radius():g}.")
    print("EF chart remains regular across the horizon.")


if __name__ == "__main__":
    main()
