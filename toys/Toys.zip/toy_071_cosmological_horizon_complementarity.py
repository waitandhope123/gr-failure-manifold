#!/usr/bin/env python3
"""
Toy 071 — Cosmological horizon complementarity (de Sitter): vacuum choice + observer location

Classification (lab axes):
- Failure Trigger: observer
- Failure Mode: observer_disagreement
- Failure Sharpness: contextual
- Repairable Within Classical GR: only_by_reinterpretation

What it probes (pressure point):
- A positive cosmological constant introduces a cosmological horizon with an associated
  Gibbons–Hawking temperature.
- The notion of "particles" depends both on the observer's worldline (location in the
  static patch) and on the quantum state/vacuum choice.

Model (controlled approximation):
- 4D de Sitter spacetime in static coordinates (G=c=1; and for temperature conventions
  set ħ=k_B=1):
    ds^2 = -(1 - H^2 r^2) dt^2 + (1 - H^2 r^2)^{-1} dr^2 + r^2 dΩ^2
  where H = sqrt(Λ/3).

Key quantities:
- Cosmological horizon radius: r_H = 1/H = sqrt(3/Λ)
- Gibbons–Hawking temperature (geodesic/Bunch–Davies): T_dS = H/(2π)
- Local static observer redshift factor: χ(r) = sqrt(1 - H^2 r^2)
- Local temperature in Bunch–Davies seen by a static observer at radius r:
    T_loc(r) = T_dS / χ(r)

Vacuum / "particle content" operationalization:
- In the Bunch–Davies (de Sitter-invariant) state, a static Unruh–DeWitt detector obeys
  thermal detailed balance at temperature T_loc(r). For a level spacing ω>0:
    R_abs/R_emit = exp(-ω/T_loc).
- In the static-patch vacuum (defined by positive frequency with respect to ∂_t in the
  static patch), the same stationary detector is in its vacuum and (idealized) absorption
  is suppressed: R_abs≈0, so R_abs/R_emit≈0.

Diagnostics exported:
- For several observer radii and several detector gaps ω, export the implied detailed-balance
  ratio for each vacuum choice.

Observed Results (what breaks and why it matters):
- The same geometry (fixed Λ) supports different notions of vacuum; a stationary detector's
  inferred "thermal bath" depends on that choice and on where the detector sits.
- This is horizon thermality without black holes, and it is observer/state-relative rather than
  an intrinsic property of curvature alone.

Export:
- Strict JSON schema per lab protocol; writes <script_name>.json.
- Undefined quantities exported as null; keys never omitted.
"""

from __future__ import annotations

import argparse
import json
import math
import os
from typing import Any, Dict, List, Optional


# ----------------------------
# Helpers
# ----------------------------


def py_to_json_name(py_path: str) -> str:
    base = os.path.splitext(os.path.basename(py_path))[0]
    return base + ".json"


def require(cond: bool, msg: str) -> None:
    if not cond:
        raise ValueError(msg)


def parse_csv_floats(s: str) -> List[float]:
    return [float(x.strip()) for x in s.split(",") if x.strip()]


def finite_or_none(x: float) -> Optional[float]:
    return x if (isinstance(x, (int, float)) and math.isfinite(x)) else None


# ----------------------------
# Toy 071
# ----------------------------


class Toy071CosmologicalHorizonComplementarity:
    toy_id = "071"

    def __init__(self, Lambda: float) -> None:
        require(Lambda > 0.0, "Lambda must be > 0 for de Sitter.")
        self.Lambda = float(Lambda)

    def H(self) -> float:
        return math.sqrt(self.Lambda / 3.0)

    def horizon_radius(self) -> float:
        return 1.0 / self.H()

    def chi(self, r: float) -> Optional[float]:
        # χ = sqrt(1 - H^2 r^2) in static patch
        if r < 0.0:
            return None
        val = 1.0 - (self.H() ** 2) * (r ** 2)
        if val < 0.0:
            return None
        return math.sqrt(val)

    def temperature_dS(self) -> float:
        # T = H / (2π) in units ħ=k_B=1
        return self.H() / (2.0 * math.pi)

    def temperature_local_bunch_davies(self, r: float) -> Optional[float]:
        ch = self.chi(r)
        if ch is None or ch == 0.0:
            return None
        return self.temperature_dS() / ch

    def curvature_invariants(self) -> Dict[str, float]:
        # 4D de Sitter: Ricci scalar R = 4Λ, Kretschmann K = R_abcd R^abcd = 8Λ^2/3
        R = 4.0 * self.Lambda
        K = (8.0 / 3.0) * (self.Lambda ** 2)
        return {"ricci_scalar": R, "kretschmann": K}

    def detailed_balance_ratio(self, omega: float, T: Optional[float]) -> Optional[float]:
        # ratio = exp(-ω/T) for thermal state; if T is None/0, undefined here
        if T is None or T <= 0.0:
            return None
        return math.exp(-omega / T)

    def sample_point(self, r: float, omegas: List[float]) -> Dict[str, Any]:
        rH = self.horizon_radius()
        ch = self.chi(r)
        TdS = self.temperature_dS()
        Tloc_bd = self.temperature_local_bunch_davies(r)

        # Two vacuum choices: (i) Bunch–Davies, (ii) static-patch vacuum
        # For static vacuum, idealized stationary detector sees no thermal bath => absorption suppressed.
        ratios_bd: Dict[str, Optional[float]] = {}
        ratios_static: Dict[str, Optional[float]] = {}
        for w in omegas:
            ratios_bd[str(w)] = finite_or_none(self.detailed_balance_ratio(w, Tloc_bd))
            # In static-patch vacuum: R_abs/R_emit ~ 0 for ω>0 (idealized)
            ratios_static[str(w)] = 0.0 if w > 0.0 else None

        inv = self.curvature_invariants()

        # Region test: within static patch r<rH
        region = None
        if r < rH:
            region = "static_patch (r<r_H)"
        elif abs(r - rH) < 1e-12:
            region = "horizon (r=r_H)"
        else:
            region = "outside_static_patch (r>r_H)"

        return {
            "coordinates": {"t": None, "r": r, "theta": None, "phi": None},
            "curvature_invariants": {
                "ricci_scalar": finite_or_none(inv["ricci_scalar"]),
                "kretschmann": finite_or_none(inv["kretschmann"]),
                "note": "de Sitter has constant scalar invariants; observer-dependence here is not due to curvature gradients.",
            },
            "local_observables": {
                "Lambda": self.Lambda,
                "H": finite_or_none(self.H()),
                "chi_redshift_factor": finite_or_none(ch) if ch is not None else None,
                "temperature_global_T_dS": finite_or_none(TdS),
                "vacua": {
                    "bunch_davies": {
                        "vacuum_state": "bunch_davies (de Sitter invariant)",
                        "temperature_local": finite_or_none(Tloc_bd) if Tloc_bd is not None else None,
                        "detector_detailed_balance_ratio_Rabs_over_Remit": ratios_bd,
                        "particle_content_detected": (
                            "thermal" if (Tloc_bd is not None and r < rH) else "undefined"
                        ),
                    },
                    "static_patch_vacuum": {
                        "vacuum_state": "static_patch_vacuum (positive frequency w.r.t. ∂_t)",
                        "temperature_local": 0.0 if r < rH else None,
                        "detector_detailed_balance_ratio_Rabs_over_Remit": ratios_static,
                        "particle_content_detected": ("none" if r < rH else "undefined"),
                        "note": "Idealized: stationary detector defines particles with respect to static time; absorption suppressed in this vacuum.",
                    },
                },
            },
            "causal_structure": {
                "horizon_radius_r_H": finite_or_none(rH),
                "region": region,
                "note": "Static coordinates cover r<r_H. Horizon thermality persists even with constant curvature invariants.",
            },
        }

    def build_payload(self, r_values: List[float], omegas: List[float]) -> Dict[str, Any]:
        require(len(r_values) >= 1, "Need at least one observer radius.")
        require(all(w > 0.0 for w in omegas), "All omegas should be > 0 for detailed balance.")

        sample_points = [self.sample_point(r=r, omegas=omegas) for r in r_values]

        rH = self.horizon_radius()
        TdS = self.temperature_dS()

        # Summary: maximum local BD temperature among sample radii (diverges as r->rH^-)
        max_Tloc = None
        for sp in sample_points:
            Tloc = sp["local_observables"]["vacua"]["bunch_davies"]["temperature_local"]
            if Tloc is not None:
                max_Tloc = Tloc if max_Tloc is None else max(max_Tloc, Tloc)

        return {
            "toy_id": self.toy_id,
            "theory": "General Relativity (de Sitter) + QFT detector thermality (vacuum-dependent)",
            "spacetime": "de Sitter static patch (Λ>0): horizon thermality and vacuum/observer dependence",
            "units": {"G": 1, "c": 1},
            "parameters": {
                "Lambda": self.Lambda,
                "H": finite_or_none(self.H()),
                "observer_r_samples": r_values,
                "detector_gap_omegas": omegas,
                "conventions": "ħ = k_B = 1; G=c=1",
            },
            "notes": {
                "pressure_point": (
                    "In de Sitter, horizon thermality is not black-hole-specific and is not purely geometric: "
                    "particle content depends on observer (location/redshift) and on vacuum choice (Bunch–Davies vs static patch)."
                ),
                "key_formulas": {
                    "H": "H = sqrt(Λ/3)",
                    "horizon": "r_H = 1/H = sqrt(3/Λ)",
                    "temperature": "T_dS = H/(2π)",
                    "redshift": "χ(r)=sqrt(1 - H^2 r^2)",
                    "local_temperature": "T_loc = T_dS / χ(r) (Bunch–Davies)",
                    "detailed_balance": "R_abs/R_emit = exp(-ω/T_loc) (thermal state)",
                },
                "domain_of_validity": (
                    "QFT detector thermality on fixed de Sitter background; "
                    "static-patch vacuum vs Bunch–Davies vacuum compared operationally via detailed balance."
                ),
            },
            "sample_points": sample_points,
            "observables": {
                "summary": {
                    "horizon_radius_r_H": finite_or_none(rH),
                    "temperature_global_T_dS": finite_or_none(TdS),
                    "max_bunch_davies_local_temperature_over_samples": finite_or_none(max_Tloc) if max_Tloc is not None else None,
                    "note": "Bunch–Davies appears thermal to static observers with redshifted T_loc; static vacuum is non-thermal for the same detector.",
                }
            },
        }

    def export_json(self, r_values: List[float], omegas: List[float], out_path: Optional[str] = None) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)
        payload = self.build_payload(r_values=r_values, omegas=omegas)
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2, sort_keys=True)
        return out_path


def main() -> None:
    ap = argparse.ArgumentParser(description="Toy 071: de Sitter cosmological horizon thermality and vacuum/observer dependence.")
    ap.add_argument("--Lambda", type=float, default=0.03, help="Cosmological constant Λ>0 (G=c=1).")
    ap.add_argument(
        "--r",
        type=str,
        default="0.0,2.0,4.0,5.0",
        help="Comma-separated static radii r to sample (must satisfy r<r_H for static patch).",
    )
    ap.add_argument(
        "--omega",
        type=str,
        default="0.25,0.5,1.0",
        help="Comma-separated detector gaps ω>0 to evaluate detailed balance.",
    )
    ap.add_argument("--out", type=str, default="", help="Optional output JSON path; default is <script>.json")
    args = ap.parse_args()

    r_values = parse_csv_floats(args.r)
    omegas = parse_csv_floats(args.omega)

    toy = Toy071CosmologicalHorizonComplementarity(Lambda=float(args.Lambda))

    out_path = args.out.strip() or None
    json_path = toy.export_json(r_values=r_values, omegas=omegas, out_path=out_path)

    print(f"Wrote {json_path}")
    print("Toy 071 complete: de Sitter horizon thermality is observer/vacuum dependent (complementarity).")


if __name__ == "__main__":
    main()
