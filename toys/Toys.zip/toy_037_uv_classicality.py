#!/usr/bin/env python3
"""
Toy 037 — Curvature scale vs Planck scale (classicality / UV breakdown diagnostic)

Pressure point / weakness probed:
- Classical GR has no intrinsic UV regulator. It happily produces regimes where curvature becomes so large
  that the notion of a smooth classical spacetime is expected to fail.
- This toy computes a dimensionless "classicality parameter" by comparing curvature invariants
  to a chosen minimum length scale ℓ_min (default: Planck length in geometric units, but user-settable).

Because your lab defaults to geometric units G=c=1, we cannot derive a unique Planck length without also
fixing ħ. Therefore:
- We introduce an explicit parameter l_min (a length scale cutoff) as an input.
- The toy reports where curvature invariants imply length scales comparable to or below l_min.

Model spacetime:
- Schwarzschild vacuum, mass M (G=c=1).
- Invariants:
    Ricci scalar: R = 0
    Kretschmann: K = 48 M^2 / r^6

Classicality diagnostics:
- A curvature length scale from K:
    L_K(r) = K^{-1/4}   (since K has units of 1/length^4)
- Dimensionless UV parameter:
    chi(r) = (l_min / L_K(r)) = l_min * K^{1/4}
  Interpretation:
    chi << 1  => classical regime (curvature scale >> cutoff)
    chi ~ 1   => UV breakdown (curvature scale ~ cutoff)
    chi >> 1  => deep UV (classical GR not operationally trustworthy)

Export:
- Writes JSON named exactly like this .py file.
- Uses the mandatory schema; undefined quantities are null.
"""

from __future__ import annotations

import argparse
import json
import math
import os
from typing import Any, Dict, List, Optional


# ----------------------------
# Helpers
# ----------------------------

def py_to_json_name(py_path: str) -> str:
    base = os.path.splitext(os.path.basename(py_path))[0]
    return base + ".json"


def require(cond: bool, msg: str) -> None:
    if not cond:
        raise ValueError(msg)


def parse_csv_floats(s: str) -> List[float]:
    return [float(x.strip()) for x in s.split(",") if x.strip()]


# ----------------------------
# Schwarzschild invariants + UV diagnostic
# ----------------------------

def horizon_radius(M: float) -> float:
    return 2.0 * M


def ricci_scalar(_: float, __: float) -> float:
    return 0.0


def kretschmann(M: float, r: float) -> Optional[float]:
    if r <= 0.0:
        return None
    return 48.0 * (M * M) / (r ** 6)


def curvature_length_from_K(K: float) -> Optional[float]:
    if K <= 0.0 or not math.isfinite(K):
        return None
    # L_K = K^{-1/4}
    return K ** (-0.25)


def chi_uv(l_min: float, K: float) -> Optional[float]:
    if l_min <= 0.0:
        return None
    if K <= 0.0 or not math.isfinite(K):
        return None
    # chi = l_min / L_K = l_min * K^{1/4}
    return l_min * (K ** 0.25)


def regime_from_chi(chi: Optional[float]) -> Optional[str]:
    if chi is None:
        return None
    if chi < 1e-3:
        return "deep_classical"
    if chi < 1e-1:
        return "classical"
    if chi < 1.0:
        return "approaching_uv"
    if chi < 10.0:
        return "uv_breakdown"
    return "deep_uv"


# ----------------------------
# Toy 037 driver
# ----------------------------

class Toy037UVClassicality:
    toy_id = "037"

    def __init__(self, M: float, r_values: List[float], l_min: float) -> None:
        require(M > 0.0, "M must be > 0")
        require(l_min > 0.0, "l_min must be > 0")
        require(len(r_values) > 0, "r_values must be non-empty")
        for r in r_values:
            require(r > 0.0, "all r must be > 0")
        self.M = float(M)
        self.r_values = [float(r) for r in r_values]
        self.l_min = float(l_min)

    def build_payload(self) -> Dict[str, Any]:
        M = self.M
        rh = horizon_radius(M)

        sample_points: List[Dict[str, Any]] = []

        # Track where chi crosses ~1
        closest_to_one = None  # (abs(log10 chi), r, chi, Lk, K)
        for r in self.r_values:
            K = kretschmann(M, r)
            Lk = curvature_length_from_K(K) if K is not None else None
            chi = chi_uv(self.l_min, K) if K is not None else None
            reg = regime_from_chi(chi)

            # determine region
            region = "exterior" if r > rh else ("horizon" if r == rh else "interior")

            if chi is not None and chi > 0:
                score = abs(math.log10(chi))
                if closest_to_one is None or score < closest_to_one[0]:
                    closest_to_one = (score, r, chi, Lk, K)

            sample_points.append({
                "coordinates": {
                    "r": r
                },
                "curvature_invariants": {
                    "ricci_scalar": ricci_scalar(M, r),
                    "kretschmann": K
                },
                "local_observables": {
                    "mass_M": M,
                    "horizon_radius": rh,
                    "curvature_length_L_K": Lk,
                    "l_min_cutoff": self.l_min,
                    "chi_uv": chi,
                    "regime": reg,
                    "notes": (
                        "chi_uv = l_min * K^{1/4} compares the cutoff length to the curvature length scale. "
                        "When chi_uv ~ 1, classical spacetime is expected to lose operational meaning."
                    )
                },
                "causal_structure": {
                    "horizon_radius": rh,
                    "region": region,
                    "energy_warning": (
                        "Classical GR does not contain a UV cutoff; this toy flags where curvature reaches the chosen cutoff."
                    )
                }
            })

        r_star = closest_to_one[1] if closest_to_one is not None else None
        chi_star = closest_to_one[2] if closest_to_one is not None else None
        Lk_star = closest_to_one[3] if closest_to_one is not None else None
        K_star = closest_to_one[4] if closest_to_one is not None else None

        payload: Dict[str, Any] = {
            "toy_id": self.toy_id,
            "theory": "General Relativity (UV / classicality diagnostics)",
            "spacetime": "Schwarzschild vacuum (UV breakdown flagged by curvature vs cutoff scale)",
            "units": {"G": 1, "c": 1},
            "parameters": {
                "M": self.M,
                "r_values": self.r_values,
                "l_min_cutoff": self.l_min
            },
            "notes": {
                "pressure_point": (
                    "GR allows arbitrarily large curvature (e.g., near r=0 in Schwarzschild) without an intrinsic regulator. "
                    "This toy introduces an explicit minimum length l_min and computes a dimensionless parameter chi_uv "
                    "to flag where classical spacetime is expected to fail operationally."
                ),
                "definitions_used": {
                    "kretschmann": "K = 48 M^2 / r^6",
                    "curvature_length": "L_K = K^{-1/4}",
                    "uv_parameter": "chi_uv = l_min / L_K = l_min * K^{1/4}"
                },
                "interpretation": (
                    "Because the lab uses G=c=1, the Planck length is not determined unless ħ is fixed. "
                    "Therefore l_min is user-supplied (could represent Planck, EFT cutoff, or a measurement limit)."
                )
            },
            "sample_points": sample_points,
            "observables": {
                "summary": {
                    "closest_to_chi_eq_1": {
                        "r": r_star,
                        "chi_uv": chi_star,
                        "curvature_length_L_K": Lk_star,
                        "kretschmann": K_star
                    },
                    "rule_of_thumb": "Classical regime: chi_uv << 1. UV breakdown: chi_uv ≳ 1.",
                    "key_result": (
                        "For fixed M, K grows ~ r^{-6} and chi_uv grows ~ r^{-3/2}; "
                        "classicality inevitably fails as r decreases if l_min is nonzero."
                    )
                }
            }
        }
        return payload

    def export_json(self, out_path: Optional[str] = None) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)
        payload = self.build_payload()
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2, sort_keys=True)
        return out_path


def main() -> None:
    ap = argparse.ArgumentParser(description="Toy 037: Curvature vs cutoff scale (UV classicality diagnostic).")
    ap.add_argument("--M", type=float, default=1.0, help="Schwarzschild mass M>0")
    ap.add_argument("--r", type=str, default="100,50,20,10,5,2,1,0.5,0.2,0.1,0.05,0.02,0.01",
                    help="Comma-separated radii r>0 to sample")
    ap.add_argument("--lmin", type=float, default=1e-3,
                    help="Minimum length cutoff l_min > 0 (user-chosen; e.g., Planck length in your unit convention)")
    ap.add_argument("--out", type=str, default="",
                    help="Optional output path. If omitted, uses <this_script_name>.json")
    args = ap.parse_args()

    toy = Toy037UVClassicality(
        M=float(args.M),
        r_values=parse_csv_floats(args.r),
        l_min=float(args.lmin),
    )
    out_path = args.out.strip() or None
    json_path = toy.export_json(out_path=out_path)
    print(f"Wrote {json_path}")
    print("Notes:")
    print("- chi_uv ~ 1 marks curvature length ~ cutoff length; chi_uv >> 1 is deep UV.")


if __name__ == "__main__":
    main()
