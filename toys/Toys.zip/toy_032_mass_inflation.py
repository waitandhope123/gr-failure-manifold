#!/usr/bin/env python3
"""
Toy 032 — Inner horizon instability (mass inflation) in Reissner–Nordström (RN)

What it probes (weak point):
- RN (and Kerr) contain an inner (Cauchy) horizon that is classically a boundary of predictability.
- Small perturbations (ingoing + outgoing flux) are exponentially blue-shifted near the inner horizon.
- In simplified “mass inflation” models (Poisson–Israel / Ori), an effective interior mass parameter
  grows ~ exp(kappa_- * v) along advanced time v near the Cauchy horizon, driving curvature large
  even without a curvature singularity in the unperturbed exact solution.

This toy implements a controlled proxy model:
- Background: RN with |Q| < M, geometric units G=c=1.
- Inner horizon radius r_- and surface gravity kappa_- are computed from RN.
- Mass inflation ansatz near inner horizon:
    m_eff(v) = M + A * (exp(kappa_- * v) - 1)
  where A>0 is a small perturbation amplitude (toy parameter).

Curvature diagnostic (proxy):
- We evaluate a "Kretschmann proxy" at r = r_- (inner horizon scale) using the Schwarzschild-like scaling:
    K_proxy(v) = 48 * m_eff(v)^2 / r_-^6
  This is not the exact RN K, but it captures the mass-inflation-driven blow-up scale with m_eff.

Export:
- Writes JSON named exactly like this .py file.
- Uses the mandatory schema and keeps undefined quantities as null.
"""

from __future__ import annotations

import argparse
import json
import math
import os
from typing import Any, Dict, List, Optional


# ----------------------------
# Helpers
# ----------------------------

def py_to_json_name(py_path: str) -> str:
    base = os.path.splitext(os.path.basename(py_path))[0]
    return base + ".json"


def require(cond: bool, msg: str) -> None:
    if not cond:
        raise ValueError(msg)


def linspace(a: float, b: float, n: int) -> List[float]:
    require(n >= 2, "n must be >= 2")
    step = (b - a) / (n - 1)
    return [a + i * step for i in range(n)]


# ----------------------------
# RN geometry essentials
# ----------------------------

def rn_horizons(M: float, Q: float) -> (float, float):
    """
    RN horizons:
      r_± = M ± sqrt(M^2 - Q^2), for |Q| < M
    """
    require(M > 0.0, "M must be > 0")
    require(abs(Q) < M, "|Q| must be < M (sub-extremal RN)")
    disc = math.sqrt(M * M - Q * Q)
    r_plus = M + disc
    r_minus = M - disc
    require(r_minus > 0.0, "r_- must be > 0 for sub-extremal RN")
    return r_plus, r_minus


def rn_surface_gravity_inner(M: float, Q: float) -> float:
    """
    Surface gravity at inner horizon (magnitude):
      kappa_- = (r_+ - r_-)/(2 r_-^2)
    (Conventions differ in sign; we use positive magnitude for growth rate.)
    """
    r_plus, r_minus = rn_horizons(M, Q)
    return (r_plus - r_minus) / (2.0 * r_minus * r_minus)


# ----------------------------
# Mass inflation proxy model
# ----------------------------

def m_eff(M: float, A: float, kappa_minus: float, v: float) -> float:
    """
    Mass inflation ansatz:
      m_eff(v) = M + A (exp(kappa_- v) - 1)
    """
    return M + A * (math.exp(kappa_minus * v) - 1.0)


def kretschmann_proxy(m: float, r_scale: float) -> float:
    """
    Proxy curvature scaling (Schwarzschild-like):
      K ~ 48 m^2 / r^6
    Used here at r_scale ~ r_- to show inflation-driven growth.
    """
    require(r_scale > 0.0, "r_scale must be > 0")
    return 48.0 * (m * m) / (r_scale ** 6)


# ----------------------------
# Toy 032 driver
# ----------------------------

class Toy032MassInflation:
    toy_id = "032"

    def __init__(self, M: float, Q: float, A: float, v_max: float, n: int) -> None:
        require(M > 0.0, "M must be > 0")
        require(abs(Q) < M, "|Q| must be < M (sub-extremal)")
        require(A >= 0.0, "A must be >= 0")
        require(v_max > 0.0, "v_max must be > 0")
        require(n >= 2, "n must be >= 2")
        self.M = float(M)
        self.Q = float(Q)
        self.A = float(A)
        self.v_max = float(v_max)
        self.n = int(n)

        self.r_plus, self.r_minus = rn_horizons(self.M, self.Q)
        self.kappa_minus = rn_surface_gravity_inner(self.M, self.Q)

    def build_payload(self) -> Dict[str, Any]:
        v_values = linspace(0.0, self.v_max, self.n)
        sample_points: List[Dict[str, Any]] = []

        # Evaluate along advanced time v near the inner horizon scale r_-
        for v in v_values:
            m = m_eff(self.M, self.A, self.kappa_minus, v)
            Kp = kretschmann_proxy(m, self.r_minus)
            blueshift = math.exp(self.kappa_minus * v)

            sample_points.append({
                "coordinates": {
                    "v_advanced": v,
                    "r_scale": self.r_minus,
                    "r_plus": self.r_plus,
                    "r_minus": self.r_minus
                },
                "curvature_invariants": {
                    "ricci_scalar": 0.0,                 # electrovac: trace-free stress-energy => R = 0
                    "kretschmann_proxy": Kp              # proxy for inflation-driven growth
                },
                "local_observables": {
                    "mass_parameter_M_background": self.M,
                    "charge_Q": self.Q,
                    "inner_surface_gravity_kappa_minus": self.kappa_minus,
                    "effective_mass_m_eff": m,
                    "blueshift_factor_exp(kappa_minus*v)": blueshift,
                    "notes": (
                        "m_eff is a mass-inflation ansatz near the Cauchy horizon; "
                        "K_proxy uses Schwarzschild-like scaling at r=r_- to show blow-up scale."
                    )
                },
                "causal_structure": {
                    "event_horizon_r_plus": self.r_plus,
                    "cauchy_horizon_r_minus": self.r_minus,
                    "region": "near inner (Cauchy) horizon",
                    "predictability_warning": (
                        "Cauchy horizon signals breakdown of global determinism; "
                        "perturbations are exponentially blue-shifted (mass inflation)."
                    )
                }
            })

        # Summaries
        m0 = m_eff(self.M, self.A, self.kappa_minus, 0.0)
        m_end = m_eff(self.M, self.A, self.kappa_minus, self.v_max)
        K0 = kretschmann_proxy(m0, self.r_minus)
        Kend = kretschmann_proxy(m_end, self.r_minus)

        payload: Dict[str, Any] = {
            "toy_id": self.toy_id,
            "theory": "General Relativity (black hole interiors, predictability limits)",
            "spacetime": "Reissner–Nordström interior (mass inflation proxy near Cauchy horizon)",
            "units": {"G": 1, "c": 1},
            "parameters": {
                "M": self.M,
                "Q": self.Q,
                "A_perturbation_amplitude": self.A,
                "v_max": self.v_max,
                "n_samples": self.n
            },
            "notes": {
                "pressure_point": (
                    "Sub-extremal RN has an inner (Cauchy) horizon, a boundary of predictability. "
                    "Small perturbations are exponentially blue-shifted there, producing 'mass inflation' "
                    "and driving curvature large, indicating classical instability of the idealized inner horizon."
                ),
                "model_limitations": (
                    "This is a simplified ansatz model capturing exponential growth scale via kappa_-. "
                    "It is not a full solution of perturbed Einstein–Maxwell equations."
                ),
                "definitions_used": {
                    "horizons": "r_± = M ± sqrt(M^2 - Q^2)",
                    "inner_surface_gravity": "kappa_- = (r_+ - r_-)/(2 r_-^2)",
                    "mass_inflation_ansatz": "m_eff(v) = M + A (exp(kappa_- v) - 1)",
                    "kretschmann_proxy": "K_proxy = 48 m_eff^2 / r_-^6"
                }
            },
            "sample_points": sample_points,
            "observables": {
                "summary": {
                    "r_plus": self.r_plus,
                    "r_minus": self.r_minus,
                    "kappa_minus": self.kappa_minus,
                    "m_eff_start": m0,
                    "m_eff_end": m_end,
                    "kretschmann_proxy_start": K0,
                    "kretschmann_proxy_end": Kend,
                    "growth_factor_m_eff_over_interval": (m_end / m0) if m0 != 0.0 else None,
                    "growth_factor_K_proxy_over_interval": (Kend / K0) if K0 != 0.0 else None,
                    "key_result": (
                        "Even tiny A can produce enormous effective mass/curvature growth over advanced time "
                        "due to exp(kappa_- v) blue-shift near the Cauchy horizon."
                    )
                }
            }
        }
        return payload

    def export_json(self, out_path: Optional[str] = None) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)
        payload = self.build_payload()
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2, sort_keys=True)
        return out_path


def main() -> None:
    ap = argparse.ArgumentParser(description="Toy 032: Mass inflation proxy near RN inner horizon.")
    ap.add_argument("--M", type=float, default=1.0, help="Mass parameter M > 0")
    ap.add_argument("--Q", type=float, default=0.8, help="Charge Q with |Q| < M (sub-extremal)")
    ap.add_argument("--A", type=float, default=1e-6, help="Perturbation amplitude A >= 0 (toy parameter)")
    ap.add_argument("--vmax", type=float, default=50.0, help="Max advanced time v > 0")
    ap.add_argument("--n", type=int, default=11, help="Number of samples along v (>=2)")
    ap.add_argument("--out", type=str, default="", help="Optional output path; default is <script>.json")
    args = ap.parse_args()

    toy = Toy032MassInflation(M=args.M, Q=args.Q, A=args.A, v_max=args.vmax, n=args.n)
    out_path = args.out.strip() or None
    json_path = toy.export_json(out_path=out_path)
    print(f"Wrote {json_path}")
    print("Notes:")
    print("- This toy uses an exponential mass-inflation ansatz set by inner-horizon surface gravity kappa_-.")


if __name__ == "__main__":
    main()
