#!/usr/bin/env python3
"""
Toy 42 — Numerical stability near horizons and singular limits

Purpose:
- Probe floating-point and numerical pathologies near:
  * event horizon r → 2M
  * singularity r → 0
- Separate physical divergence from numerical breakdown.

Spacetime:
- Schwarzschild (vacuum, M > 0)

Diagnostics:
- Kretschmann scalar
- Relative finite-difference sensitivity
- NaN / Inf detection
"""

from __future__ import annotations

import json
import math
import os
from typing import Dict, List, Optional


# ----------------------------
# Helpers
# ----------------------------

def py_to_json_name(py_path: str) -> str:
    base = os.path.splitext(os.path.basename(py_path))[0]
    return base + ".json"


def require(cond: bool, msg: str) -> None:
    if not cond:
        raise ValueError(msg)


# ----------------------------
# Physics
# ----------------------------

class Schwarzschild:
    def __init__(self, M: float):
        require(M > 0.0, "M must be > 0")
        self.M = float(M)

    def kretschmann(self, r: float) -> float:
        return 48.0 * self.M**2 / r**6

    def horizon_radius(self) -> float:
        return 2.0 * self.M


# ----------------------------
# Toy 42
# ----------------------------

class Toy042NumericalStability:
    toy_id = "042"

    def __init__(self, M: float = 1.0, eps: float = 1e-8):
        self.M = M
        self.eps = eps
        self.geom = Schwarzschild(M)

    def finite_difference_sensitivity(self, r: float) -> Optional[float]:
        """
        Relative sensitivity:
        |K(r+eps) - K(r)| / (|K(r)| * eps)
        """
        try:
            K0 = self.geom.kretschmann(r)
            K1 = self.geom.kretschmann(r + self.eps)
            if not math.isfinite(K0) or not math.isfinite(K1):
                return None
            return abs(K1 - K0) / (abs(K0) * self.eps)
        except Exception:
            return None

    def evaluate_at_r(self, r: float) -> Dict:
        record: Dict[str, Optional[float]] = {}

        try:
            K = self.geom.kretschmann(r)
            record["kretschmann"] = K if math.isfinite(K) else None
        except Exception:
            record["kretschmann"] = None

        sensitivity = self.finite_difference_sensitivity(r)

        return {
            "coordinates": {"r": r},
            "curvature_invariants": {
                "kretschmann": record["kretschmann"],
            },
            "local_observables": {
                "relative_sensitivity": sensitivity,
            },
            "causal_structure": {
                "near_horizon": abs(r - self.geom.horizon_radius()) < 10 * self.eps,
                "near_singularity": r < 10 * self.eps,
            },
        }

    def build_payload(self, r_values: List[float]) -> Dict:
        samples = [self.evaluate_at_r(r) for r in r_values]

        return {
            "toy_id": self.toy_id,
            "theory": "General Relativity",
            "spacetime": "Schwarzschild (numerical stability limits)",
            "units": {"G": 1, "c": 1},
            "parameters": {
                "M": self.M,
                "epsilon_step": self.eps,
            },
            "notes": {
                "purpose": (
                    "Diagnose numerical instability near horizons and singular limits. "
                    "Physical divergence must be distinguished from floating-point failure."
                ),
                "pressure_point": (
                    "Numerical breakdown may occur well before physical divergence."
                ),
            },
            "sample_points": samples,
            "observables": {
                "summary": {
                    "horizon_radius_2M": self.geom.horizon_radius(),
                    "min_r_sampled": min(r_values),
                    "max_r_sampled": max(r_values),
                }
            },
        }

    def export_json(self, r_values: List[float], out_path: Optional[str] = None) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)
        payload = self.build_payload(r_values)
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2, sort_keys=True)
        return out_path


# ----------------------------
# CLI
# ----------------------------

def main() -> None:
    M = 1.0
    toy = Toy042NumericalStability(M=M, eps=1e-8)

    rh = 2.0 * M

    r_values = [
        10.0,
        5.0,
        2.1,
        2.01,
        2.001,
        rh,
        1.999,
        1.0,
        0.5,
        0.1,
        0.01,
        1e-4,
        1e-6,
    ]

    out = toy.export_json(r_values=r_values)

    print(f"Wrote {out}")
    print("Toy 42 complete: numerical stability limits.")

if __name__ == "__main__":
    main()
