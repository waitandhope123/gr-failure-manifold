#!/usr/bin/env python3
"""
Toy 036 — Energy conditions vs “realistic” matter (perfect-fluid EOS in flat FLRW)

Pressure point / weakness probed:
- Many key GR results (singularity theorems, focusing, area theorems) rely on energy conditions
  (NEC/WEC/SEC/DEC).
- But whether these conditions hold is a statement about *matter*, not geometry.
- Even very common effective matter models (e.g., dark-energy-like w≈-1) violate SEC, and “phantom”
  models (w<-1) violate NEC/WEC. Super-stiff models (w>1) violate DEC (superluminal-ish stress).

Model:
- Flat FLRW (k=0) with a single perfect fluid, p = w ρ (constant w).
- For w != -1, use analytic power-law scale factor:
    a(t) = (t/t0)^n,  n = 2 / (3(1+w))
    H(t) = n/t,  Hdot(t) = -n/t^2
- For w = -1, use de Sitter:
    a(t) = exp(H0 (t - t0)), H(t)=H0, Hdot=0

From Friedmann (k=0, G=c=1):
- ρ = 3 H^2 / (8π)
- p = w ρ

Energy conditions for perfect fluid:
- NEC:  ρ + p >= 0
- WEC:  ρ >= 0 and ρ + p >= 0
- SEC:  ρ + 3p >= 0 and ρ + p >= 0
- DEC:  ρ >= |p|

Curvature invariants (k=0):
- Ricci scalar:      R = 6 (Hdot + 2H^2)
- Kretschmann scalar:K = 12 [ (Hdot + H^2)^2 + H^4 ]

Export:
- Writes JSON named exactly like this .py file.
- Uses the mandatory schema; undefined quantities are null.
"""

from __future__ import annotations

import argparse
import json
import math
import os
from typing import Any, Dict, List, Optional


# ----------------------------
# Helpers
# ----------------------------

def py_to_json_name(py_path: str) -> str:
    base = os.path.splitext(os.path.basename(py_path))[0]
    return base + ".json"


def require(cond: bool, msg: str) -> None:
    if not cond:
        raise ValueError(msg)


def parse_csv_floats(s: str) -> List[float]:
    return [float(x.strip()) for x in s.split(",") if x.strip()]


# ----------------------------
# FLRW + EOS utilities
# ----------------------------

def n_powerlaw(w: float) -> Optional[float]:
    if w == -1.0:
        return None
    # n = 2 / [3(1+w)]
    denom = 3.0 * (1.0 + w)
    if denom == 0.0:
        return None
    return 2.0 / denom


def H_flrw(t: float, w: float, t0: float, H0: float) -> float:
    require(t > 0.0, "t must be > 0")
    if w == -1.0:
        require(H0 > 0.0, "H0 must be > 0 for w=-1 (de Sitter)")
        return H0
    n = n_powerlaw(w)
    assert n is not None
    return n / t


def Hdot_flrw(t: float, w: float, t0: float, H0: float) -> float:
    require(t > 0.0, "t must be > 0")
    if w == -1.0:
        return 0.0
    n = n_powerlaw(w)
    assert n is not None
    return -n / (t * t)


def a_flrw(t: float, w: float, t0: float, H0: float) -> float:
    require(t > 0.0, "t must be > 0")
    require(t0 > 0.0, "t0 must be > 0")
    if w == -1.0:
        require(H0 > 0.0, "H0 must be > 0 for w=-1 (de Sitter)")
        return math.exp(H0 * (t - t0))
    n = n_powerlaw(w)
    assert n is not None
    return (t / t0) ** n


def rho_from_friedmann(H: float) -> float:
    # rho = 3 H^2 / (8π)
    return 3.0 * (H * H) / (8.0 * math.pi)


def pressure(w: float, rho: float) -> float:
    return w * rho


def ricci_scalar(H: float, Hdot: float) -> float:
    # R = 6 (Hdot + 2H^2)
    return 6.0 * (Hdot + 2.0 * H * H)


def kretschmann(H: float, Hdot: float) -> float:
    # K = 12[(Hdot + H^2)^2 + H^4]
    return 12.0 * ((Hdot + H * H) ** 2 + (H ** 4))


# ----------------------------
# Energy conditions (perfect fluid)
# ----------------------------

def energy_conditions(rho: float, p: float, tol: float = 0.0) -> Dict[str, bool]:
    nec = (rho + p) >= -tol
    wec = (rho >= -tol) and nec
    sec = (rho + 3.0 * p) >= -tol and nec
    dec = (rho >= abs(p) - tol) and (rho >= -tol)
    return {"NEC": nec, "WEC": wec, "SEC": sec, "DEC": dec}


# ----------------------------
# Toy 036 driver
# ----------------------------

class Toy036EnergyConditions:
    toy_id = "036"

    def __init__(
        self,
        w_values: List[float],
        t_values: List[float],
        t0: float,
        H0: float,
        tol: float,
    ) -> None:
        require(len(w_values) > 0, "w_values must be non-empty")
        require(len(t_values) > 0, "t_values must be non-empty")
        require(t0 > 0.0, "t0 must be > 0")
        require(tol >= 0.0, "tol must be >= 0")
        for t in t_values:
            require(t > 0.0, "all t must be > 0")

        self.w_values = [float(w) for w in w_values]
        self.t_values = [float(t) for t in t_values]
        self.t0 = float(t0)
        self.H0 = float(H0)
        self.tol = float(tol)

    def build_payload(self) -> Dict[str, Any]:
        sample_points: List[Dict[str, Any]] = []

        # Counters for summary
        counts = {k: 0 for k in ["NEC", "WEC", "SEC", "DEC"]}
        total = 0

        for w in self.w_values:
            for t in self.t_values:
                H = H_flrw(t, w, self.t0, self.H0)
                Hd = Hdot_flrw(t, w, self.t0, self.H0)
                a = a_flrw(t, w, self.t0, self.H0)

                rho = rho_from_friedmann(H)
                p = pressure(w, rho)

                conds = energy_conditions(rho, p, tol=self.tol)
                for k, ok in conds.items():
                    if not ok:
                        counts[k] += 1
                total += 1

                # Simple interpretation tags
                tags: List[str] = []
                if w < -1.0:
                    tags.append("phantom_like (NEC usually violated)")
                elif w == -1.0:
                    tags.append("cosmological_constant_like (SEC violated)")
                elif 0.0 <= w <= 1.0:
                    tags.append("standard_fluid_range")
                elif w > 1.0:
                    tags.append("superstiff (DEC violated)")
                elif -1.0 < w < -1.0/3.0:
                    tags.append("accelerating (SEC violated)")

                sample_points.append({
                    "coordinates": {
                        "t": t,
                        "w": w
                    },
                    "curvature_invariants": {
                        "ricci_scalar": ricci_scalar(H, Hd),
                        "kretschmann": kretschmann(H, Hd)
                    },
                    "local_observables": {
                        "scale_factor_a": a,
                        "hubble_H": H,
                        "Hdot": Hd,
                        "rho_from_friedmann": rho,
                        "pressure_p": p,
                        "energy_conditions_satisfied": conds,
                        "tags": tags,
                        "notes": (
                            "Energy conditions are constraints on stress-energy, not geometry. "
                            "This toy shows which constant-w perfect fluids satisfy/violate NEC/WEC/SEC/DEC "
                            "while still producing a consistent FLRW solution (k=0)."
                        )
                    },
                    "causal_structure": {
                        "radial_null_cone_dr_dt": {"outgoing": 1.0, "ingoing": -1.0},
                        "horizon_radius": None,
                        "region": "flat FLRW (k=0), perfect fluid p=wρ",
                        "energy_warning": (
                            "Many foundational GR theorems assume energy conditions; "
                            "violations can invalidate focusing/singularity conclusions."
                        )
                    }
                })

        frac_viol = {k: (counts[k] / total if total > 0 else None) for k in counts}

        payload: Dict[str, Any] = {
            "toy_id": self.toy_id,
            "theory": "General Relativity (energy conditions diagnostics)",
            "spacetime": "Flat FLRW (k=0) with constant-w perfect fluid",
            "units": {"G": 1, "c": 1},
            "parameters": {
                "w_values": self.w_values,
                "t_values": self.t_values,
                "t0": self.t0,
                "H0_for_w=-1": self.H0 if any(w == -1.0 for w in self.w_values) else None,
                "tolerance": self.tol
            },
            "notes": {
                "pressure_point": (
                    "Energy conditions are assumptions about matter. They are not guaranteed by GR itself, "
                    "yet they underwrite key global results (focusing, singularity theorems, area increase). "
                    "This toy tests NEC/WEC/SEC/DEC for simple effective fluids and shows how easily they fail."
                ),
                "definitions_used": {
                    "EOS": "p = w ρ (constant w)",
                    "Friedmann_k=0": "ρ = 3H^2/(8π)",
                    "NEC": "ρ + p ≥ 0",
                    "WEC": "ρ ≥ 0 and NEC",
                    "SEC": "ρ + 3p ≥ 0 and NEC",
                    "DEC": "ρ ≥ |p|"
                },
                "scale_factor_models": {
                    "w != -1": "a(t)=(t/t0)^n, n=2/[3(1+w)]",
                    "w = -1": "a(t)=exp(H0(t-t0))"
                }
            },
            "sample_points": sample_points,
            "observables": {
                "summary": {
                    "n_samples": total,
                    "violations_count": counts,
                    "violations_fraction": frac_viol,
                    "key_result": (
                        "SEC is generically violated by accelerating components (w < -1/3), "
                        "NEC/WEC are violated by phantom-like w < -1, and DEC is violated by w > 1."
                    )
                }
            }
        }
        return payload

    def export_json(self, out_path: Optional[str] = None) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)
        payload = self.build_payload()
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2, sort_keys=True)
        return out_path


def main() -> None:
    ap = argparse.ArgumentParser(description="Toy 036: Energy conditions vs constant-w perfect fluids in FLRW.")
    ap.add_argument("--w", type=str, default="-1.5,-1,-0.7,-0.3333333,0,0.3333333,1,2",
                    help="Comma-separated EOS parameters w")
    ap.add_argument("--t", type=str, default="0.5,1,2,5,10",
                    help="Comma-separated sample times t>0")
    ap.add_argument("--t0", type=float, default=1.0, help="Normalization time t0>0 (for power-law a(t))")
    ap.add_argument("--H0", type=float, default=1.0, help="H0>0 used only for w=-1 (de Sitter)")
    ap.add_argument("--tol", type=float, default=0.0, help="Numerical tolerance for inequalities (>= -tol)")
    ap.add_argument("--out", type=str, default="",
                    help="Optional output path. If omitted, uses <this_script_name>.json")
    args = ap.parse_args()

    toy = Toy036EnergyConditions(
        w_values=parse_csv_floats(args.w),
        t_values=parse_csv_floats(args.t),
        t0=float(args.t0),
        H0=float(args.H0),
        tol=float(args.tol),
    )
    out_path = args.out.strip() or None
    json_path = toy.export_json(out_path=out_path)
    print(f"Wrote {json_path}")
    print("Notes:")
    print("- This toy evaluates NEC/WEC/SEC/DEC for p = w rho fluids using k=0 Friedmann dynamics.")


if __name__ == "__main__":
    main()
