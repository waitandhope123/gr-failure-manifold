#!/usr/bin/env python3
"""
Toy 045 — Constraint propagation and drift (linearized GR, harmonic gauge)

What it probes (weak points / pressure points):
- Einstein evolution is a constrained system: even in linearized GR, you must CONTROL constraints.
- In harmonic gauge, the gauge-constraint fields C_mu = ∂^ν \bar{h}_{μν} should be zero.
  If not, they propagate (and in nonlinear/numerical GR they can grow and crash evolutions).
- This toy models constraint propagation in 1D and shows:
  (a) constraints persist/propagate if violated,
  (b) a simple damping term can actively suppress violations.

Physics basis (real, linearized GR):
- Linearized vacuum Einstein in harmonic gauge:
    □ \bar{h}_{μν} = 0
  with constraints:
    C_μ := ∂^ν \bar{h}_{μν} = 0
  and C_μ obeys:
    □ C_μ = 0
- We model one representative constraint component C(t,x) on a periodic 1D domain:
    C_tt = C_xx                      (undamped)
  and with constraint damping (proxy for common NR practice):
    C_tt + κ C_t = C_xx              (damped)

Numerics:
- Periodic domain x in [0, Lx)
- Second-order finite differences in space, explicit time stepping (leapfrog-like)
- Deterministic initial constraint-violation pulse

Exports:
- Time series metrics of constraint violation norms for undamped and damped evolutions.
"""

from __future__ import annotations

import argparse
import json
import math
import os
from typing import Any, Dict, List, Optional, Tuple


# ----------------------------
# Helpers
# ----------------------------

def py_to_json_name(py_path: str) -> str:
    base = os.path.splitext(os.path.basename(py_path))[0]
    return base + ".json"


def require(cond: bool, msg: str) -> None:
    if not cond:
        raise ValueError(msg)


def l2_norm(u: List[float], dx: float) -> float:
    return math.sqrt(sum(val * val for val in u) * dx)


def linf_norm(u: List[float]) -> float:
    return max(abs(val) for val in u) if u else 0.0


def periodic_idx(i: int, n: int) -> int:
    return i % n


def second_derivative_periodic(u: List[float], dx: float) -> List[float]:
    n = len(u)
    inv_dx2 = 1.0 / (dx * dx)
    out = [0.0] * n
    for i in range(n):
        um = u[periodic_idx(i - 1, n)]
        up = u[periodic_idx(i + 1, n)]
        out[i] = (up - 2.0 * u[i] + um) * inv_dx2
    return out


def gaussian(x: float, mu: float, sigma: float) -> float:
    z = (x - mu) / sigma
    return math.exp(-0.5 * z * z)


# ----------------------------
# Core evolution
# ----------------------------

def evolve_constraint_wave(
    *,
    n: int,
    Lx: float,
    dt: float,
    t_end: float,
    kappa: float,
    amp: float,
    sigma: float,
) -> Tuple[List[float], List[float], List[float], float]:
    """
    Evolve C_tt + kappa*C_t = C_xx on periodic domain with initial pulse in C.
    Returns:
      times, l2_series, linf_series, dx
    """
    require(n >= 32, "n should be reasonably large (>=32).")
    require(Lx > 0.0, "Lx must be > 0.")
    require(dt > 0.0 and t_end > 0.0, "dt and t_end must be > 0.")
    require(sigma > 0.0, "sigma must be > 0.")
    require(kappa >= 0.0, "kappa must be >= 0.")

    dx = Lx / n

    # CFL-ish safety for wave equation (c=1). Keep dt <= dx for stability.
    require(dt <= 0.9 * dx, "For stability, choose dt <= 0.9*dx (CFL for c=1).")

    # Grid
    xs = [i * dx for i in range(n)]
    mu = 0.5 * Lx

    # Initial data: constraint violation pulse
    # C(t=0,x) = amp * exp(-(x-mu)^2/(2 sigma^2))
    # C_t(t=0,x) = 0  (start at rest)
    C0 = [amp * gaussian(x, mu, sigma) for x in xs]
    V0 = [0.0 for _ in xs]  # V = C_t

    # Convert to 1st order system:
    # C_t = V
    # V_t = C_xx - kappa*V
    C = C0[:]
    V = V0[:]

    times: List[float] = []
    l2s: List[float] = []
    linfs: List[float] = []

    t = 0.0
    steps = int(math.ceil(t_end / dt))

    for _ in range(steps + 1):
        # record
        times.append(t)
        l2s.append(l2_norm(C, dx))
        linfs.append(linf_norm(C))

        # step
        C_xx = second_derivative_periodic(C, dx)

        # simple explicit update (2nd order accurate if dt small; deterministic)
        # V^{n+1} = V^n + dt*(C_xx^n - kappa*V^n)
        # C^{n+1} = C^n + dt*V^{n+1}   (semi-implicit on V improves stability)
        V_new = [V[i] + dt * (C_xx[i] - kappa * V[i]) for i in range(n)]
        C_new = [C[i] + dt * V_new[i] for i in range(n)]

        C, V = C_new, V_new
        t += dt
        if t >= t_end:
            break

    return times, l2s, linfs, dx


# ----------------------------
# Toy 045 wrapper / export
# ----------------------------

class Toy045ConstraintDrift:
    toy_id = "045"

    def __init__(
        self,
        *,
        Lx: float = 10.0,
        n: int = 512,
        dt: float = 0.01,
        t_end: float = 10.0,
        amp: float = 1e-3,
        sigma: float = 0.5,
        kappa_damped: float = 1.0,
    ) -> None:
        self.Lx = float(Lx)
        self.n = int(n)
        self.dt = float(dt)
        self.t_end = float(t_end)
        self.amp = float(amp)
        self.sigma = float(sigma)
        self.kappa_damped = float(kappa_damped)

    def build_payload(self) -> Dict[str, Any]:
        # Undamped (kappa=0) vs damped
        t_u, l2_u, linf_u, dx = evolve_constraint_wave(
            n=self.n, Lx=self.Lx, dt=self.dt, t_end=self.t_end,
            kappa=0.0, amp=self.amp, sigma=self.sigma
        )
        t_d, l2_d, linf_d, _ = evolve_constraint_wave(
            n=self.n, Lx=self.Lx, dt=self.dt, t_end=self.t_end,
            kappa=self.kappa_damped, amp=self.amp, sigma=self.sigma
        )

        require(len(t_u) == len(t_d), "Time grids should match (same dt,t_end).")

        # Sample points at selected times (keep JSON compact but useful)
        # include beginning, quarter, half, three-quarter, end
        idxs = sorted(set([
            0,
            len(t_u) // 4,
            len(t_u) // 2,
            (3 * len(t_u)) // 4,
            len(t_u) - 1,
        ]))

        sample_points: List[Dict[str, Any]] = []
        for k in idxs:
            sample_points.append({
                "coordinates": {"t": t_u[k]},
                "curvature_invariants": {
                    # Not curvature invariants per se; we use this slot for "constraint invariants" (lab diagnostics).
                    # Schema requires the key; values are still physically interpretable diagnostics.
                    "constraint_metrics": {
                        "L2_C_undamped": l2_u[k],
                        "Linf_C_undamped": linf_u[k],
                        "L2_C_damped": l2_d[k],
                        "Linf_C_damped": linf_d[k],
                    }
                },
                "local_observables": {
                    "constraint_violation": {
                        "L2_undamped": l2_u[k],
                        "Linf_undamped": linf_u[k],
                        "L2_damped": l2_d[k],
                        "Linf_damped": linf_d[k],
                    }
                },
                "causal_structure": {
                    "domain": "periodic_1D",
                    "wave_speed_c": 1.0,
                }
            })

        payload: Dict[str, Any] = {
            "toy_id": self.toy_id,
            "theory": "General Relativity (linearized, harmonic gauge proxy)",
            "spacetime": "Linearized vacuum GR: harmonic constraint propagation in 1D",
            "units": {"G": 1, "c": 1},
            "parameters": {
                "domain_length_Lx": self.Lx,
                "grid_points_n": self.n,
                "dx": dx,
                "dt": self.dt,
                "t_end": self.t_end,
                "initial_constraint_amp": self.amp,
                "initial_constraint_sigma": self.sigma,
                "kappa_undamped": 0.0,
                "kappa_damped": self.kappa_damped,
            },
            "notes": {
                "assumptions": [
                    "Linearized vacuum GR",
                    "Harmonic gauge constraints C_mu = ∂^ν \\bar{h}_{μν} (modeled by one component C)",
                    "Constraint propagation obeys □C = 0; damping modeled by C_tt + κ C_t = C_xx",
                    "1D periodic domain used as controlled numerical proxy",
                ],
                "pressure_point": (
                    "Constraint violations are not automatically eliminated by evolution; "
                    "they propagate and can contaminate numerical solutions. "
                    "Active damping can suppress violations."
                ),
                "key_formulas": {
                    "constraint_wave": "C_tt = C_xx (undamped)",
                    "constraint_damped": "C_tt + κ C_t = C_xx (damped proxy)",
                },
            },
            "sample_points": sample_points,
            "observables": {
                "time_series": {
                    "t": t_u,
                    "L2_undamped": l2_u,
                    "Linf_undamped": linf_u,
                    "L2_damped": l2_d,
                    "Linf_damped": linf_d,
                },
                "summary": {
                    "initial_L2": l2_u[0],
                    "final_L2_undamped": l2_u[-1],
                    "final_L2_damped": l2_d[-1],
                    "ratio_final_damped_to_undamped": (l2_d[-1] / l2_u[-1]) if l2_u[-1] != 0 else None,
                    "note": "Undamped violations persist/propagate; damping should reduce norms over time.",
                }
            }
        }
        return payload

    def export_json(self, out_path: Optional[str] = None) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)
        payload = self.build_payload()
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2, sort_keys=True)
        return out_path


# ----------------------------
# CLI
# ----------------------------

def main() -> None:
    ap = argparse.ArgumentParser(description="Toy 045: Constraint propagation and drift (linearized GR proxy).")
    ap.add_argument("--Lx", type=float, default=10.0, help="Domain length (periodic)")
    ap.add_argument("--n", type=int, default=512, help="Grid points")
    ap.add_argument("--dt", type=float, default=0.01, help="Time step (must satisfy dt <= 0.9*dx)")
    ap.add_argument("--t_end", type=float, default=10.0, help="End time")
    ap.add_argument("--amp", type=float, default=1e-3, help="Initial constraint pulse amplitude")
    ap.add_argument("--sigma", type=float, default=0.5, help="Initial pulse width")
    ap.add_argument("--kappa", type=float, default=1.0, help="Constraint damping coefficient κ")
    ap.add_argument("--out", type=str, default="", help="Optional output path. If omitted, uses <this_script_name>.json")
    args = ap.parse_args()

    toy = Toy045ConstraintDrift(
        Lx=float(args.Lx),
        n=int(args.n),
        dt=float(args.dt),
        t_end=float(args.t_end),
        amp=float(args.amp),
        sigma=float(args.sigma),
        kappa_damped=float(args.kappa),
    )

    out_path = args.out.strip() or None
    json_path = toy.export_json(out_path=out_path)

    print(f"Wrote {json_path}")
    print("Toy 045 complete: constraint propagation (undamped vs damped).")


if __name__ == "__main__":
    main()
