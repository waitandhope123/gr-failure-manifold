#!/usr/bin/env python3
"""
Toy 027 — Null Raychaudhuri equation and NEC diagnostic

Model (G=c=1):
Null geodesic congruence with zero twist.
Shear is set to zero to isolate the NEC term.

Null Raychaudhuri equation:
  dθ/dλ = - (1/2) θ^2 - R_ab k^a k^b

Using Einstein equations:
  R_ab k^a k^b = 8π T_ab k^a k^b

Diagnostic:
- If T_ab k^a k^b >= 0 (NEC satisfied), congruence focuses.
- If T_ab k^a k^b < 0 (NEC violated), defocusing is possible.
"""

from __future__ import annotations

import argparse
import json
import os
from typing import Any, Dict, List, Optional


# ----------------------------
# Helpers
# ----------------------------

def py_to_json_name(py_path: str) -> str:
    base = os.path.splitext(os.path.basename(py_path))[0]
    return base + ".json"


def parse_csv_floats(s: str) -> List[float]:
    return [float(x.strip()) for x in s.split(",") if x.strip()]


def require(cond: bool, msg: str) -> None:
    if not cond:
        raise ValueError(msg)


# ----------------------------
# Toy 027
# ----------------------------

class Toy027NullRaychaudhuri:
    toy_id = "027"

    def __init__(self, theta0: float, Tabkk: float) -> None:
        self.theta0 = float(theta0)
        self.Tabkk = float(Tabkk)

    def ricci_contraction(self) -> float:
        # R_ab k^a k^b = 8π T_ab k^a k^b
        return 8.0 * 3.141592653589793 * self.Tabkk

    def evolve_theta(self, lam: float) -> float:
        # Numerical-friendly closed form when R_ab k k is constant
        R = self.ricci_contraction()
        if abs(R) < 1e-15:
            return self.theta0 / (1.0 + 0.5 * self.theta0 * lam)
        else:
            # Implicit solution branch chosen to avoid singularities at lam=0
            return - ( (2.0 * R) ** 0.5 ) * (
                ( (self.theta0 - (2.0 * R) ** 0.5) /
                  (self.theta0 + (2.0 * R) ** 0.5) )
                * pow(
                    ( (self.theta0 + (2.0 * R) ** 0.5) /
                      (self.theta0 - (2.0 * R) ** 0.5) ),
                    lam
                )
                - 1
            )

    def build_payload(self, lam_values: List[float]) -> Dict[str, Any]:
        sample_points: List[Dict[str, Any]] = []

        for lam in lam_values:
            theta_raw = self.evolve_theta(lam)
            theta = theta_raw if isinstance(theta_raw, (int, float)) else None

            sample_points.append({
                "coordinates": {"affine_parameter": lam},
                "curvature_invariants": {
                    "ricci_contraction_Rab_kk": self.ricci_contraction()
                },
                "local_observables": {
                    "expansion_theta": theta
                },
                "causal_structure": {
                    "null_focusing": (theta is not None and theta < 0),
                    "theta_is_real": (theta is not None),
                },
            })

        payload: Dict[str, Any] = {
            "toy_id": self.toy_id,
            "theory": "General Relativity (null congruences)",
            "spacetime": "Generic null geodesic bundle",
            "units": {"G": 1, "c": 1},
            "parameters": {
                "theta0": self.theta0,
                "Tabkk": self.Tabkk,
            },
            "notes": {
                "pressure_point": (
                    "Null focusing depends entirely on the null energy condition. "
                    "Violating the NEC allows defocusing, enabling exotic geometries."
                )
            },
            "sample_points": sample_points,
            "observables": {
                "null_energy_condition_satisfied": self.Tabkk >= 0.0
            },
        }

        return payload

    def export_json(self, lam_values: List[float], out_path: Optional[str] = None) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)
        payload = self.build_payload(lam_values)
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2, sort_keys=True)
        return out_path


# ----------------------------
# CLI
# ----------------------------

def main() -> None:
    ap = argparse.ArgumentParser(description="Toy 027: null Raychaudhuri NEC diagnostic.")
    ap.add_argument("--theta0", type=float, default=-0.1, help="Initial expansion θ(0)")
    ap.add_argument("--Tabkk", type=float, default=0.01, help="T_ab k^a k^b")
    ap.add_argument("--lam", type=str, default="0,0.5,1,1.5,2,3,4",
                    help="Comma-separated affine parameters")
    ap.add_argument("--out", type=str, default="",
                    help="Optional output path")
    args = ap.parse_args()

    toy = Toy027NullRaychaudhuri(theta0=args.theta0, Tabkk=args.Tabkk)
    lam_values = parse_csv_floats(args.lam)

    out_path = args.out.strip() or None
    json_path = toy.export_json(lam_values, out_path)

    print(f"Wrote {json_path}")


if __name__ == "__main__":
    main()
