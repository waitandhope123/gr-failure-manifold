#!/usr/bin/env python3
"""
Toy 035 — Breakdown of linearized gravity (plane GW in TT gauge, quantitative validity proxy)

Pressure point / weakness probed:
- Linearized GR assumes |h_{μν}| << 1 and discards O(h^2) terms.
- But GR is nonlinear: when h is not small, "linearized predictions" (e.g., tidal field from a GW)
  are not self-consistent because omitted terms become comparable.

Model:
- Weak plane gravitational wave propagating in +z direction, TT gauge, plus polarization only:
    h_xx =  +A cos(φ)
    h_yy =  -A cos(φ)
    h_xy =  0
  with phase φ = ω (t - z), geometric units G=c=1.

Linearized vacuum tidal field (gauge-invariant at this order):
- For TT waves:
    R_{0x0x} = -1/2 * d^2(h_xx)/dt^2 = + (A ω^2 / 2) cos(φ)
    R_{0y0y} = -R_{0x0x}
    R_{0x0y} = 0 (for pure plus)

We export:
- A "tidal_norm" built from the electric part of the Riemann tensor.
- A "nonlinearity_ratio_proxy" ~ |h| = |A cos(φ)|, representing the size of neglected O(h^2) terms
  relative to O(h) terms (order-of-magnitude criterion).
- Curvature scalar invariants are exported as proxies because:
    * For plane waves, many scalar invariants vanish in the exact pp-wave class.
    * Here the physically meaningful diagnostic is the tidal field + validity parameter.

Export:
- Writes JSON named exactly like this .py file.
- Uses the mandatory schema; undefined quantities are null.
"""

from __future__ import annotations

import argparse
import json
import math
import os
from typing import Any, Dict, List, Optional


# ----------------------------
# Helpers
# ----------------------------

def py_to_json_name(py_path: str) -> str:
    base = os.path.splitext(os.path.basename(py_path))[0]
    return base + ".json"


def require(cond: bool, msg: str) -> None:
    if not cond:
        raise ValueError(msg)


def parse_csv_floats(s: str) -> List[float]:
    return [float(x.strip()) for x in s.split(",") if x.strip()]


# ----------------------------
# Linearized plane GW (TT gauge)
# ----------------------------

def phase(omega: float, t: float, z: float) -> float:
    return omega * (t - z)


def h_xx(A: float, omega: float, t: float, z: float) -> float:
    return A * math.cos(phase(omega, t, z))


def h_yy(A: float, omega: float, t: float, z: float) -> float:
    return -A * math.cos(phase(omega, t, z))


def tidal_R0x0x(A: float, omega: float, t: float, z: float) -> float:
    # R_{0x0x} = -(1/2) d^2 h_xx / dt^2
    # h_xx = A cos(ω(t-z)) => d^2/dt^2 = -A ω^2 cos(...) => R0x0x = +(A ω^2 / 2) cos(...)
    return 0.5 * A * (omega ** 2) * math.cos(phase(omega, t, z))


def tidal_R0y0y(A: float, omega: float, t: float, z: float) -> float:
    # For plus polarization: R0y0y = -R0x0x
    return -tidal_R0x0x(A, omega, t, z)


def tidal_norm(A: float, omega: float, t: float, z: float) -> float:
    """
    Norm of the electric part of the Riemann tensor E_ij = R_{0i0j} (linearized).
    For pure plus polarization:
      E_xx = R0x0x, E_yy = R0y0y, others ~ 0
    Use Frobenius-like norm: sqrt(E_xx^2 + E_yy^2)
    """
    exx = tidal_R0x0x(A, omega, t, z)
    eyy = tidal_R0y0y(A, omega, t, z)
    return math.sqrt(exx * exx + eyy * eyy)


def nonlinearity_ratio_proxy(A: float, omega: float, t: float, z: float) -> float:
    """
    Order-of-magnitude validity proxy:
      neglected terms ~ O(h^2) relative to kept O(h) terms => ratio ~ |h|
    Here take |h_xx| as representative: |A cos φ|.
    """
    return abs(h_xx(A, omega, t, z))


def kretschmann_proxy_from_tidal(A: float, omega: float, t: float, z: float) -> float:
    """
    Proxy scalar made from tidal components:
      K_proxy ~ 8 * (E_ij E_ij)   (up to conventions)
    This is NOT claiming the true scalar invariant is nonzero for an exact plane wave;
    it's a diagnostic of tidal magnitude in this linearized model.
    """
    E = tidal_norm(A, omega, t, z)
    return 8.0 * (E ** 2)


# ----------------------------
# Toy 035 driver
# ----------------------------

class Toy035LinearizedBreakdown:
    toy_id = "035"

    def __init__(self, A_values: List[float], omega: float, t_values: List[float], z_values: List[float]) -> None:
        require(len(A_values) > 0, "A_values must be non-empty")
        require(omega > 0.0, "omega must be > 0")
        require(len(t_values) > 0, "t_values must be non-empty")
        require(len(z_values) > 0, "z_values must be non-empty")
        for A in A_values:
            require(A >= 0.0, "A must be >= 0")
        self.A_values = [float(a) for a in A_values]
        self.omega = float(omega)
        self.t_values = [float(t) for t in t_values]
        self.z_values = [float(z) for z in z_values]

    def build_payload(self) -> Dict[str, Any]:
        sample_points: List[Dict[str, Any]] = []

        for A in self.A_values:
            for t in self.t_values:
                for z in self.z_values:
                    hx = h_xx(A, self.omega, t, z)
                    hy = h_yy(A, self.omega, t, z)
                    Rxx = tidal_R0x0x(A, self.omega, t, z)
                    Ryy = tidal_R0y0y(A, self.omega, t, z)
                    Enorm = tidal_norm(A, self.omega, t, z)
                    ratio = nonlinearity_ratio_proxy(A, self.omega, t, z)

                    # A simple regime tag
                    if ratio < 1e-3:
                        regime = "safe_linear"
                    elif ratio < 1e-1:
                        regime = "borderline_linear"
                    else:
                        regime = "nonlinear_expected"

                    sample_points.append({
                        "coordinates": {
                            "t": t,
                            "z": z,
                            "phase_phi": phase(self.omega, t, z),
                            "omega": self.omega,
                            "A": A
                        },
                        "curvature_invariants": {
                            # Linearized vacuum: Ricci scalar = 0 (at O(h))
                            "ricci_scalar": 0.0,
                            # Proxy scalar representing tidal magnitude in this model
                            "kretschmann_proxy": kretschmann_proxy_from_tidal(A, self.omega, t, z)
                        },
                        "local_observables": {
                            "h_xx": hx,
                            "h_yy": hy,
                            "R0x0x_linear": Rxx,
                            "R0y0y_linear": Ryy,
                            "tidal_norm_linear": Enorm,
                            "nonlinearity_ratio_proxy_|h|": ratio,
                            "validity_regime": regime,
                            "notes": (
                                "Linearized model keeps O(h) and drops O(h^2). "
                                "A simple consistency check is |h| << 1. "
                                "When |h| ~ 0.1 or larger, nonlinear corrections are expected to matter."
                            )
                        },
                        "causal_structure": {
                            "radial_null_cone_dz_dt": {"outgoing": 1.0, "ingoing": -1.0},
                            "horizon_radius": None,
                            "region": "weak-field plane GW (linearized TT gauge)",
                            "energy_warning": (
                                "Linearized gravity neglects gravitational self-interaction; "
                                "validity requires |h|<<1 and small nonlinearities."
                            )
                        }
                    })

        # Summary: report maximum |h| observed and the implied validity status
        max_ratio = 0.0
        for A in self.A_values:
            # max over phase is simply A
            max_ratio = max(max_ratio, A)

        payload: Dict[str, Any] = {
            "toy_id": self.toy_id,
            "theory": "General Relativity (linearized gravity validity)",
            "spacetime": "Linearized plane gravitational wave on Minkowski (TT gauge, plus polarization)",
            "units": {"G": 1, "c": 1},
            "parameters": {
                "A_values": self.A_values,
                "omega": self.omega,
                "t_values": self.t_values,
                "z_values": self.z_values
            },
            "notes": {
                "pressure_point": (
                    "Linearized gravity assumes |h|<<1; GR's nonlinearity is ignored at O(h^2). "
                    "This toy quantifies a plane-wave tidal field at O(h) and exports a validity proxy |h| "
                    "showing when neglected nonlinear terms become significant."
                ),
                "definitions_used": {
                    "metric_perturbation": "h_xx=A cos(ω(t−z)), h_yy=−A cos(ω(t−z))",
                    "tidal_field": "R0x0x = (A ω^2 /2) cos(ω(t−z)), R0y0y=−R0x0x",
                    "validity_proxy": "nonlinearity_ratio ≈ |h| (size of O(h^2) relative to O(h))"
                },
                "caution": (
                    "Plane waves can have vanishing true scalar invariants in exact pp-wave solutions; "
                    "we export a Kretschmann-like proxy derived from tidal magnitude for comparability across toys."
                )
            },
            "sample_points": sample_points,
            "observables": {
                "summary": {
                    "max_|h|_over_samples": max_ratio,
                    "rule_of_thumb": "Linearized regime requires max |h| << 1 (e.g., 1e-3 to 1e-2 comfortably).",
                    "key_result": (
                        "As A increases, the validity proxy |h| approaches unity, indicating nonlinear GR terms "
                        "cannot be neglected even though the linear tidal formula still returns finite numbers."
                    )
                }
            }
        }
        return payload

    def export_json(self, out_path: Optional[str] = None) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)
        payload = self.build_payload()
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2, sort_keys=True)
        return out_path


def main() -> None:
    ap = argparse.ArgumentParser(description="Toy 035: Breakdown of linearized gravity (plane GW validity proxy).")
    ap.add_argument("--A", type=str, default="1e-6,1e-3,1e-2,1e-1,0.3",
                    help="Comma-separated GW strain amplitudes A>=0")
    ap.add_argument("--omega", type=float, default=1.0, help="Angular frequency ω>0")
    ap.add_argument("--t", type=str, default="0,0.5,1,2", help="Comma-separated sample times t")
    ap.add_argument("--z", type=str, default="0,0.25,0.5,1", help="Comma-separated sample positions z")
    ap.add_argument("--out", type=str, default="",
                    help="Optional output path. If omitted, uses <this_script_name>.json")
    args = ap.parse_args()

    toy = Toy035LinearizedBreakdown(
        A_values=parse_csv_floats(args.A),
        omega=float(args.omega),
        t_values=parse_csv_floats(args.t),
        z_values=parse_csv_floats(args.z),
    )

    out_path = args.out.strip() or None
    json_path = toy.export_json(out_path=out_path)
    print(f"Wrote {json_path}")
    print("Notes:")
    print("- Validity proxy: |h| << 1. If |h| ~ 0.1 or larger, nonlinear corrections are expected to matter.")


if __name__ == "__main__":
    main()
