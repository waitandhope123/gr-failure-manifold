#!/usr/bin/env python3
"""
Toy 021 — Schwarzschild tidal forces and observer survivability (geodesic deviation)

What it probes (pressure point):
- GR predicts smooth horizon crossing for point particles,
  but extended bodies experience tidal forces set by curvature gradients.
- Demonstrates that "nothing special at the horizon" is geometrically true
  yet operationally false for finite-sized observers.
- Separates curvature invariants from physically felt tidal accelerations.

Model (G=c=1):
Schwarzschild spacetime with mass M.

Radial tidal eigenvalues in orthonormal free-fall frame:
  λ_radial   = +2M / r^3
  λ_tangential = -M / r^3

Relative tidal acceleration across body size ℓ:
  a_tidal = |λ| * ℓ
"""

from __future__ import annotations

import argparse
import json
import math
import os
from typing import Any, Dict, List, Optional


# ----------------------------
# Helpers
# ----------------------------

def py_to_json_name(py_path: str) -> str:
    base = os.path.splitext(os.path.basename(py_path))[0]
    return base + ".json"


def parse_csv_floats(s: str) -> List[float]:
    return [float(x.strip()) for x in s.split(",") if x.strip()]


def require(cond: bool, msg: str) -> None:
    if not cond:
        raise ValueError(msg)


# ----------------------------
# Toy 021
# ----------------------------

class Toy021TidalForces:
    toy_id = "021"

    def __init__(self, M: float = 1.0, body_size: float = 1.0) -> None:
        require(M > 0.0, "M must be > 0.")
        require(body_size > 0.0, "body_size must be > 0.")
        self.M = float(M)
        self.body_size = float(body_size)

    def horizon(self) -> float:
        return 2.0 * self.M

    # --- Curvature invariants ---
    def ricci_scalar(self, r: float) -> float:
        return 0.0

    def kretschmann(self, r: float) -> float:
        return 48.0 * (self.M ** 2) / (r ** 6)

    # --- Tidal eigenvalues ---
    def tidal_radial(self, r: float) -> float:
        return 2.0 * self.M / (r ** 3)

    def tidal_tangential(self, r: float) -> float:
        return -1.0 * self.M / (r ** 3)

    def build_payload(self, r_values: List[float]) -> Dict[str, Any]:
        sample_points: List[Dict[str, Any]] = []
        rh = self.horizon()

        for r in r_values:
            require(r > 0.0, "All radii must be > 0.")
            r = float(r)

            lam_r = self.tidal_radial(r)
            lam_t = self.tidal_tangential(r)

            a_r = abs(lam_r) * self.body_size
            a_t = abs(lam_t) * self.body_size

            coordinates = {"t": None, "r": r, "theta": None, "phi": None}

            curvature_invariants = {
                "ricci_scalar": self.ricci_scalar(r),
                "kretschmann": self.kretschmann(r),
            }

            local_observables = {
                "body_size": self.body_size,
                "tidal_eigenvalues": {
                    "radial": lam_r,
                    "tangential": lam_t,
                },
                "tidal_accelerations": {
                    "radial": a_r,
                    "tangential": a_t,
                    "max": max(a_r, a_t),
                },
            }

            causal_structure = {
                "horizon_radius": rh,
                "region": (
                    "exterior (r>2M)" if r > rh else
                    ("horizon (r=2M)" if abs(r - rh) < 1e-12 else
                     "interior (r<2M)")
                ),
                "notes": (
                    "Tidal forces finite at horizon for large M, "
                    "but diverge as r -> 0."
                ),
            }

            sample_points.append({
                "coordinates": coordinates,
                "curvature_invariants": curvature_invariants,
                "local_observables": local_observables,
                "causal_structure": causal_structure,
            })

        payload: Dict[str, Any] = {
            "toy_id": self.toy_id,
            "theory": "General Relativity (geodesic deviation)",
            "spacetime": "Schwarzschild (tidal forces on extended observers)",
            "units": {"G": 1, "c": 1},
            "parameters": {
                "M": self.M,
                "body_size": self.body_size,
            },
            "notes": {
                "pressure_point": (
                    "Curvature invariants can be small at the horizon, "
                    "yet extended observers experience tidal forces that "
                    "scale with size and curvature gradients."
                ),
                "tidal_scaling": "a_tidal ~ (M / r^3) * body_size",
            },
            "sample_points": sample_points,
            "observables": {
                "horizon_radius": rh,
            },
        }

        return payload

    def export_json(self, r_values: List[float], out_path: Optional[str] = None) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)
        payload = self.build_payload(r_values=r_values)
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2, sort_keys=True)
        return out_path


# ----------------------------
# CLI
# ----------------------------

def main() -> None:
    ap = argparse.ArgumentParser(description="Toy 021: Schwarzschild tidal forces exporter.")
    ap.add_argument("--M", type=float, default=1.0, help="Black hole mass M (geometric units)")
    ap.add_argument("--body_size", type=float, default=1.0, help="Proper size of observer/body")
    ap.add_argument(
        "--r",
        type=str,
        default="2.1,3,5,10,20,50,100",
        help="Comma-separated radii",
    )
    ap.add_argument("--out", type=str, default="",
                    help="Optional output path. If omitted, uses <this_script_name>.json")
    args = ap.parse_args()

    toy = Toy021TidalForces(M=float(args.M), body_size=float(args.body_size))
    r_values = parse_csv_floats(args.r)

    out_path = args.out.strip() or None
    json_path = toy.export_json(r_values=r_values, out_path=out_path)

    print(f"Wrote {json_path}")
    print(f"Horizon radius: r = {toy.horizon():g}")


if __name__ == "__main__":
    main()
