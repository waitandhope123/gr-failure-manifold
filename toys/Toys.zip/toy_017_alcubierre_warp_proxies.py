#!/usr/bin/env python3
"""
Toy 017 — Alcubierre warp bubble (1D slice): expansion/shear + energy-condition violation proxy

What it probes (pressure point):
- GR permits metrics with “effective faster-than-light” global transport, but requires
  exotic stress-energy (violations of standard energy conditions).
- The Alcubierre warp drive is the canonical stress test: it is built to have
  a moving “bubble” with nearly flat interior, but demands negative energy densities.

This toy does NOT solve Einstein’s equations for T_{μν} fully (that’s a longer derivation).
Instead it provides numerically grounded, experiment-style diagnostics that are standard
in the warp-drive discussion:
- The shape function f(r) and its gradients (where “exoticity” concentrates at the bubble wall)
- The expansion scalar proxy of Eulerian observers in a 1D slice (qualitative indicator of
  local volume expansion/contraction)
- A conservative “NEC-violation-likelihood proxy” based on gradient-squared of f
  (since known energy densities scale with v^2 * |∇f|^2 and become negative in parts of the wall)

Assumptions / setup:
- Alcubierre metric in 3+1 form:
    ds^2 = -dt^2 + [dx - v_s f(r_s) dt]^2 + dy^2 + dz^2
  where the bubble center moves along x with speed v_s, and
    r_s = sqrt( (x - x_s(t))^2 + y^2 + z^2 ),  x_s(t)=v_s t
- We sample a 1D slice along the motion axis: y=z=0 at a fixed coordinate time t0,
  so r_s = |x - v_s t0|.
- Shape function (Alcubierre 1994 "tanh" form):
    f(r) = [tanh(σ(r+R)) - tanh(σ(r-R))] / [2 tanh(σ R)]
  with bubble radius R and wall thickness ~ 1/σ.

Diagnostics computed (1D slice):
- f(r), df/dr (analytic)
- Along the axis, df/dx = df/dr * sign(x - x_s)
- "Wall indicator": |df/dx| peaks at bubble wall; interior/exterior nearly 0
- Proxy expansion scalar in 1D: θ_proxy = d/dx (v_s f) = v_s df/dx
  (In full 3D, θ involves ∇·shift; this slice captures the sign/scale on-axis.)
- Proxy NEC violation scale:
    nec_proxy = - v_s^2 * (df/dx)^2
  This is NOT an actual T_{μν} contraction; it’s a sign-carrying heuristic:
  known energy densities in warp metrics contain negative pieces scaling like -v^2|∇f|^2.

Curvature invariants:
- Not computed here (can be added later); exported as null.

STRICT EXPORT RULE:
- Writes JSON named exactly like this .py file (toy_017_alcubierre_warp_proxies.json).
- JSON follows the canonical schema with required keys and required subkeys.
- Undefined quantities are exported as null (JSON null).

IMPORTANT NOTE:
- This toy intentionally mixes exact geometry definition with conservative proxies, to keep it minimal.
  If you want the exact T_{μν} and actual energy density ρ for Eulerian observers, say so and we’ll
  do a dedicated toy with a small symbolic-to-numeric pipeline.
"""

from __future__ import annotations

import argparse
import json
import math
import os
from typing import Any, Dict, List, Optional


# ----------------------------
# Helpers
# ----------------------------

def py_to_json_name(py_path: str) -> str:
    base = os.path.splitext(os.path.basename(py_path))[0]
    return base + ".json"


def parse_csv_floats(s: str) -> List[float]:
    return [float(x.strip()) for x in s.split(",") if x.strip()]


def require(cond: bool, msg: str) -> None:
    if not cond:
        raise ValueError(msg)


def sign(x: float) -> float:
    if x > 0.0:
        return 1.0
    if x < 0.0:
        return -1.0
    return 0.0


# ----------------------------
# Toy 017
# ----------------------------

class Toy017AlcubierreWarpProxies:
    toy_id = "017"

    def __init__(self, v: float = 0.5, R: float = 2.0, sigma: float = 2.0, t0: float = 0.0) -> None:
        # v can exceed 1 in coordinate sense; that's the point of the stress test.
        require(R > 0.0, "R must be > 0.")
        require(sigma > 0.0, "sigma must be > 0.")
        self.v = float(v)
        self.R = float(R)
        self.sigma = float(sigma)
        self.t0 = float(t0)

    def x_s(self) -> float:
        return self.v * self.t0

    def f(self, r: float) -> float:
        # tanh wall profile
        s = self.sigma
        R = self.R
        denom = 2.0 * math.tanh(s * R)
        # Avoid division by ~0 for tiny sR (but we require sigma>0 and R>0; still safe)
        if abs(denom) < 1e-15:
            return None  # type: ignore[return-value]
        return (math.tanh(s * (r + R)) - math.tanh(s * (r - R))) / denom

    def df_dr(self, r: float) -> Optional[float]:
        # derivative of tanh is sech^2 = 1/cosh^2
        s = self.sigma
        R = self.R
        denom = 2.0 * math.tanh(s * R)
        if abs(denom) < 1e-15:
            return None
        # d/dr tanh(s(r±R)) = s * sech^2(s(r±R))
        a = s * (r + R)
        b = s * (r - R)
        sech2_a = 1.0 / (math.cosh(a) ** 2)
        sech2_b = 1.0 / (math.cosh(b) ** 2)
        return (s * sech2_a - s * sech2_b) / denom

    def axis_r(self, x: float) -> float:
        # along axis y=z=0 at time t0: r_s = |x - x_s|
        return abs(x - self.x_s())

    def df_dx_axis(self, x: float) -> Optional[float]:
        r = self.axis_r(x)
        d = self.df_dr(r)
        if d is None:
            return None
        return d * sign(x - self.x_s())

    def build_payload(self, x_values: List[float]) -> Dict[str, Any]:
        sample_points: List[Dict[str, Any]] = []

        xs = self.x_s()

        for x in x_values:
            x = float(x)

            r = self.axis_r(x)
            fval = self.f(r)
            dfdx = self.df_dx_axis(x)

            # Proxies
            theta_proxy = None if dfdx is None else (self.v * dfdx)
            nec_proxy = None if dfdx is None else (-(self.v ** 2) * (dfdx ** 2))

            # "bubble interior" heuristic: f ~ 1
            interior = None if fval is None else (fval > 0.9)
            wall = None if dfdx is None else (abs(dfdx) > 0.05)  # arbitrary threshold for labeling

            coordinates = {"t": self.t0, "x": x, "y": 0.0, "z": 0.0}

            curvature_invariants = {
                "ricci_scalar": None,
                "kretschmann": None,
                "note": "Not computed in this minimal proxy toy; warp-drive stress-energy is the main focus.",
            }

            local_observables = {
                "warp_parameters": {
                    "v_bubble": self.v,
                    "R": self.R,
                    "sigma": self.sigma,
                    "t0": self.t0,
                    "x_center": xs,
                },
                "shape_function_axis": {
                    "r_s": r,
                    "f(r_s)": fval,
                    "df_dx": dfdx,
                    "interpretation": "f≈1 inside bubble; f≈0 outside; gradients localize on the wall.",
                },
                "kinematics_proxies_axis": {
                    "theta_proxy_d_dx_of_vf": theta_proxy,
                    "theta_proxy_formula": "θ_proxy = d/dx (v f) = v df/dx (1D slice)",
                    "nec_violation_proxy": nec_proxy,
                    "nec_proxy_formula": "nec_proxy = - v^2 (df/dx)^2 (heuristic sign-carrying scale)",
                },
                "labels": {
                    "likely_interior_f_gt_0p9": interior,
                    "likely_wall_abs_dfdx_gt_0p05": wall,
                },
            }

            causal_structure = {
                "notes": (
                    "Alcubierre metric is constructed to allow a bubble translating at coordinate speed v. "
                    "GR allows the geometry, but stress-energy required violates energy conditions; "
                    "this toy flags where gradients (and thus exoticity proxies) concentrate."
                ),
                "horizon_like_features": None,
                "radial_null_cone_dr_dt": None,
            }

            sample_points.append({
                "coordinates": coordinates,
                "curvature_invariants": curvature_invariants,
                "local_observables": local_observables,
                "causal_structure": causal_structure,
            })

        payload: Dict[str, Any] = {
            "toy_id": self.toy_id,
            "theory": "General Relativity (engineered metric stress test)",
            "spacetime": "Alcubierre warp bubble (1D axis slice): expansion + energy-condition violation proxies",
            "units": {"G": 1, "c": 1},
            "parameters": {
                "v": self.v,
                "R": self.R,
                "sigma": self.sigma,
                "t0": self.t0,
                "x_values": x_values,
            },
            "notes": {
                "pressure_point": (
                    "Warp-drive geometries separate local from global notions of speed but demand exotic stress-energy. "
                    "Even when curvature/invariants are not emphasized, gradients of the shaping function signal where "
                    "negative-energy requirements concentrate."
                ),
                "key_formulas": {
                    "metric_1D": "ds^2 = -dt^2 + (dx - v f(r_s) dt)^2 + dy^2 + dz^2",
                    "shape_f": "f(r)=[tanh(σ(r+R)) - tanh(σ(r-R))]/[2 tanh(σR)]",
                    "theta_proxy": "θ_proxy = v df/dx (axis slice)",
                    "nec_proxy": "nec_proxy = - v^2 (df/dx)^2 (heuristic)",
                    "bubble_center": "x_s(t)=v t; r_s=|x-x_s| on axis",
                },
                "domain_of_validity": (
                    "This is a diagnostic/proxy toy. It defines the metric and computes exact shape gradients, "
                    "but exports only conservative proxies for expansion and NEC-violation scaling."
                ),
            },
            "sample_points": sample_points,
            "observables": {
                "bubble_center_xs": xs,
                "comment": "Look for |df/dx| peaks to locate the wall; nec_proxy is most negative where gradients are largest.",
            },
        }
        return payload

    def export_json(self, x_values: List[float], out_path: Optional[str] = None) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)
        payload = self.build_payload(x_values=x_values)
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2, sort_keys=True)
        return out_path


# ----------------------------
# CLI
# ----------------------------

def main() -> None:
    ap = argparse.ArgumentParser(description="Toy 017: Alcubierre warp bubble proxies on-axis.")
    ap.add_argument("--v", type=float, default=0.5, help="Bubble coordinate speed v (can exceed 1 to stress test)")
    ap.add_argument("--R", type=float, default=2.0, help="Bubble radius R")
    ap.add_argument("--sigma", type=float, default=2.0, help="Wall thickness parameter σ (~1/thickness)")
    ap.add_argument("--t0", type=float, default=0.0, help="Sample time t0")
    ap.add_argument(
        "--x",
        type=str,
        default="-6,-4,-3,-2.5,-2,-1.5,-1,-0.5,0,0.5,1,1.5,2,2.5,3,4,6",
        help="Comma-separated x positions along axis (y=z=0) to sample",
    )
    ap.add_argument("--out", type=str, default="", help="Optional output path. If omitted, uses <script>.json")
    args = ap.parse_args()

    toy = Toy017AlcubierreWarpProxies(v=float(args.v), R=float(args.R), sigma=float(args.sigma), t0=float(args.t0))
    x_values = parse_csv_floats(args.x)

    out_path = args.out.strip() or None
    json_path = toy.export_json(x_values=x_values, out_path=out_path)

    print(f"Wrote {json_path}")
    print(f"Bubble center x_s(t0) = {toy.x_s():g}")
    print("Note: nec_proxy is a heuristic sign-carrying scale, not a full stress-energy tensor computation.")


if __name__ == "__main__":
    main()
