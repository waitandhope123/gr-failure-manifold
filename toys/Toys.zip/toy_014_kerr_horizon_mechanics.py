#!/usr/bin/env python3
"""
Toy 014 — Kerr horizon mechanics: irreducible mass + extractable rotational energy

What it probes (pressure point):
- Rotation stores *extractable* energy in the spacetime (not localizable as a density).
- “How much energy can you get out of a spinning BH?” becomes a clean, global, invariant-ish
  bookkeeping problem via horizon area / irreducible mass.
- Connects geometry (r_+, area) to energetics (M_irreducible, E_rot) and horizon kinematics (Ω_H, κ).

Assumptions / setup:
- Kerr vacuum black hole in geometric units (G=c=1).
- Only valid as a BH when |a| <= M. If |a| > M => naked singularity regime (no horizon); export nulls.

Key formulas (geometric units):
- r_± = M ± sqrt(M^2 - a^2)   (defined only if |a|<=M)
- Horizon area: A = 4π (r_+^2 + a^2) = 8π M r_+
- Irreducible mass: M_irr = sqrt(A / (16π)) = sqrt( (r_+^2 + a^2)/4 ) = sqrt(M r_+ / 2)
- Extractable rotational energy (upper bound via reversible processes):
    E_rot = M - M_irr
    fraction = E_rot / M
  (maximum fraction occurs at extremal |a|=M: 1 - 1/sqrt(2) ≈ 0.2929)
- Horizon angular velocity:
    Ω_H = a / (r_+^2 + a^2) = a / (2 M r_+)
- Surface gravity:
    κ = (r_+ - r_-) / (2 (r_+^2 + a^2))
  (goes to 0 in the extremal limit)

Curvature invariant (Kretschmann) at horizon on equator (θ=π/2):
- On equator, Kerr reduces to K = 48 M^2 / r^6 (same r-dependence as Schwarzschild there),
  so K_H(eq) = 48 M^2 / r_+^6  (defined only if r_+ exists)

STRICT EXPORT RULE:
- Writes JSON named exactly like this .py file (toy_014_kerr_horizon_mechanics.json).
- JSON follows the canonical schema with required keys and required subkeys.
- Undefined quantities are exported as null (JSON null).
"""

from __future__ import annotations

import argparse
import json
import math
import os
from typing import Any, Dict, List, Optional


# ----------------------------
# Helpers
# ----------------------------

def py_to_json_name(py_path: str) -> str:
    base = os.path.splitext(os.path.basename(py_path))[0]
    return base + ".json"


def parse_csv_floats(s: str) -> List[float]:
    return [float(x.strip()) for x in s.split(",") if x.strip()]


def require(cond: bool, msg: str) -> None:
    if not cond:
        raise ValueError(msg)


# ----------------------------
# Toy 014
# ----------------------------

class Toy014KerrHorizonMechanics:
    toy_id = "014"

    def __init__(self, M: float = 1.0) -> None:
        require(M > 0.0, "M must be > 0.")
        self.M = float(M)

    def is_bh(self, a: float) -> bool:
        return abs(a) <= self.M

    def r_pm(self, a: float) -> Dict[str, Optional[float]]:
        disc = self.M * self.M - a * a
        if disc < 0.0:
            return {"r_plus": None, "r_minus": None}
        root = math.sqrt(disc)
        return {"r_plus": self.M + root, "r_minus": self.M - root}

    def area(self, a: float) -> Optional[float]:
        rpm = self.r_pm(a)
        rp = rpm["r_plus"]
        if rp is None:
            return None
        return 4.0 * math.pi * (rp * rp + a * a)

    def Mirr(self, a: float) -> Optional[float]:
        A = self.area(a)
        if A is None:
            return None
        return math.sqrt(A / (16.0 * math.pi))

    def E_rot(self, a: float) -> Optional[float]:
        Mirr = self.Mirr(a)
        if Mirr is None:
            return None
        return self.M - Mirr

    def E_rot_fraction(self, a: float) -> Optional[float]:
        Er = self.E_rot(a)
        if Er is None:
            return None
        return Er / self.M

    def Omega_H(self, a: float) -> Optional[float]:
        rpm = self.r_pm(a)
        rp = rpm["r_plus"]
        if rp is None:
            return None
        denom = (rp * rp + a * a)
        if denom == 0.0:
            return None
        return a / denom

    def kappa(self, a: float) -> Optional[float]:
        rpm = self.r_pm(a)
        rp = rpm["r_plus"]
        rm = rpm["r_minus"]
        if rp is None or rm is None:
            return None
        denom = 2.0 * (rp * rp + a * a)
        if denom == 0.0:
            return None
        return (rp - rm) / denom

    def kretschmann_horizon_equator(self, a: float) -> Optional[float]:
        # Equatorial Kerr: K = 48 M^2 / r^6 evaluated at r=r_+ (if horizon exists)
        rpm = self.r_pm(a)
        rp = rpm["r_plus"]
        if rp is None:
            return None
        return 48.0 * (self.M ** 2) / (rp ** 6)

    def kind(self, a: float) -> str:
        disc = self.M * self.M - a * a
        if disc < 0:
            return "naked_singularity (|a|>M)"
        if abs(disc) < 1e-15:
            return "extremal (|a|=M)"
        return "subextremal (|a|<M)"

    def build_payload(self, a_values: List[float]) -> Dict[str, Any]:
        sample_points: List[Dict[str, Any]] = []

        for a in a_values:
            a = float(a)

            rpm = self.r_pm(a)
            rp = rpm["r_plus"]
            rm = rpm["r_minus"]
            A = self.area(a)
            Mirr = self.Mirr(a)
            Er = self.E_rot(a)
            Er_frac = self.E_rot_fraction(a)
            OmH = self.Omega_H(a)
            kap = self.kappa(a)
            K_h_eq = self.kretschmann_horizon_equator(a)

            # Minimal "coordinates" for this toy: parameter space point (a)
            coordinates = {"a": a, "a_over_M": (a / self.M), "theta_deg": 90.0, "r": rp}

            curvature_invariants = {
                "ricci_scalar": 0.0,
                "kretschmann_at_outer_horizon_equator": K_h_eq,
                "note": "K at r=r_+, θ=π/2 if horizon exists; otherwise null.",
            }

            local_observables = {
                "spin": {
                    "M": self.M,
                    "a": a,
                    "a_over_M": (a / self.M),
                    "kind": self.kind(a),
                },
                "horizon_geometry": {
                    "r_plus": rp,
                    "r_minus": rm,
                    "area_A": A,
                    "irreducible_mass_Mirr": Mirr,
                },
                "energetics": {
                    "extractable_rotational_energy_Erot": Er,
                    "extractable_fraction_Erot_over_M": Er_frac,
                    "extremal_max_fraction_reference": (1.0 - 1.0 / math.sqrt(2.0)),
                    "note": "E_rot is the reversible-extraction upper bound from horizon area (Penrose-like idealization).",
                },
                "horizon_kinematics": {
                    "Omega_H": OmH,
                    "surface_gravity_kappa": kap,
                    "notes": {
                        "Omega_H": "Horizon angular velocity; sets superradiance condition ω < m Ω_H (not modeled here).",
                        "kappa": "Surface gravity; tends to 0 at extremality.",
                    },
                },
            }

            causal_structure = {
                "horizon_exists": (rp is not None),
                "outer_horizon_r_plus": rp,
                "inner_horizon_r_minus": rm,
                "extremality": {
                    "condition": "|a| <= M (BH), |a|=M extremal",
                    "discriminant_M2_minus_a2": (self.M * self.M - a * a),
                },
                "radial_null_cone_dr_dt": None,
            }

            sample_points.append({
                "coordinates": coordinates,
                "curvature_invariants": curvature_invariants,
                "local_observables": local_observables,
                "causal_structure": causal_structure,
            })

        payload: Dict[str, Any] = {
            "toy_id": self.toy_id,
            "theory": "General Relativity (Kerr horizon mechanics)",
            "spacetime": "Kerr: horizon area, irreducible mass, and extractable rotational energy",
            "units": {"G": 1, "c": 1},
            "parameters": {
                "M": self.M,
                "a_values_sampled": a_values,
                "theta_fixed": "pi/2 (equator) for horizon-curvature diagnostic",
            },
            "notes": {
                "pressure_point": (
                    "Backreaction-free vacuum rotation still carries an energy reservoir. "
                    "GR localizes it only globally (via horizon area / irreducible mass), "
                    "highlighting the nonlocal nature of gravitational energy bookkeeping."
                ),
                "key_formulas": {
                    "r_pm": "r_± = M ± sqrt(M^2 - a^2)",
                    "area": "A = 4π(r_+^2 + a^2) = 8π M r_+",
                    "Mirr": "M_irr = sqrt(A/(16π)) = sqrt(M r_+ / 2)",
                    "Erot": "E_rot = M - M_irr; fraction = 1 - M_irr/M",
                    "Omega_H": "Ω_H = a/(r_+^2+a^2) = a/(2 M r_+)",
                    "kappa": "κ = (r_+ - r_-)/(2(r_+^2+a^2))",
                    "max_extractable_fraction": "1 - 1/√2 ≈ 0.2929 at |a|=M",
                },
                "domain_of_validity": (
                    "Exact Kerr vacuum. Energetics correspond to ideal reversible processes; "
                    "real astrophysical extraction is model-dependent."
                ),
            },
            "sample_points": sample_points,
            "observables": {
                "reference": {
                    "max_extractable_fraction_extremal": (1.0 - 1.0 / math.sqrt(2.0)),
                }
            },
        }
        return payload

    def export_json(self, a_values: List[float], out_path: Optional[str] = None) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)
        payload = self.build_payload(a_values=a_values)
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2, sort_keys=True)
        return out_path


# ----------------------------
# CLI
# ----------------------------

def main() -> None:
    ap = argparse.ArgumentParser(description="Toy 014: Kerr horizon mechanics (area, Mirr, extractable rotational energy).")
    ap.add_argument("--M", type=float, default=1.0, help="Mass M (geometric units)")
    ap.add_argument(
        "--a_values",
        type=str,
        default="-1.2,-1.0,-0.9,-0.7,-0.5,0.0,0.5,0.7,0.9,1.0,1.2",
        help="Comma-separated Kerr a values to sample (include |a|>M to show horizon disappearance)",
    )
    ap.add_argument("--out", type=str, default="", help="Optional output path; default is <script>.json")
    args = ap.parse_args()

    toy = Toy014KerrHorizonMechanics(M=float(args.M))
    a_values = parse_csv_floats(args.a_values)

    out_path = args.out.strip() or None
    json_path = toy.export_json(a_values=a_values, out_path=out_path)

    print(f"Wrote {json_path}")
    print(f"M={toy.M:g}; sampled {len(a_values)} a-values. (Horizon exists iff |a|<=M.)")


if __name__ == "__main__":
    main()
