#!/usr/bin/env python3
"""
Toy 052 — Gauge mode amplitude vs physical mode (linearized GR on Minkowski)

What it probes (weak point / pressure point):
- Large coordinate/gauge perturbations can exist with *zero* physical curvature.
- A code (or intuition) that monitors metric components h_{μν} can "see" huge growth
  even when gauge-invariant curvature diagnostics remain ~0.
- Physical TT gravitational waves produce nonzero linearized curvature scalars at O(h^2),
  while pure-gauge perturbations produce identically zero linearized Riemann.

Model:
- Background: Minkowski, η = diag(-1, +1, +1, +1), G=c=1.
- Two perturbations:
  (A) Physical TT plane wave traveling in +x:
      h_yy =  A_phys cos(k (t - x))
      h_zz = -A_phys cos(k (t - x))
      others 0
  (B) Pure gauge perturbation built from a gauge vector ξ_μ:
      Choose ξ_y = (A_gauge/(2k)) * y * sin(k (t - x)), others 0
      Then h^gauge_{μν} = ∂_μ ξ_ν + ∂_ν ξ_μ
      This can have large h components (including h_ty, h_xy, h_yy) but *zero* linearized Riemann.

Diagnostics:
- Compute linearized Riemann tensor (flat background) from h_{μν}:
    R_{αβγδ} = 1/2 (∂_γ∂_β h_{αδ} + ∂_δ∂_α h_{βγ}
                    - ∂_δ∂_β h_{αγ} - ∂_γ∂_α h_{βδ})
- Compute a curvature scalar proxy (O(h^2) invariant):
    K_lin = R_{αβγδ} R^{αβγδ}   using η to raise indices
  (This is a "linearized Kretschmann" proxy; it vanishes for pure gauge.)
"""

from __future__ import annotations

import argparse
import json
import math
import os
from typing import Any, Dict, List, Optional, Tuple


# ----------------------------
# Helpers
# ----------------------------

def py_to_json_name(py_path: str) -> str:
    base = os.path.splitext(os.path.basename(py_path))[0]
    return base + ".json"


def require(cond: bool, msg: str) -> None:
    if not cond:
        raise ValueError(msg)


def parse_csv_floats(s: str) -> List[float]:
    return [float(x.strip()) for x in s.split(",") if x.strip()]


def finite_or_none(x: float) -> Optional[float]:
    return x if math.isfinite(x) else None


def eta(mu: int, nu: int) -> float:
    # Minkowski metric diag(-1, +1, +1, +1)
    if mu != nu:
        return 0.0
    return -1.0 if mu == 0 else 1.0


# ----------------------------
# Toy 052
# ----------------------------

class Toy052GaugeVsPhysical:
    toy_id = "052"

    def __init__(
        self,
        *,
        A_phys: float = 1e-3,
        A_gauge: float = 1.0,
        k: float = 1.0,
        y0: float = 1.0,
        z0: float = 0.0,
    ) -> None:
        require(k > 0.0, "k must be > 0.")
        self.A_phys = float(A_phys)
        self.A_gauge = float(A_gauge)
        self.k = float(k)
        self.y0 = float(y0)
        self.z0 = float(z0)

    def phase(self, t: float, x: float) -> float:
        return self.k * (t - x)

    # ----------------------------
    # Perturbations h_{μν}
    # ----------------------------

    def h_phys_TT(self, t: float, x: float, y: float, z: float) -> List[List[float]]:
        # Only yy and zz components, TT plane wave in +x
        ph = self.phase(t, x)
        c = math.cos(ph)
        h = [[0.0 for _ in range(4)] for __ in range(4)]
        h[2][2] = self.A_phys * c         # yy
        h[3][3] = -self.A_phys * c        # zz
        return h

    def h_pure_gauge(self, t: float, x: float, y: float, z: float) -> List[List[float]]:
        """
        Build h_{μν} = ∂_μ ξ_ν + ∂_ν ξ_μ from ξ_y = (A_gauge/(2k)) * y * sin(k(t-x)).
        Indices: 0=t, 1=x, 2=y, 3=z.
        """
        ph = self.phase(t, x)
        s = math.sin(ph)
        c = math.cos(ph)

        # ξ components
        xi = [0.0, 0.0, (self.A_gauge / (2.0 * self.k)) * y * s, 0.0]

        # First derivatives ∂_μ ξ_ν (only nonzero where ν=2)
        # d/dt: ∂0 ξ2 = (A/(2k)) * y * cos(ph) * k = (A/2) y cos(ph)
        d0_xi2 = (self.A_gauge / 2.0) * y * c
        # d/dx: ∂1 ξ2 = (A/(2k)) * y * cos(ph) * (-k) = -(A/2) y cos(ph)
        d1_xi2 = -(self.A_gauge / 2.0) * y * c
        # d/dy: ∂2 ξ2 = (A/(2k)) * sin(ph)
        d2_xi2 = (self.A_gauge / (2.0 * self.k)) * s
        # d/dz: 0
        d3_xi2 = 0.0

        # Assemble ∂_μ ξ_ν
        d_xi = [[0.0 for _ in range(4)] for __ in range(4)]
        d_xi[0][2] = d0_xi2
        d_xi[1][2] = d1_xi2
        d_xi[2][2] = d2_xi2
        d_xi[3][2] = d3_xi2

        # h_{μν} = d_xi[μ][ν] + d_xi[ν][μ]
        h = [[0.0 for _ in range(4)] for __ in range(4)]
        for mu in range(4):
            for nu in range(4):
                h[mu][nu] = d_xi[mu][nu] + d_xi[nu][mu]
        return h

    # ----------------------------
    # Second derivatives ∂_α∂_β h_{μν} (analytic)
    # ----------------------------

    def d2_h_phys(self, mu: int, nu: int, a: int, b: int, t: float, x: float, y: float, z: float) -> float:
        # Only h_yy and h_zz depend on t,x via cos(k(t-x)).
        if not ((mu, nu) in [(2, 2), (3, 3)]):
            return 0.0

        amp = self.A_phys if (mu, nu) == (2, 2) else -self.A_phys
        ph = self.phase(t, x)
        c = math.cos(ph)

        # Second derivatives with respect to t/x only
        # For cos(k(t-x)):
        # ∂tt: -k^2 cos, ∂xx: -k^2 cos, ∂tx: +k^2 cos
        def d2(a_: int, b_: int) -> float:
            if (a_ == 0 and b_ == 0) or (a_ == 1 and b_ == 1):
                return -self.k * self.k * c
            if (a_ == 0 and b_ == 1) or (a_ == 1 and b_ == 0):
                return +self.k * self.k * c
            return 0.0

        return amp * d2(a, b)

    def d2_h_gauge(self, mu: int, nu: int, a: int, b: int, t: float, x: float, y: float, z: float) -> float:
        """
        For the pure gauge h derived from ξ_y = (A/(2k)) y sin(k(t-x)),
        compute analytic second derivatives of h_{μν} at (t,x,y,z).

        Nonzero h components are among: h_ty, h_xy, h_yy.
        (h is symmetric.)
        """
        A = self.A_gauge
        k = self.k
        ph = self.phase(t, x)
        s = math.sin(ph)
        c = math.cos(ph)

        # Handy scalars:
        # h_ty = (A/2) y cos(ph)
        # h_xy = -(A/2) y cos(ph)
        # h_yy = (A/k) sin(ph)   (since h_yy = 2 ∂y ξ_y = (A/k) sin(ph))
        # Others 0.

        # Determine which component:
        # (mu,nu) order-insensitive
        pair = (mu, nu) if mu <= nu else (nu, mu)

        # Each h component is a simple separable function of y and phase.
        def h_component_type() -> str:
            if pair == (0, 2):  # t-y
                return "ty"
            if pair == (1, 2):  # x-y
                return "xy"
            if pair == (2, 2):  # y-y
                return "yy"
            return "zero"

        typ = h_component_type()
        if typ == "zero":
            return 0.0

        # For phase dependence:
        # cos(ph): ∂tt = -k^2 cos, ∂xx = -k^2 cos, ∂tx = +k^2 cos
        # sin(ph): ∂tt = -k^2 sin, ∂xx = -k^2 sin, ∂tx = +k^2 sin
        def d2_phase(kind: str, a_: int, b_: int) -> float:
            if kind == "cos":
                base = c
            else:
                base = s
            if (a_ == 0 and b_ == 0) or (a_ == 1 and b_ == 1):
                return -k * k * base
            if (a_ == 0 and b_ == 1) or (a_ == 1 and b_ == 0):
                return +k * k * base
            return 0.0

        # y dependence:
        # for ty, xy: proportional to y * cos(ph)
        # for yy: proportional to sin(ph) (independent of y)
        if typ == "ty":
            # h_ty = (A/2) y cos(ph)
            # derivatives wrt y: ∂y h_ty = (A/2) cos(ph), ∂yy h_ty = 0
            # derivatives wrt t/x: act on cos(ph)
            pref = (A / 2.0) * y
            if a in (2, 3) or b in (2, 3):
                # Mixed derivatives involving y:
                # ∂y∂t: (A/2) * ∂t cos = (A/2) * (-k sin)
                # ∂y∂x: (A/2) * ∂x cos = (A/2) * (+k sin)
                # ∂yy: 0, ∂yz: 0
                # We'll handle systematically:
                if (a, b) == (2, 0) or (a, b) == (0, 2):
                    return (A / 2.0) * (-k * s)
                if (a, b) == (2, 1) or (a, b) == (1, 2):
                    return (A / 2.0) * (+k * s)
                if (a == 2 and b == 2) or (a == 3) or (b == 3):
                    return 0.0
                return 0.0
            return pref * d2_phase("cos", a, b)

        if typ == "xy":
            # h_xy = -(A/2) y cos(ph)
            pref = -(A / 2.0) * y
            if a in (2, 3) or b in (2, 3):
                if (a, b) == (2, 0) or (a, b) == (0, 2):
                    return -(A / 2.0) * (-k * s)  # derivative of pref*y*cos; pref has minus
                if (a, b) == (2, 1) or (a, b) == (1, 2):
                    return -(A / 2.0) * (+k * s)
                if (a == 2 and b == 2) or (a == 3) or (b == 3):
                    return 0.0
                return 0.0
            return pref * d2_phase("cos", a, b)

        # typ == "yy":
        # h_yy = (A/k) sin(ph)
        if a == 2 or b == 2 or a == 3 or b == 3:
            return 0.0
        return (A / k) * d2_phase("sin", a, b)

    # ----------------------------
    # Linearized Riemann & K_lin
    # ----------------------------

    def R_lin(
        self,
        *,
        model: str,
        a: int,
        b: int,
        c: int,
        d: int,
        t: float,
        x: float,
        y: float,
        z: float,
    ) -> float:
        """
        Linearized Riemann with all-lowered indices in flat background.
        """
        def d2_h(mu: int, nu: int, aa: int, bb: int) -> float:
            if model == "physical_TT":
                return self.d2_h_phys(mu, nu, aa, bb, t, x, y, z)
            if model == "pure_gauge":
                return self.d2_h_gauge(mu, nu, aa, bb, t, x, y, z)
            raise ValueError("unknown model")

        # R_abcd = 1/2( ∂c∂b h_ad + ∂d∂a h_bc - ∂d∂b h_ac - ∂c∂a h_bd )
        term = (
            d2_h(a, d, c, b)
            + d2_h(b, c, d, a)
            - d2_h(a, c, d, b)
            - d2_h(b, d, c, a)
        )
        return 0.5 * term

    def K_lin(self, *, model: str, t: float, x: float, y: float, z: float) -> float:
        """
        K_lin = R_{abcd} R^{abcd} with raising by η^{..} (η is diagonal here).
        Brute-force sum over indices 0..3.
        """
        K = 0.0
        for a in range(4):
            for b in range(4):
                for c in range(4):
                    for d in range(4):
                        R_abcd = self.R_lin(model=model, a=a, b=b, c=c, d=d, t=t, x=x, y=y, z=z)
                        # Raise all indices: R^{abcd} = η^{aa}η^{bb}η^{cc}η^{dd} R_abcd (diagonal η)
                        raised = eta(a, a) * eta(b, b) * eta(c, c) * eta(d, d) * R_abcd
                        K += R_abcd * raised
        return K

    def max_abs_h(self, h: List[List[float]]) -> float:
        m = 0.0
        for i in range(4):
            for j in range(4):
                m = max(m, abs(h[i][j]))
        return m

    def sample_point(self, t: float, x: float) -> Dict[str, Any]:
        y = self.y0
        z = self.z0

        hP = self.h_phys_TT(t, x, y, z)
        hG = self.h_pure_gauge(t, x, y, z)

        KP = self.K_lin(model="physical_TT", t=t, x=x, y=y, z=z)
        KG = self.K_lin(model="pure_gauge", t=t, x=x, y=y, z=z)

        # Simple local diagnostics (metric components are NOT gauge-invariant):
        return {
            "coordinates": {"t": t, "x": x, "y": y, "z": z},
            "curvature_invariants": {
                # Background is flat, but we export the linearized curvature scalar proxy at O(h^2)
                "linearized_kretschmann_proxy_physical_TT": finite_or_none(KP),
                "linearized_kretschmann_proxy_pure_gauge": finite_or_none(KG),
            },
            "local_observables": {
                "max_abs_h_physical_TT": finite_or_none(self.max_abs_h(hP)),
                "max_abs_h_pure_gauge": finite_or_none(self.max_abs_h(hG)),
                "representative_components": {
                    "h_yy_physical_TT": finite_or_none(hP[2][2]),
                    "h_zz_physical_TT": finite_or_none(hP[3][3]),
                    "h_ty_pure_gauge": finite_or_none(hG[0][2]),
                    "h_xy_pure_gauge": finite_or_none(hG[1][2]),
                    "h_yy_pure_gauge": finite_or_none(hG[2][2]),
                },
                "ratio_max_abs_h_gauge_over_physical": (
                    finite_or_none(self.max_abs_h(hG) / self.max_abs_h(hP))
                    if self.max_abs_h(hP) > 0.0 else None
                ),
            },
            "causal_structure": {
                "background_lightcone": "Minkowski",
                "note": (
                    "Pure-gauge fields can be large while curvature remains ~0; "
                    "monitoring h_{μν} alone is not a physical stability test."
                ),
            },
        }

    def build_payload(self, t_values: List[float], x_values: List[float]) -> Dict[str, Any]:
        require(len(t_values) >= 1 and len(x_values) >= 1, "Need at least one t and one x sample.")

        sample_points: List[Dict[str, Any]] = []
        max_hP = 0.0
        max_hG = 0.0
        max_abs_KP = 0.0
        max_abs_KG = 0.0

        for t in t_values:
            for x in x_values:
                sp = self.sample_point(float(t), float(x))
                sample_points.append(sp)

                max_hP = max(max_hP, abs(sp["local_observables"]["max_abs_h_physical_TT"] or 0.0))
                max_hG = max(max_hG, abs(sp["local_observables"]["max_abs_h_pure_gauge"] or 0.0))
                max_abs_KP = max(max_abs_KP, abs(sp["curvature_invariants"]["linearized_kretschmann_proxy_physical_TT"] or 0.0))
                max_abs_KG = max(max_abs_KG, abs(sp["curvature_invariants"]["linearized_kretschmann_proxy_pure_gauge"] or 0.0))

        return {
            "toy_id": self.toy_id,
            "theory": "General Relativity (linearized; gauge vs physical modes)",
            "spacetime": "Minkowski + perturbations (TT wave vs pure gauge diffeomorphism)",
            "units": {"G": 1, "c": 1},
            "parameters": {
                "A_phys": self.A_phys,
                "A_gauge": self.A_gauge,
                "k": self.k,
                "evaluation_point_y0": self.y0,
                "evaluation_point_z0": self.z0,
                "t_samples": t_values,
                "x_samples": x_values,
            },
            "notes": {
                "assumptions": [
                    "Flat Minkowski background",
                    "Linearized perturbations in vacuum",
                    "Physical model is TT plane wave in +x direction",
                    "Gauge model built explicitly from a gauge vector ξ_μ (pure diffeomorphism)",
                    "K_lin is computed from linearized Riemann and is O(h^2) as a scalar proxy",
                ],
                "pressure_point": (
                    "Gauge/coordinate degrees of freedom can dominate metric-component behavior while "
                    "physical curvature diagnostics remain ~0. Large h_{μν} does not imply physical gravity."
                ),
                "key_formulas": {
                    "linearized_riemann": (
                        "R_{αβγδ}=1/2(∂γ∂β h_{αδ}+∂δ∂α h_{βγ}-∂δ∂β h_{αγ}-∂γ∂α h_{βδ})"
                    ),
                    "K_lin_proxy": "K_lin = R_{αβγδ} R^{αβγδ} (raised with η)",
                    "TT_wave": "h_yy=A cos(k(t-x)), h_zz=-A cos(k(t-x))",
                    "pure_gauge": "h_{μν}=∂_μ ξ_ν + ∂_ν ξ_μ with ξ_y=(A_gauge/(2k)) y sin(k(t-x))",
                },
            },
            "sample_points": sample_points,
            "observables": {
                "summary": {
                    "max_abs_h_physical_TT_over_grid": finite_or_none(max_hP),
                    "max_abs_h_pure_gauge_over_grid": finite_or_none(max_hG),
                    "max_abs_K_lin_physical_TT_over_grid": finite_or_none(max_abs_KP),
                    "max_abs_K_lin_pure_gauge_over_grid": finite_or_none(max_abs_KG),
                    "note": (
                        "Expect: max_abs_h_pure_gauge can be >> max_abs_h_physical, while "
                        "max_abs_K_lin_pure_gauge ~ 0 (up to floating/analytic cancellation)."
                    ),
                }
            },
        }

    def export_json(self, t_values: List[float], x_values: List[float], out_path: Optional[str] = None) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)
        payload = self.build_payload(t_values=t_values, x_values=x_values)
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2, sort_keys=True)
        return out_path


# ----------------------------
# CLI
# ----------------------------

def main() -> None:
    ap = argparse.ArgumentParser(description="Toy 052: gauge vs physical modes (linearized GR).")
    ap.add_argument("--A_phys", type=float, default=1e-3, help="Amplitude of physical TT wave")
    ap.add_argument("--A_gauge", type=float, default=1.0, help="Amplitude parameter for pure gauge ξ (controls |h|)")
    ap.add_argument("--k", type=float, default=1.0, help="Wave number k>0")
    ap.add_argument("--y0", type=float, default=1.0, help="Evaluation y coordinate (gauge h depends on y)")
    ap.add_argument("--z0", type=float, default=0.0, help="Evaluation z coordinate")
    ap.add_argument("--t", type=str, default="0,0.5,1.0,1.5,2.0", help="Comma-separated t samples")
    ap.add_argument("--x", type=str, default="0,0.5,1.0", help="Comma-separated x samples")
    ap.add_argument("--out", type=str, default="", help="Optional output path. If omitted, uses <this_script_name>.json")
    args = ap.parse_args()

    toy = Toy052GaugeVsPhysical(
        A_phys=float(args.A_phys),
        A_gauge=float(args.A_gauge),
        k=float(args.k),
        y0=float(args.y0),
        z0=float(args.z0),
    )

    t_values = parse_csv_floats(args.t)
    x_values = parse_csv_floats(args.x)

    out_path = args.out.strip() or None
    json_path = toy.export_json(t_values=t_values, x_values=x_values, out_path=out_path)

    print(f"Wrote {json_path}")
    print("Toy 052 complete: gauge vs physical modes (linearized GR).")


if __name__ == "__main__":
    main()
