#!/usr/bin/env python3
"""
Toy 079 — Thermal time hypothesis: modular flow time depends on thermodynamic state (non-unique out of equilibrium)

Classification (lab axes):
- Failure Trigger: energetic + observer/state
- Failure Mode: operational_undefined (time definition becomes state-dependent / non-unique)
- Failure Sharpness: contextual
- Repairable Within Classical GR: no

What it probes (pressure point):
- In the thermal time hypothesis (Rovelli et al.), a notion of time flow can be defined from the
  state itself via the modular Hamiltonian K = -ln ρ (up to an additive constant).
- For equilibrium Gibbs states ρ ∝ e^{-βH}, K is (approximately) proportional to the physical
  Hamiltonian H (plus a constant), yielding a clean, unique thermal time scaling.
- For non-equilibrium states, K is not proportional to H; the resulting modular flow defines a
  different 'time' generator, and there is no unique mapping to physical time.

Model (controlled finite-dimensional toy):
- 3-level system with Hamiltonian H = diag(0, E, 2E) (units with k_B=1).
- Consider three states:
  (A) Equilibrium Gibbs:       ρ_eq ∝ e^{-βH}
  (B) Non-equilibrium diagonal:ρ_diag with populations not fitting any single β
  (C) Coherent non-equilibrium:ρ_coh with off-diagonal coherence (so [K, H] ≠ 0)

Diagnostics (numerical):
- Compute modular Hamiltonian K = -logm(ρ) (on support; small eigenvalues clipped).
- Best-fit β (least squares) such that K ≈ β H + c I on the diagonal in the energy basis.
- Residual (RMS) of that fit on diagonal entries.
- Commutator norm ||[K,H]||_F as a 'generator misalignment' measure.
- If residual and commutator are near zero => "thermal time" aligns with physical H (unique scaling).
  Otherwise => time definition is state-dependent / ambiguous.

Observed Results (what breaks and why it matters):
- Equilibrium Gibbs states yield K ~ βH + const and [K,H]=0 (clean thermal time).
- Non-equilibrium states generically produce K not proportional to H, and may not commute with H,
  so the modular flow is not equivalent to physical time evolution. "Time" becomes state-dependent.

Export:
- Strict JSON schema per lab protocol; writes <script_name>.json.
- Undefined quantities exported as null; keys never omitted.
"""

from __future__ import annotations

import argparse
import json
import math
import os
from typing import Any, Dict, List, Optional, Tuple

import numpy as np


# ----------------------------
# Helpers
# ----------------------------

def py_to_json_name(py_path: str) -> str:
    base = os.path.splitext(os.path.basename(py_path))[0]
    return base + ".json"


def require(cond: bool, msg: str) -> None:
    if not cond:
        raise ValueError(msg)


def finite_or_none(x: float) -> Optional[float]:
    return x if (isinstance(x, (int, float)) and math.isfinite(x)) else None


def complex_to_pair(z: complex) -> Dict[str, float]:
    return {"re": float(np.real(z)), "im": float(np.imag(z))}


def mat_to_list(m: np.ndarray) -> List[List[Dict[str, float]]]:
    out: List[List[Dict[str, float]]] = []
    for i in range(m.shape[0]):
        row = []
        for j in range(m.shape[1]):
            row.append(complex_to_pair(complex(m[i, j])))
        out.append(row)
    return out


def vec_to_list(v: np.ndarray) -> List[Dict[str, float]]:
    return [complex_to_pair(complex(x)) for x in v.reshape(-1)]


def von_neumann_entropy(rho: np.ndarray, eps: float = 1e-15) -> float:
    evals = np.linalg.eigvalsh(0.5 * (rho + rho.conj().T))
    evals = np.clip(np.real(evals), eps, 1.0)
    return float(-np.sum(evals * np.log(evals)))


def logm_psd(rho: np.ndarray, clip: float = 1e-12) -> np.ndarray:
    # Hermitian PSD log via spectral decomposition with eigenvalue clipping
    rhoH = 0.5 * (rho + rho.conj().T)
    evals, evecs = np.linalg.eigh(rhoH)
    evals_clipped = np.clip(np.real(evals), clip, None)
    log_evals = np.log(evals_clipped)
    return (evecs @ np.diag(log_evals) @ evecs.conj().T)


def fro_norm(a: np.ndarray) -> float:
    return float(np.sqrt(np.real(np.trace(a.conj().T @ a))))


def fit_beta_and_c(diagK: np.ndarray, diagH: np.ndarray) -> Tuple[float, float, float]:
    # Least squares for diagK ≈ beta*diagH + c
    # Return beta, c, rms residual
    x = diagH.reshape(-1, 1)
    A = np.hstack([x, np.ones_like(x)])
    y = diagK.reshape(-1, 1)
    sol, _, _, _ = np.linalg.lstsq(A, y, rcond=None)
    beta = float(sol[0, 0])
    c = float(sol[1, 0])
    yhat = A @ sol
    resid = float(np.sqrt(np.mean((y - yhat) ** 2)))
    return beta, c, resid


# ----------------------------
# Toy 079
# ----------------------------

class Toy079ThermalTimeHypothesis:
    toy_id = "079"

    def __init__(self, *, E: float = 1.0, beta_eq: float = 1.0, clip: float = 1e-12) -> None:
        require(E > 0.0, "E must be > 0.")
        require(beta_eq > 0.0, "beta_eq must be > 0.")
        require(clip > 0.0, "clip must be > 0.")
        self.E = float(E)
        self.beta_eq = float(beta_eq)
        self.clip = float(clip)

        # 3-level Hamiltonian in energy basis
        self.H = np.diag([0.0, self.E, 2.0 * self.E]).astype(complex)

    def gibbs_state(self, beta: float) -> np.ndarray:
        e = np.array([0.0, self.E, 2.0 * self.E], dtype=float)
        w = np.exp(-beta * e)
        Z = float(np.sum(w))
        p = w / Z
        return np.diag(p).astype(complex)

    def diag_noneq_state(self) -> np.ndarray:
        # A diagonal distribution that is not exactly Gibbs for any single beta on three levels
        # (e.g., middle level overpopulated relative to exponential)
        p = np.array([0.62, 0.33, 0.05], dtype=float)
        p = p / float(np.sum(p))
        return np.diag(p).astype(complex)

    def coherent_noneq_state(self) -> np.ndarray:
        # Start from a diagonal mixed state and add small coherence between |0> and |2>
        p = np.array([0.55, 0.35, 0.10], dtype=float)
        p = p / float(np.sum(p))
        rho = np.diag(p).astype(complex)
        # add coherence and renormalize to keep PSD-ish (small enough)
        gamma = 0.06
        rho[0, 2] = gamma
        rho[2, 0] = gamma
        # ensure Hermitian and renormalize trace
        rho = 0.5 * (rho + rho.conj().T)
        rho = rho / float(np.real(np.trace(rho)))
        # If numerical PSD issues appear, clip via eigenvalue fix
        evals, evecs = np.linalg.eigh(rho)
        evals = np.clip(np.real(evals), 1e-10, None)
        rho = (evecs @ np.diag(evals) @ evecs.conj().T)
        rho = rho / float(np.real(np.trace(rho)))
        return rho

    def analyze_state(self, rho: np.ndarray, label: str) -> Dict[str, Any]:
        # Modular Hamiltonian K = -ln ρ (up to additive const)
        log_rho = logm_psd(rho, clip=self.clip)
        K = -log_rho

        # Compare to H in energy basis: fit beta and c to diagonal entries
        diagK = np.real(np.diag(K))
        diagH = np.real(np.diag(self.H))
        beta_fit, c_fit, resid = fit_beta_and_c(diagK, diagH)

        # Commutator norm: if K proportional to H (and both diagonal), commutator ~0
        comm = K @ self.H - self.H @ K
        comm_norm = fro_norm(comm)

        S = von_neumann_entropy(rho)

        # Decide if "thermal time is uniquely aligned with H"
        tol_resid = 1e-6
        tol_comm = 1e-8
        aligned = (resid < tol_resid) and (comm_norm < tol_comm)

        return {
            "state_label": label,
            "rho": mat_to_list(rho),
            "entropy_S": finite_or_none(S),
            "modular_hamiltonian_K": mat_to_list(K),
            "beta_fit": finite_or_none(beta_fit),
            "c_fit": finite_or_none(c_fit),
            "fit_residual_rms": finite_or_none(resid),
            "commutator_fro_norm": finite_or_none(comm_norm),
            "thermal_time_defined_as_unique_scaling": bool(aligned),
            "note": (
                "aligned=True indicates K ≈ βH + cI (diagonal fit) and [K,H]≈0. "
                "If false, modular flow differs from physical H-time and depends on state."
            ),
        }

    def build_payload(self) -> Dict[str, Any]:
        rho_eq = self.gibbs_state(self.beta_eq)
        rho_diag = self.diag_noneq_state()
        rho_coh = self.coherent_noneq_state()

        analysis_eq = self.analyze_state(rho_eq, "equilibrium_gibbs")
        analysis_diag = self.analyze_state(rho_diag, "nonequilibrium_diagonal")
        analysis_coh = self.analyze_state(rho_coh, "nonequilibrium_coherent")

        # Distinguish by residual/comm norms
        states = [analysis_eq, analysis_diag, analysis_coh]
        resid_vals = [s["fit_residual_rms"] for s in states if s["fit_residual_rms"] is not None]
        comm_vals = [s["commutator_fro_norm"] for s in states if s["commutator_fro_norm"] is not None]

        return {
            "toy_id": self.toy_id,
            "theory": "Thermal time hypothesis diagnostic (modular flow time from state)",
            "spacetime": "N/A (time from state via modular Hamiltonian; finite-dimensional proxy)",
            "units": {"G": 1, "c": 1},
            "parameters": {
                "hamiltonian_H": "diag(0, E, 2E)",
                "E": self.E,
                "beta_equilibrium": self.beta_eq,
                "eigenvalue_clip_for_log": self.clip,
                "tolerances": {"residual": 1e-6, "commutator": 1e-8},
            },
            "notes": {
                "pressure_point": (
                    "If time is defined thermally (via modular flow), then the time generator depends on the state. "
                    "Only in equilibrium Gibbs states does the modular Hamiltonian align with a physical Hamiltonian H "
                    "up to a constant, yielding a unique scaling."
                ),
                "key_definitions": {
                    "modular_hamiltonian": "K = -ln ρ (up to additive constant)",
                    "thermal_time_alignment": "K ≈ β H + c I and [K,H]≈0",
                },
                "domain_of_validity": (
                    "Finite-dimensional proxy capturing how modular flow depends on state; not a full relativistic field theory."
                ),
            },
            "sample_points": [
                {
                    "coordinates": {"case": analysis_eq["state_label"]},
                    "curvature_invariants": {"ricci_scalar": None, "kretschmann": None, "note": "No classical geometry."},
                    "local_observables": analysis_eq,
                    "causal_structure": {"thermal_time_defined": analysis_eq["thermal_time_defined_as_unique_scaling"], "note": "Equilibrium yields unique scaling."},
                },
                {
                    "coordinates": {"case": analysis_diag["state_label"]},
                    "curvature_invariants": {"ricci_scalar": None, "kretschmann": None, "note": "No classical geometry."},
                    "local_observables": analysis_diag,
                    "causal_structure": {"thermal_time_defined": analysis_diag["thermal_time_defined_as_unique_scaling"], "note": "Non-equilibrium diagonal breaks unique β fit (residual>0)."},
                },
                {
                    "coordinates": {"case": analysis_coh["state_label"]},
                    "curvature_invariants": {"ricci_scalar": None, "kretschmann": None, "note": "No classical geometry."},
                    "local_observables": analysis_coh,
                    "causal_structure": {"thermal_time_defined": analysis_coh["thermal_time_defined_as_unique_scaling"], "note": "Coherence typically yields [K,H]≠0; modular flow differs from H-time."},
                },
            ],
            "observables": {
                "summary": {
                    "beta_fit_values": {
                        analysis_eq["state_label"]: analysis_eq["beta_fit"],
                        analysis_diag["state_label"]: analysis_diag["beta_fit"],
                        analysis_coh["state_label"]: analysis_coh["beta_fit"],
                    },
                    "fit_residual_rms_range": {
                        "min": finite_or_none(min(resid_vals)) if resid_vals else None,
                        "max": finite_or_none(max(resid_vals)) if resid_vals else None,
                    },
                    "commutator_norm_range": {
                        "min": finite_or_none(min(comm_vals)) if comm_vals else None,
                        "max": finite_or_none(max(comm_vals)) if comm_vals else None,
                    },
                    "uniqueness_status": False,
                    "note": "Equilibrium aligns; non-equilibrium does not => time-from-state is state-dependent.",
                }
            },
        }

    def export_json(self, out_path: Optional[str] = None) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)
        payload = self.build_payload()
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2, sort_keys=True)
        return out_path


def main() -> None:
    ap = argparse.ArgumentParser(description="Toy 079: thermal time hypothesis (state-dependent time generator).")

    ap.add_argument("--E", type=float, default=1.0, help="Energy gap unit E for H=diag(0,E,2E). (k_B=1)")
    ap.add_argument("--beta_eq", type=float, default=1.0, help="Inverse temperature β for equilibrium Gibbs state.")
    ap.add_argument("--clip", type=float, default=1e-12, help="Eigenvalue clip for log(ρ).")

    ap.add_argument("--out", type=str, default="", help="Optional output JSON path; default is <script>.json")
    args = ap.parse_args()

    toy = Toy079ThermalTimeHypothesis(E=float(args.E), beta_eq=float(args.beta_eq), clip=float(args.clip))
    out_path = args.out.strip() or None
    json_path = toy.export_json(out_path=out_path)

    print(f"Wrote {json_path}")
    print("Toy 079 complete: modular (thermal) time aligns only in equilibrium; otherwise state-dependent.")


if __name__ == "__main__":
    main()
