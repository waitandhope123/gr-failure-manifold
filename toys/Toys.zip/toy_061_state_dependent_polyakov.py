#!/usr/bin/env python3
"""
Toy 061 — State-dependent semiclassical stress-energy near a Schwarzschild horizon
(2D Polyakov model on the (t, r*) sector)

What it probes (pressure point):
- Same classical geometry (Schwarzschild) admits inequivalent semiclassical states with
  qualitatively different ⟨T_ab⟩ near the horizon (regular vs divergent).
- Geometry alone does not determine the semiclassical stress-energy: the quantum state does.

Model / assumptions:
- Fixed Schwarzschild background, mass M, geometric units G=c=1.
- Consider the 1+1D reduced metric in null coords u=t-r*, v=t+r*:
    ds^2 = - f(r) du dv,    f(r) = 1 - 2M/r
- Massless conformal scalar in 2D: Polyakov (conformal anomaly) stress tensor:
    <T_uu> = -(1/48π)[(ρ')^2 - ρ''] + t_uu
    <T_vv> = -(1/48π)[(ρ')^2 - ρ''] + t_vv
    <T_uv> = +(1/48π) ρ''
  with ρ = (1/2) ln f and ' = d/dr* = f d/dr.

For Schwarzschild, these derivatives simplify exactly:
  ρ'  = M / r^2
  ρ'' = - 2M f / r^3
So the anomaly pieces are explicit functions of r (no placeholders).

State choices (standard 2D CFT constants):
- Boulware:        t_uu = 0,                 t_vv = 0
- Unruh:           t_uu = κ^2/(48π),         t_vv = 0
- Hartle–Hawking:  t_uu = κ^2/(48π),         t_vv = κ^2/(48π)
where surface gravity κ = 1/(4M).

Exports:
- For sample radii r>2M, exports <T_uu>, <T_vv>, <T_uv> for each state
- Also exports a static-observer energy density proxy:  ρ_static = T_tt / f
  (diverges if finite T_tt but f→0; uses null if non-finite)
- Horizon regularity proxy: evaluates (du/dU)^2 T_uu near horizon where
    U = -exp(-κ u)  => (du/dU)^2 = 1/(κ^2 U^2)
  We do NOT take U→0 (needs full coordinate-dependent evaluation), but we export
  a diagnostic scaling using f as a proxy for near-horizon behavior:
    "T_uu_total" (should →0 for regular future-horizon states).
"""

from __future__ import annotations

import argparse
import json
import math
import os
from typing import Any, Dict, List, Optional


# ----------------------------
# Helpers
# ----------------------------

def py_to_json_name(py_path: str) -> str:
    base = os.path.splitext(os.path.basename(py_path))[0]
    return base + ".json"


def require(cond: bool, msg: str) -> None:
    if not cond:
        raise ValueError(msg)


def parse_csv_floats(s: str) -> List[float]:
    return [float(x.strip()) for x in s.split(",") if x.strip()]


def finite_or_none(x: float) -> Optional[float]:
    return x if (isinstance(x, (int, float)) and math.isfinite(x)) else None


# ----------------------------
# Toy 061
# ----------------------------

class Toy061StateDependentPolyakov:
    toy_id = "061"

    def __init__(self, M: float = 1.0) -> None:
        require(M > 0.0, "M must be > 0.")
        self.M = float(M)
        self.kappa = 1.0 / (4.0 * self.M)  # surface gravity

        # State constants t_uu, t_vv (2D Polyakov/CFT integration constants)
        t_thermal = (self.kappa * self.kappa) / (48.0 * math.pi)  # κ^2/(48π)

        self.states: Dict[str, Dict[str, float]] = {
            "Boulware": {"t_uu": 0.0,       "t_vv": 0.0},
            "Unruh":    {"t_uu": t_thermal, "t_vv": 0.0},
            "HartleHawking": {"t_uu": t_thermal, "t_vv": t_thermal},
        }

    def f(self, r: float) -> float:
        require(r > 0.0, "r must be > 0.")
        return 1.0 - 2.0 * self.M / r

    # Exact 2D conformal factor derivatives in Schwarzschild (see docstring)
    def rho_prime(self, r: float) -> float:
        # ρ' = dρ/dr* = M/r^2
        return self.M / (r * r)

    def rho_double_prime(self, r: float) -> float:
        # ρ'' = d^2ρ/dr*^2 = -2 M f / r^3
        return -2.0 * self.M * self.f(r) / (r ** 3)

    def anomaly_base(self, r: float) -> float:
        """
        Base anomaly term:
          A(r) = -(1/48π)[(ρ')^2 - ρ'']
        so that:
          <T_uu> = A + t_uu
          <T_vv> = A + t_vv
        """
        rp = self.rho_prime(r)
        rpp = self.rho_double_prime(r)
        return -(1.0 / (48.0 * math.pi)) * (rp * rp - rpp)

    def T_uv(self, r: float) -> float:
        # <T_uv> = +(1/48π) ρ''
        return (1.0 / (48.0 * math.pi)) * self.rho_double_prime(r)

    def null_components_for_state(self, r: float, state: str) -> Dict[str, Optional[float]]:
        A = self.anomaly_base(r)
        tuv = self.T_uv(r)
        t_uu = self.states[state]["t_uu"]
        t_vv = self.states[state]["t_vv"]
        Tuu = A + t_uu
        Tvv = A + t_vv
        return {"T_uu": finite_or_none(Tuu), "T_vv": finite_or_none(Tvv), "T_uv": finite_or_none(tuv)}

    def to_trstar_components(self, Tuu: float, Tvv: float, Tuv: float) -> Dict[str, float]:
        # u=t-r*, v=t+r*  =>  T_tt = Tuu + Tvv + 2Tuv
        T_tt = Tuu + Tvv + 2.0 * Tuv
        T_trs = -Tuu + Tvv
        T_rsrs = Tuu + Tvv - 2.0 * Tuv
        return {"T_tt": T_tt, "T_t_rstar": T_trs, "T_rstar_rstar": T_rsrs}

    def static_energy_density(self, r: float, T_tt: float) -> Optional[float]:
        # Metric in (t,r*): ds^2 = -f dt^2 + f dr*^2
        # Static observer: u^t = 1/sqrt(f) => ρ = T_tt / f
        f = self.f(r)
        if f <= 0.0:
            return None
        return finite_or_none(T_tt / f)

    def kretschmann_4d(self, r: float) -> float:
        # 4D Schwarzschild Kretschmann: 48 M^2 / r^6
        return 48.0 * (self.M ** 2) / (r ** 6)

    def build_payload(self, r_values: List[float], eps_horizon: float) -> Dict[str, Any]:
        require(eps_horizon > 0.0, "eps_horizon must be > 0.")
        r_h = 2.0 * self.M
        r_probe = r_h * (1.0 + eps_horizon)

        sample_points: List[Dict[str, Any]] = []

        # Precompute near-horizon diagnostics at r_probe
        horizon_diag: Dict[str, Any] = {"r_probe": r_probe, "eps_horizon": eps_horizon, "by_state": {}}
        for st in self.states:
            comps = self.null_components_for_state(r_probe, st)
            horizon_diag["by_state"][st] = {
                "f(r_probe)": self.f(r_probe),
                "T_uu_total_at_r_probe": comps["T_uu"],  # should be ~0 for Unruh/HartleHawking
                "T_vv_total_at_r_probe": comps["T_vv"],
                "note": "Future-horizon regularity in this 2D model corresponds to T_uu→0 as r→2M+ (for appropriate state).",
            }

        for r in r_values:
            r = float(r)
            require(r > r_h, "All r must be strictly > 2M (outside horizon) for this toy.")
            f = self.f(r)
            A = self.anomaly_base(r)
            rp = self.rho_prime(r)
            rpp = self.rho_double_prime(r)
            tuv = self.T_uv(r)

            by_state: Dict[str, Any] = {}
            for st in self.states:
                comps = self.null_components_for_state(r, st)
                # Convert to (t,r*) components if all finite
                if comps["T_uu"] is None or comps["T_vv"] is None or comps["T_uv"] is None:
                    tr = {"T_tt": None, "T_t_rstar": None, "T_rstar_rstar": None}
                    rho_stat = None
                else:
                    tr_raw = self.to_trstar_components(float(comps["T_uu"]), float(comps["T_vv"]), float(comps["T_uv"]))
                    tr = {k: finite_or_none(v) for k, v in tr_raw.items()}
                    rho_stat = None if tr["T_tt"] is None else self.static_energy_density(r, float(tr["T_tt"]))

                by_state[st] = {
                    "t_constants": self.states[st],
                    "null_components": comps,
                    "trstar_components": tr,
                    "rho_static_Ttt_over_f": rho_stat,
                }

            sample_points.append({
                "coordinates": {"t": None, "r": r, "r_star": None, "u": None, "v": None},
                "curvature_invariants": {
                    "ricci_scalar": 0.0,  # 4D vacuum Schwarzschild
                    "kretschmann": finite_or_none(self.kretschmann_4d(r)),
                    "note": "Curvature invariants are 4D Schwarzschild vacuum values; stress tensor here is a 2D semiclassical proxy on (t,r*).",
                },
                "local_observables": {
                    "f": f,
                    "rho": 0.5 * math.log(f),
                    "rho_prime_drstar": rp,
                    "rho_double_prime_drstar2": rpp,
                    "anomaly_base_A": A,
                    "T_uv_anomaly": tuv,
                    "by_state": by_state,
                },
                "causal_structure": {
                    "horizon_radius_2M": r_h,
                    "r_minus_2M": r - r_h,
                    "near_horizon": (r < r_h * 1.05),
                    "state_dependence": True,
                    "note": "Different quantum states correspond to different integration constants (t_uu,t_vv) and change near-horizon behavior.",
                },
            })

        payload: Dict[str, Any] = {
            "toy_id": self.toy_id,
            "theory": "Semiclassical GR (2D Polyakov stress tensor proxy)",
            "spacetime": "Schwarzschild (fixed background), sampled outside the horizon",
            "units": {"G": 1, "c": 1},
            "parameters": {
                "M": self.M,
                "kappa_surface_gravity": self.kappa,
                "states": self.states,
                "r_values": r_values,
                "eps_horizon_probe": eps_horizon,
            },
            "notes": {
                "assumptions": [
                    "Fixed Schwarzschild geometry (no backreaction)",
                    "2D reduction to (t,r*) sector; stress tensor is a 2D conformal anomaly (Polyakov) expectation value",
                    "State dependence encoded by constants t_uu, t_vv (Boulware/Unruh/Hartle–Hawking choices)",
                ],
                "pressure_point": (
                    "The semiclassical stress-energy is not determined by the metric alone: "
                    "different quantum states produce different ⟨T_ab⟩, changing horizon regularity and "
                    "energy densities for observers. This thickens the classical 'failure boundary' into a state-dependent one."
                ),
                "key_equations": {
                    "metric_2d": "ds^2 = -f(r) du dv,  f=1-2M/r,  u=t-r*, v=t+r*",
                    "polyakov_Tuu": "<T_uu>=-(1/48π)[(ρ')^2-ρ'']+t_uu",
                    "polyakov_Tvv": "<T_vv>=-(1/48π)[(ρ')^2-ρ'']+t_vv",
                    "polyakov_Tuv": "<T_uv>=(1/48π)ρ''",
                    "rho": "ρ=(1/2)ln f,  ' = d/dr* = f d/dr",
                    "schw_simplifications": "ρ'=M/r^2,  ρ''=-2Mf/r^3",
                    "surface_gravity": "κ=1/(4M),  t_thermal=κ^2/(48π)",
                    "static_energy_density_proxy": "ρ_static = T_tt / f  (static observer in (t,r*) sector)",
                },
                "domain_of_validity": (
                    "Semiclassical proxy only: 2D conformal field on reduced sector, fixed background, "
                    "no renormalization subtleties beyond Polyakov model, and no 4D graybody factors."
                ),
            },
            "sample_points": sample_points,
            "observables": {
                "horizon_regularization_proxy": horizon_diag,
                "interpretation": {
                    "expected_behavior": {
                        "Boulware": "No flux at infinity; near-horizon stress typically problematic/divergent in 4D; in this 2D proxy T_uu does not cancel at r→2M.",
                        "Unruh": "Outgoing thermal flux; future-horizon regularity achieved by canceling the anomaly term in T_uu near r→2M.",
                        "HartleHawking": "Thermal bath; cancels near-horizon anomaly in both T_uu and T_vv in this 2D proxy.",
                    }
                },
            },
        }
        return payload

    def export_json(self, r_values: List[float], eps_horizon: float, out_path: Optional[str] = None) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)
        payload = self.build_payload(r_values=r_values, eps_horizon=eps_horizon)
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2, sort_keys=True)
        return out_path


def main() -> None:
    ap = argparse.ArgumentParser(
        description="Toy 061: State-dependent semiclassical stress-energy near a Schwarzschild horizon (2D Polyakov proxy)."
    )
    ap.add_argument("--M", type=float, default=1.0, help="Schwarzschild mass M>0")
    ap.add_argument(
        "--r",
        type=str,
        default="2.001,2.01,2.05,2.1,2.5,3.0,5.0,10.0",
        help="Comma-separated radii r (must be > 2M)",
    )
    ap.add_argument(
        "--eps_horizon",
        type=float,
        default=1e-4,
        help="Probe offset for near-horizon diagnostics: r_probe = 2M(1+eps_horizon)",
    )
    ap.add_argument("--out", type=str, default="", help="Optional output path; default is <script>.json")
    args = ap.parse_args()

    toy = Toy061StateDependentPolyakov(M=float(args.M))
    r_values = parse_csv_floats(args.r)

    out_path = args.out.strip() or None
    json_path = toy.export_json(r_values=r_values, eps_horizon=float(args.eps_horizon), out_path=out_path)

    print(f"Wrote {json_path}")
    print(f"M={toy.M:g}, kappa=1/(4M)={toy.kappa:g}, horizon r_h=2M={2*toy.M:g}")
    print("States t_uu,t_vv:")
    for k, v in toy.states.items():
        print(f"  {k}: {v}")


if __name__ == "__main__":
    main()
