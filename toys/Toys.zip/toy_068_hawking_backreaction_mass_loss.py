#!/usr/bin/env python3
"""
Toy 068 — Semiclassical backreaction: Hawking-like mass loss and thick failure zone

What it probes (pressure point):
- Classical GR exact solutions (Schwarzschild) are not stable under semiclassical flux:
  the mass drifts in time, so the geometry evolves away from the static solution.
- The breakdown is "thick": predictions worsen progressively as M approaches a cutoff scale.
- GR contains no internal UV rule for what happens at small M; we model a cutoff explicitly.

Model (controlled approximation; G=c=1; also use ħ=k_B=1 for thermodynamic formulas):
- Treat the black hole as a slowly evaporating Schwarzschild spacetime with time-dependent mass M(t).
- Use the standard scaling for evaporation in geometric units:
    dM/dt = - alpha / M^2
  where alpha > 0 is an effective constant encoding field content / greybody factors.
  (We do not claim a precise 4D value; alpha is a parameter.)

- Derived quantities:
    r_h(t) = 2 M(t)
    Hawking temperature: T_H(t) = 1/(8π M(t))
    Luminosity proxy: P(t) = alpha / M(t)^2  (since P = -dM/dt)
    Kretschmann at horizon: K_h = 48 M^2 / r_h^6 = 3/(4 M^4)

Cutoff / domain-of-validity handling:
- When M drops below M_min (a user-defined cutoff), quantities are marked undefined (null)
  and a "uv_breakdown" flag is set.
- This reflects that classical/semiclassical approximations are not trusted beyond this scale.

Extra diagnostic:
- Evolve a nearby alpha' = alpha * (1 + delta_alpha_frac) to quantify sensitivity (thickening):
  small state/flux changes produce growing divergence in remaining lifetime and M(t).

Export:
- Strict JSON schema per lab protocol.
- Undefined quantities => null; keys never omitted.
"""

from __future__ import annotations

import argparse
import json
import math
import os
from typing import Any, Dict, List, Optional, Tuple


# ----------------------------
# Helpers
# ----------------------------

def py_to_json_name(py_path: str) -> str:
    base = os.path.splitext(os.path.basename(py_path))[0]
    return base + ".json"


def require(cond: bool, msg: str) -> None:
    if not cond:
        raise ValueError(msg)


def finite_or_none(x: float) -> Optional[float]:
    return x if (isinstance(x, (int, float)) and math.isfinite(x)) else None


# ----------------------------
# Physics: ODE and derived quantities
# ----------------------------

def dM_dt(M: float, alpha: float) -> float:
    # dM/dt = - alpha / M^2
    if M <= 0.0:
        return float("nan")
    return -alpha / (M * M)


def rk4_step_M(t: float, M: float, dt: float, alpha: float) -> float:
    k1 = dM_dt(M, alpha)
    k2 = dM_dt(M + 0.5 * dt * k1, alpha)
    k3 = dM_dt(M + 0.5 * dt * k2, alpha)
    k4 = dM_dt(M + dt * k3, alpha)
    return M + (dt / 6.0) * (k1 + 2.0 * k2 + 2.0 * k3 + k4)


def horizon_radius(M: float) -> Optional[float]:
    return None if M <= 0.0 else 2.0 * M


def hawking_temperature(M: float) -> Optional[float]:
    # T_H = 1/(8π M)
    if M <= 0.0:
        return None
    return 1.0 / (8.0 * math.pi * M)


def kretschmann_at_horizon(M: float) -> Optional[float]:
    # K_h = 3/(4 M^4)
    if M <= 0.0:
        return None
    return 3.0 / (4.0 * (M ** 4))


def luminosity_proxy(M: float, alpha: float) -> Optional[float]:
    # P = alpha / M^2
    if M <= 0.0:
        return None
    return alpha / (M * M)


# ----------------------------
# Toy 068
# ----------------------------

class Toy068HawkingBackreaction:
    toy_id = "068"

    def __init__(
        self,
        *,
        M0: float,
        alpha: float,
        delta_alpha_frac: float,
        M_min: float,
        t_start: float,
        t_end: float,
        dt: float,
        sample_every: int,
    ) -> None:
        require(M0 > 0.0, "M0 must be > 0.")
        require(alpha > 0.0, "alpha must be > 0.")
        require(M_min > 0.0, "M_min must be > 0.")
        require(t_end > t_start, "t_end must be > t_start.")
        require(dt > 0.0, "dt must be > 0.")
        require(sample_every >= 1, "sample_every must be >= 1.")

        self.M0 = float(M0)
        self.alpha = float(alpha)
        self.delta_alpha_frac = float(delta_alpha_frac)
        self.M_min = float(M_min)
        self.t_start = float(t_start)
        self.t_end = float(t_end)
        self.dt = float(dt)
        self.sample_every = int(sample_every)

    def evolve(self, alpha_used: float) -> List[Dict[str, Any]]:
        t = self.t_start
        M = self.M0
        steps = int(math.floor((self.t_end - self.t_start) / self.dt))

        out: List[Dict[str, Any]] = []
        for n in range(steps + 1):
            if n % self.sample_every == 0 or n == steps:
                uv_breakdown = (M <= self.M_min)

                # Always report geometry parameter M(t); derived observables become null in breakdown zone
                rh = horizon_radius(M)
                TH = hawking_temperature(M)
                Kh = kretschmann_at_horizon(M)
                P = luminosity_proxy(M, alpha_used)

                if uv_breakdown:
                    rh = None
                    TH = None
                    Kh = None
                    P = None

                out.append({
                    "t": t,
                    "M": finite_or_none(M),
                    "uv_breakdown": uv_breakdown,
                    "r_h": finite_or_none(rh) if rh is not None else None,
                    "T_H": finite_or_none(TH) if TH is not None else None,
                    "K_h": finite_or_none(Kh) if Kh is not None else None,
                    "P": finite_or_none(P) if P is not None else None,
                })

            # Step forward unless already invalid
            if not math.isfinite(M) or M <= 0.0:
                break
            M_next = rk4_step_M(t, M, self.dt, alpha_used)
            t += self.dt
            M = M_next

        return out

    def build_payload(self) -> Dict[str, Any]:
        base = self.evolve(self.alpha)
        alpha_pert = self.alpha * (1.0 + self.delta_alpha_frac)
        pert = self.evolve(alpha_pert)

        # Time-align by index (same dt/sample_every)
        sample_points: List[Dict[str, Any]] = []
        for b, p in zip(base, pert):
            # Sensitivity diagnostics
            dM = None
            d_rh = None
            if b["M"] is not None and p["M"] is not None:
                dM = p["M"] - b["M"]
            if b["r_h"] is not None and p["r_h"] is not None:
                d_rh = p["r_h"] - b["r_h"]

            # Curvature invariants: use horizon K_h when defined; Ricci is vacuum (0) for Schwarzschild outside breakdown
            curv_note = "Schwarzschild vacuum: Ricci scalar = 0; horizon Kretschmann K_h = 3/(4 M^4) when within validity."
            ricci = 0.0 if not b["uv_breakdown"] else None
            K_h = b["K_h"]

            sample_points.append({
                "coordinates": {"t": b["t"]},
                "curvature_invariants": {
                    "ricci_scalar": ricci,
                    "kretschmann_at_horizon": K_h,
                    "note": curv_note,
                },
                "local_observables": {
                    "mass_M": b["M"],
                    "horizon_radius_r_h": b["r_h"],
                    "hawking_temperature_T_H": b["T_H"],
                    "luminosity_proxy_P": b["P"],
                    "uv_breakdown": b["uv_breakdown"],
                    "nearby_flux_parameter": {
                        "alpha_used": self.alpha,
                        "alpha_perturbed": alpha_pert,
                        "M_perturbed": p["M"],
                        "r_h_perturbed": p["r_h"],
                        "delta_M": finite_or_none(dM) if dM is not None else None,
                        "delta_r_h": finite_or_none(d_rh) if d_rh is not None else None,
                        "note": "Sensitivity to flux/state parameter alpha; divergence grows as M decreases (thickening).",
                    },
                },
                "causal_structure": {
                    "horizon_radius": b["r_h"],
                    "region": "evaporating Schwarzschild (quasi-static)",
                    "note": (
                        "Horizon exists while M > M_min; beyond cutoff, classical/semiclassical causal structure not trusted."
                    ),
                },
            })

        # Summary metrics: time to reach cutoff (if reached)
        def time_to_cutoff(series: List[Dict[str, Any]]) -> Optional[float]:
            for row in series:
                if row["uv_breakdown"]:
                    return row["t"]
            return None

        t_cut_base = time_to_cutoff(base)
        t_cut_pert = time_to_cutoff(pert)

        payload: Dict[str, Any] = {
            "toy_id": self.toy_id,
            "theory": "General Relativity (Schwarzschild) + semiclassical backreaction (phenomenological mass loss)",
            "spacetime": "Evaporating Schwarzschild (quasi-static), dM/dt = -alpha/M^2",
            "units": {"G": 1, "c": 1},
            "parameters": {
                "M0": self.M0,
                "alpha": self.alpha,
                "delta_alpha_frac": self.delta_alpha_frac,
                "M_min_cutoff": self.M_min,
                "t_start": self.t_start,
                "t_end": self.t_end,
                "dt": self.dt,
                "sample_every": self.sample_every,
                "conventions": "ħ = k_B = 1 for Hawking temperature expression",
            },
            "notes": {
                "pressure_point": (
                    "Backreaction thickens failure: the geometry drifts (M(t) changes), and near a cutoff scale "
                    "classical/semiclassical predictions must be declared undefined (null). GR contains no UV rule."
                ),
                "key_equations": {
                    "mass_loss": "dM/dt = -alpha / M^2",
                    "horizon": "r_h = 2M",
                    "temperature": "T_H = 1/(8π M)",
                    "luminosity_proxy": "P = alpha / M^2",
                    "kretschmann_horizon": "K_h = 3/(4 M^4)",
                },
                "domain_of_validity": (
                    "Quasi-static approximation: M varies slowly compared to light-crossing time. "
                    "Cutoff M_min is an explicit declaration of UV breakdown."
                ),
            },
            "sample_points": sample_points,
            "observables": {
                "summary": {
                    "reaches_cutoff_by_t_end": (t_cut_base is not None),
                    "time_to_cutoff_base": finite_or_none(t_cut_base) if t_cut_base is not None else None,
                    "time_to_cutoff_perturbed_alpha": finite_or_none(t_cut_pert) if t_cut_pert is not None else None,
                    "note": (
                        "Difference in cutoff times under small delta_alpha illustrates thick sensitivity; "
                        "no sharp boundary is singled out by geometry alone."
                    ),
                }
            },
        }
        return payload

    def export_json(self, out_path: Optional[str] = None) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)
        payload = self.build_payload()
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2, sort_keys=True)
        return out_path


def main() -> None:
    ap = argparse.ArgumentParser(description="Toy 068: semiclassical backreaction via Hawking-like mass loss.")
    ap.add_argument("--M0", type=float, default=5.0, help="Initial mass M0 > 0")
    ap.add_argument("--alpha", type=float, default=1e-4, help="Mass-loss coefficient alpha > 0")
    ap.add_argument("--delta_alpha_frac", type=float, default=0.05, help="Fractional perturbation for sensitivity test")
    ap.add_argument("--M_min", type=float, default=1.0, help="Cutoff mass M_min > 0 (UV breakdown proxy)")
    ap.add_argument("--t_start", type=float, default=0.0, help="Start time")
    ap.add_argument("--t_end", type=float, default=2e6, help="End time")
    ap.add_argument("--dt", type=float, default=100.0, help="Time step dt > 0")
    ap.add_argument("--sample_every", type=int, default=200, help="Sample every N steps")
    ap.add_argument("--out", type=str, default="", help="Optional output JSON path")
    args = ap.parse_args()

    toy = Toy068HawkingBackreaction(
        M0=float(args.M0),
        alpha=float(args.alpha),
        delta_alpha_frac=float(args.delta_alpha_frac),
        M_min=float(args.M_min),
        t_start=float(args.t_start),
        t_end=float(args.t_end),
        dt=float(args.dt),
        sample_every=int(args.sample_every),
    )

    out_path = args.out.strip() or None
    json_path = toy.export_json(out_path=out_path)

    print(f"Wrote {json_path}")
    print("Toy 068 complete: backreaction-driven drift + explicit UV cutoff yields thick failure zone behavior.")


if __name__ == "__main__":
    main()
