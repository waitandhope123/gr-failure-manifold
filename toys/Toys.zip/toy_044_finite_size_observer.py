#!/usr/bin/env python3
"""
Toy 044 — Finite-size observer and instrument breakdown (tidal limits)

What it probes (weak points / pressure points):
- The equivalence principle is exact only for pointlike observers.
- Real observers/instruments have finite size L, so tidal gradients produce
  differential accelerations across the body even in smooth regions.
- This toy quantifies when an extended "rod" or "clock" becomes operationally invalid
  under Schwarzschild tidal fields.

Model:
- Schwarzschild vacuum spacetime, geometric units G=c=1.
- Static observer outside the horizon (r > 2M) with a finite-size instrument of length L.
- Uses the standard gravito-electric (tidal) tensor components in an orthonormal frame:
    E_rr = + 2M / r^3   (radial stretching)
    E_tt = E_θθ = E_φφ = - M / r^3  (transverse compression)
- Differential acceleration across length L (radial alignment):
    a_diff ≈ |E_rr| * L

Operational criterion:
- If a_diff > a_max => "instrument failure" (survivability/operability threshold).
- If r <= 2M: static observer is undefined => return null for static-observer observables.

Exports:
- Curvature invariants (Ricci scalar, Kretschmann).
- Tidal tensor scalars and differential acceleration across L.
- Flags for "static-observer-defined" and "instrument_operational".
"""

from __future__ import annotations

import argparse
import json
import math
import os
from typing import Any, Dict, List, Optional


# ----------------------------
# Helpers
# ----------------------------

def py_to_json_name(py_path: str) -> str:
    base = os.path.splitext(os.path.basename(py_path))[0]
    return base + ".json"


def require(cond: bool, msg: str) -> None:
    if not cond:
        raise ValueError(msg)


def parse_csv_floats(s: str) -> List[float]:
    return [float(x.strip()) for x in s.split(",") if x.strip()]


def finite_or_none(x: float) -> Optional[float]:
    return x if math.isfinite(x) else None


# ----------------------------
# Toy 044
# ----------------------------

class Toy044FiniteSizeObserver:
    toy_id = "044"

    def __init__(self, M: float = 1.0, L: float = 1e-3, a_max: float = 1e-2) -> None:
        require(M > 0.0, "M must be > 0.")
        require(L > 0.0, "L must be > 0.")
        require(a_max > 0.0, "a_max must be > 0.")
        self.M = float(M)
        self.L = float(L)
        self.a_max = float(a_max)

    def horizon_radius(self) -> float:
        return 2.0 * self.M

    # Invariants (vacuum Schwarzschild)
    def ricci_scalar(self, r: float) -> float:
        require(r > 0.0, "r must be > 0.")
        return 0.0

    def kretschmann(self, r: float) -> float:
        require(r > 0.0, "r must be > 0.")
        return 48.0 * (self.M ** 2) / (r ** 6)

    # Tidal tensor components in orthonormal frame for static observer (r > 2M)
    # Gravito-electric part of Riemann: E_ij
    def tidal_components_static(self, r: float) -> Dict[str, float]:
        require(r > 0.0, "r must be > 0.")
        # These are the standard Schwarzschild tidal eigenvalues for static observers
        E_rr = 2.0 * self.M / (r ** 3)
        E_tt = -self.M / (r ** 3)  # transverse (theta-theta and phi-phi)
        return {"E_rr": E_rr, "E_theta_theta": E_tt, "E_phi_phi": E_tt}

    def evaluate_at_r(self, r: float) -> Dict[str, Any]:
        require(r > 0.0, "r must be > 0.")
        rh = self.horizon_radius()
        outside = r > rh

        # Invariants always defined for r>0
        R = self.ricci_scalar(r)
        K = self.kretschmann(r)

        # Static observer observables only defined for r>2M
        if outside:
            tidal = self.tidal_components_static(r)
            a_diff = abs(tidal["E_rr"]) * self.L  # differential acceleration across length L
            operational = a_diff <= self.a_max
            local = {
                "static_observer_defined": True,
                "instrument_length_L": self.L,
                "max_tolerable_diff_accel_a_max": self.a_max,
                "tidal_E_rr": finite_or_none(tidal["E_rr"]),
                "tidal_E_theta_theta": finite_or_none(tidal["E_theta_theta"]),
                "tidal_E_phi_phi": finite_or_none(tidal["E_phi_phi"]),
                "differential_accel_across_L": finite_or_none(a_diff),
                "instrument_operational": operational,
            }
        else:
            local = {
                "static_observer_defined": False,
                "instrument_length_L": self.L,
                "max_tolerable_diff_accel_a_max": self.a_max,
                "tidal_E_rr": None,
                "tidal_E_theta_theta": None,
                "tidal_E_phi_phi": None,
                "differential_accel_across_L": None,
                "instrument_operational": None,
            }

        return {
            "coordinates": {"r": r},
            "curvature_invariants": {
                "ricci_scalar_R": R,
                "kretschmann_K": K,
            },
            "local_observables": local,
            "causal_structure": {
                "horizon_radius_2M": rh,
                "inside_horizon": (r < rh),
                "at_horizon": (abs(r - rh) <= 0.0),
                "static_region_defined": outside,
            },
        }

    def build_payload(self, r_values: List[float]) -> Dict[str, Any]:
        rh = self.horizon_radius()
        sample_points = [self.evaluate_at_r(r) for r in r_values]

        # Summary statistics (only over defined static region)
        defined_points = [sp for sp in sample_points if sp["local_observables"]["static_observer_defined"]]
        operational_points = [sp for sp in defined_points if sp["local_observables"]["instrument_operational"]]

        min_operational_r = None
        if operational_points:
            min_operational_r = min(sp["coordinates"]["r"] for sp in operational_points)

        return {
            "toy_id": self.toy_id,
            "theory": "General Relativity",
            "spacetime": "Schwarzschild (finite-size observer tidal limits)",
            "units": {"G": 1, "c": 1},
            "parameters": {
                "M": self.M,
                "L": self.L,
                "a_max": self.a_max,
                "r_samples": r_values,
            },
            "notes": {
                "assumptions": [
                    "Vacuum Schwarzschild, geometric units G=c=1",
                    "Static observer outside the horizon (r > 2M)",
                    "Finite-size instrument approximated as a rod of length L aligned radially",
                    "Operational failure threshold: a_diff = |E_rr|*L > a_max",
                ],
                "pressure_point": (
                    "Extended bodies feel tidal gradients; the equivalence principle does not protect finite instruments. "
                    "Operational validity becomes scale-dependent (depends on L and tolerance a_max), even where curvature is modest."
                ),
                "key_formulas": {
                    "tidal_E_rr": "E_rr = 2M / r^3 (static orthonormal frame)",
                    "tidal_transverse": "E_θθ = E_φφ = -M / r^3",
                    "diff_accel": "a_diff ≈ |E_rr| * L",
                },
            },
            "sample_points": sample_points,
            "observables": {
                "summary": {
                    "horizon_radius_2M": rh,
                    "num_samples": len(sample_points),
                    "num_static_defined": len(defined_points),
                    "num_operational": len(operational_points),
                    "min_r_where_operational_outside_horizon": min_operational_r,
                    "note": (
                        "Inside r<=2M, the 'static observer' model is undefined; observables are null there by design."
                    ),
                }
            },
        }

    def export_json(self, r_values: List[float], out_path: Optional[str] = None) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)
        payload = self.build_payload(r_values=r_values)
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2, sort_keys=True)
        return out_path


# ----------------------------
# CLI
# ----------------------------

def main() -> None:
    ap = argparse.ArgumentParser(description="Toy 044: Finite-size observer tidal breakdown in Schwarzschild.")
    ap.add_argument("--M", type=float, default=1.0, help="Mass parameter M (geometric units)")
    ap.add_argument("--L", type=float, default=1e-3, help="Instrument/rod length L (geometric units)")
    ap.add_argument("--a_max", type=float, default=1e-2, help="Max tolerable differential acceleration across L")
    ap.add_argument(
        "--r",
        type=str,
        default="100,20,10,6,4,3,2.5,2.1,2.01,2.001,1.9,1.0,0.5",
        help="Comma-separated radii r>0 (include near 2M; static region undefined for r<=2M)",
    )
    ap.add_argument("--out", type=str, default="", help="Optional output path. If omitted, uses <this_script_name>.json")
    args = ap.parse_args()

    r_values = parse_csv_floats(args.r)
    toy = Toy044FiniteSizeObserver(M=float(args.M), L=float(args.L), a_max=float(args.a_max))

    out_path = args.out.strip() or None
    json_path = toy.export_json(r_values=r_values, out_path=out_path)

    print(f"Wrote {json_path}")
    print(f"Note: static observer model only defined for r>2M={toy.horizon_radius():g}.")


if __name__ == "__main__":
    main()
