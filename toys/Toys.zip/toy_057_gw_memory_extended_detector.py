#!/usr/bin/env python3
"""
Toy 057 — GW memory as an extended (nonlocal-in-time) detector observable

What it probes (pressure point):
- A finite detector can register a *permanent* displacement (“memory”) even though local curvature
  becomes ~0 before and after the burst.
- Local-in-time curvature diagnostics can miss integrated/extended effects.
- Operationally, the detector response is an integral over the wave history, not a pointwise scalar.

Model (G=c=1, controlled approximation):
- Linearized GR on Minkowski in TT gauge (plus polarization), wave propagating in +x.
- Evaluate at fixed x=0 (so retarded time u = t - x = t).
- TT strain:
    h_yy(u) = h(u),   h_zz(u) = -h(u), others 0

Memory waveform (smooth step):
    h(u) = (h_mem/2) * (1 + tanh((u - u_c)/tau))
  so h ≈ 0 for u << u_c and h ≈ h_mem for u >> u_c.

Curvature diagnostic (linearized Riemann component relevant for geodesic deviation):
- For this TT wave:
    R_{tyty} = -1/2 * d^2 h_yy / du^2 = -1/2 * h''(u)
  where:
    h'(u)  = (h_mem/2)*(1/tau)*sech^2((u-u_c)/tau)
    h''(u) = -(h_mem/tau^2)*sech^2((u-u_c)/tau)*tanh((u-u_c)/tau)

Detector observable (finite separation L in y):
- Proper separation in TT gauge (to first order):
    L(u) ≈ L0 * (1 + 1/2 * h(u))
- Memory is the *permanent* fractional change:
    ΔL/L0 ≈ (1/2) * h_mem

Exports:
- Time samples u=t with h(u), h'(u), h''(u), R_{tyty}(u), L(u)
- Shows: curvature ~0 at early/late times but ΔL ≠ 0
"""

from __future__ import annotations

import argparse
import json
import math
import os
from typing import Any, Dict, List, Optional


# ----------------------------
# Helpers
# ----------------------------

def py_to_json_name(py_path: str) -> str:
    base = os.path.splitext(os.path.basename(py_path))[0]
    return base + ".json"


def parse_csv_floats(s: str) -> List[float]:
    return [float(x.strip()) for x in s.split(",") if x.strip()]


def require(cond: bool, msg: str) -> None:
    if not cond:
        raise ValueError(msg)


def finite_or_none(x: float) -> Optional[float]:
    return x if math.isfinite(x) else None


def sech(x: float) -> float:
    return 1.0 / math.cosh(x)


# ----------------------------
# Toy 057
# ----------------------------

class Toy057GWMemory:
    toy_id = "057"

    def __init__(
        self,
        *,
        h_mem: float = 1e-3,
        u_c: float = 0.0,
        tau: float = 1.0,
        L0: float = 1.0,
        x0: float = 0.0,
    ) -> None:
        require(tau > 0.0, "tau must be > 0.")
        require(L0 > 0.0, "L0 must be > 0.")
        self.h_mem = float(h_mem)
        self.u_c = float(u_c)
        self.tau = float(tau)
        self.L0 = float(L0)
        self.x0 = float(x0)

    # Retarded time u = t - x (evaluate at x=x0)
    def u(self, t: float) -> float:
        return t - self.x0

    def h(self, u: float) -> float:
        return 0.5 * self.h_mem * (1.0 + math.tanh((u - self.u_c) / self.tau))

    def h_prime(self, u: float) -> float:
        # h'(u) = (h_mem/2)(1/tau) sech^2
        s = sech((u - self.u_c) / self.tau)
        return 0.5 * self.h_mem * (1.0 / self.tau) * (s * s)

    def h_double_prime(self, u: float) -> float:
        # h''(u) = -(h_mem/tau^2) sech^2 * tanh
        w = (u - self.u_c) / self.tau
        s = sech(w)
        return -(self.h_mem / (self.tau * self.tau)) * (s * s) * math.tanh(w)

    def R_ty_ty(self, u: float) -> float:
        # R_{tyty} = -1/2 h''(u)
        return -0.5 * self.h_double_prime(u)

    def detector_separation(self, u: float) -> float:
        # L(u) ≈ L0 (1 + 1/2 h(u)) to first order in h
        return self.L0 * (1.0 + 0.5 * self.h(u))

    def sample_point(self, t: float) -> Dict[str, Any]:
        u = self.u(t)
        h = self.h(u)
        hp = self.h_prime(u)
        hpp = self.h_double_prime(u)
        R = self.R_ty_ty(u)
        L = self.detector_separation(u)

        # Local curvature proxy scalar (not a true invariant, but a local tidal component)
        # You can build invariants too, but memory's point is: curvature is transient.
        return {
            "coordinates": {"t": t, "x": self.x0, "u_retarded": u},
            "curvature_invariants": {
                "linearized_tidal_component_R_ty_ty": finite_or_none(R),
                "linearized_kretschmann_proxy": finite_or_none(8.0 * (R * R)),  # simple proxy ~ R^2 scaling
            },
            "local_observables": {
                "h_yy_TT": finite_or_none(h),
                "dh_du": finite_or_none(hp),
                "d2h_du2": finite_or_none(hpp),
                "detector_separation_L_y": finite_or_none(L),
                "fractional_change_L_over_L0_minus_1": finite_or_none(L / self.L0 - 1.0),
            },
            "causal_structure": {
                "wave_propagation_direction": "+x",
                "note": (
                    "Curvature (tidal component) is localized near the transition, "
                    "but the detector separation retains a permanent offset (memory)."
                ),
            },
        }

    def build_payload(self, t_values: List[float]) -> Dict[str, Any]:
        require(len(t_values) >= 3, "Need at least three time samples.")
        t_values = sorted(t_values)

        sample_points: List[Dict[str, Any]] = [self.sample_point(t) for t in t_values]

        # Memory summary: compare early vs late times (first and last samples)
        t_early = t_values[0]
        t_late = t_values[-1]
        u_early = self.u(t_early)
        u_late = self.u(t_late)

        L_early = self.detector_separation(u_early)
        L_late = self.detector_separation(u_late)
        frac_mem_measured = (L_late - L_early) / self.L0
        frac_mem_expected = 0.5 * (self.h(u_late) - self.h(u_early))  # ≈ 0.5*h_mem if samples bracket the step

        # Curvature transient measure: max |R_ty_ty| over samples
        max_abs_R = 0.0
        for sp in sample_points:
            R = sp["curvature_invariants"]["linearized_tidal_component_R_ty_ty"]
            if R is not None:
                max_abs_R = max(max_abs_R, abs(R))

        return {
            "toy_id": self.toy_id,
            "theory": "General Relativity (linearized; TT gauge) — gravitational-wave memory",
            "spacetime": "Minkowski + TT plane wave with step-like memory (h_final != h_initial)",
            "units": {"G": 1, "c": 1},
            "parameters": {
                "h_mem": self.h_mem,
                "u_c_center": self.u_c,
                "tau_transition": self.tau,
                "detector_initial_separation_L0": self.L0,
                "evaluation_x0": self.x0,
                "t_samples": t_values,
            },
            "notes": {
                "assumptions": [
                    "Linearized gravity on Minkowski background",
                    "TT gauge plus polarization, wave in +x direction",
                    "Memory waveform modeled as smooth tanh step",
                    "Detector is two freely-falling test masses with separation along y",
                    "Uses first-order TT relation L≈L0(1+1/2 h)",
                ],
                "pressure_point": (
                    "Extended detector observables can retain permanent offsets (memory) "
                    "even when local curvature diagnostics return to ~0. "
                    "Pointwise scalars are insufficient to capture integrated physical effects."
                ),
                "key_formulas": {
                    "h_u": "h(u)=(h_mem/2)(1+tanh((u-u_c)/tau))",
                    "R_ty_ty": "R_{tyty} = -1/2 d^2h/du^2",
                    "detector_response": "L(u)≈L0(1+1/2 h(u))",
                    "memory_fractional": "ΔL/L0≈(1/2)(h_final-h_initial)≈h_mem/2",
                },
            },
            "sample_points": sample_points,
            "observables": {
                "memory": {
                    "L_early": finite_or_none(L_early),
                    "L_late": finite_or_none(L_late),
                    "measured_fractional_memory_deltaL_over_L0": finite_or_none(frac_mem_measured),
                    "expected_fractional_memory_from_samples": finite_or_none(frac_mem_expected),
                    "max_abs_R_ty_ty_over_samples": finite_or_none(max_abs_R),
                    "note": (
                        "Choose time samples that bracket the step (u<<u_c and u>>u_c) "
                        "to see ΔL/L0≈h_mem/2 while R_{tyty}→0 at early/late times."
                    ),
                }
            },
        }

    def export_json(self, t_values: List[float], out_path: Optional[str] = None) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)
        payload = self.build_payload(t_values=t_values)
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2, sort_keys=True)
        return out_path


# ----------------------------
# CLI
# ----------------------------

def main() -> None:
    ap = argparse.ArgumentParser(description="Toy 057: GW memory (extended detector observable) in linearized GR.")
    ap.add_argument("--h_mem", type=float, default=1e-3, help="Final-minus-initial strain step size")
    ap.add_argument("--u_c", type=float, default=0.0, help="Center of the transition in retarded time u")
    ap.add_argument("--tau", type=float, default=1.0, help="Transition timescale tau > 0")
    ap.add_argument("--L0", type=float, default=1.0, help="Initial detector separation L0 > 0")
    ap.add_argument("--x0", type=float, default=0.0, help="Evaluation position x0 (u=t-x0)")
    ap.add_argument("--t", type=str, default="-10,-5,-2,-1,0,1,2,5,10",
                    help="Comma-separated coordinate times t (should bracket the step)")
    ap.add_argument("--out", type=str, default="", help="Optional output path")
    args = ap.parse_args()

    t_values = parse_csv_floats(args.t)

    toy = Toy057GWMemory(
        h_mem=float(args.h_mem),
        u_c=float(args.u_c),
        tau=float(args.tau),
        L0=float(args.L0),
        x0=float(args.x0),
    )

    out_path = args.out.strip() or None
    json_path = toy.export_json(t_values=t_values, out_path=out_path)

    print(f"Wrote {json_path}")
    print("Toy 057 complete: GW memory as extended detector observable.")


if __name__ == "__main__":
    main()
