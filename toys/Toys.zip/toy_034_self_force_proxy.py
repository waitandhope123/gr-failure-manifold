#!/usr/bin/env python3
"""
Toy 034 — Gravitational radiation reaction as a self-force proxy (EMRI, circular inspiral around Schwarzschild)

Pressure point / weakness probed:
- "Free-fall = geodesic" is only true in the strict test-mass limit.
- A small body of mass μ orbiting a black hole of mass M emits gravitational waves,
  loses energy, and its orbit shrinks: motion deviates from a geodesic due to self-interaction.
- Full GR self-force is technically hard; this toy implements a controlled leading-order proxy:
    * Exact Schwarzschild circular-orbit energy Ẽ(r) for a test particle
    * Leading-order (quadrupole / Newtonian) GW energy flux P(r)
    * Inspiral rate from energy balance: dr/dt = - P / (dE/dr)

Assumptions:
- Background spacetime: Schwarzschild of mass M (geometric units G=c=1)
- Extreme mass ratio: μ << M (EMRI proxy)
- Quasi-circular inspiral: adiabatic evolution through circular geodesics
- Flux: leading-order quadrupole formula (not full relativistic flux)

Core formulas (G=c=1):
- Horizon: r_h = 2M
- Circular geodesic specific energy:
    Ẽ(r) = (1 - 2M/r) / sqrt(1 - 3M/r)     (valid for r > 3M)
  Total orbital energy: E(r) = μ * Ẽ(r)
- Orbital frequency (Schwarzschild / Kepler):
    Ω(r) = sqrt(M / r^3)
- GW power (quadrupole, circular, EMRI approx):
    P(r) ≈ (32/5) * μ^2 * M^3 / r^5
- Inspiral rate (energy balance):
    dr/dt = - P(r) / (dE/dr)

Export:
- Writes JSON named exactly like this .py file.
- Uses the mandatory schema; undefined quantities are null.
"""

from __future__ import annotations

import argparse
import json
import math
import os
from typing import Any, Dict, List, Optional


# ----------------------------
# Helpers
# ----------------------------

def py_to_json_name(py_path: str) -> str:
    base = os.path.splitext(os.path.basename(py_path))[0]
    return base + ".json"


def require(cond: bool, msg: str) -> None:
    if not cond:
        raise ValueError(msg)


def safe_float(x: float) -> Optional[float]:
    if math.isfinite(x):
        return float(x)
    return None


# ----------------------------
# Schwarzschild orbit + flux
# ----------------------------

def r_horizon(M: float) -> float:
    return 2.0 * M


def ricci_scalar_schw(_: float, __: float) -> float:
    return 0.0


def kretschmann_schw(M: float, r: float) -> Optional[float]:
    if r <= 0.0:
        return None
    return 48.0 * (M * M) / (r ** 6)


def E_tilde_circular(M: float, r: float) -> Optional[float]:
    # Ẽ = (1 - 2M/r)/sqrt(1 - 3M/r), valid for r > 3M
    if r <= 3.0 * M:
        return None
    num = 1.0 - 2.0 * M / r
    den2 = 1.0 - 3.0 * M / r
    if den2 <= 0.0:
        return None
    return num / math.sqrt(den2)


def Omega_circular(M: float, r: float) -> Optional[float]:
    # Ω = sqrt(M/r^3)
    if r <= 0.0:
        return None
    return math.sqrt(M / (r ** 3))


def gw_power_quadrupole(M: float, mu: float, r: float) -> Optional[float]:
    # P ≈ (32/5) μ^2 M^3 / r^5  (EMRI approx; leading order)
    if r <= 0.0:
        return None
    return (32.0 / 5.0) * (mu ** 2) * (M ** 3) / (r ** 5)


def dE_dr_numeric(M: float, mu: float, r: float, h_frac: float = 1e-6) -> Optional[float]:
    """
    Numerical derivative of E(r) = μ Ẽ(r). Use a small fractional step.
    """
    if r <= 3.0 * M:
        return None
    h = max(h_frac * r, 1e-12)
    r1 = r - h
    r2 = r + h
    if r1 <= 3.0 * M:
        r1 = 3.0 * M + 1e-9

    E1t = E_tilde_circular(M, r1)
    E2t = E_tilde_circular(M, r2)
    if E1t is None or E2t is None:
        return None
    E1 = mu * E1t
    E2 = mu * E2t
    return (E2 - E1) / (r2 - r1)


def dr_dt_energy_balance(M: float, mu: float, r: float) -> Optional[float]:
    """
    dr/dt = - P / (dE/dr)
    """
    P = gw_power_quadrupole(M, mu, r)
    dEdr = dE_dr_numeric(M, mu, r)
    if P is None or dEdr is None or dEdr == 0.0:
        return None
    return -P / dEdr


# ----------------------------
# Toy 034 driver
# ----------------------------

class Toy034SelfForceProxy:
    toy_id = "034"

    def __init__(
        self,
        M: float,
        mu: float,
        r0: float,
        t_max: float,
        dt: float,
        r_stop: float,
    ) -> None:
        require(M > 0.0, "M must be > 0")
        require(mu > 0.0, "mu must be > 0")
        require(mu < 0.1 * M, "This toy assumes EMRI-like mu << M; please choose mu < 0.1 M.")
        require(r0 > 3.0 * M, "r0 must be > 3M (circular geodesics exist only for r>3M).")
        require(t_max > 0.0, "t_max must be > 0")
        require(dt > 0.0, "dt must be > 0")
        require(r_stop > 3.0 * M, "r_stop must be > 3M (stop radius must remain in circular regime).")

        self.M = float(M)
        self.mu = float(mu)
        self.r0 = float(r0)
        self.t_max = float(t_max)
        self.dt = float(dt)
        self.r_stop = float(r_stop)

    def build_payload(self) -> Dict[str, Any]:
        M = self.M
        mu = self.mu

        # Integrate r(t) adiabatically using explicit Euler (deterministic)
        t = 0.0
        r = self.r0
        phase = 0.0  # orbital phase ~ ∫Ω dt

        sample_points: List[Dict[str, Any]] = []

        while t <= self.t_max and r > self.r_stop:
            Et = E_tilde_circular(M, r)
            Omega = Omega_circular(M, r)
            P = gw_power_quadrupole(M, mu, r)
            rdot = dr_dt_energy_balance(M, mu, r)

            # Update phase (if Omega is defined)
            if Omega is not None:
                phase += Omega * self.dt

            # Curvature invariants of background at r
            K = kretschmann_schw(M, r)

            # Region label
            rh = r_horizon(M)
            region = "exterior" if r > rh else ("horizon" if r == rh else "interior")

            sample_points.append({
                "coordinates": {
                    "t": t,
                    "r": r,
                    "phase_orbital": phase
                },
                "curvature_invariants": {
                    "ricci_scalar": ricci_scalar_schw(M, r),
                    "kretschmann": K
                },
                "local_observables": {
                    "mu": mu,
                    "M": M,
                    "specific_energy_E_tilde": Et,
                    "orbital_energy_E": (mu * Et) if Et is not None else None,
                    "orbital_frequency_Omega": Omega,
                    "gw_frequency_f_gw": (Omega / math.pi) if Omega is not None else None,  # f_gw ~ 2Ω/(2π)=Ω/π
                    "gw_power_P_quadrupole": P,
                    "dr_dt_from_energy_balance": rdot,
                    "notes": (
                        "Adiabatic inspiral via energy balance: dr/dt = -P/(dE/dr). "
                        "This is a self-force *proxy* (radiation reaction), not a full GR self-force computation."
                    )
                },
                "causal_structure": {
                    "horizon_radius": rh,
                    "region": region,
                    "predictability_warning": None,
                    "energy_warning": (
                        "Radiation reaction is a self-interaction effect: the orbit deviates from a geodesic "
                        "once μ is finite (even if μ << M)."
                    )
                }
            })

            # Step r forward
            if rdot is None:
                # cannot evolve further in this regime
                break
            r_next = r + rdot * self.dt
            # prevent crossing into invalid circular regime by numerical overshoot
            r = max(r_next, self.r_stop)
            t += self.dt

        # Summaries
        payload: Dict[str, Any] = {
            "toy_id": self.toy_id,
            "theory": "General Relativity (radiation reaction / self-force proxy)",
            "spacetime": "Schwarzschild background + GW energy-flux driven inspiral (adiabatic EMRI proxy)",
            "units": {"G": 1, "c": 1},
            "parameters": {
                "M": self.M,
                "mu": self.mu,
                "r0": self.r0,
                "t_max": self.t_max,
                "dt": self.dt,
                "r_stop": self.r_stop
            },
            "notes": {
                "pressure_point": (
                    "Geodesic motion is an approximation. Finite μ produces radiation reaction "
                    "(a self-interaction) that drives inspiral. A fully consistent treatment requires "
                    "self-force/second-order perturbation theory; this toy quantifies the effect in a controlled proxy."
                ),
                "limitations": (
                    "Flux is leading-order quadrupole; dE/dr uses numerical differentiation; "
                    "no conservative self-force component; no strong-field relativistic flux corrections."
                ),
                "definitions_used": {
                    "E_tilde_circular": "Ẽ=(1-2M/r)/sqrt(1-3M/r), r>3M",
                    "Omega_circular": "Ω=sqrt(M/r^3)",
                    "quadrupole_power": "P≈(32/5) μ^2 M^3 / r^5",
                    "energy_balance": "dr/dt = -P / (dE/dr)"
                }
            },
            "sample_points": sample_points,
            "observables": {
                "summary": {
                    "n_steps": len(sample_points),
                    "final_t": sample_points[-1]["coordinates"]["t"] if sample_points else None,
                    "final_r": sample_points[-1]["coordinates"]["r"] if sample_points else None,
                    "final_phase": sample_points[-1]["coordinates"]["phase_orbital"] if sample_points else None,
                    "key_result": (
                        "A finite μ produces a secular inspiral (dr/dt<0) from GW emission; "
                        "the worldline deviates from a circular geodesic sequence in a controlled way."
                    )
                }
            }
        }
        return payload

    def export_json(self, out_path: Optional[str] = None) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)
        payload = self.build_payload()
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2, sort_keys=True)
        return out_path


def main() -> None:
    ap = argparse.ArgumentParser(description="Toy 034: Radiation reaction as a self-force proxy (EMRI inspiral).")
    ap.add_argument("--M", type=float, default=1.0, help="Central BH mass M > 0")
    ap.add_argument("--mu", type=float, default=1e-3, help="Small body mass mu (assume mu << M)")
    ap.add_argument("--r0", type=float, default=20.0, help="Initial radius r0 > 3M")
    ap.add_argument("--tmax", type=float, default=5e6, help="Max integration time")
    ap.add_argument("--dt", type=float, default=5e4, help="Time step for adiabatic evolution")
    ap.add_argument("--rstop", type=float, default=6.0, help="Stop radius (>3M). Default 6M (ISCO scale).")
    ap.add_argument("--out", type=str, default="", help="Optional output path; default is <script>.json")
    args = ap.parse_args()

    toy = Toy034SelfForceProxy(
        M=float(args.M),
        mu=float(args.mu),
        r0=float(args.r0),
        t_max=float(args.tmax),
        dt=float(args.dt),
        r_stop=float(args.rstop),
    )
    out_path = args.out.strip() or None
    json_path = toy.export_json(out_path=out_path)
    print(f"Wrote {json_path}")
    print("Notes:")
    print("- This toy is an adiabatic self-force proxy using quadrupole GW flux + exact circular-orbit energy.")


if __name__ == "__main__":
    main()
