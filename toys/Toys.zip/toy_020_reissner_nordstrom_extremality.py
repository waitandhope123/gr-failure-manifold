#!/usr/bin/env python3
"""
Toy 020 — Reissner–Nordström: charge, extremality, and inner horizon (Cauchy horizon)

What it probes (pressure point):
- RN (electrovac) introduces qualitatively new causal structure vs Schwarzschild:
  * Outer event horizon r_+
  * Inner (Cauchy) horizon r_- (global predictability issue)
  * Extremal limit |Q|=M where horizons merge and surface gravity -> 0
  * Naked singularity regime |Q|>M (cosmic censorship stress test)
- Separates coordinate artifacts from invariant behavior by exporting curvature scalars and horizon diagnostics.

Model / assumptions:
- Spherical symmetry, static electrovac solution (Einstein–Maxwell).
- Metric in Schwarzschild-like coordinates:
    ds^2 = -f(r) dt^2 + f(r)^{-1} dr^2 + r^2 dΩ^2
    f(r) = 1 - 2M/r + Q^2/r^2
- Geometric units G=c=1.
- Maxwell field (pure electric): E_r = Q/r^2.

Useful diagnostics:
- Horizons (if |Q|<=M):
    r_± = M ± sqrt(M^2 - Q^2)
- Surface gravity at outer horizon:
    κ_+ = (r_+ - r_-)/(2 r_+^2)   (->0 as |Q|->M)
- Electric potential at horizon:
    Φ_H = Q / r_+
- Radial null coordinate slope:
    dr/dt = ± f(r)  (in these coordinates)
- Ricci scalar R = 0 for electrovac (trace-free).
- Kretschmann scalar (RN):
    K = 48 M^2 / r^6 - 96 M Q^2 / r^7 + 56 Q^4 / r^8

Energy-condition / matter content (Maxwell):
- Local electric field magnitude: |E| = |Q|/r^2
- Maxwell invariant: I1 = F_ab F^ab = -2 Q^2 / r^4  (pure electric; sign from metric)
- EM energy density for static observer: ρ_em = Q^2 / (8π r^4)

STRICT EXPORT RULE:
- Writes JSON named exactly like this .py file (toy_020_reissner_nordstrom_extremality.json).
- JSON follows the canonical schema with required keys and required subkeys.
- Undefined quantities are exported as null (JSON null).
"""

from __future__ import annotations

import argparse
import json
import math
import os
from typing import Any, Dict, List, Optional


# ----------------------------
# Helpers
# ----------------------------

def py_to_json_name(py_path: str) -> str:
    base = os.path.splitext(os.path.basename(py_path))[0]
    return base + ".json"


def parse_csv_floats(s: str) -> List[float]:
    return [float(x.strip()) for x in s.split(",") if x.strip()]


def require(cond: bool, msg: str) -> None:
    if not cond:
        raise ValueError(msg)


# ----------------------------
# Toy 020
# ----------------------------

class Toy020ReissnerNordstromExtremality:
    toy_id = "020"

    def __init__(self, M: float = 1.0, Q: float = 0.6) -> None:
        require(M > 0.0, "M must be > 0.")
        self.M = float(M)
        self.Q = float(Q)

    def f(self, r: float) -> float:
        require(r > 0.0, "r must be > 0.")
        return 1.0 - 2.0 * self.M / r + (self.Q * self.Q) / (r * r)

    def is_black_hole(self) -> bool:
        return abs(self.Q) <= self.M

    def kind(self) -> str:
        disc = self.M * self.M - self.Q * self.Q
        if disc < 0.0:
            return "naked_singularity (|Q|>M)"
        if abs(disc) < 1e-15:
            return "extremal (|Q|=M)"
        return "subextremal (|Q|<M)"

    def horizons(self) -> Dict[str, Optional[float]]:
        disc = self.M * self.M - self.Q * self.Q
        if disc < 0.0:
            return {"r_plus": None, "r_minus": None}
        root = math.sqrt(disc)
        return {"r_plus": self.M + root, "r_minus": self.M - root}

    # Curvature invariants (electrovac):
    def ricci_scalar(self) -> float:
        return 0.0

    def kretschmann(self, r: float) -> float:
        # RN Kretschmann:
        # K = 48 M^2 / r^6 - 96 M Q^2 / r^7 + 56 Q^4 / r^8
        require(r > 0.0, "r must be > 0.")
        M = self.M
        Q2 = self.Q * self.Q
        r2 = r * r
        r6 = r2 * r2 * r2
        r7 = r6 * r
        r8 = r7 * r
        return 48.0 * (M * M) / r6 - 96.0 * M * Q2 / r7 + 56.0 * (Q2 * Q2) / r8

    # Maxwell field diagnostics:
    def E_r(self, r: float) -> float:
        require(r > 0.0, "r must be > 0.")
        return self.Q / (r * r)

    def maxwell_invariant_F2(self, r: float) -> float:
        # For pure electric in signature (-,+,+,+): F_ab F^ab = -2 E^2 = -2 Q^2 / r^4
        require(r > 0.0, "r must be > 0.")
        Q2 = self.Q * self.Q
        r4 = (r * r) * (r * r)
        return -2.0 * Q2 / r4

    def rho_em_static(self, r: float) -> float:
        # Energy density measured by static observer: ρ = E^2/(8π) = Q^2/(8π r^4)
        require(r > 0.0, "r must be > 0.")
        Q2 = self.Q * self.Q
        r4 = (r * r) * (r * r)
        return Q2 / (8.0 * math.pi * r4)

    # Horizon mechanics:
    def surface_gravity_kappa_plus(self) -> Optional[float]:
        hz = self.horizons()
        rp = hz["r_plus"]
        rm = hz["r_minus"]
        if rp is None or rm is None:
            return None
        denom = 2.0 * rp * rp
        if denom == 0.0:
            return None
        return (rp - rm) / denom

    def horizon_potential_PhiH(self) -> Optional[float]:
        hz = self.horizons()
        rp = hz["r_plus"]
        if rp is None:
            return None
        if rp == 0.0:
            return None
        return self.Q / rp

    def region_label(self, r: float) -> str:
        hz = self.horizons()
        rp = hz["r_plus"]
        rm = hz["r_minus"]
        if rp is None or rm is None:
            return "no_horizon_regime (|Q|>M)"
        if r > rp:
            return "exterior (r>r_plus)"
        if abs(r - rp) < 1e-12:
            return "outer_horizon (r=r_plus)"
        if r > rm:
            return "between_horizons (r_minus<r<r_plus)"
        if abs(r - rm) < 1e-12:
            return "inner_horizon (r=r_minus)"
        return "interior (r<r_minus)"

    def radial_null_cone_dr_dt(self, r: float) -> Dict[str, Optional[float]]:
        # In Schwarzschild-like coordinates: dr/dt = ± f(r)
        fr = self.f(r)
        return {"outgoing": fr, "ingoing": -fr, "note": "Coordinate slope; degenerates at horizons where f=0."}

    def build_payload(self, r_values: List[float]) -> Dict[str, Any]:
        sample_points: List[Dict[str, Any]] = []

        hz = self.horizons()
        rp = hz["r_plus"]
        rm = hz["r_minus"]

        for r in r_values:
            r = float(r)
            require(r > 0.0, "All radii must be > 0.")

            fr = self.f(r)
            K = self.kretschmann(r)

            coordinates = {"t": None, "r": r, "theta": None, "phi": None}

            curvature_invariants = {
                "ricci_scalar": self.ricci_scalar(),
                "kretschmann": K,
            }

            local_observables = {
                "metric_function": {
                    "f(r)": fr,
                    "f_definition": "f=1-2M/r+Q^2/r^2",
                },
                "electromagnetism": {
                    "Q": self.Q,
                    "E_r": self.E_r(r),
                    "F_abF^ab": self.maxwell_invariant_F2(r),
                    "rho_em_static": self.rho_em_static(r),
                    "notes": "Pure electric field; sign of F^2 indicates electric-dominated field in (-,+,+,+).",
                },
                "horizon_structure": {
                    "kind": self.kind(),
                    "r_plus": rp,
                    "r_minus": rm,
                    "surface_gravity_kappa_plus": self.surface_gravity_kappa_plus(),
                    "horizon_potential_PhiH": self.horizon_potential_PhiH(),
                    "extremality_discriminant_M2_minus_Q2": (self.M * self.M - self.Q * self.Q),
                },
            }

            causal_structure = {
                "region": self.region_label(r),
                "radial_null_cone_dr_dt": self.radial_null_cone_dr_dt(r),
                "notes": {
                    "inner_horizon": "RN has an inner (Cauchy) horizon r_- (if |Q|<M), linked to predictability issues.",
                    "extremal_limit": "At |Q|=M: r_+=r_-=M and kappa_+ -> 0.",
                    "naked_singularity": "If |Q|>M: no horizons; curvature singularity at r=0 is exposed.",
                },
            }

            sample_points.append({
                "coordinates": coordinates,
                "curvature_invariants": curvature_invariants,
                "local_observables": local_observables,
                "causal_structure": causal_structure,
            })

        payload: Dict[str, Any] = {
            "toy_id": self.toy_id,
            "theory": "General Relativity (Einstein–Maxwell electrovac)",
            "spacetime": "Reissner–Nordström: horizons, extremality, and inner (Cauchy) horizon",
            "units": {"G": 1, "c": 1},
            "parameters": {
                "M": self.M,
                "Q": self.Q,
            },
            "notes": {
                "pressure_point": (
                    "Adding charge introduces a second (inner) horizon and an extremal boundary. "
                    "The |Q|>M regime removes horizons entirely (cosmic censorship stress test)."
                ),
                "key_formulas": {
                    "f": "f(r)=1-2M/r+Q^2/r^2",
                    "horizons": "r_±=M±sqrt(M^2-Q^2) (if |Q|<=M)",
                    "kappa_plus": "κ_+=(r_+-r_-)/(2 r_+^2)",
                    "PhiH": "Φ_H=Q/r_+",
                    "kretschmann": "K=48M^2/r^6 - 96MQ^2/r^7 + 56Q^4/r^8",
                    "radial_null": "dr/dt=±f(r) (coordinate slope)",
                    "E_field": "E_r=Q/r^2; ρ_em=Q^2/(8π r^4); F^2=-2Q^2/r^4",
                },
                "domain_of_validity": (
                    "Exact RN electrovac. Coordinate diagnostics use Schwarzschild-like coordinates; "
                    "global extensions across horizons not constructed here."
                ),
            },
            "sample_points": sample_points,
            "observables": {
                "horizons": {
                    "kind": self.kind(),
                    "r_plus": rp,
                    "r_minus": rm,
                    "surface_gravity_kappa_plus": self.surface_gravity_kappa_plus(),
                    "horizon_potential_PhiH": self.horizon_potential_PhiH(),
                }
            },
        }
        return payload

    def export_json(self, r_values: List[float], out_path: Optional[str] = None) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)
        payload = self.build_payload(r_values=r_values)
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2, sort_keys=True)
        return out_path


# ----------------------------
# CLI
# ----------------------------

def main() -> None:
    ap = argparse.ArgumentParser(description="Toy 020: Reissner–Nordström extremality + inner horizon exporter.")
    ap.add_argument("--M", type=float, default=1.0, help="Mass parameter M (>0)")
    ap.add_argument("--Q", type=float, default=0.6, help="Charge parameter Q (can be >M to show naked regime)")
    ap.add_argument(
        "--r",
        type=str,
        default="0.6,0.8,1.0,1.2,1.5,2.0,3.0,5.0,10.0",
        help="Comma-separated radii r to sample (avoid r=0)",
    )
    ap.add_argument("--out", type=str, default="", help="Optional output path; default is <script>.json")
    args = ap.parse_args()

    toy = Toy020ReissnerNordstromExtremality(M=float(args.M), Q=float(args.Q))
    r_values = parse_csv_floats(args.r)

    out_path = args.out.strip() or None
    json_path = toy.export_json(r_values=r_values, out_path=out_path)

    hz = toy.horizons()
    print(f"Wrote {json_path}")
    print(f"RN kind: {toy.kind()}; M={toy.M:g}, Q={toy.Q:g}, M^2-Q^2={toy.M*toy.M - toy.Q*toy.Q:g}")
    print(f"Horizons: r_+={hz['r_plus']}, r_-={hz['r_minus']}")
    print(f"kappa_+={toy.surface_gravity_kappa_plus()}, Phi_H={toy.horizon_potential_PhiH()}")


if __name__ == "__main__":
    main()
