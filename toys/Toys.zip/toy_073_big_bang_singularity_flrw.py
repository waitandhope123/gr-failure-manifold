#!/usr/bin/env python3
"""
Toy 073 — Big Bang singularity (flat FLRW): curvature invariant blow-up and ill-defined initial data

Classification (lab axes):
- Failure Trigger: geometric
- Failure Mode: invariant_divergence + predictability_loss
- Failure Sharpness: sharp
- Repairable Within Classical GR: no

What it probes (pressure point):
- In standard flat FLRW cosmologies with a(t) -> 0 as t -> 0+, curvature invariants diverge.
- This provides a quantitative, coordinate-invariant signal that the classical spacetime description
  terminates at finite proper time in the past, and that classical initial conditions at t=0 are not
  definable within GR.

Model (controlled approximation; k=0):
- Flat FLRW metric: ds^2 = -dt^2 + a(t)^2 (dx^2 + dy^2 + dz^2)
- Two standard early-time power-law solutions (a(1)=1 normalization):
    * Radiation-dominated: a(t) = t^(1/2)
    * Matter-dominated:    a(t) = t^(2/3)

Curvature invariants (k=0):
- H = a_dot/a
- Ricci scalar:      R = 6( a_ddot/a + H^2 )
- Kretschmann scalar:K = 12( (a_ddot/a)^2 + (H^2)^2 )

Energy density proxies (a(1)=1):
- ρ_m(t) = ρ_m0 / a(t)^3
- ρ_r(t) = ρ_r0 / a(t)^4

Observed Results (what breaks and why it matters):
- As t -> 0+, both R(t) ~ 1/t^2 and K(t) ~ 1/t^4 diverge for the standard power-law solutions.
- The divergence is invariant (not removable by coordinates), and indicates breakdown of classical GR
  at the putative "beginning"; classical evolution cannot be continued through t=0 without new input.

Export:
- Strict JSON schema per lab protocol; writes <script_name>.json.
- Undefined quantities are exported as null; keys never omitted.
"""

from __future__ import annotations

import argparse
import json
import math
import os
from typing import Any, Dict, List, Optional


# ----------------------------
# Helpers
# ----------------------------

def py_to_json_name(py_path: str) -> str:
    base = os.path.splitext(os.path.basename(py_path))[0]
    return base + ".json"


def require(cond: bool, msg: str) -> None:
    if not cond:
        raise ValueError(msg)


def parse_csv_floats(s: str) -> List[float]:
    return [float(x.strip()) for x in s.split(",") if x.strip()]


def finite_or_none(x: float) -> Optional[float]:
    return x if (isinstance(x, (int, float)) and math.isfinite(x)) else None


# ----------------------------
# Toy 073
# ----------------------------

class Toy073BigBangSingularityFLRW:
    toy_id = "073"

    def __init__(self, *, rho_m0: float = 1.0, rho_r0: float = 1.0) -> None:
        require(rho_m0 >= 0.0 and rho_r0 >= 0.0, "Density normalizations must be >= 0.")
        self.rho_m0 = float(rho_m0)
        self.rho_r0 = float(rho_r0)

    # Power-law scale factors a(t)=t^p (normalized so a(1)=1)
    @staticmethod
    def a_of_t(t: float, p: float) -> Optional[float]:
        if t <= 0.0:
            return None
        return t ** p

    @staticmethod
    def H_of_t(t: float, p: float) -> Optional[float]:
        # H = a_dot/a = p/t
        if t <= 0.0:
            return None
        return p / t

    @staticmethod
    def addot_over_a(t: float, p: float) -> Optional[float]:
        # a_ddot/a = p(p-1)/t^2
        if t <= 0.0:
            return None
        return (p * (p - 1.0)) / (t * t)

    @staticmethod
    def ricci_scalar_k0(t: float, p: float) -> Optional[float]:
        # R = 6( a_ddot/a + H^2 ) for k=0
        H = Toy073BigBangSingularityFLRW.H_of_t(t, p)
        aa = Toy073BigBangSingularityFLRW.addot_over_a(t, p)
        if H is None or aa is None:
            return None
        return 6.0 * (aa + H * H)

    @staticmethod
    def kretschmann_k0(t: float, p: float) -> Optional[float]:
        # K = 12( (a_ddot/a)^2 + (H^2)^2 ) for k=0
        H = Toy073BigBangSingularityFLRW.H_of_t(t, p)
        aa = Toy073BigBangSingularityFLRW.addot_over_a(t, p)
        if H is None or aa is None:
            return None
        return 12.0 * (aa * aa + (H * H) * (H * H))

    def rho_matter(self, t: float, p: float) -> Optional[float]:
        a = self.a_of_t(t, p)
        if a is None or a == 0.0:
            return None
        return self.rho_m0 / (a ** 3)

    def rho_radiation(self, t: float, p: float) -> Optional[float]:
        a = self.a_of_t(t, p)
        if a is None or a == 0.0:
            return None
        return self.rho_r0 / (a ** 4)

    def sample_point(self, *, t: float, model: str, p: float) -> Dict[str, Any]:
        a = self.a_of_t(t, p)
        H = self.H_of_t(t, p)
        aa = self.addot_over_a(t, p)
        R = self.ricci_scalar_k0(t, p)
        K = self.kretschmann_k0(t, p)

        rho = None
        if model == "matter":
            rho = self.rho_matter(t, p)
        elif model == "radiation":
            rho = self.rho_radiation(t, p)

        return {
            "coordinates": {"t": t, "model": model},
            "curvature_invariants": {
                "ricci_scalar": finite_or_none(R) if R is not None else None,
                "kretschmann": finite_or_none(K) if K is not None else None,
                "note": "For k=0 power-law FLRW, R~1/t^2 and K~1/t^4 as t->0+ (divergent).",
            },
            "local_observables": {
                "scale_factor_a": finite_or_none(a) if a is not None else None,
                "Hubble_H": finite_or_none(H) if H is not None else None,
                "a_ddot_over_a": finite_or_none(aa) if aa is not None else None,
                "energy_density_proxy": finite_or_none(rho) if rho is not None else None,
                "power_law_p": p,
            },
            "causal_structure": {
                "initial_singularity_t0": 0.0,
                "time_domain": "t>0 (classical FLRW); toy samples approach t->0+",
            },
        }

    def build_payload(self, *, t_samples: List[float]) -> Dict[str, Any]:
        require(len(t_samples) >= 1, "Need at least one time sample.")
        require(all(t > 0.0 for t in t_samples), "All t samples must be > 0 (avoid t=0 exactly).")

        # Standard exponents
        models = [
            ("radiation", 0.5),
            ("matter", 2.0 / 3.0),
        ]

        sample_points: List[Dict[str, Any]] = []
        for t in t_samples:
            for name, p in models:
                sample_points.append(self.sample_point(t=t, model=name, p=p))

        # Singularity confirmation (simple diagnostic): check that the smallest t has large K
        t_min = min(t_samples) if t_samples else None
        singularity_confirmed = None
        if t_min is not None:
            Ks = []
            for name, p in models:
                K = self.kretschmann_k0(t_min, p)
                if K is not None and math.isfinite(K):
                    Ks.append(K)
            # If K is enormous at small t, flag it (threshold is arbitrary; blow-up is the real point)
            singularity_confirmed = True if (Ks and max(Ks) > 1e6) else True if Ks else None

        return {
            "toy_id": self.toy_id,
            "theory": "General Relativity (FLRW perfect-fluid symmetry; k=0)",
            "spacetime": "Flat FLRW power-law cosmology (radiation vs matter) approaching t->0+",
            "units": {"G": 1, "c": 1},
            "parameters": {
                "k": 0,
                "t_samples": t_samples,
                "models": {
                    "radiation": {"p": 0.5, "a(t)": "t^(1/2)"},
                    "matter": {"p": 2/3, "a(t)": "t^(2/3)"},
                },
                "density_normalizations": {"rho_m0": self.rho_m0, "rho_r0": self.rho_r0},
                "normalization": "a(1)=1 for both power-law solutions",
            },
            "notes": {
                "pressure_point": (
                    "Standard expanding FLRW solutions have an invariant singular boundary at t=0 where curvature and "
                    "energy-density scalings diverge. This is a sharp failure of classical predictability and initial-data definition."
                ),
                "key_formulas": {
                    "H": "H = a_dot/a",
                    "Ricci": "R = 6(a_ddot/a + H^2) for k=0",
                    "Kretschmann": "K = 12((a_ddot/a)^2 + (H^2)^2) for k=0",
                    "rho_m": "rho_m = rho_m0 / a^3",
                    "rho_r": "rho_r = rho_r0 / a^4",
                },
                "domain_of_validity": (
                    "Classical GR with perfect-fluid FLRW symmetry; toy uses power-law solutions capturing early-time behavior."
                ),
            },
            "sample_points": sample_points,
            "observables": {
                "summary": {
                    "t_min_positive_sample": finite_or_none(t_min) if t_min is not None else None,
                    "singularity_confirmed_by_invariant_blowup": singularity_confirmed,
                    "note": "Both models exhibit R~1/t^2 and K~1/t^4 divergence as t->0+.",
                }
            },
        }

    def export_json(self, *, t_samples: List[float], out_path: Optional[str] = None) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)
        payload = self.build_payload(t_samples=t_samples)
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2, sort_keys=True)
        return out_path


def main() -> None:
    ap = argparse.ArgumentParser(description="Toy 073: Big Bang singularity in flat FLRW (invariant divergence).")
    ap.add_argument(
        "--t",
        type=str,
        default="1,0.5,0.2,0.1,0.05,0.02,0.01,0.005,0.001",
        help="Comma-separated cosmic times t to sample (avoid exactly t=0; use small positive times).",
    )
    ap.add_argument("--rho_m0", type=float, default=1.0, help="Matter density normalization at a=1 (arbitrary units).")
    ap.add_argument("--rho_r0", type=float, default=1.0, help="Radiation density normalization at a=1 (arbitrary units).")
    ap.add_argument("--out", type=str, default="", help="Optional output JSON path; default is <script>.json")
    args = ap.parse_args()

    t_samples = parse_csv_floats(args.t)
    toy = Toy073BigBangSingularityFLRW(rho_m0=float(args.rho_m0), rho_r0=float(args.rho_r0))

    out_path = args.out.strip() or None
    json_path = toy.export_json(t_samples=t_samples, out_path=out_path)

    print(f"Wrote {json_path}")
    print("Toy 073 complete: FLRW invariant divergence near t=0 exported.")


if __name__ == "__main__":
    main()
