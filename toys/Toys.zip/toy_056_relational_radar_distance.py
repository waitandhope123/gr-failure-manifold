#!/usr/bin/env python3
"""
Toy 056 — Relational distance via radar ranging (operational “distance” is observer- and gauge-dependent)

What it probes (pressure point):
- “Distance” is not a scalar property of spacetime; it is an operational construction.
- Even in the same spacetime, different observer families and protocols produce different
  distances (and can disagree with naive coordinate separations).
- This toy exports an operational radar distance for a static observer in Schwarzschild
  and contrasts it with proper spatial distance on a Schwarzschild t=const slice.

Model (G=c=1):
- Spacetime: Schwarzschild exterior (r > 2M), static observers at fixed r.
- Two operational notions between radii r1 and r2 (r2 > r1 > 2M):
  (A) Radar ranging (static observer at r1 sends light to r2 and back, measures proper time Δτ):
      For radial null geodesics in Schwarzschild:
        dt/dr = ± 1/(1 - 2M/r)
      Coordinate round-trip time:
        Δt_round = 2 ∫_{r1}^{r2} dr / (1 - 2M/r)
                  = 2[(r2 - r1) + 2M ln((r2-2M)/(r1-2M))]
      Proper time for static observer at r1:
        Δτ = sqrt(1 - 2M/r1) * Δt_round
      Radar distance:
        D_radar = Δτ / 2

  (B) Proper spatial distance on Schwarzschild t=const slice:
      dl = dr / sqrt(1 - 2M/r)
      D_slice = ∫_{r1}^{r2} dr / sqrt(1 - 2M/r)
              = [ sqrt(r(r-2M)) + 2M ln( sqrt(r) + sqrt(r-2M) ) ]_{r1}^{r2}

Exports:
- For each (r1, r2): D_radar, D_slice, coordinate separation Δr
- Also redshift factor at r1 and log divergence near horizon

Pressure point:
- Operational observables depend on observer choice and protocol; “distance” is not unique.
"""

from __future__ import annotations

import argparse
import itertools
import json
import math
import os
from typing import Any, Dict, List, Optional, Tuple


# ----------------------------
# Helpers
# ----------------------------

def py_to_json_name(py_path: str) -> str:
    base = os.path.splitext(os.path.basename(py_path))[0]
    return base + ".json"


def parse_csv_floats(s: str) -> List[float]:
    return [float(x.strip()) for x in s.split(",") if x.strip()]


def require(cond: bool, msg: str) -> None:
    if not cond:
        raise ValueError(msg)


def finite_or_none(x: float) -> Optional[float]:
    return x if math.isfinite(x) else None


# ----------------------------
# Toy 056
# ----------------------------

class Toy056RelationalRadarDistance:
    toy_id = "056"

    def __init__(self, *, M: float = 1.0) -> None:
        require(M > 0.0, "M must be > 0.")
        self.M = float(M)

    def f(self, r: float) -> float:
        return 1.0 - 2.0 * self.M / r

    def horizon(self) -> float:
        return 2.0 * self.M

    # Radar: coordinate round-trip time
    def delta_t_round(self, r1: float, r2: float) -> Optional[float]:
        if r2 <= r1 or r1 <= self.horizon():
            return None
        # Δt_round = 2[(r2-r1)+2M ln((r2-2M)/(r1-2M))]
        try:
            return 2.0 * ((r2 - r1) + 2.0 * self.M * math.log((r2 - 2.0 * self.M) / (r1 - 2.0 * self.M)))
        except ValueError:
            return None

    def radar_distance(self, r1: float, r2: float) -> Optional[float]:
        dt = self.delta_t_round(r1, r2)
        if dt is None:
            return None
        f1 = self.f(r1)
        if f1 <= 0.0:
            return None
        d_tau = math.sqrt(f1) * dt
        return 0.5 * d_tau

    # Proper distance on t=const slice
    def slice_distance(self, r1: float, r2: float) -> Optional[float]:
        if r2 <= r1 or r1 <= self.horizon():
            return None

        def F(r: float) -> float:
            # F(r) = sqrt(r(r-2M)) + 2M ln( sqrt(r) + sqrt(r-2M) )
            if r <= 2.0 * self.M:
                return float("nan")
            a = math.sqrt(r * (r - 2.0 * self.M))
            b = 2.0 * self.M * math.log(math.sqrt(r) + math.sqrt(r - 2.0 * self.M))
            return a + b

        v = F(r2) - F(r1)
        return finite_or_none(v)

    def sample_point(self, r1: float, r2: float) -> Dict[str, Any]:
        dr = r2 - r1
        dt_round = self.delta_t_round(r1, r2)
        D_radar = self.radar_distance(r1, r2)
        D_slice = self.slice_distance(r1, r2)

        f1 = self.f(r1)
        redshift_factor = math.sqrt(f1) if f1 > 0.0 else None
        z_inf_from_r1 = (1.0 / math.sqrt(f1) - 1.0) if f1 > 0.0 else None

        # Curvature invariants of Schwarzschild
        K1 = 48.0 * self.M**2 / (r1**6) if r1 > 0.0 else None
        K2 = 48.0 * self.M**2 / (r2**6) if r2 > 0.0 else None

        ratio_radar_to_slice = (D_radar / D_slice) if (D_radar is not None and D_slice not in (None, 0.0)) else None

        return {
            "coordinates": {"r1": r1, "r2": r2},
            "curvature_invariants": {
                "kretschmann_at_r1": finite_or_none(K1) if K1 is not None else None,
                "kretschmann_at_r2": finite_or_none(K2) if K2 is not None else None,
            },
            "local_observables": {
                "delta_r_coordinate": finite_or_none(dr),
                "delta_t_round_trip_coordinate": finite_or_none(dt_round) if dt_round is not None else None,
                "redshift_factor_sqrt_1_minus_2M_over_r1": finite_or_none(redshift_factor) if redshift_factor is not None else None,
                "gravitational_redshift_z_inf_from_r1": finite_or_none(z_inf_from_r1) if z_inf_from_r1 is not None else None,
                "distance_radar_static_observer_at_r1": finite_or_none(D_radar) if D_radar is not None else None,
                "distance_slice_t_const": finite_or_none(D_slice) if D_slice is not None else None,
                "ratio_radar_over_slice": finite_or_none(ratio_radar_to_slice) if ratio_radar_to_slice is not None else None,
            },
            "causal_structure": {
                "horizon_radius_2M": self.horizon(),
                "valid_domain": (r1 > self.horizon() and r2 > r1),
                "note": (
                    "Radar distance uses a clock at r1 and null travel time; slice distance uses a chosen foliation. "
                    "They disagree and both diverge as r1 approaches 2M."
                ),
            },
        }

    def build_payload(self, r1_values: List[float], r2_values: List[float]) -> Dict[str, Any]:
        require(len(r1_values) >= 1 and len(r2_values) >= 1, "Need r1 and r2 samples.")

        sample_points: List[Dict[str, Any]] = []
        invalid = 0
        for r1, r2 in itertools.product(r1_values, r2_values):
            sp = self.sample_point(float(r1), float(r2))
            if not sp["causal_structure"]["valid_domain"]:
                invalid += 1
            sample_points.append(sp)

        # Summary: pick a representative pair if possible
        rep = None
        for sp in sample_points:
            if sp["causal_structure"]["valid_domain"]:
                rep = sp
                break

        return {
            "toy_id": self.toy_id,
            "theory": "General Relativity (operational observables)",
            "spacetime": "Schwarzschild exterior (radar ranging vs slice distance)",
            "units": {"G": 1, "c": 1},
            "parameters": {
                "M": self.M,
                "r1_samples": r1_values,
                "r2_samples": r2_values,
            },
            "notes": {
                "assumptions": [
                    "Static observers at fixed Schwarzschild r",
                    "Radar ranging uses null signals and proper time at r1",
                    "Slice distance uses Schwarzschild t=const foliation",
                    "Exterior domain only (r>2M)",
                ],
                "pressure_point": (
                    "‘Distance’ is not unique in GR. It depends on observer choice and operational protocol. "
                    "Coordinate separations are not observables, and even operational notions differ."
                ),
                "key_formulas": {
                    "delta_t_round": "Δt_round=2[(r2-r1)+2M ln((r2-2M)/(r1-2M))]",
                    "D_radar": "D_radar = (1/2) sqrt(1-2M/r1) * Δt_round",
                    "D_slice": "∫ dr/sqrt(1-2M/r) = [sqrt(r(r-2M))+2M ln(sqrt(r)+sqrt(r-2M))]_{r1}^{r2}",
                },
            },
            "sample_points": sample_points,
            "observables": {
                "summary": {
                    "invalid_pairs_count": invalid,
                    "representative_valid_pair": rep,
                    "note": "Both operational distances diverge as r1→2M+, but with different scaling/meaning.",
                }
            },
        }

    def export_json(self, r1_values: List[float], r2_values: List[float], out_path: Optional[str] = None) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)
        payload = self.build_payload(r1_values=r1_values, r2_values=r2_values)
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2, sort_keys=True)
        return out_path


# ----------------------------
# CLI
# ----------------------------

def main() -> None:
    ap = argparse.ArgumentParser(description="Toy 056: radar distance vs slice distance in Schwarzschild.")
    ap.add_argument("--M", type=float, default=1.0, help="Schwarzschild mass M")
    ap.add_argument("--r1", type=str, default="2.2,2.5,3,4,6,10", help="Comma-separated r1 (observer radius), must be >2M")
    ap.add_argument("--r2", type=str, default="3,4,6,10,20", help="Comma-separated r2 (target radius), must satisfy r2>r1")
    ap.add_argument("--out", type=str, default="", help="Optional output path")
    args = ap.parse_args()

    r1_values = parse_csv_floats(args.r1)
    r2_values = parse_csv_floats(args.r2)

    toy = Toy056RelationalRadarDistance(M=float(args.M))
    out_path = args.out.strip() or None
    json_path = toy.export_json(r1_values=r1_values, r2_values=r2_values, out_path=out_path)

    print(f"Wrote {json_path}")
    print("Toy 056 complete: relational radar distance vs slice distance.")


if __name__ == "__main__":
    main()
