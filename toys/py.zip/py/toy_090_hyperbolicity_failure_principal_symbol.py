#!/usr/bin/env python3
"""
Toy 090 — Hyperbolicity / well-posedness failure (principal symbol diagnostic)

What it probes (pressure point):
- Some GR formulations/gauge choices can lose strong hyperbolicity.
- This is a PDE-level failure mode: even with smooth initial data, the IVP can be ill-posed
  (unbounded growth of high-frequency modes) or only weakly hyperbolic (non-diagonalizable symbol).

Minimal proxy:
- 1D first-order linear system: U_t + A(p) U_x = 0
- Fourier mode U ~ exp(i k x) gives U_t = - i k A(p) U
  -> well-posedness hinges on eigen-structure of A(p) (principal symbol).
- Choose a one-parameter family with three regimes:
    p > 0  : strongly hyperbolic (real, distinct eigenvalues; diagonalizable)
    p = 0  : weakly hyperbolic (repeated eigenvalue with defective eigenvectors)
    p < 0  : elliptic/ill-posed (complex eigenvalues -> exponential growth ∝ |k|)

Matrix family:
  A(p) = [[1, 1],
          [p, 1]]
Eigenvalues:
  λ = 1 ± sqrt(p)
- For p<0, sqrt(p)= i sqrt(|p|) -> complex conjugate pair.

Export:
- For each (p,k) sample:
  - eigenvalues
  - diagonalizable flag
  - growth_rate_high_k_proxy = |k| * max(|Im(λ)|)
  - well_posed_ivp flag (strongly hyperbolic only)
- Curvature fields are null by design.

STRICT EXPORT RULE:
- Writes JSON named exactly like this .py file.
- JSON follows canonical schema; undefined quantities are null.
"""

from __future__ import annotations

import argparse
import json
import math
import os
from typing import Any, Dict, List, Optional, Tuple


# ----------------------------
# Helpers
# ----------------------------

def py_to_json_name(py_path: str) -> str:
    base = os.path.splitext(os.path.basename(py_path))[0]
    return base + ".json"


def parse_csv_floats(s: str) -> List[float]:
    return [float(x.strip()) for x in s.split(",") if x.strip()]


def require(cond: bool, msg: str) -> None:
    if not cond:
        raise ValueError(msg)


def complex_sqrt_p(p: float) -> complex:
    # principal sqrt: for p>=0 real; for p<0 purely imaginary
    if p >= 0.0:
        return complex(math.sqrt(p), 0.0)
    return complex(0.0, math.sqrt(-p))


def eigenvalues_A(p: float) -> Tuple[complex, complex]:
    s = complex_sqrt_p(p)
    return (1.0 + s, 1.0 - s)


def diagonalizable_flag(p: float) -> Optional[bool]:
    # For this 2x2 family:
    # - p > 0: distinct real eigenvalues -> diagonalizable over R (strongly hyperbolic proxy)
    # - p = 0: repeated eigenvalue; A=[[1,1],[0,1]] -> defective (not diagonalizable)
    # - p < 0: eigenvalues complex; diagonalizable over C, but IVP ill-posed due to growth with |k|
    # We return:
    #   True for p>0
    #   False for p=0
    #   True for p<0 (over C) but still mark well_posed_ivp false separately
    if math.isnan(p):
        return None
    if p == 0.0:
        return False
    return True


def growth_rate_proxy(p: float, k: float) -> Optional[float]:
    # For U_t = - i k A U, eigenmode growth rate is Re(-i k λ) = k * Im(λ)
    # Worst-case exponential growth per unit time: |k| * max(|Im(λ)|).
    if math.isnan(p) or math.isnan(k):
        return None
    lam1, lam2 = eigenvalues_A(p)
    im_max = max(abs(lam1.imag), abs(lam2.imag))
    return abs(k) * im_max


def classify_regime(p: float) -> str:
    if p > 0.0:
        return "strongly_hyperbolic"
    if p == 0.0:
        return "weakly_hyperbolic_defective"
    return "elliptic_ill_posed_complex_characteristics"


# ----------------------------
# Toy 090
# ----------------------------

class Toy090HyperbolicityPrincipalSymbol:
    toy_id = "090"

    def __init__(self) -> None:
        pass

    def build_payload(self, p_values: List[float], k_values: List[float]) -> Dict[str, Any]:
        sample_points: List[Dict[str, Any]] = []

        # summaries
        counts = {
            "strongly_hyperbolic": 0,
            "weakly_hyperbolic_defective": 0,
            "elliptic_ill_posed_complex_characteristics": 0,
        }
        defined = 0
        max_growth = 0.0

        for p in p_values:
            p = float(p)
            regime = classify_regime(p)
            counts[regime] += 1

            lam1, lam2 = eigenvalues_A(p)
            diag = diagonalizable_flag(p)

            for k in k_values:
                k = float(k)

                g = growth_rate_proxy(p, k)
                if g is not None:
                    defined += 1
                    max_growth = max(max_growth, g)

                # Well-posed IVP proxy: require strong hyperbolicity (p>0) and no complex speeds.
                well_posed = True if p > 0.0 else False

                sample_points.append({
                    "coordinates": {
                        "p_formulation_parameter": p,
                        "k_fourier_wavenumber": k,
                    },
                    "curvature_invariants": {
                        "ricci_scalar": None,
                        "kretschmann": None,
                    },
                    "local_observables": {
                        "principal_symbol": {
                            "A_matrix": [[1.0, 1.0], [p, 1.0]],
                            "eigenvalues": [
                                {"re": float(lam1.real), "im": float(lam1.imag)},
                                {"re": float(lam2.real), "im": float(lam2.imag)},
                            ],
                            "diagonalizable_over_C": diag,
                            "regime": regime,
                        },
                        "ivp_health": {
                            "well_posed_ivp_proxy": well_posed,
                            "growth_rate_high_k_proxy": g,
                            "note": (
                                "For p<0, complex characteristics imply exponential growth ~ |k|."
                                if p < 0.0 else
                                ("For p=0, defective symbol implies weak hyperbolicity (loss of uniform bounds)."
                                 if p == 0.0 else
                                 "For p>0, distinct real characteristics (strong hyperbolicity proxy).")
                            ),
                        },
                    },
                    "causal_structure": {
                        "interpreted_as": "PDE_characteristics_not_spacetime_lightcones",
                        "hyperbolicity_regime": regime,
                    },
                })

        payload: Dict[str, Any] = {
            "toy_id": self.toy_id,
            "theory": "PDE well-posedness diagnostic (GR formulation/gauge proxy)",
            "spacetime": "N/A (principal symbol / hyperbolicity test)",
            "units": {"G": None, "c": None},
            "parameters": {
                "system": "U_t + A(p) U_x = 0",
                "A(p)": "[[1,1],[p,1]]",
                "p_values": p_values,
                "k_values": k_values,
            },
            "notes": {
                "pressure_point": (
                    "Failure can occur at the level of hyperbolicity: the IVP may be ill-posed or only weakly "
                    "hyperbolic depending on formulation/gauge, independent of curvature or coordinates."
                ),
                "interpretation": (
                    "This toy is a minimal principal-symbol analogue of GR formulation health checks. "
                    "It flags regimes where high-frequency modes grow without bound (p<0) or where the symbol "
                    "is defective (p=0)."
                ),
            },
            "sample_points": sample_points,
            "observables": {
                "summary": {
                    "regime_counts_over_p_grid": counts,
                    "fraction_p_strongly_hyperbolic": counts["strongly_hyperbolic"] / len(p_values) if p_values else None,
                    "fraction_p_weakly_hyperbolic_defective": counts["weakly_hyperbolic_defective"] / len(p_values) if p_values else None,
                    "fraction_p_elliptic_ill_posed": counts["elliptic_ill_posed_complex_characteristics"] / len(p_values) if p_values else None,
                    "max_growth_rate_high_k_proxy_over_samples": max_growth if defined > 0 else None,
                    "well_posed_ivp_proxy_rule": "True iff p>0",
                }
            },
        }
        return payload

    def export_json(self, p_values: List[float], k_values: List[float], out_path: Optional[str] = None) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)
        payload = self.build_payload(p_values=p_values, k_values=k_values)
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2, sort_keys=True)
        return out_path


# ----------------------------
# CLI
# ----------------------------

def main() -> None:
    ap = argparse.ArgumentParser(description="Toy 090: Hyperbolicity / well-posedness principal symbol diagnostic.")
    ap.add_argument("--p", type=str, default="-1,-0.25,0,0.01,0.25,1",
                    help="Comma-separated p values (controls hyperbolicity regime).")
    ap.add_argument("--k", type=str, default="1,5,20,100",
                    help="Comma-separated Fourier wavenumbers to sample.")
    ap.add_argument("--out", type=str, default="")
    args = ap.parse_args()

    p_values = parse_csv_floats(args.p)
    k_values = parse_csv_floats(args.k)
    require(len(p_values) > 0 and len(k_values) > 0, "Provide non-empty p and k grids.")

    toy = Toy090HyperbolicityPrincipalSymbol()
    out_path = args.out.strip() or None
    json_path = toy.export_json(p_values=p_values, k_values=k_values, out_path=out_path)

    print(f"Wrote {json_path}")
    print("Toy 090 complete: hyperbolicity / well-posedness diagnostic.")


if __name__ == "__main__":
    main()
