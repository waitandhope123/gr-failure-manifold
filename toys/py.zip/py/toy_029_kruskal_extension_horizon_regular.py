#!/usr/bin/env python3
"""
Toy 029 — Kruskal extension: horizon is regular (Schwarzschild coordinate artifact)

What it probes (pressure point):
- Schwarzschild coordinates are singular at r=2M, but the spacetime is not.
- Kruskal–Szekeres coordinates make the horizon manifestly regular.
- Exposes coordinate dependence vs invariant curvature.

Model (G=c=1):
Schwarzschild spacetime with mass M.

Key definitions:
  r* = r + 2M ln|r/(2M) - 1|          (tortoise)
  u  = t - r*,   v = t + r*
  For r > 2M:  U = -exp(-u/(4M)),  V =  exp(v/(4M))
  For r < 2M:  U =  exp(-u/(4M)),  V =  exp(v/(4M))    (choose signs so UV>0 inside)
  T = (V + U)/2,  X = (V - U)/2

Kruskal metric (radial-temporal part):
  ds^2 = A(r) (-dT^2 + dX^2) + r^2 dΩ^2
  A(r) = (32 M^3 / r) * exp(-r/(2M))
which is finite at r=2M.

STRICT EXPORT RULE:
- Writes JSON named exactly like this .py file.
- JSON follows canonical schema; undefined quantities are null.
"""

from __future__ import annotations

import argparse
import json
import math
import os
from typing import Any, Dict, List, Optional


# ----------------------------
# Helpers
# ----------------------------

def py_to_json_name(py_path: str) -> str:
    base = os.path.splitext(os.path.basename(py_path))[0]
    return base + ".json"


def parse_csv_floats(s: str) -> List[float]:
    return [float(x.strip()) for x in s.split(",") if x.strip()]


def require(cond: bool, msg: str) -> None:
    if not cond:
        raise ValueError(msg)


# ----------------------------
# Toy 029
# ----------------------------

class Toy029KruskalExtension:
    toy_id = "029"

    def __init__(self, M: float = 1.0, t0: float = 0.0) -> None:
        require(M > 0.0, "M must be > 0.")
        self.M = float(M)
        self.t0 = float(t0)

    def horizon(self) -> float:
        return 2.0 * self.M

    def f(self, r: float) -> float:
        require(r > 0.0, "r must be > 0.")
        return 1.0 - 2.0 * self.M / r

    # Curvature invariants (Schwarzschild vacuum)
    def ricci_scalar(self, r: float) -> float:
        return 0.0

    def kretschmann(self, r: float) -> float:
        require(r > 0.0, "r must be > 0.")
        return 48.0 * (self.M ** 2) / (r ** 6)

    # Tortoise coordinate
    def r_star(self, r: float) -> float:
        require(r > 0.0, "r must be > 0.")
        x = abs(r / (2.0 * self.M) - 1.0)
        # Avoid log(0) exactly at the horizon:
        if x == 0.0:
            x = 1e-300
        return r + 2.0 * self.M * math.log(x)

    def kruskal_UV_TX(self, r: float, t: float) -> Dict[str, float]:
        rs = self.r_star(r)
        u = t - rs
        v = t + rs

        # Sign conventions to match UV sign across regions:
        # Outside (r>2M): U<0, V>0 => UV<0
        # Inside  (r<2M): U>0, V>0 => UV>0
        if r > self.horizon():
            U = -math.exp(-u / (4.0 * self.M))
            V =  math.exp( v / (4.0 * self.M))
        elif r < self.horizon():
            U =  math.exp(-u / (4.0 * self.M))
            V =  math.exp( v / (4.0 * self.M))
        else:
            # Exactly at horizon: U or V tends to 0 depending on u,v; use limit with r* -> -inf.
            # We set U=0, V finite from v (using r* -> -inf gives V->0 too for finite t),
            # but exact values depend on approach. Use nulls to avoid implying a unique value.
            return {"u": u, "v": v, "r_star": rs, "U": float("nan"), "V": float("nan"), "T": float("nan"), "X": float("nan")}

        T = 0.5 * (V + U)
        X = 0.5 * (V - U)
        return {"u": u, "v": v, "r_star": rs, "U": U, "V": V, "T": T, "X": X}

    def A_prefactor(self, r: float) -> float:
        # A(r) = (32 M^3 / r) exp(-r/(2M))
        return (32.0 * (self.M ** 3) / r) * math.exp(-r / (2.0 * self.M))

    def build_payload(self, r_values: List[float]) -> Dict[str, Any]:
        sample_points: List[Dict[str, Any]] = []
        rh = self.horizon()

        for r in r_values:
            r = float(r)
            require(r > 0.0, "All radii must be > 0.")

            k = self.kruskal_UV_TX(r=r, t=self.t0)
            A = self.A_prefactor(r)

            # Handle "exact horizon" case where we set NaNs above
            def clean(x: float) -> Optional[float]:
                return None if (isinstance(x, float) and (math.isnan(x) or math.isinf(x))) else x

            coordinates = {
                "schwarzschild": {"t": self.t0, "r": r, "theta": None, "phi": None},
                "kruskal": {
                    "r_star": clean(k["r_star"]),
                    "u": clean(k["u"]),
                    "v": clean(k["v"]),
                    "U": clean(k["U"]),
                    "V": clean(k["V"]),
                    "T": clean(k["T"]),
                    "X": clean(k["X"]),
                },
            }

            curvature_invariants = {
                "ricci_scalar": self.ricci_scalar(r),
                "kretschmann": self.kretschmann(r),
            }

            local_observables = {
                "schwarzschild_f": self.f(r),
                "kruskal_prefactor_A": A,
                "kruskal_metric_radial_temporal": {
                    "g_TT": -A,
                    "g_XX": +A,
                    "horizon_regular": True,  # A(r) finite at r=2M
                },
                "special_radii": {"horizon_2M": rh},
            }

            causal_structure = {
                "horizon_radius": rh,
                "region": (
                    "exterior (r>2M)" if r > rh else
                    ("horizon (r=2M)" if abs(r - rh) < 1e-12 else
                     "interior (r<2M)")
                ),
                "coordinate_pathology": {
                    "schwarzschild_coords_singular_at_horizon": True,
                    "kruskal_coords_regular_at_horizon": True,
                },
            }

            sample_points.append({
                "coordinates": coordinates,
                "curvature_invariants": curvature_invariants,
                "local_observables": local_observables,
                "causal_structure": causal_structure,
            })

        payload: Dict[str, Any] = {
            "toy_id": self.toy_id,
            "theory": "General Relativity (coordinate extension)",
            "spacetime": "Schwarzschild in Kruskal–Szekeres coordinates (horizon regularity)",
            "units": {"G": 1, "c": 1},
            "parameters": {
                "M": self.M,
                "t0": self.t0,
            },
            "notes": {
                "pressure_point": (
                    "The Schwarzschild horizon is not a curvature singularity; it is a coordinate singularity. "
                    "Kruskal coordinates remove the coordinate pathology while invariants remain finite at r=2M."
                ),
                "key_formulas": {
                    "r_star": "r* = r + 2M ln|r/(2M) - 1|",
                    "U_V": "U = ±exp(-u/(4M)), V = exp(v/(4M)) with sign chosen by region",
                    "T_X": "T=(V+U)/2, X=(V-U)/2",
                    "A(r)": "A(r)=(32 M^3 / r) exp(-r/(2M))",
                },
            },
            "sample_points": sample_points,
            "observables": {
                "horizon_2M": rh,
                "kruskal_prefactor_at_horizon": (16.0 * (self.M ** 2) / math.e),  # A(2M)=16 M^2 e^{-1}
            },
        }

        return payload

    def export_json(self, r_values: List[float], out_path: Optional[str] = None) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)
        payload = self.build_payload(r_values=r_values)
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2, sort_keys=True)
        return out_path


# ----------------------------
# CLI
# ----------------------------

def main() -> None:
    ap = argparse.ArgumentParser(description="Toy 029: Kruskal extension (horizon regularity).")
    ap.add_argument("--M", type=float, default=1.0, help="Mass parameter M (geometric units)")
    ap.add_argument("--t0", type=float, default=0.0, help="Schwarzschild time slice t=t0 for coordinate mapping")
    ap.add_argument(
        "--r",
        type=str,
        default="1.9,1.99,2,2.01,2.1,3,6,10",
        help="Comma-separated radii (include values around 2M to see horizon behavior)",
    )
    ap.add_argument("--out", type=str, default="",
                    help="Optional output path. If omitted, uses <this_script_name>.json")
    args = ap.parse_args()

    toy = Toy029KruskalExtension(M=float(args.M), t0=float(args.t0))
    r_values = parse_csv_floats(args.r)

    out_path = args.out.strip() or None
    json_path = toy.export_json(r_values=r_values, out_path=out_path)

    print(f"Wrote {json_path}")
    print(f"Horizon radius: r = {toy.horizon():g}")


if __name__ == "__main__":
    main()
