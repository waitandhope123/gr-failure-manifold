#!/usr/bin/env python3
"""
Toy 072 — Vacuum energy catastrophe (naive zero-point energy vs observed Λ energy density)

Classification (lab axes):
- Failure Trigger: matter (quantum fields)
- Failure Mode: energy_nonconservation (incompatible coupling/bookkeeping)
- Failure Sharpness: sharp
- Repairable Within Classical GR: no

What it probes (pressure point):
- A naive QFT estimate of vacuum (zero-point) energy density (integrating 1/2 ħω over modes up
  to a UV cutoff) overshoots the energy density associated with the observed cosmological constant
  by an enormous factor (~10^120 for Planck-scale cutoff).
- This is not numerical slop; it’s a structural mismatch between naive vacuum energy bookkeeping
  and gravitational coupling.

Model (controlled approximation):
- Use a massless scalar in flat space as a proxy for UV zero-point energy density:
    ρ_vac(k_max) = ∫_0^{k_max} (d^3k/(2π)^3) * (1/2) ħ c k
                = (ħ c / (16 π^2)) * k_max^4
- Choose k_max = α / ℓ_p with ℓ_p = sqrt(ħ G / c^3) (Planck length), and vary α.

Observed Λ energy density (SI):
- Treat Λ_obs as a supplied parameter (default provided; override as desired).
- Energy density associated with Λ in GR:
    ρ_Λ = (c^4 Λ) / (8π G)     [J/m^3]

Observed Results (what breaks and why it matters):
- For α≈1 (Planck cutoff), ρ_vac is absurdly larger than ρ_Λ.
- The mismatch is so large that “vacuum energy gravitates normally” + “naive UV cutoff” cannot
  both be right without additional structure beyond classical GR (renormalization/cancellation/new physics).

Export:
- Strict JSON schema per lab protocol; writes <script_name>.json.
- Undefined quantities exported as null; keys never omitted.
"""

from __future__ import annotations

import argparse
import json
import math
import os
from typing import Any, Dict, List, Optional


# ----------------------------
# Helpers
# ----------------------------

def py_to_json_name(py_path: str) -> str:
    base = os.path.splitext(os.path.basename(py_path))[0]
    return base + ".json"


def require(cond: bool, msg: str) -> None:
    if not cond:
        raise ValueError(msg)


def parse_csv_floats(s: str) -> List[float]:
    return [float(x.strip()) for x in s.split(",") if x.strip()]


def finite_or_none(x: float) -> Optional[float]:
    return x if (isinstance(x, (int, float)) and math.isfinite(x)) else None


# ----------------------------
# Toy 072
# ----------------------------

class Toy072VacuumEnergyCatastrophe:
    toy_id = "072"

    # Stable CODATA values (sufficient precision for the scale comparison)
    HBAR = 1.054571817e-34         # J*s
    C = 299_792_458.0              # m/s
    G_SI = 6.67430e-11             # m^3/(kg*s^2)
    PI = math.pi

    def __init__(self, *, Lambda_obs_m2: float) -> None:
        require(Lambda_obs_m2 > 0.0, "Lambda_obs must be > 0 (1/m^2).")
        self.Lambda_obs_m2 = float(Lambda_obs_m2)

    def planck_length(self) -> float:
        # ℓ_p = sqrt(ħ G / c^3)
        return math.sqrt(self.HBAR * self.G_SI / (self.C ** 3))

    def k_max(self, alpha: float) -> Optional[float]:
        # k_max = α / ℓ_p
        if alpha <= 0.0:
            return None
        lp = self.planck_length()
        if lp <= 0.0:
            return None
        return alpha / lp

    def rho_vac_zero_point(self, alpha: float) -> Optional[float]:
        # ρ_vac = (ħ c / (16 π^2)) * k_max^4    [J/m^3]
        k = self.k_max(alpha)
        if k is None:
            return None
        pref = (self.HBAR * self.C) / (16.0 * (self.PI ** 2))
        return pref * (k ** 4)

    def rho_lambda(self) -> float:
        # ρ_Λ = c^4 Λ / (8π G)  [J/m^3]
        return (self.C ** 4) * self.Lambda_obs_m2 / (8.0 * self.PI * self.G_SI)

    def build_sample_point(self, alpha: float) -> Dict[str, Any]:
        rv = self.rho_vac_zero_point(alpha)
        rL = self.rho_lambda()

        ratio = None
        if rv is not None and rL > 0.0:
            ratio = rv / rL

        return {
            "coordinates": {"cutoff_scale_alpha": alpha},
            "curvature_invariants": {
                "ricci_scalar": None,
                "kretschmann": None,
                "note": "Not a metric toy: compares energy densities that would source curvature in semiclassical gravity.",
            },
            "local_observables": {
                "planck_length_m": finite_or_none(self.planck_length()),
                "k_max_1_over_m": finite_or_none(self.k_max(alpha)) if self.k_max(alpha) is not None else None,
                "rho_vac_QFT_J_per_m3": finite_or_none(rv) if rv is not None else None,
                "rho_Lambda_obs_J_per_m3": finite_or_none(rL),
                "ratio_rho_vac_over_rho_Lambda": finite_or_none(ratio) if ratio is not None else None,
            },
            "causal_structure": {
                "horizon_radius": None,
                "region": None,
                "note": "No causal structure computed; this is an energy bookkeeping/coupling diagnostic.",
            },
        }

    def build_payload(self, alphas: List[float]) -> Dict[str, Any]:
        require(len(alphas) >= 1, "Need at least one cutoff scale alpha.")
        sample_points = [self.build_sample_point(a) for a in alphas]

        ratios: List[float] = []
        for sp in sample_points:
            r = sp["local_observables"]["ratio_rho_vac_over_rho_Lambda"]
            if r is not None and math.isfinite(r):
                ratios.append(float(r))

        ratio_min = min(ratios) if ratios else None
        ratio_max = max(ratios) if ratios else None

        return {
            "toy_id": self.toy_id,
            "theory": "Semiclassical gravity pressure test (QFT zero-point energy + GR coupling via Λ)",
            "spacetime": "N/A (energy density comparison: QFT vacuum vs observed cosmological constant)",
            "units": {"G": 1, "c": 1},
            "parameters": {
                "Lambda_obs_1_over_m2": self.Lambda_obs_m2,
                "cutoff_scales_alpha": alphas,
                "constants_SI": {
                    "hbar_J_s": self.HBAR,
                    "c_m_s": self.C,
                    "G_m3_kg_s2": self.G_SI,
                },
                "rho_vac_formula": "rho_vac = (ħ c / (16π^2)) * k_max^4, with k_max = α/ℓ_p and ℓ_p = sqrt(ħ G / c^3)",
                "rho_Lambda_formula": "rho_Lambda = c^4 Λ / (8π G)",
            },
            "notes": {
                "pressure_point": (
                    "Naive vacuum energy density from QFT (with Planck-scale cutoff) is incompatible with the "
                    "energy density inferred from the observed cosmological constant by an enormous factor."
                ),
                "interpretation": (
                    "The catastrophe is robust to order-unity prefactors: classical GR does not supply a mechanism "
                    "to cancel/renormalize vacuum energy’s gravitational effect."
                ),
                "domain_of_validity": (
                    "Toy uses a standard flat-space zero-point energy integral as a proxy; the mismatch does not "
                    "depend on precision cosmology beyond an order-of-magnitude Λ value."
                ),
            },
            "sample_points": sample_points,
            "observables": {
                "summary": {
                    "rho_Lambda_obs_J_per_m3": finite_or_none(self.rho_lambda()),
                    "ratio_range_over_samples": {
                        "min": finite_or_none(ratio_min) if ratio_min is not None else None,
                        "max": finite_or_none(ratio_max) if ratio_max is not None else None,
                    },
                    "catastrophe_flag": True if (ratio_max is not None and ratio_max > 1e80) else None,
                    "note": "catastrophe_flag is just an extreme-mismatch marker; typical ratios are far larger.",
                }
            },
        }

    def export_json(self, alphas: List[float], out_path: Optional[str] = None) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)
        payload = self.build_payload(alphas=alphas)
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2, sort_keys=True)
        return out_path


def main() -> None:
    ap = argparse.ArgumentParser(description="Toy 072: vacuum energy catastrophe (QFT zero-point vs observed Λ).")
    ap.add_argument(
        "--Lambda_obs",
        type=float,
        default=1.1056e-52,
        help="Cosmological constant Λ in 1/m^2 (override if you want a different input).",
    )
    ap.add_argument(
        "--alpha",
        type=str,
        default="0.1,1.0,10.0",
        help="Comma-separated UV cutoff scales α for k_max = α/ℓ_p.",
    )
    ap.add_argument("--out", type=str, default="", help="Optional output JSON path; default is <script>.json")
    args = ap.parse_args()

    alphas = parse_csv_floats(args.alpha)
    toy = Toy072VacuumEnergyCatastrophe(Lambda_obs_m2=float(args.Lambda_obs))

    out_path = args.out.strip() or None
    json_path = toy.export_json(alphas=alphas, out_path=out_path)

    print(f"Wrote {json_path}")
    print("Toy 072 complete: naive QFT vacuum energy vs observed Lambda energy density mismatch exported.")


if __name__ == "__main__":
    main()
