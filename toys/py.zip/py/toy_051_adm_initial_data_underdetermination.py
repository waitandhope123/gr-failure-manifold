#!/usr/bin/env python3
"""
Toy 051 — ADM initial data underdetermination

What it probes:
- Identical intrinsic 3-geometry can correspond to different extrinsic curvature K_ij
- The Einstein initial value problem is underdetermined without gauge / slicing choice
- Same spacetime (Minkowski), same curvature invariants, different ADM data

Model:
- Spacetime: Minkowski (flat)
- Two slicings:
  1) Inertial slicing: standard t = const  → K_ij = 0
  2) Accelerated slicing: Rindler-like     → K_ij ≠ 0
- Both satisfy vacuum Einstein equations
"""

from __future__ import annotations

import json
import math
import os
from typing import Any, Dict, List, Optional


# ----------------------------
# Helpers
# ----------------------------

def py_to_json_name(py_path: str) -> str:
    base = os.path.splitext(os.path.basename(py_path))[0]
    return base + ".json"


def finite_or_none(x: float) -> Optional[float]:
    return x if math.isfinite(x) else None


# ----------------------------
# Toy 051
# ----------------------------

class Toy051ADMInitialData:
    toy_id = "051"

    def __init__(self, acceleration: float = 0.1) -> None:
        self.a = float(acceleration)

    # Flat spacetime invariants
    def ricci_scalar(self) -> float:
        return 0.0

    def kretschmann(self) -> float:
        return 0.0

    # Extrinsic curvature models
    def extrinsic_curvature_inertial(self) -> Dict[str, float]:
        return {
            "K_xx": 0.0,
            "K_yy": 0.0,
            "K_zz": 0.0,
            "trace_K": 0.0,
        }

    def extrinsic_curvature_accelerated(self) -> Dict[str, float]:
        # Rindler slicing of Minkowski has nonzero K ~ a
        K = self.a
        return {
            "K_xx": K,
            "K_yy": 0.0,
            "K_zz": 0.0,
            "trace_K": K,
        }

    def sample_point(self, slicing: str) -> Dict[str, Any]:
        if slicing == "inertial":
            K = self.extrinsic_curvature_inertial()
        elif slicing == "accelerated":
            K = self.extrinsic_curvature_accelerated()
        else:
            raise ValueError("Unknown slicing")

        return {
            "coordinates": {
                "t": None,
                "x": 0.0,
                "y": 0.0,
                "z": 0.0,
            },
            "curvature_invariants": {
                "ricci_scalar": self.ricci_scalar(),
                "kretschmann": self.kretschmann(),
            },
            "local_observables": {
                "slicing": slicing,
                "extrinsic_curvature": K,
                "intrinsic_3_metric": "flat (delta_ij)",
            },
            "causal_structure": {
                "horizon_present": (slicing == "accelerated"),
                "notes": (
                    "Rindler horizon present for accelerated observers"
                    if slicing == "accelerated"
                    else "No horizon for inertial observers"
                ),
            },
        }

    def build_payload(self) -> Dict[str, Any]:
        sample_points: List[Dict[str, Any]] = [
            self.sample_point("inertial"),
            self.sample_point("accelerated"),
        ]

        return {
            "toy_id": self.toy_id,
            "theory": "General Relativity (ADM formulation)",
            "spacetime": "Minkowski (different slicings)",
            "units": {"G": 1, "c": 1},
            "parameters": {
                "acceleration_parameter_a": self.a,
            },
            "notes": {
                "pressure_point": (
                    "Identical intrinsic geometry does not uniquely fix extrinsic curvature. "
                    "The ADM initial value problem is underdetermined without gauge/slicing choice."
                ),
                "assumptions": [
                    "Vacuum spacetime",
                    "Flat intrinsic 3-metric",
                    "Different time foliations of the same spacetime",
                ],
                "key_fact": (
                    "Same spacetime, same curvature invariants, different K_ij → "
                    "initial data alone does not uniquely encode physics."
                ),
            },
            "sample_points": sample_points,
            "observables": {
                "comparison": {
                    "curvature_invariants_identical": True,
                    "extrinsic_curvature_identical": False,
                    "spacetime_identical": True,
                }
            },
        }

    def export_json(self, out_path: Optional[str] = None) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)
        payload = self.build_payload()
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2, sort_keys=True)
        return out_path


# ----------------------------
# CLI
# ----------------------------

def main() -> None:
    toy = Toy051ADMInitialData(acceleration=0.1)
    out = toy.export_json()
    print(f"Wrote {out}")
    print("Toy 051 complete: ADM initial data underdetermination.")


if __name__ == "__main__":
    main()
