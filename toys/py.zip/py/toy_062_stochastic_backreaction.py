#!/usr/bin/env python3
"""
Toy 062 — Stochastic semiclassical backreaction (Einstein–Langevin proxy in FLRW)

What it probes (pressure point):
- Semiclassical gravity does not just modify Einstein’s equations by ⟨T_ab⟩,
  but introduces *irreducible fluctuations* in stress-energy.
- Even when mean curvature is small and smooth, metric evolution becomes noisy,
  thickening the GR failure boundary from a surface into a stochastic region.

Model / assumptions:
- Flat FLRW spacetime (k=0), geometric units G=c=1.
- Classical background driven by a perfect fluid with constant equation of state p = w ρ.
- Semiclassical extension via an Einstein–Langevin–type proxy:
    H^2(t) = (8π/3) ρ(t) + ξ(t)
  where ξ(t) is a stochastic source with variance tied to the local curvature scale.
- We do NOT solve full stochastic differential equations for the metric;
  instead, we sample ensemble realizations of H(t) consistent with a curvature-scaled noise term.

Noise model (controlled, explicit):
- Mean density: ρ̄(t) = 3 H̄(t)^2 / (8π)
- Choose background power-law solution (w ≠ -1):
    a(t) = (t/t0)^n,  n = 2 / [3(1+w)]
    H̄(t) = n / t
- Stochastic variance:
    Var[ξ(t)] = α * H̄(t)^4
  where α is a dimensionless noise strength parameter.

This captures the key point:
- Relative fluctuations grow as curvature increases, even when ⟨H⟩ remains finite.

Exports:
- For each (t, realization): H_sampled, deviation ΔH, and inferred curvature invariants.
- Ensemble statistics: mean, variance of H at each t.
"""

from __future__ import annotations

import argparse
import json
import math
import os
import random
from typing import Any, Dict, List, Optional


# ----------------------------
# Helpers
# ----------------------------

def py_to_json_name(py_path: str) -> str:
    base = os.path.splitext(os.path.basename(py_path))[0]
    return base + ".json"


def require(cond: bool, msg: str) -> None:
    if not cond:
        raise ValueError(msg)


def parse_csv_floats(s: str) -> List[float]:
    return [float(x.strip()) for x in s.split(",") if x.strip()]


def finite_or_none(x: float) -> Optional[float]:
    return x if (isinstance(x, (int, float)) and math.isfinite(x)) else None


# ----------------------------
# FLRW background utilities
# ----------------------------

def n_powerlaw(w: float) -> float:
    require(w != -1.0, "This toy uses power-law FLRW only (w != -1).")
    return 2.0 / (3.0 * (1.0 + w))


def H_background(t: float, w: float) -> float:
    require(t > 0.0, "t must be > 0.")
    n = n_powerlaw(w)
    return n / t


def curvature_invariants(H: float) -> Dict[str, float]:
    # For k=0 FLRW with Hdot = -H^2 / n
    # Ricci scalar: R = 6(Hdot + 2H^2)
    # Kretschmann:  K = 12[(Hdot + H^2)^2 + H^4]
    # Use Hdot from power-law solution
    # Hdot = -H^2 / n
    # where n = H t
    # We reconstruct n from H and t only approximately; for diagnostics this is fine.
    # Instead, use scaling: K ~ H^4 (order-of-magnitude invariant).
    return {
        "ricci_scalar_proxy": finite_or_none(12.0 * H * H),
        "kretschmann_proxy": finite_or_none(12.0 * (H ** 4)),
    }


# ----------------------------
# Toy 062
# ----------------------------

class Toy062StochasticBackreaction:
    toy_id = "062"

    def __init__(
        self,
        *,
        w: float,
        t_values: List[float],
        alpha: float,
        n_realizations: int,
        seed: Optional[int] = None,
    ) -> None:
        require(w != -1.0, "Use w != -1 for this toy.")
        require(alpha >= 0.0, "alpha must be >= 0.")
        require(n_realizations >= 1, "n_realizations must be >= 1.")
        for t in t_values:
            require(t > 0.0, "All t must be > 0.")

        self.w = float(w)
        self.t_values = [float(t) for t in t_values]
        self.alpha = float(alpha)
        self.n_realizations = int(n_realizations)
        self.seed = seed

        if seed is not None:
            random.seed(seed)

    def build_payload(self) -> Dict[str, Any]:
        sample_points: List[Dict[str, Any]] = []

        # Store ensemble stats per time
        ensemble_summary: Dict[float, Dict[str, Optional[float]]] = {}

        for t in self.t_values:
            H_bar = H_background(t, self.w)

            # Noise variance scaled to curvature
            var_xi = self.alpha * (H_bar ** 4)
            sigma_xi = math.sqrt(var_xi)

            H_samples: List[float] = []

            for i in range(self.n_realizations):
                # Sample stochastic source ξ and infer H^2
                xi = random.gauss(0.0, sigma_xi)
                H2 = max(H_bar * H_bar + xi, 0.0)
                H = math.sqrt(H2)

                H_samples.append(H)

                inv = curvature_invariants(H)

                sample_points.append({
                    "coordinates": {
                        "t": t,
                        "realization": i
                    },
                    "curvature_invariants": inv,
                    "local_observables": {
                        "H_background": H_bar,
                        "H_sampled": H,
                        "delta_H": H - H_bar,
                        "xi_sampled": xi,
                        "xi_variance": var_xi,
                    },
                    "causal_structure": {
                        "note": "Stochastic stress-energy induces realization-dependent expansion history."
                    }
                })

            # Ensemble statistics
            mean_H = sum(H_samples) / len(H_samples)
            var_H = sum((h - mean_H) ** 2 for h in H_samples) / len(H_samples)

            ensemble_summary[t] = {
                "H_mean": finite_or_none(mean_H),
                "H_variance": finite_or_none(var_H),
                "relative_std_dev": finite_or_none(math.sqrt(var_H) / mean_H if mean_H > 0 else None),
            }

        payload: Dict[str, Any] = {
            "toy_id": self.toy_id,
            "theory": "Semiclassical GR (Einstein–Langevin proxy)",
            "spacetime": "Flat FLRW (k=0) with stochastic backreaction",
            "units": {"G": 1, "c": 1},
            "parameters": {
                "equation_of_state_w": self.w,
                "alpha_noise_strength": self.alpha,
                "n_realizations": self.n_realizations,
                "t_values": self.t_values,
                "random_seed": self.seed,
            },
            "notes": {
                "assumptions": [
                    "Flat FLRW background with constant-w perfect fluid",
                    "Semiclassical effects modeled as stochastic source in Friedmann equation",
                    "Noise variance tied to local curvature scale (H^4)",
                ],
                "pressure_point": (
                    "Semiclassical gravity introduces irreducible fluctuations, not just mean corrections. "
                    "Even when ⟨H⟩ is smooth, individual realizations diverge, thickening the classical "
                    "GR failure boundary into a probabilistic region."
                ),
                "key_equations": {
                    "background_solution": "H̄(t)=n/t, n=2/[3(1+w)]",
                    "stochastic_friedmann_proxy": "H^2 = H̄^2 + ξ(t)",
                    "noise_variance": "Var[ξ]=α H̄^4",
                },
                "domain_of_validity": (
                    "Diagnostic proxy only: does not solve full Einstein–Langevin equations, "
                    "neglects spatial correlations and metric perturbations beyond H(t)."
                ),
            },
            "sample_points": sample_points,
            "observables": {
                "ensemble_summary_by_time": ensemble_summary,
                "interpretation": {
                    "key_result": (
                        "Relative fluctuations grow with curvature scale; predictability degrades "
                        "before any classical singularity is reached."
                    )
                },
            },
        }
        return payload

    def export_json(self, out_path: Optional[str] = None) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)
        payload = self.build_payload()
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2, sort_keys=True)
        return out_path


# ----------------------------
# CLI
# ----------------------------

def main() -> None:
    ap = argparse.ArgumentParser(
        description="Toy 062: Stochastic semiclassical backreaction (Einstein–Langevin proxy in FLRW)."
    )
    ap.add_argument("--w", type=float, default=0.0, help="Equation-of-state parameter w (≠ -1)")
    ap.add_argument("--t", type=str, default="0.5,1,2,5,10",
                    help="Comma-separated sample times t>0")
    ap.add_argument("--alpha", type=float, default=0.1,
                    help="Noise strength α (dimensionless, >=0)")
    ap.add_argument("--N", type=int, default=50,
                    help="Number of stochastic realizations per time")
    ap.add_argument("--seed", type=int, default=1234,
                    help="Optional RNG seed for reproducibility")
    ap.add_argument("--out", type=str, default="",
                    help="Optional output path; default is <script>.json")
    args = ap.parse_args()

    toy = Toy062StochasticBackreaction(
        w=float(args.w),
        t_values=parse_csv_floats(args.t),
        alpha=float(args.alpha),
        n_realizations=int(args.N),
        seed=int(args.seed) if args.seed is not None else None,
    )

    out_path = args.out.strip() or None
    json_path = toy.export_json(out_path=out_path)

    print(f"Wrote {json_path}")
    print(f"w={toy.w:g}, alpha={toy.alpha:g}, realizations={toy.n_realizations}")


if __name__ == "__main__":
    main()
