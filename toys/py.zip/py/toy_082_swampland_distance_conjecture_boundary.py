#!/usr/bin/env python3
"""
Toy 082 — Swampland Distance Conjecture boundary:
effective field theory breakdown from infinite-distance moduli motion

Classification (lab axes):
- Failure Trigger: state + EFT validity
- Failure Mode: operational_undefined (EFT cutoff collapses)
- Failure Sharpness: thick (parameter-dependent)
- Repairable Within Classical GR: no

What it probes (pressure point):
The Swampland Distance Conjecture (SDC) suggests that as a scalar modulus φ
moves an O(1) distance in field space (in Planck units), an infinite tower
of states becomes exponentially light:

    m_tower(φ) ~ m0 * exp(-α Δφ)

As the tower descends, the EFT cutoff Λ_eff drops due to species bounds.
This toy quantifies *when GR + scalar EFT ceases to be predictive* because
Λ_eff falls below local curvature or energy scales.

This is an applicability boundary for GR-as-EFT, not a theorem violation.

Model:
- 4D GR + canonically normalized scalar φ
- Flat field-space metric (Δφ = |φ - φ0|)
- Tower mass model: m(φ) = m0 exp(-α Δφ)
- Number of species below cutoff: N ~ (Λ / m)^p  (p=1 proxy)
- Species bound: Λ_eff ~ M_pl / sqrt(N)

Numerics:
- Deterministic scan over φ
- Compare Λ_eff(φ) to a fixed curvature scale κ (input)
- EFT declared broken when Λ_eff < κ

Export:
- Strict JSON schema per lab protocol.
"""

from __future__ import annotations

import argparse
import json
import math
import os
from typing import Any, Dict, List, Optional


# ----------------------------
# Helpers
# ----------------------------

def py_to_json_name(py_path: str) -> str:
    base = os.path.splitext(os.path.basename(py_path))[0]
    return base + ".json"


def require(cond: bool, msg: str) -> None:
    if not cond:
        raise ValueError(msg)


def linspace(a: float, b: float, n: int) -> List[float]:
    require(n >= 2, "linspace requires n>=2.")
    step = (b - a) / (n - 1)
    return [a + i * step for i in range(n)]


def finite_or_none(x: float) -> Optional[float]:
    return x if (isinstance(x, (int, float)) and math.isfinite(x)) else None


# ----------------------------
# Toy 082
# ----------------------------

class Toy082SwamplandDistanceBoundary:
    toy_id = "082"

    def __init__(
        self,
        *,
        phi0: float,
        phi_max: float,
        n_phi: int,
        alpha: float,
        m0: float,
        curvature_scale: float,
        p_species: float = 1.0,
        Mpl: float = 1.0,
    ) -> None:
        require(n_phi >= 2, "Need at least 2 phi samples.")
        require(alpha > 0.0, "alpha must be > 0.")
        require(m0 > 0.0, "m0 must be > 0.")
        require(curvature_scale > 0.0, "curvature_scale must be > 0.")
        require(Mpl > 0.0, "Mpl must be > 0.")
        require(p_species > 0.0, "p_species must be > 0.")

        self.phi0 = float(phi0)
        self.phi_max = float(phi_max)
        self.n_phi = int(n_phi)
        self.alpha = float(alpha)
        self.m0 = float(m0)
        self.curvature_scale = float(curvature_scale)
        self.p_species = float(p_species)
        self.Mpl = float(Mpl)

    def tower_mass(self, dphi: float) -> float:
        return self.m0 * math.exp(-self.alpha * dphi)

    def species_cutoff(self, m: float) -> Optional[float]:
        if m <= 0.0:
            return None
        # Proxy: N ~ (Λ/m)^p  => Λ ~ (Mpl^2 m^p)^(1/(p+2))
        # Here simplified iterative proxy: Λ_eff ~ Mpl / sqrt(N) with N~(Mpl/m)^p
        N = (self.Mpl / m) ** self.p_species
        if N <= 0.0:
            return None
        return self.Mpl / math.sqrt(N)

    def sample_point(self, phi: float) -> Dict[str, Any]:
        dphi = abs(phi - self.phi0)
        m = self.tower_mass(dphi)
        Lambda = self.species_cutoff(m)

        eft_valid = None
        if Lambda is not None:
            eft_valid = (Lambda > self.curvature_scale)

        return {
            "coordinates": {
                "phi": phi,
                "delta_phi": dphi,
            },
            "curvature_invariants": {
                "ricci_scalar": None,
                "kretschmann": None,
                "note": "Toy does not fix a spacetime metric; curvature enters only via comparison scale κ.",
            },
            "local_observables": {
                "tower_mass_m": finite_or_none(m),
                "species_cutoff_Lambda_eff": finite_or_none(Lambda) if Lambda is not None else None,
                "curvature_scale_kappa": self.curvature_scale,
                "eft_valid_proxy": eft_valid,
                "note": (
                    "EFT validity proxy: Λ_eff > κ. "
                    "When Λ_eff < κ, GR+scalar EFT loses predictivity."
                ),
            },
            "causal_structure": {
                "predictive_regime": eft_valid,
                "failure_mode": (
                    "EFT_breakdown_from_species_proliferation"
                    if eft_valid is False else None
                ),
            },
        }

    def build_payload(self) -> Dict[str, Any]:
        phis = linspace(self.phi0, self.phi_max, self.n_phi)
        sample_points = [self.sample_point(phi) for phi in phis]

        # Find first breakdown point
        breakdown_phi = None
        for sp in sample_points:
            if sp["local_observables"]["eft_valid_proxy"] is False:
                breakdown_phi = sp["coordinates"]["phi"]
                break

        return {
            "toy_id": self.toy_id,
            "theory": "General Relativity as EFT + scalar modulus (Swampland Distance Conjecture proxy)",
            "spacetime": "No fixed background; EFT validity tested against curvature scale",
            "units": {"G": 1, "c": 1},
            "parameters": {
                "phi0": self.phi0,
                "phi_max": self.phi_max,
                "n_phi": self.n_phi,
                "alpha": self.alpha,
                "m0": self.m0,
                "p_species": self.p_species,
                "curvature_scale_kappa": self.curvature_scale,
                "Mpl": self.Mpl,
            },
            "notes": {
                "pressure_point": (
                    "Large excursions in scalar field space cause towers of states to descend, "
                    "collapsing the EFT cutoff below physical scales. "
                    "This marks an applicability boundary for GR-as-EFT."
                ),
                "key_relations": {
                    "tower_mass": "m(φ) = m0 * exp(-α Δφ)",
                    "species_bound_proxy": "Λ_eff ~ Mpl / sqrt(N),  N ~ (Mpl/m)^p",
                    "eft_validity": "Λ_eff > κ",
                },
                "domain_of_validity": (
                    "Uses conjectured scaling relations as numerical proxies. "
                    "Purpose is to locate EFT breakdown, not to prove the conjecture."
                ),
            },
            "sample_points": sample_points,
            "observables": {
                "eft_breakdown_detected": (breakdown_phi is not None),
                "eft_breakdown_phi": breakdown_phi,
                "note": (
                    "Beyond breakdown_phi, curvature/energy scales exceed the EFT cutoff; "
                    "classical GR cannot be trusted even with smooth geometry."
                ),
            },
        }

    def export_json(self, out_path: Optional[str] = None) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)
        payload = self.build_payload()
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2, sort_keys=True)
        return out_path


def main() -> None:
    ap = argparse.ArgumentParser(description="Toy 082: Swampland Distance Conjecture EFT boundary.")
    ap.add_argument("--phi0", type=float, default=0.0, help="Reference field value φ0")
    ap.add_argument("--phi_max", type=float, default=5.0, help="Maximum field value scanned")
    ap.add_argument("--n_phi", type=int, default=200, help="Number of φ samples")
    ap.add_argument("--alpha", type=float, default=1.0, help="SDC exponential rate α")
    ap.add_argument("--m0", type=float, default=1.0, help="Initial tower mass scale m0")
    ap.add_argument("--kappa", type=float, default=1e-2, help="Curvature/energy comparison scale κ")
    ap.add_argument("--p_species", type=float, default=1.0, help="Species growth exponent p")
    ap.add_argument("--Mpl", type=float, default=1.0, help="Planck mass (units)")
    ap.add_argument("--out", type=str, default="", help="Optional output JSON path")
    args = ap.parse_args()

    toy = Toy082SwamplandDistanceBoundary(
        phi0=args.phi0,
        phi_max=args.phi_max,
        n_phi=args.n_phi,
        alpha=args.alpha,
        m0=args.m0,
        curvature_scale=args.kappa,
        p_species=args.p_species,
        Mpl=args.Mpl,
    )

    out_path = args.out.strip() or None
    json_path = toy.export_json(out_path=out_path)

    print(f"Wrote {json_path}")
    print("Toy 082 complete: EFT breakdown from swampland distance scaling exported.")


if __name__ == "__main__":
    main()
