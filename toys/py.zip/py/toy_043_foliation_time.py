#!/usr/bin/env python3
"""
Toy 043 — Foliation-dependent time evolution (same infall, different slicings)

What it probes:
- The same physical worldline can look radically different under different time foliations.
- For a radial geodesic infall (E=1, “from rest at infinity” idealization),
  proper time to the horizon is finite, while Schwarzschild coordinate time diverges.
- Horizon-regular slicings (PG time, ingoing EF advanced time) stay finite.

Model:
- Schwarzschild spacetime (vacuum), geometric units G=c=1.
- Radial timelike geodesic with conserved energy E=1 (standard analytic forms).

Exports:
- For each sample radius r: (tau, t_schw, t_pg, v_ef) with finiteness flags.
- Curvature invariants (R, K) to emphasize unchanged geometry.
"""

from __future__ import annotations

import argparse
import json
import math
import os
from typing import Any, Dict, List, Optional


# ----------------------------
# Helpers
# ----------------------------

def py_to_json_name(py_path: str) -> str:
    base = os.path.splitext(os.path.basename(py_path))[0]
    return base + ".json"


def require(cond: bool, msg: str) -> None:
    if not cond:
        raise ValueError(msg)


def parse_csv_floats(s: str) -> List[float]:
    return [float(x.strip()) for x in s.split(",") if x.strip()]


def safe_float(x: float) -> Optional[float]:
    return x if math.isfinite(x) else None


# ----------------------------
# Physics: Schwarzschild + infall (E=1)
# ----------------------------

class Toy043FoliationTime:
    toy_id = "043"

    def __init__(self, M: float = 1.0) -> None:
        require(M > 0.0, "M must be > 0.")
        self.M = float(M)

    def horizon_radius(self) -> float:
        return 2.0 * self.M

    def f(self, r: float) -> float:
        require(r > 0.0, "r must be > 0.")
        return 1.0 - 2.0 * self.M / r

    # Invariants (vacuum Schwarzschild)
    def ricci_scalar(self, r: float) -> float:
        require(r > 0.0, "r must be > 0.")
        return 0.0

    def kretschmann(self, r: float) -> float:
        require(r > 0.0, "r must be > 0.")
        return 48.0 * (self.M ** 2) / (r ** 6)

    # Proper time from r_start to r for E=1:
    # dr/dtau = -sqrt(2M/r)  =>  tau(r) - tau(r0) = (2/3)/sqrt(2M) * (r0^(3/2) - r^(3/2))
    def tau_from_rstart(self, r: float, r_start: float) -> float:
        require(r > 0.0 and r_start > 0.0, "r and r_start must be > 0.")
        require(r_start >= r, "For infall sampling, require r_start >= r.")
        return (2.0 / 3.0) * (r_start ** 1.5 - r ** 1.5) / math.sqrt(2.0 * self.M)

    # Schwarzschild coordinate time t(r) for E=1 (up to additive constant).
    # Standard closed form (log diverges at r=2M):
    # t(r) = 2M * [ -(2/3) x^(3/2) - 2 x^(1/2) + ln |(sqrt(x)+1)/(sqrt(x)-1)| ] + C
    # where x = r/(2M)
    def t_schw_primitive(self, r: float) -> float:
        require(r > 0.0, "r must be > 0.")
        x = r / (2.0 * self.M)
        sx = math.sqrt(x)
        # log argument blows up as x -> 1
        arg = abs((sx + 1.0) / (sx - 1.0))
        return 2.0 * self.M * (-(2.0 / 3.0) * (x ** 1.5) - 2.0 * sx + math.log(arg))

    # Tortoise coordinate: r* = r + 2M ln|r/(2M) - 1|
    def r_tortoise(self, r: float) -> float:
        require(r > 0.0, "r must be > 0.")
        x = r / (2.0 * self.M)
        return r + 2.0 * self.M * math.log(abs(x - 1.0))

    # Ingoing PG time transform (one common convention):
    # t_PG = t + 2 sqrt(2Mr) + 2M ln |(sqrt(r)-sqrt(2M))/(sqrt(r)+sqrt(2M))|
    def t_pg_from_t(self, t_schw: float, r: float) -> float:
        require(r > 0.0, "r must be > 0.")
        rt = 2.0 * math.sqrt(2.0 * self.M * r)
        num = abs(math.sqrt(r) - math.sqrt(2.0 * self.M))
        den = abs(math.sqrt(r) + math.sqrt(2.0 * self.M))
        # ratio -> 0 at horizon; log -> -inf; cancels +inf in t_schw along infall
        return t_schw + rt + 2.0 * self.M * math.log(num / den)

    def build_payload(self, r_values: List[float], r_start: float) -> Dict[str, Any]:
        require(r_start > 0.0, "r_start must be > 0.")
        rh = self.horizon_radius()
        require(r_start > rh, "Choose r_start > 2M so the Schwarzschild-time divergence is visible near the horizon.")

        # Set t=0, tau=0 at r_start by subtracting primitives at r_start.
        t0 = self.t_schw_primitive(r_start)

        sample_points: List[Dict[str, Any]] = []
        all_tau_finite = True
        all_tpg_finite = True
        all_vef_finite = True

        for r in r_values:
            require(r > 0.0, "All sample radii must be > 0.")
            require(r_start >= r, "All sample radii must be <= r_start for infall sampling.")

            # Proper time
            tau = self.tau_from_rstart(r=r, r_start=r_start)
            tau_json = safe_float(tau)
            if tau_json is None:
                all_tau_finite = False

            # Schwarzschild coordinate time (may be inf at/near horizon)
            try:
                t_s = self.t_schw_primitive(r) - t0
                t_s_json = safe_float(t_s)
            except (ValueError, ZeroDivisionError, OverflowError):
                t_s_json = None

            # Ingoing EF advanced time v = t + r*
            try:
                rstar = self.r_tortoise(r)
                v_ef = (None if t_s_json is None else (t_s_json + rstar))
                v_ef_json = safe_float(v_ef) if v_ef is not None else None
            except (ValueError, OverflowError):
                v_ef_json = None

            if v_ef_json is None:
                all_vef_finite = False

            # PG time
            try:
                if t_s_json is None:
                    t_pg_json = None
                else:
                    t_pg = self.t_pg_from_t(t_schw=t_s_json, r=r)
                    t_pg_json = safe_float(t_pg)
            except (ValueError, OverflowError):
                t_pg_json = None

            if t_pg_json is None:
                all_tpg_finite = False

            # Invariants
            R = self.ricci_scalar(r)
            K = self.kretschmann(r)

            # Simple “near-horizon” indicator
            near_horizon = abs(r - rh) <= max(1e-12, 1e-9 * rh)

            sample_points.append(
                {
                    "coordinates": {
                        "r": r,
                        "r_start": r_start,
                    },
                    "curvature_invariants": {
                        "ricci_scalar_R": R,
                        "kretschmann_K": K,
                    },
                    "local_observables": {
                        "proper_time_tau_from_r_start": tau_json,
                        "schwarzschild_time_t_from_r_start": t_s_json,
                        "pg_time_t_pg_from_r_start": t_pg_json,
                        "ef_advanced_time_v_from_r_start": v_ef_json,
                        "finite_flags": {
                            "tau_finite": tau_json is not None,
                            "t_schw_finite": t_s_json is not None,
                            "t_pg_finite": t_pg_json is not None,
                            "v_ef_finite": v_ef_json is not None,
                        },
                    },
                    "causal_structure": {
                        "horizon_radius_2M": rh,
                        "inside_horizon": (r < rh),
                        "at_or_near_horizon": near_horizon,
                    },
                }
            )

        payload: Dict[str, Any] = {
            "toy_id": self.toy_id,
            "theory": "General Relativity",
            "spacetime": "Schwarzschild (same infall, different foliations)",
            "units": {"G": 1, "c": 1},
            "parameters": {
                "M": self.M,
                "r_start": r_start,
                "r_samples": r_values,
            },
            "notes": {
                "assumptions": [
                    "Vacuum Schwarzschild, geometric units G=c=1",
                    "Radial timelike geodesic with conserved energy E=1",
                    "Times reported are shifted so that tau=0 and coordinate times=0 at r=r_start",
                ],
                "pressure_point": (
                    "Proper time to the horizon is finite, but Schwarzschild coordinate time diverges. "
                    "Horizon-regular slicings (PG, ingoing EF advanced time) remain finite along infall."
                ),
                "key_formulas": {
                    "dr_dtau": "dr/dτ = -sqrt(2M/r)  (E=1 infall)",
                    "tau(r)": "τ(r)-τ(r0) = (2/3)/sqrt(2M) * (r0^(3/2) - r^(3/2))",
                    "t_schw(r)": "t(r)=2M[-(2/3)x^(3/2)-2x^(1/2)+ln|(sqrt(x)+1)/(sqrt(x)-1)|]+C, x=r/(2M)",
                    "r_star": "r* = r + 2M ln|r/(2M)-1|",
                    "v_ef": "v = t + r*",
                    "t_pg": "t_PG = t + 2 sqrt(2Mr) + 2M ln |(sqrt(r)-sqrt(2M))/(sqrt(r)+sqrt(2M))|",
                },
            },
            "sample_points": sample_points,
            "observables": {
                "summary": {
                    "horizon_radius_2M": rh,
                    "all_tau_finite": all_tau_finite,
                    "all_pg_time_finite": all_tpg_finite,
                    "all_ef_advanced_time_finite": all_vef_finite,
                    "note": (
                        "Expect t_schw to become extremely large / undefined near r=2M; "
                        "tau, t_pg, and v_ef should remain finite for r>0 (except possible numerical overflow if pushed too hard)."
                    ),
                }
            },
        }

        return payload

    def export_json(self, r_values: List[float], r_start: float, out_path: Optional[str] = None) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)
        payload = self.build_payload(r_values=r_values, r_start=r_start)
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2, sort_keys=True)
        return out_path


# ----------------------------
# CLI
# ----------------------------

def main() -> None:
    ap = argparse.ArgumentParser(description="Toy 043: Same infall, different time foliations (t, t_PG, v_EF).")
    ap.add_argument("--M", type=float, default=1.0, help="Mass parameter M (geometric units)")
    ap.add_argument("--r_start", type=float, default=10.0, help="Starting radius r_start > 2M")
    ap.add_argument(
        "--r",
        type=str,
        default="10,6,4,3,2.5,2.1,2.01,2.001,2.0001",
        help="Comma-separated radii r <= r_start (sample near 2M to see divergence in Schwarzschild time)",
    )
    ap.add_argument("--out", type=str, default="", help="Optional output path. If omitted, uses <this_script_name>.json")
    args = ap.parse_args()

    r_values = parse_csv_floats(args.r)
    toy = Toy043FoliationTime(M=float(args.M))

    out_path = args.out.strip() or None
    json_path = toy.export_json(r_values=r_values, r_start=float(args.r_start), out_path=out_path)

    print(f"Wrote {json_path}")
    print(f"Note: horizon at r=2M={toy.horizon_radius():g}. Expect Schwarzschild t to blow up near 2M.")


if __name__ == "__main__":
    main()
