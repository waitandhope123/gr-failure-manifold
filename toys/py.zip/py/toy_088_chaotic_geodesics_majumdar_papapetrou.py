#!/usr/bin/env python3
"""
Toy 088 — Classical chaos without singularities (chaotic geodesics proxy)

What it probes (pressure point):
- Deterministic equations can become practically unpredictable even when curvature is finite
  and no horizon/singularity is encountered along the sampled trajectory.
- This is a "failure mode" distinct from coordinate artifacts or underdetermination:
  sensitivity to initial conditions (positive Lyapunov exponent).

Model choice (minimal, controlled):
- Use a Newtonian-like, time-independent effective potential with two fixed centers
  as a proxy for multi-center GR geodesic complexity (e.g. Majumdar–Papapetrou family).
- We do NOT claim to evolve exact GR geodesics here; we claim a clean diagnostic:
  chaos (exponential separation) arises in smooth multi-center systems.
- Curvature invariants are exported as null to avoid misrepresenting geometry.

Dynamics:
- 2D motion in (x,y) with Hamiltonian:
    H = 1/2 (vx^2 + vy^2) + Phi(x,y)
  with Phi = -M1/r1 - M2/r2, r1,2 distances to two centers.
- Integrate two nearby trajectories with separation ||δx|| and track
  finite-time Lyapunov proxy:
    λ(t) ≈ (1/t) ln( ||δx(t)|| / ||δx(0)|| )
- "Chaos detected" if λ(t_end) > λ_min and separation grows by many e-folds.

Why this still belongs in your lab:
- It encodes a distinct failure axis: predictability breakdown without any geometric singularity.
- The JSON makes the regime and limitations explicit.

STRICT EXPORT RULE:
- Writes JSON named exactly like this .py file.
- JSON follows canonical schema; undefined quantities are null.
"""

from __future__ import annotations

import argparse
import json
import math
import os
from typing import Any, Dict, List, Optional, Tuple


# ----------------------------
# Helpers
# ----------------------------

def py_to_json_name(py_path: str) -> str:
    base = os.path.splitext(os.path.basename(py_path))[0]
    return base + ".json"


def require(cond: bool, msg: str) -> None:
    if not cond:
        raise ValueError(msg)


# ----------------------------
# Dynamics
# ----------------------------

class TwoCenterPotential:
    def __init__(self, M1: float, M2: float, x1: float, x2: float, softening: float = 0.0):
        require(M1 > 0.0 and M2 > 0.0, "M1,M2 must be > 0.")
        require(x1 < x2, "Require x1 < x2 for clarity.")
        require(softening >= 0.0, "softening must be >= 0.")
        self.M1 = float(M1)
        self.M2 = float(M2)
        self.x1 = float(x1)
        self.x2 = float(x2)
        self.eps = float(softening)

    def _r1(self, x: float, y: float) -> float:
        return math.sqrt((x - self.x1) ** 2 + y ** 2 + self.eps ** 2)

    def _r2(self, x: float, y: float) -> float:
        return math.sqrt((x - self.x2) ** 2 + y ** 2 + self.eps ** 2)

    def phi(self, x: float, y: float) -> float:
        r1 = self._r1(x, y)
        r2 = self._r2(x, y)
        return -self.M1 / r1 - self.M2 / r2

    def grad_phi(self, x: float, y: float) -> Tuple[float, float]:
        # ∇(-M/r) = + M (r_vec) / r^3
        dx1 = x - self.x1
        dx2 = x - self.x2
        r1 = self._r1(x, y)
        r2 = self._r2(x, y)

        g1x = self.M1 * dx1 / (r1 ** 3)
        g1y = self.M1 * y   / (r1 ** 3)
        g2x = self.M2 * dx2 / (r2 ** 3)
        g2y = self.M2 * y   / (r2 ** 3)

        return (g1x + g2x, g1y + g2y)

    def energy(self, x: float, y: float, vx: float, vy: float) -> float:
        return 0.5 * (vx * vx + vy * vy) + self.phi(x, y)


def rk4_step(
    pot: TwoCenterPotential,
    state: Tuple[float, float, float, float],
    dt: float,
) -> Tuple[float, float, float, float]:
    x, y, vx, vy = state

    def f(s: Tuple[float, float, float, float]) -> Tuple[float, float, float, float]:
        sx, sy, svx, svy = s
        gx, gy = pot.grad_phi(sx, sy)
        # Equations: xdot=v, vdot = -∇Phi? Here Phi is negative; force is -∇Phi.
        # Since grad_phi computed ∇Phi, acceleration = -∇Phi.
        ax = -gx
        ay = -gy
        return (svx, svy, ax, ay)

    k1 = f((x, y, vx, vy))
    k2 = f((x + 0.5*dt*k1[0], y + 0.5*dt*k1[1], vx + 0.5*dt*k1[2], vy + 0.5*dt*k1[3]))
    k3 = f((x + 0.5*dt*k2[0], y + 0.5*dt*k2[1], vx + 0.5*dt*k2[2], vy + 0.5*dt*k2[3]))
    k4 = f((x + dt*k3[0], y + dt*k3[1], vx + dt*k3[2], vy + dt*k3[3]))

    xn = x + (dt/6.0)*(k1[0] + 2*k2[0] + 2*k3[0] + k4[0])
    yn = y + (dt/6.0)*(k1[1] + 2*k2[1] + 2*k3[1] + k4[1])
    vxn = vx + (dt/6.0)*(k1[2] + 2*k2[2] + 2*k3[2] + k4[2])
    vyn = vy + (dt/6.0)*(k1[3] + 2*k2[3] + 2*k3[3] + k4[3])

    return (xn, yn, vxn, vyn)


def l2_sep(a: Tuple[float, float, float, float], b: Tuple[float, float, float, float]) -> float:
    dx = a[0] - b[0]
    dy = a[1] - b[1]
    dvx = a[2] - b[2]
    dvy = a[3] - b[3]
    return math.sqrt(dx*dx + dy*dy + dvx*dvx + dvy*dvy)


# ----------------------------
# Toy 088
# ----------------------------

class Toy088ChaoticGeodesicsProxy:
    toy_id = "088"

    def __init__(
        self,
        M1: float = 1.0,
        M2: float = 1.0,
        separation: float = 2.0,
        softening: float = 1e-3,
    ) -> None:
        self.M1 = float(M1)
        self.M2 = float(M2)
        self.sep = float(separation)
        self.softening = float(softening)
        require(self.sep > 0.0, "separation must be > 0.")
        self.pot = TwoCenterPotential(M1=self.M1, M2=self.M2, x1=-0.5*self.sep, x2=+0.5*self.sep, softening=self.softening)

    def simulate(
        self,
        x0: float,
        y0: float,
        vx0: float,
        vy0: float,
        delta0: float,
        dt: float,
        n_steps: int,
        sample_every: int,
        escape_radius: float,
    ) -> Dict[str, Any]:
        require(dt > 0.0, "dt must be > 0.")
        require(n_steps >= 1, "n_steps must be >= 1.")
        require(sample_every >= 1, "sample_every must be >= 1.")
        require(delta0 > 0.0, "delta0 must be > 0.")
        require(escape_radius > 0.0, "escape_radius must be > 0.")

        sA = (float(x0), float(y0), float(vx0), float(vy0))
        # Perturb position in y by delta0 (deterministic choice)
        sB = (float(x0), float(y0 + delta0), float(vx0), float(vy0))

        E0_A = self.pot.energy(*sA)
        E0_B = self.pot.energy(*sB)
        d0 = l2_sep(sA, sB)

        traj: List[Dict[str, Any]] = []
        t = 0.0

        escaped = False
        escape_time = None
        min_r_to_centers = float("inf")

        # We'll compute a running finite-time Lyapunov proxy using separation in phase space
        # lambda(t) = (1/t) ln(d(t)/d0) (defined for t>0)
        max_lambda = -float("inf")
        last_lambda = None

        for i in range(n_steps + 1):
            # Track proximity to centers (avoid confusing chaos with near-singular core hits)
            r1 = math.sqrt((sA[0] + 0.5*self.sep) ** 2 + sA[1] ** 2)
            r2 = math.sqrt((sA[0] - 0.5*self.sep) ** 2 + sA[1] ** 2)
            min_r_to_centers = min(min_r_to_centers, r1, r2)

            # Escape check
            rr = math.sqrt(sA[0] ** 2 + sA[1] ** 2)
            if (not escaped) and rr > escape_radius:
                escaped = True
                escape_time = t

            if i % sample_every == 0:
                d = l2_sep(sA, sB)
                lam = None
                if t > 0.0 and d > 0.0 and d0 > 0.0:
                    lam = (1.0 / t) * math.log(d / d0)
                    last_lambda = lam
                    max_lambda = max(max_lambda, lam)

                traj.append({
                    "coordinates": {"t": t},
                    "curvature_invariants": {"ricci_scalar": None, "kretschmann": None},
                    "local_observables": {
                        "state_A": {"x": sA[0], "y": sA[1], "vx": sA[2], "vy": sA[3]},
                        "state_B": {"x": sB[0], "y": sB[1], "vx": sB[2], "vy": sB[3]},
                        "separation_phase_space_L2": d,
                        "finite_time_lyapunov_proxy": lam,
                        "energy_A": self.pot.energy(*sA),
                        "energy_B": self.pot.energy(*sB),
                    },
                    "causal_structure": {},
                })

            # Step
            if i < n_steps:
                sA = rk4_step(self.pot, sA, dt)
                sB = rk4_step(self.pot, sB, dt)
                t += dt

        # Energy drift diagnostics (numerical sanity check)
        E_end_A = self.pot.energy(*sA)
        E_end_B = self.pot.energy(*sB)
        drift_A = abs(E_end_A - E0_A)
        drift_B = abs(E_end_B - E0_B)

        return {
            "trajectory": traj,
            "summary": {
                "E0_A": E0_A,
                "E0_B": E0_B,
                "E_end_A": E_end_A,
                "E_end_B": E_end_B,
                "energy_drift_abs_A": drift_A,
                "energy_drift_abs_B": drift_B,
                "t_end": t,
                "delta0_phase_space_L2": d0,
                "lambda_proxy_last": last_lambda,
                "lambda_proxy_max_over_samples": (max_lambda if max_lambda != -float("inf") else None),
                "escaped": escaped,
                "escape_time": escape_time,
                "min_distance_to_centers_over_run": min_r_to_centers,
            }
        }

    def build_payload(
        self,
        x0: float,
        y0: float,
        vx0: float,
        vy0: float,
        delta0: float,
        dt: float,
        n_steps: int,
        sample_every: int,
        escape_radius: float,
        chaos_lambda_threshold: float,
        efolds_threshold: float,
    ) -> Dict[str, Any]:
        sim = self.simulate(
            x0=x0, y0=y0, vx0=vx0, vy0=vy0,
            delta0=delta0, dt=dt, n_steps=n_steps,
            sample_every=sample_every, escape_radius=escape_radius,
        )

        traj = sim["trajectory"]
        summ = sim["summary"]

        # Decide "chaos detected" based on final or max Lyapunov proxy and e-fold growth
        d0 = summ["delta0_phase_space_L2"]
        d_end = traj[-1]["local_observables"]["separation_phase_space_L2"] if traj else None
        efolds = None
        if d_end is not None and d0 > 0.0 and d_end > 0.0:
            efolds = math.log(d_end / d0)

        lam = summ["lambda_proxy_last"]
        lam_max = summ["lambda_proxy_max_over_samples"]

        chaos_detected = False
        if lam is not None and efolds is not None:
            chaos_detected = (lam > chaos_lambda_threshold) and (efolds > efolds_threshold)

        payload: Dict[str, Any] = {
            "toy_id": self.toy_id,
            "theory": "GR-inspired multi-center geodesic complexity (chaos diagnostic proxy)",
            "spacetime": "Two-center static background (Majumdar–Papapetrou-inspired proxy; not exact GR geodesics)",
            "units": {"G": 1, "c": 1},
            "parameters": {
                "centers": {
                    "M1": self.M1,
                    "M2": self.M2,
                    "x1": -0.5 * self.sep,
                    "x2": +0.5 * self.sep,
                    "separation": self.sep,
                    "softening_eps": self.softening,
                },
                "initial_conditions": {"x0": x0, "y0": y0, "vx0": vx0, "vy0": vy0},
                "perturbation": {"delta0_phase_space_L2": delta0, "applied_to": "y position of copy trajectory"},
                "integration": {
                    "method": "RK4",
                    "dt": dt,
                    "n_steps": n_steps,
                    "sample_every": sample_every,
                    "escape_radius": escape_radius,
                },
                "chaos_thresholds": {
                    "lambda_min": chaos_lambda_threshold,
                    "efolds_min": efolds_threshold,
                },
            },
            "notes": {
                "pressure_point": (
                    "Even in smooth, time-independent systems with no horizon/singularity encountered, "
                    "deterministic motion can be practically unpredictable due to exponential sensitivity "
                    "to initial conditions (positive Lyapunov exponent)."
                ),
                "caution": (
                    "This toy is an explicit proxy: it does not claim to integrate exact GR geodesics. "
                    "Curvature invariants are therefore set to null."
                ),
                "diagnostic": (
                    "Finite-time Lyapunov proxy λ(t) = (1/t) ln(||δ(t)||/||δ(0)||) computed in phase space."
                ),
            },
            "sample_points": traj,
            "observables": {
                "summary": {
                    "lambda_proxy_last": lam,
                    "lambda_proxy_max_over_samples": lam_max,
                    "separation_efolds_ln_dend_over_d0": efolds,
                    "chaos_detected": chaos_detected,
                    "escaped": summ["escaped"],
                    "escape_time": summ["escape_time"],
                    "min_distance_to_centers_over_run": summ["min_distance_to_centers_over_run"],
                    "energy_drift_abs_A": summ["energy_drift_abs_A"],
                    "energy_drift_abs_B": summ["energy_drift_abs_B"],
                    "t_end": summ["t_end"],
                }
            },
        }
        return payload

    def export_json(
        self,
        x0: float,
        y0: float,
        vx0: float,
        vy0: float,
        delta0: float,
        dt: float,
        n_steps: int,
        sample_every: int,
        escape_radius: float,
        chaos_lambda_threshold: float,
        efolds_threshold: float,
        out_path: Optional[str] = None,
    ) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)
        payload = self.build_payload(
            x0=x0, y0=y0, vx0=vx0, vy0=vy0,
            delta0=delta0, dt=dt, n_steps=n_steps,
            sample_every=sample_every, escape_radius=escape_radius,
            chaos_lambda_threshold=chaos_lambda_threshold,
            efolds_threshold=efolds_threshold,
        )
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2, sort_keys=True)
        return out_path


# ----------------------------
# CLI
# ----------------------------

def main() -> None:
    ap = argparse.ArgumentParser(description="Toy 088: Chaotic geodesics diagnostic proxy (two-center).")
    ap.add_argument("--M1", type=float, default=1.0)
    ap.add_argument("--M2", type=float, default=1.0)
    ap.add_argument("--sep", type=float, default=2.0)
    ap.add_argument("--soft", type=float, default=1e-3)
    ap.add_argument("--x0", type=float, default=0.1)
    ap.add_argument("--y0", type=float, default=0.6)
    ap.add_argument("--vx0", type=float, default=0.6)
    ap.add_argument("--vy0", type=float, default=0.0)
    ap.add_argument("--delta0", type=float, default=1e-6)
    ap.add_argument("--dt", type=float, default=2e-3)
    ap.add_argument("--n_steps", type=int, default=200000)
    ap.add_argument("--sample_every", type=int, default=2000)
    ap.add_argument("--escape_radius", type=float, default=50.0)
    ap.add_argument("--lambda_min", type=float, default=0.01)
    ap.add_argument("--efolds_min", type=float, default=5.0)
    ap.add_argument("--out", type=str, default="")
    args = ap.parse_args()

    toy = Toy088ChaoticGeodesicsProxy(
        M1=args.M1, M2=args.M2, separation=args.sep, softening=args.soft
    )
    out_path = args.out.strip() or None
    json_path = toy.export_json(
        x0=args.x0, y0=args.y0, vx0=args.vx0, vy0=args.vy0,
        delta0=args.delta0, dt=args.dt, n_steps=args.n_steps,
        sample_every=args.sample_every, escape_radius=args.escape_radius,
        chaos_lambda_threshold=args.lambda_min, efolds_threshold=args.efolds_min,
        out_path=out_path,
    )

    print(f"Wrote {json_path}")
    print("Toy 088 complete: chaotic geodesics diagnostic proxy.")


if __name__ == "__main__":
    main()
