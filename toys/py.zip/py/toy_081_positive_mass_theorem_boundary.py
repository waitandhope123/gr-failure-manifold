#!/usr/bin/env python3
"""
Toy 081 — Positive Mass Theorem boundary: hypothesis failure (completeness / asymptotic flatness)
makes global energy positivity non-applicable.

Classification (lab axes):
- Failure Trigger: boundary + topology + energetic
- Failure Mode: operational_undefined (ADM energy undefined) + energy_nonconservation (positivity not guaranteed)
- Failure Sharpness: sharp (theorem switches on/off with hypotheses)
- Repairable Within Classical GR: no (it's a boundary of applicability, not a fixable bug)

What it probes (pressure point):
Positive Mass Theorem (PMT) (informal): For an asymptotically flat, complete Riemannian 3-manifold
with nonnegative scalar curvature, ADM mass is >= 0 (and equals 0 only for flat space).

This toy demonstrates *hypothesis boundaries* numerically:
1) Schwarzschild (t=const spatial slice, time-symmetric):
   - ADM mass equals M (asymptotically flat).
   - For M > 0: the spatial proper distance to r=2M from any r0>2M diverges (inner end is infinitely far),
     consistent with completeness of the standard t=const slice exterior end.
   - For M < 0: f(r)=1-2M/r = 1+2|M|/r > 0 for all r>0; there is a naked curvature singularity at r=0.
     The spatial proper distance to r=0 is *finite* => geodesic incompleteness -> PMT hypotheses fail.
     In that case, "ADM mass negative" is not a counterexample to PMT; it's outside applicability.

2) Flat 3-torus (compact topology):
   - Scalar curvature is zero, but there is no asymptotic region => ADM mass is undefined (null).
   - "Global energy positivity" is operationally undefined, not violated.

Numerics:
- Deterministic trapezoidal integration of spatial proper radial distance:
    ds = dr / sqrt(f(r))   (radial line on t=const slice in Schwarzschild coordinates where f>0)
  For M>0, integrate from r0 down to r_in = 2M(1+eps); distance grows as eps -> 0.
  For M<0, integrate from r0 down to r_in = eps; distance converges as eps -> 0.

Export:
- Strict JSON schema per lab protocol; writes <script_name>.json.
- Undefined quantities exported as null; keys never omitted.
"""

from __future__ import annotations

import argparse
import json
import math
import os
from typing import Any, Dict, List, Optional


# ----------------------------
# Helpers
# ----------------------------

def py_to_json_name(py_path: str) -> str:
    base = os.path.splitext(os.path.basename(py_path))[0]
    return base + ".json"


def require(cond: bool, msg: str) -> None:
    if not cond:
        raise ValueError(msg)


def parse_csv_floats(s: str) -> List[float]:
    return [float(x.strip()) for x in s.split(",") if x.strip()]


def finite_or_none(x: float) -> Optional[float]:
    return x if (isinstance(x, (int, float)) and math.isfinite(x)) else None


def trapz_integral(xs: List[float], ys: List[float]) -> float:
    require(len(xs) == len(ys) and len(xs) >= 2, "trapz requires same-length arrays, len>=2.")
    total = 0.0
    for i in range(len(xs) - 1):
        dx = xs[i + 1] - xs[i]
        total += 0.5 * dx * (ys[i] + ys[i + 1])
    return total


def linspace(a: float, b: float, n: int) -> List[float]:
    require(n >= 2, "linspace requires n>=2.")
    if n == 2:
        return [a, b]
    step = (b - a) / (n - 1)
    return [a + i * step for i in range(n)]


# ----------------------------
# Toy 081
# ----------------------------

class Toy081PositiveMassBoundary:
    toy_id = "081"

    def __init__(self, *, M: float, r0: float, r_samples: List[float], torus_L: float) -> None:
        require(r0 > 0.0, "r0 must be > 0.")
        require(torus_L > 0.0, "torus_L must be > 0.")
        require(len(r_samples) >= 1, "Need at least one r sample.")

        self.M = float(M)
        self.r0 = float(r0)
        self.r_samples = list(map(float, r_samples))
        self.torus_L = float(torus_L)

    # Schwarzschild functions
    def f_schw(self, r: float) -> float:
        return 1.0 - 2.0 * self.M / r

    def horizon(self) -> Optional[float]:
        # Only meaningful for M>0
        return 2.0 * self.M if self.M > 0.0 else None

    def kretschmann_schw(self, r: float) -> Optional[float]:
        if r <= 0.0:
            return None
        return 48.0 * (self.M ** 2) / (r ** 6)

    def adm_mass(self) -> Optional[float]:
        # For asymptotically flat Schwarzschild, ADM mass equals parameter M (even if M<0).
        return self.M

    def scalar_curvature_spatial_time_symmetric(self) -> float:
        # Time-symmetric vacuum initial data has scalar curvature R^(3)=0.
        return 0.0

    def proper_radial_distance(self, r_inner: float, r_outer: float, n: int = 200000) -> Optional[float]:
        """
        Compute ∫_{r_inner}^{r_outer} dr / sqrt(f(r)) for region where f(r)>0.
        Returns null if f <= 0 somewhere in interval.
        """
        require(r_outer > r_inner > 0.0, "Need 0<r_inner<r_outer.")
        rs = linspace(r_inner, r_outer, n)

        inv_sqrt_f: List[float] = []
        for r in rs:
            fr = self.f_schw(r)
            if fr <= 0.0 or not math.isfinite(fr):
                return None
            inv_sqrt_f.append(1.0 / math.sqrt(fr))

        return trapz_integral(rs, inv_sqrt_f)

    def completeness_proxy(self, eps_list: List[float]) -> Dict[str, Any]:
        """
        For M>0: inner boundary approaches r=2M from above.
        For M<0: inner boundary approaches r=0 from above.
        Measures whether proper distance to inner boundary tends to infinity (complete-like) or stays finite (incomplete-like).
        """
        results: List[Dict[str, Any]] = []

        if self.M > 0.0:
            rh = 2.0 * self.M
            require(self.r0 > rh, "For M>0, require r0 > 2M to be in exterior f>0.")
            for eps in eps_list:
                require(eps > 0.0, "eps must be > 0.")
                r_in = rh * (1.0 + eps)
                d = self.proper_radial_distance(r_in, self.r0)
                results.append({
                    "epsilon": eps,
                    "r_inner": r_in,
                    "proper_distance_r0_to_r_inner": finite_or_none(d) if d is not None else None,
                })
            # heuristic: if distances increase strongly as eps decreases, report "diverges"
            distances = [x["proper_distance_r0_to_r_inner"] for x in results if x["proper_distance_r0_to_r_inner"] is not None]
            divergence_proxy = None
            if len(distances) >= 2:
                divergence_proxy = (distances[-1] - distances[0]) if (distances[0] is not None and distances[-1] is not None) else None
            return {
                "case": "M>0 (horizon present)",
                "inner_boundary": "r -> 2M^+",
                "epsilons": eps_list,
                "distance_samples": results,
                "interpretation": (
                    "For the standard exterior t=const slice, proper distance to r=2M diverges as epsilon->0; "
                    "inner end is infinitely far (completeness-consistent)."
                ),
                "divergence_proxy_delta": finite_or_none(divergence_proxy) if divergence_proxy is not None else None,
            }

        # M <= 0 case
        require(self.r0 > 0.0, "r0 must be > 0.")
        for eps in eps_list:
            require(eps > 0.0, "eps must be > 0.")
            r_in = eps
            d = self.proper_radial_distance(r_in, self.r0)
            results.append({
                "epsilon": eps,
                "r_inner": r_in,
                "proper_distance_r0_to_r_inner": finite_or_none(d) if d is not None else None,
            })

        distances = [x["proper_distance_r0_to_r_inner"] for x in results if x["proper_distance_r0_to_r_inner"] is not None]
        convergence_proxy = None
        if len(distances) >= 2:
            convergence_proxy = abs(distances[-1] - distances[0])
        return {
            "case": "M<=0 (no horizon; naked r=0 singularity if M<0)",
            "inner_boundary": "r -> 0^+",
            "epsilons": eps_list,
            "distance_samples": results,
            "interpretation": (
                "For negative-mass Schwarzschild, f(r)>0 for all r>0, but curvature diverges at r=0. "
                "Proper distance to r=0 is finite => geodesic incompleteness; PMT hypotheses fail here."
            ),
            "convergence_proxy_abs_delta": finite_or_none(convergence_proxy) if convergence_proxy is not None else None,
        }

    # Torus diagnostics
    def torus_curvature(self) -> Dict[str, float]:
        # Flat torus: all curvature invariants zero
        return {"ricci_scalar": 0.0, "kretschmann": 0.0}

    def torus_adm_mass(self) -> Optional[float]:
        # No asymptotic region; ADM undefined.
        return None

    def region_label_schw(self, r: float) -> str:
        if self.M > 0.0:
            rh = 2.0 * self.M
            if r > rh:
                return "exterior (r>2M)"
            if abs(r - rh) < 1e-12:
                return "horizon (r=2M)"
            return "interior (r<2M; f<0 in standard coords)"
        # M<=0: f(r)>0 for all r>0
        return "exterior-like (f>0 for all r>0); singularity at r=0"

    def sample_point_schwarzschild(self, r: float) -> Dict[str, Any]:
        inv = {
            "ricci_scalar": 0.0,
            "kretschmann": finite_or_none(self.kretschmann_schw(r)) if self.kretschmann_schw(r) is not None else None,
            "note": "Vacuum Schwarzschild: R=0; K=48 M^2/r^6 diverges as r->0 if M!=0.",
        }

        fr = None
        if r > 0.0:
            fr = self.f_schw(r)

        # ADM mass is defined for asymptotically flat Schwarzschild
        adm = self.adm_mass()

        # PMT applicability proxy: needs asymptotically flat + complete + R^(3)>=0
        # Here: asymptotically flat is true, R^(3)=0 is true, completeness depends on M sign.
        complete_proxy = True if self.M > 0.0 else False  # negative mass slice has finite distance to r=0 singularity

        pmt_applicable = True if (complete_proxy and self.scalar_curvature_spatial_time_symmetric() >= 0.0) else False

        local_obs = {
            "schwarzschild": {
                "M": self.M,
                "f_r": finite_or_none(fr) if fr is not None else None,
                "adm_mass_M_ADM": finite_or_none(adm) if adm is not None else None,
                "spatial_scalar_curvature_R3": self.scalar_curvature_spatial_time_symmetric(),
                "completeness_proxy": complete_proxy,
                "pmt_applicability_proxy": pmt_applicable,
                "note": (
                    "If PMT applicability proxy is false, negative ADM mass is not a theorem violation; "
                    "it indicates a hypothesis boundary (here: incompleteness due to r=0 singularity at finite distance)."
                ),
            }
        }

        causal = {
            "horizon_radius": finite_or_none(self.horizon()) if self.horizon() is not None else None,
            "region": self.region_label_schw(r),
        }

        return {
            "coordinates": {"case": "schwarzschild_t_const_slice", "t": None, "r": r, "theta": None, "phi": None},
            "curvature_invariants": inv,
            "local_observables": local_obs,
            "causal_structure": causal,
        }

    def sample_point_torus(self, x: float, y: float, z: float) -> Dict[str, Any]:
        curv = self.torus_curvature()

        local_obs = {
            "torus": {
                "L": self.torus_L,
                "adm_mass_M_ADM": None,
                "asymptotically_flat": False,
                "pmt_applicability_proxy": False,
                "note": "Compact flat space has no ADM mass; positivity is operationally undefined, not violated.",
            }
        }

        causal = {
            "global_topology": "T^3 (periodic in x,y,z)",
            "closed_spatial_loops": True,
        }

        return {
            "coordinates": {"case": "flat_3_torus", "x": x, "y": y, "z": z},
            "curvature_invariants": {
                "ricci_scalar": curv["ricci_scalar"],
                "kretschmann": curv["kretschmann"],
                "note": "Flat torus: invariants zero everywhere; topology is nontrivial.",
            },
            "local_observables": local_obs,
            "causal_structure": causal,
        }

    def build_payload(self, *, epsilons: List[float]) -> Dict[str, Any]:
        require(len(epsilons) >= 2, "Provide at least two epsilons to see divergence/convergence trend.")
        # Build sample points: Schwarzschild at provided r_samples, plus a few torus lattice points
        sample_points: List[Dict[str, Any]] = []

        for r in self.r_samples:
            sample_points.append(self.sample_point_schwarzschild(r))

        # Torus sample points (deterministic grid corners)
        L = self.torus_L
        torus_pts = [
            (0.0, 0.0, 0.0),
            (0.5 * L, 0.0, 0.0),
            (0.0, 0.5 * L, 0.0),
            (0.0, 0.0, 0.5 * L),
        ]
        for x, y, z in torus_pts:
            sample_points.append(self.sample_point_torus(x, y, z))

        # Completeness boundary measurement on Schwarzschild slice
        completeness = self.completeness_proxy(epsilons)

        # Summary flags
        pmt_applicable_proxy = True if (self.M > 0.0) else False
        adm = self.adm_mass()
        adm_positive = None
        if adm is not None:
            adm_positive = (adm >= 0.0)

        return {
            "toy_id": self.toy_id,
            "theory": "General Relativity (global energy theorem boundary: ADM mass positivity hypotheses)",
            "spacetime": "Schwarzschild (t=const spatial slice) + flat 3-torus (compact topology) comparator",
            "units": {"G": 1, "c": 1},
            "parameters": {
                "M": self.M,
                "r0_for_distance_test": self.r0,
                "r_samples": self.r_samples,
                "epsilons_for_inner_boundary_test": epsilons,
                "torus_L": self.torus_L,
                "integration_points": 200000,
            },
            "notes": {
                "pressure_point": (
                    "Positive mass statements depend on global hypotheses (asymptotic flatness + completeness + nonnegative scalar curvature). "
                    "Topology changes or incompleteness can make ADM mass undefined or allow negative values outside theorem scope."
                ),
                "key_formulas": {
                    "schwarzschild_f": "f(r)=1-2M/r",
                    "kretschmann": "K=48 M^2 / r^6",
                    "proper_distance_radial": "D=∫ dr/sqrt(f(r)) where f>0 on t=const slice",
                    "adm_mass_schwarzschild": "M_ADM = M",
                    "torus_adm": "ADM undefined on compact topology (no asymptotic region)",
                },
                "domain_of_validity": (
                    "Completeness test here is a proxy based on proper distance to inner boundary on the standard t=const slice. "
                    "This toy is about theorem applicability boundaries, not a full PMT proof engine."
                ),
            },
            "sample_points": sample_points,
            "observables": {
                "schwarzschild_summary": {
                    "adm_mass_M_ADM": finite_or_none(adm) if adm is not None else None,
                    "adm_mass_nonnegative": adm_positive,
                    "pmt_applicability_proxy": pmt_applicable_proxy,
                    "interpretation": (
                        "If M<0, negative ADM mass appears but completeness fails (finite distance to r=0 singularity), "
                        "so this is outside PMT hypotheses, not a counterexample."
                    ),
                },
                "completeness_boundary_measurement": completeness,
                "torus_summary": {
                    "adm_mass_M_ADM": None,
                    "asymptotically_flat": False,
                    "pmt_applicability_proxy": False,
                    "interpretation": "Compact topology removes ADM notion entirely; positivity is operationally undefined.",
                },
            },
        }

    def export_json(self, *, epsilons: List[float], out_path: Optional[str] = None) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)
        payload = self.build_payload(epsilons=epsilons)
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2, sort_keys=True)
        return out_path


def main() -> None:
    ap = argparse.ArgumentParser(description="Toy 081: Positive Mass Theorem boundary (hypothesis failure).")
    ap.add_argument("--M", type=float, default=1.0, help="Schwarzschild mass parameter M (can be negative to test hypothesis boundary).")
    ap.add_argument("--r0", type=float, default=10.0, help="Outer radius r0 used for proper-distance-to-inner-boundary test.")
    ap.add_argument("--r", type=str, default="10,6,4,3,2.5,2.1", help="Comma-separated areal radii for sample points.")
    ap.add_argument("--eps", type=str, default="1e-1,1e-2,1e-3,1e-4", help="Comma-separated epsilons for inner-boundary distance trend.")
    ap.add_argument("--torus_L", type=float, default=1.0, help="Side length for flat 3-torus samples (periodic box).")
    ap.add_argument("--out", type=str, default="", help="Optional output JSON path; default is <script>.json")
    args = ap.parse_args()

    r_samples = parse_csv_floats(args.r)
    epsilons = parse_csv_floats(args.eps)

    toy = Toy081PositiveMassBoundary(
        M=float(args.M),
        r0=float(args.r0),
        r_samples=r_samples,
        torus_L=float(args.torus_L),
    )

    out_path = args.out.strip() or None
    json_path = toy.export_json(epsilons=epsilons, out_path=out_path)

    print(f"Wrote {json_path}")
    print("Toy 081 complete: PMT boundary via completeness/asymptotic-flatness applicability tests exported.")


if __name__ == "__main__":
    main()
