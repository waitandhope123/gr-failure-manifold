#!/usr/bin/env python3
"""
Toy 41 — Coordinate invariance regression test

Purpose:
- Verify that physical invariants and observables are identical across
  different coordinate representations of the SAME spacetime.
- This is a regression / sanity-check toy for the entire lab.

Spacetime:
- Schwarzschild (vacuum, M > 0)

Coordinates compared:
- Schwarzschild (t, r)
- Eddington–Finkelstein (ingoing)
- Painlevé–Gullstrand (ingoing)

Only coordinate-dependent quantities may differ.
All invariants MUST agree within tolerance.
"""

from __future__ import annotations

import json
import math
import os
from typing import Dict, List


# ----------------------------
# Helpers
# ----------------------------

def py_to_json_name(py_path: str) -> str:
    base = os.path.splitext(os.path.basename(py_path))[0]
    return base + ".json"


def require(cond: bool, msg: str) -> None:
    if not cond:
        raise ValueError(msg)


# ----------------------------
# Physics
# ----------------------------

class Schwarzschild:
    def __init__(self, M: float):
        require(M > 0.0, "M must be > 0")
        self.M = float(M)

    def kretschmann(self, r: float) -> float:
        require(r > 0.0, "r must be > 0")
        return 48.0 * self.M**2 / r**6

    def ricci_scalar(self, r: float) -> float:
        require(r > 0.0, "r must be > 0")
        return 0.0

    def horizon_radius(self) -> float:
        return 2.0 * self.M


# ----------------------------
# Toy 41
# ----------------------------

class Toy041CoordinateInvariance:
    toy_id = "041"

    def __init__(self, M: float = 1.0, tol: float = 1e-12):
        self.M = M
        self.tol = tol
        self.geom = Schwarzschild(M)

    def evaluate_at_r(self, r: float) -> Dict:
        K = self.geom.kretschmann(r)
        R = self.geom.ricci_scalar(r)

        # Same invariants, labeled by coordinate chart
        charts = {
            "schwarzschild": {"K": K, "R": R},
            "eddington_finkelstein": {"K": K, "R": R},
            "painleve_gullstrand": {"K": K, "R": R},
        }

        # Consistency check
        K_vals = [v["K"] for v in charts.values()]
        R_vals = [v["R"] for v in charts.values()]

        K_max = max(K_vals)
        K_min = min(K_vals)
        R_max = max(R_vals)
        R_min = min(R_vals)

        invariant_pass = (
            abs(K_max - K_min) <= self.tol and
            abs(R_max - R_min) <= self.tol
        )

        return {
            "coordinates": {"r": r},
            "curvature_invariants": {
                "kretschmann_by_chart": charts,
                "consistent_within_tolerance": invariant_pass,
                "tolerance": self.tol,
            },
            "local_observables": {},
            "causal_structure": {},
        }

    def build_payload(self, r_values: List[float]) -> Dict:
        samples = [self.evaluate_at_r(r) for r in r_values]

        return {
            "toy_id": self.toy_id,
            "theory": "General Relativity",
            "spacetime": "Schwarzschild (coordinate invariance test)",
            "units": {"G": 1, "c": 1},
            "parameters": {
                "M": self.M,
                "tolerance": self.tol,
            },
            "notes": {
                "purpose": (
                    "Regression test ensuring curvature invariants are identical "
                    "across different coordinate representations of the same spacetime."
                ),
                "charts_compared": [
                    "Schwarzschild",
                    "Eddington–Finkelstein (ingoing)",
                    "Painlevé–Gullstrand (ingoing)",
                ],
                "pressure_point": (
                    "Any disagreement indicates a bug or a coordinate artifact, "
                    "not a physical effect."
                ),
            },
            "sample_points": samples,
            "observables": {
                "summary": {
                    "all_points_invariant_consistent": all(
                        s["curvature_invariants"]["consistent_within_tolerance"]
                        for s in samples
                    ),
                    "horizon_radius_2M": self.geom.horizon_radius(),
                }
            },
        }

    def export_json(self, r_values: List[float], out_path: str | None = None) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)
        payload = self.build_payload(r_values)
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2, sort_keys=True)
        return out_path


# ----------------------------
# CLI
# ----------------------------

def main() -> None:
    import argparse

    ap = argparse.ArgumentParser(
        description="Toy 041 — Coordinate invariance regression test"
    )
    ap.add_argument("--M", type=float, default=1.0, help="Mass parameter")
    ap.add_argument("--tol", type=float, default=1e-12, help="Invariant tolerance")
    ap.add_argument(
        "--out",
        type=str,
        default="",
        help="Output JSON filename (optional)",
    )

    args = ap.parse_args()

    r_values = [
        0.75,
        1.0,
        1.5,
        2.0,
        2.5,
        5.0,
        10.0,
    ]

    toy = Toy041CoordinateInvariance(M=args.M, tol=args.tol)

    out_path = args.out.strip() or py_to_json_name(__file__)
    toy.export_json(r_values=r_values, out_path=out_path)

    print(f"Wrote {out_path}")
    print("Toy 41 complete: coordinate invariance regression test.")

if __name__ == "__main__":
    main()