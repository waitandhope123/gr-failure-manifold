#!/usr/bin/env python3
"""
Toy 086 — Hyperbolicity / well-posedness failure (PDE-level breakdown)

What it probes (pressure point):
- A GR "failure mode" that is NOT curvature, horizons, or matter pathology:
  the evolution system can cease to be well-posed depending on formulation/gauge.
- Strong vs weak hyperbolicity:
  * Strongly hyperbolic systems have real characteristic speeds AND a complete eigenbasis.
  * Weakly hyperbolic (e.g., defective Jordan blocks) can exhibit high-frequency growth ~ |k| t,
    meaning arbitrarily small-scale perturbations blow up and the IVP is ill-posed.

Model:
- 1D constant-coefficient first-order system: u_t = A u_x
- Compare two formulations:
  (1) Strongly hyperbolic: A = [[1, 0],
                                [0,-1]]   (two real eigenvalues, diagonalizable)
  (2) Weakly hyperbolic:   A = [[1, 1],
                                [0, 1]]   (real eigenvalue with Jordan block; NOT diagonalizable)

Analysis method (exact, no placeholders):
- Plane-wave ansatz u ~ exp(i k x) gives ODE: d/dt u = i k A u
- Propagator: exp(i k A t)
  * Strongly hyperbolic: bounded operator norm (pure phase rotations)
  * Jordan block: exp(i k t) (I + i k t N) => operator norm grows ~ 1 + |k| t
- We export exact amplification norms vs (k,t), plus a resolution proxy:
  growth worsens with k_max ~ pi/dx as dx -> 0 (ill-posedness signature).

STRICT EXPORT RULE:
- Writes JSON named exactly like this .py file.
- JSON follows canonical schema; undefined quantities are null.
"""

from __future__ import annotations

import argparse
import json
import math
import os
from typing import Any, Dict, List, Optional, Tuple


# ----------------------------
# Helpers
# ----------------------------

def py_to_json_name(py_path: str) -> str:
    base = os.path.splitext(os.path.basename(py_path))[0]
    return base + ".json"


def parse_csv_floats(s: str) -> List[float]:
    return [float(x.strip()) for x in s.split(",") if x.strip()]


def require(cond: bool, msg: str) -> None:
    if not cond:
        raise ValueError(msg)


def matmul2(A: List[List[complex]], B: List[List[complex]]) -> List[List[complex]]:
    return [
        [A[0][0]*B[0][0] + A[0][1]*B[1][0], A[0][0]*B[0][1] + A[0][1]*B[1][1]],
        [A[1][0]*B[0][0] + A[1][1]*B[1][0], A[1][0]*B[0][1] + A[1][1]*B[1][1]],
    ]


def matvec2(A: List[List[complex]], v: List[complex]) -> List[complex]:
    return [
        A[0][0]*v[0] + A[0][1]*v[1],
        A[1][0]*v[0] + A[1][1]*v[1],
    ]


def conj_transpose2(A: List[List[complex]]) -> List[List[complex]]:
    return [
        [A[0][0].conjugate(), A[1][0].conjugate()],
        [A[0][1].conjugate(), A[1][1].conjugate()],
    ]


def opnorm2x2_exact(M: List[List[complex]]) -> float:
    """
    Exact spectral norm of a 2x2 matrix: sqrt(max eigenvalue of M* M).
    """
    MH = conj_transpose2(M)
    G = matmul2(MH, M)  # Hermitian positive semidefinite
    a = G[0][0].real
    d = G[1][1].real
    b = G[0][1]
    # Eigenvalues of [[a, b],[b*, d]] are:
    # λ = (a+d ± sqrt((a-d)^2 + 4|b|^2))/2
    disc = (a - d) * (a - d) + 4.0 * (abs(b) ** 2)
    lam_max = 0.5 * (a + d + math.sqrt(max(0.0, disc)))
    return math.sqrt(max(0.0, lam_max))


# ----------------------------
# Physics: formulations
# ----------------------------

class Formulation:
    def __init__(self, name: str, A: List[List[float]]) -> None:
        self.name = name
        self.A = [[float(A[0][0]), float(A[0][1])],
                  [float(A[1][0]), float(A[1][1])]]

    def eigen_info(self) -> Dict[str, Any]:
        """
        Compute eigenvalues and diagonalizability for 2x2 real A.
        For 2x2:
        - If discriminant < 0 => complex eigenvalues => not hyperbolic
        - If distinct real eigenvalues => diagonalizable
        - If repeated real eigenvalue:
            diagonalizable iff A is already scalar multiple of identity
            or has two independent eigenvectors (equivalently A == λI)
            (for 2x2 with repeated eigenvalue, non-diagonalizable occurs when A != λI)
        """
        a, b = self.A[0]
        c, d = self.A[1]
        tr = a + d
        det = a * d - b * c
        disc = tr * tr - 4.0 * det

        if disc < 0.0:
            # complex pair
            return {
                "eigenvalues": [None, None],
                "discriminant": disc,
                "has_real_characteristics": False,
                "diagonalizable": False,
                "strongly_hyperbolic": False,
                "weakly_hyperbolic": False,
            }

        sqrt_disc = math.sqrt(max(0.0, disc))
        lam1 = 0.5 * (tr + sqrt_disc)
        lam2 = 0.5 * (tr - sqrt_disc)

        if abs(lam1 - lam2) > 1e-14:
            # distinct real
            return {
                "eigenvalues": [lam1, lam2],
                "discriminant": disc,
                "has_real_characteristics": True,
                "diagonalizable": True,
                "strongly_hyperbolic": True,
                "weakly_hyperbolic": False,
            }

        # repeated eigenvalue
        lam = lam1
        # diagonalizable iff A == lam I for 2x2 repeated-eigenvalue case
        diagonalizable = (abs(a - lam) < 1e-14 and abs(d - lam) < 1e-14 and abs(b) < 1e-14 and abs(c) < 1e-14)
        return {
            "eigenvalues": [lam, lam],
            "discriminant": disc,
            "has_real_characteristics": True,
            "diagonalizable": diagonalizable,
            "strongly_hyperbolic": diagonalizable,
            "weakly_hyperbolic": (not diagonalizable),
        }

    def propagator(self, k: float, t: float) -> List[List[complex]]:
        """
        Return exp(i k A t) exactly for the two built-in A types we use here:
        - diagonal A (strong) : A = diag(1, -1)
        - Jordan A  (weak)    : A = [[1,1],[0,1]]

        If a different A is provided, we fall back to a safe 2x2 series with tight cap,
        but this toy is intended for the above canonical forms.
        """
        require(t >= 0.0, "t must be >= 0.")
        w = 1j * k * t

        A = self.A
        # Detect diag(1,-1)
        if abs(A[0][0] - 1.0) < 1e-15 and abs(A[1][1] + 1.0) < 1e-15 and abs(A[0][1]) < 1e-15 and abs(A[1][0]) < 1e-15:
            return [
                [complex(math.cos(k*t), math.sin(k*t)), 0j],
                [0j, complex(math.cos(-k*t), math.sin(-k*t))],  # e^{-i k t}
            ]

        # Detect Jordan [[1,1],[0,1]]
        if abs(A[0][0] - 1.0) < 1e-15 and abs(A[1][1] - 1.0) < 1e-15 and abs(A[1][0]) < 1e-15 and abs(A[0][1] - 1.0) < 1e-15:
            # A = I + N where N = [[0,1],[0,0]], N^2=0
            # exp(i k t A) = exp(i k t) * exp(i k t N) = exp(i k t) * (I + i k t N)
            phase = complex(math.cos(k*t), math.sin(k*t))
            return [
                [phase, phase * (1j * k * t)],
                [0j,    phase],
            ]

        # Fallback: truncated series exp(w A) with scaling (conservative, deterministic)
        # This is NOT the main point of the toy; intended A should match above.
        Af = [[complex(A[0][0]), complex(A[0][1])],
              [complex(A[1][0]), complex(A[1][1])]]
        I = [[1+0j, 0j], [0j, 1+0j]]
        # exp(wA) = sum_{n=0}^N (wA)^n / n!
        N = 60
        term = I
        S = [[1+0j, 0j], [0j, 1+0j]]
        for n in range(1, N+1):
            term = matmul2(term, [[w*Af[0][0], w*Af[0][1]], [w*Af[1][0], w*Af[1][1]]])
            inv_fact = 1.0 / math.factorial(n)
            S = [
                [S[0][0] + term[0][0]*inv_fact, S[0][1] + term[0][1]*inv_fact],
                [S[1][0] + term[1][0]*inv_fact, S[1][1] + term[1][1]*inv_fact],
            ]
        return S


# ----------------------------
# Toy 086
# ----------------------------

class Toy086HyperbolicityFailure:
    toy_id = "086"

    def __init__(self) -> None:
        # Canonical pair
        self.formulations = [
            Formulation("strongly_hyperbolic", [[1.0, 0.0],
                                                [0.0, -1.0]]),
            Formulation("weakly_hyperbolic_jordan", [[1.0, 1.0],
                                                     [0.0, 1.0]]),
        ]

    def amplification_norm(self, F: Formulation, k: float, t: float) -> float:
        U = F.propagator(k=k, t=t)
        return opnorm2x2_exact(U)

    def build_payload(
        self,
        k_values: List[float],
        t_values: List[float],
        dx_values: List[float],
    ) -> Dict[str, Any]:
        sample_points: List[Dict[str, Any]] = []

        # For resolution proxy, interpret k_max ~ pi/dx (highest resolvable mode)
        # Ill-posedness signature: amplification grows without bound as dx->0 for fixed t.
        for F in self.formulations:
            einfo = F.eigen_info()
            eigs = einfo["eigenvalues"]

            for t in t_values:
                for k in k_values:
                    amp = self.amplification_norm(F, k=k, t=t)

                    # A minimal "high-frequency growth proxy":
                    # compare amp at k vs amp at 2k (if possible)
                    amp2 = self.amplification_norm(F, k=2.0*k, t=t) if k != 0.0 else amp
                    hf_growth_ratio = (amp2 / amp) if (amp is not None and amp != 0.0) else None

                    sample_points.append({
                        "coordinates": {
                            "formulation": F.name,
                            "t": float(t),
                            "k": float(k),
                        },
                        "curvature_invariants": {
                            "ricci_scalar": None,
                            "kretschmann": None,
                        },
                        "local_observables": {
                            "system_matrix_A": {
                                "a11": F.A[0][0],
                                "a12": F.A[0][1],
                                "a21": F.A[1][0],
                                "a22": F.A[1][1],
                            },
                            "fourier_mode_diagnostics": {
                                "propagator_opnorm": amp,
                                "high_frequency_growth_ratio_amp_2k_over_amp_k": hf_growth_ratio,
                                "note": (
                                    "For weakly hyperbolic Jordan form, opnorm grows ~ 1 + |k| t, "
                                    "so increasing k (or resolution) worsens amplification."
                                ),
                            },
                        },
                        "causal_structure": {
                            "characteristic_speeds": eigs,
                            "has_real_characteristics": einfo["has_real_characteristics"],
                            "diagonalizable": einfo["diagonalizable"],
                            "strongly_hyperbolic": einfo["strongly_hyperbolic"],
                            "weakly_hyperbolic": einfo["weakly_hyperbolic"],
                            "well_posed_ivp": bool(einfo["strongly_hyperbolic"]),
                        },
                    })

        # Resolution proxy summary at fixed t using k_max ~ pi/dx
        # Evaluate both formulations at k_max for each dx and each t
        resolution_table: List[Dict[str, Any]] = []
        for F in self.formulations:
            einfo = F.eigen_info()
            for t in t_values:
                for dx in dx_values:
                    require(dx > 0.0, "dx must be > 0.")
                    k_max = math.pi / dx
                    amp_max = self.amplification_norm(F, k=k_max, t=t)
                    resolution_table.append({
                        "formulation": F.name,
                        "t": float(t),
                        "dx": float(dx),
                        "k_max_pi_over_dx": k_max,
                        "propagator_opnorm_at_k_max": amp_max,
                        "well_posed_ivp": bool(einfo["strongly_hyperbolic"]),
                    })

        # Aggregate summaries
        summaries: Dict[str, Any] = {}
        for F in self.formulations:
            einfo = F.eigen_info()
            # worst amplification over scanned k,t
            amps = [
                sp["local_observables"]["fourier_mode_diagnostics"]["propagator_opnorm"]
                for sp in sample_points
                if sp["coordinates"]["formulation"] == F.name
            ]
            summaries[F.name] = {
                "strongly_hyperbolic": einfo["strongly_hyperbolic"],
                "weakly_hyperbolic": einfo["weakly_hyperbolic"],
                "well_posed_ivp": bool(einfo["strongly_hyperbolic"]),
                "max_propagator_opnorm_over_samples": max(amps) if amps else None,
            }

        payload: Dict[str, Any] = {
            "toy_id": self.toy_id,
            "theory": "General Relativity (numerical formulation diagnostic proxy)",
            "spacetime": "1D first-order evolution system (hyperbolicity / well-posedness proxy)",
            "units": {"G": 1, "c": 1},
            "parameters": {
                "system": "u_t = A u_x (Fourier analysis)",
                "formulations": [
                    {"name": self.formulations[0].name, "A": self.formulations[0].A},
                    {"name": self.formulations[1].name, "A": self.formulations[1].A},
                ],
                "k_values": k_values,
                "t_values": t_values,
                "dx_values": dx_values,
                "k_max_rule": "k_max ~ pi/dx",
            },
            "notes": {
                "purpose": (
                    "Expose a non-curvature GR failure mode: formulation-dependent loss of well-posedness. "
                    "Weakly hyperbolic systems can amplify arbitrarily high-frequency content, making the IVP ill-posed."
                ),
                "pressure_point": (
                    "If the PDE formulation is not strongly hyperbolic, refinement (dx->0) can worsen behavior: "
                    "a signature of ill-posedness rather than 'physical instability'."
                ),
                "exact_result": (
                    "Jordan block case yields exp(i k t A) = exp(i k t) * (I + i k t N), so operator norm grows ~ 1 + |k| t."
                ),
            },
            "sample_points": sample_points,
            "observables": {
                "summary": summaries,
                "resolution_proxy": resolution_table,
            },
        }
        return payload

    def export_json(
        self,
        k_values: List[float],
        t_values: List[float],
        dx_values: List[float],
        out_path: Optional[str] = None,
    ) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)
        payload = self.build_payload(k_values=k_values, t_values=t_values, dx_values=dx_values)
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2, sort_keys=True)
        return out_path


# ----------------------------
# CLI
# ----------------------------

def main() -> None:
    ap = argparse.ArgumentParser(description="Toy 086: Hyperbolicity / well-posedness failure diagnostic.")
    ap.add_argument("--k", type=str, default="0,1,2,5,10,20,50",
                    help="Comma-separated Fourier wavenumbers k to sample.")
    ap.add_argument("--t", type=str, default="0,0.1,0.5,1,2",
                    help="Comma-separated times t>=0 to sample.")
    ap.add_argument("--dx", type=str, default="0.5,0.25,0.125,0.0625",
                    help="Comma-separated grid spacings dx>0 for resolution proxy (k_max ~ pi/dx).")
    ap.add_argument("--out", type=str, default="",
                    help="Optional output path. If omitted, uses <this_script_name>.json")
    args = ap.parse_args()

    k_values = parse_csv_floats(args.k)
    t_values = parse_csv_floats(args.t)
    dx_values = parse_csv_floats(args.dx)

    for t in t_values:
        require(t >= 0.0, "All t must be >= 0.")
    for dx in dx_values:
        require(dx > 0.0, "All dx must be > 0.")

    toy = Toy086HyperbolicityFailure()
    out_path = args.out.strip() or None
    json_path = toy.export_json(k_values=k_values, t_values=t_values, dx_values=dx_values, out_path=out_path)

    print(f"Wrote {json_path}")
    print("Toy 086 complete: hyperbolicity / well-posedness failure diagnostic.")


if __name__ == "__main__":
    main()
