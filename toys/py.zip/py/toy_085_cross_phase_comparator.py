#!/usr/bin/env python3
"""
Toy 085 — Cross-phase comparator: failure density + phase diagram from toy JSON outputs

Classification (lab axes):
- Failure Trigger: meta / benchmarking
- Failure Mode: operational_undefined (without comparators, coverage is qualitative)
- Failure Sharpness: contextual
- Repairable Within Classical GR: yes (this repairs the lab instrument)

What it probes (pressure point):
- As the lab grows, you need instrumented summaries:
  * schema compliance
  * undefined/null density (how often quantities become non-operational)
  * mode keyword phase diagrams (how failure modes distribute across toy IDs/phases)

Inputs:
- A directory or glob of toy JSON files exported by other toys in this lab.

Core idea:
- Parse each toy JSON (strict schema expected).
- Compute:
  1) schema compliance (missing required top-level keys)
  2) leaf null fraction ("failure density" proxy)
  3) keyword hits for standard failure modes (string scan across payload)
  4) phase binning by toy_id number (default: phase = floor((id-1)/10)+1)

Outputs:
- Strict lab JSON schema, with one sample_point per input toy JSON.
- Optionally also writes PNG plots (disabled by default to keep exports JSON-only by default).

Determinism:
- Files are processed in sorted order.
- No randomness.
"""

from __future__ import annotations

import argparse
import glob
import json
import math
import os
from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Tuple

import numpy as np


# ----------------------------
# Helpers
# ----------------------------

REQUIRED_TOP_LEVEL_KEYS = [
    "toy_id",
    "theory",
    "spacetime",
    "units",
    "parameters",
    "notes",
    "sample_points",
    "observables",
]

DEFAULT_MODE_KEYWORDS = [
    "observer_disagreement",
    "predictability_loss",
    "invariant_divergence",
    "energy_nonconservation",
    "operational_undefined",
    "constraint_violation",
    "ensemble_spread",
]


def py_to_json_name(py_path: str) -> str:
    base = os.path.splitext(os.path.basename(py_path))[0]
    return base + ".json"


def require(cond: bool, msg: str) -> None:
    if not cond:
        raise ValueError(msg)


def finite_or_none(x: float) -> Optional[float]:
    return x if (isinstance(x, (int, float)) and math.isfinite(x)) else None


def safe_int_from_toy_id(toy_id: Any) -> Optional[int]:
    try:
        s = str(toy_id).strip()
        # allow "081", "81", "toy_081", etc.
        digits = "".join(ch for ch in s if ch.isdigit())
        if digits == "":
            return None
        return int(digits)
    except Exception:
        return None


def infer_phase(toy_num: Optional[int], phase_size: int = 10) -> Optional[int]:
    if toy_num is None or toy_num <= 0:
        return None
    return ((toy_num - 1) // phase_size) + 1


def stringify_payload(x: Any, limit_chars: int = 2_000_000) -> str:
    """
    Deterministically stringify a JSON-like object for keyword scans.
    Limit avoids pathological huge strings.
    """
    try:
        s = json.dumps(x, sort_keys=True, ensure_ascii=False)
    except Exception:
        s = str(x)
    if len(s) > limit_chars:
        return s[:limit_chars]
    return s


def iter_leaves(x: Any) -> List[Any]:
    """
    Return all leaf values in nested dict/list structures.
    Leaf = not a dict/list.
    """
    leaves: List[Any] = []
    stack = [x]
    while stack:
        cur = stack.pop()
        if isinstance(cur, dict):
            for v in cur.values():
                stack.append(v)
        elif isinstance(cur, list):
            for v in cur:
                stack.append(v)
        else:
            leaves.append(cur)
    return leaves


def leaf_null_fraction(payload: Dict[str, Any]) -> Tuple[Optional[float], int, int]:
    """
    Count leaves and null leaves across the entire payload.
    null leaf = None
    Returns (null_fraction, null_count, leaf_count)
    """
    leaves = iter_leaves(payload)
    leaf_count = len(leaves)
    if leaf_count == 0:
        return None, 0, 0
    null_count = sum(1 for v in leaves if v is None)
    return null_count / leaf_count, null_count, leaf_count


def schema_missing_keys(payload: Dict[str, Any]) -> List[str]:
    missing = [k for k in REQUIRED_TOP_LEVEL_KEYS if k not in payload]
    return missing


def keyword_hits(payload: Dict[str, Any], keywords: List[str]) -> Dict[str, int]:
    s = stringify_payload(payload).lower()
    hits: Dict[str, int] = {}
    for kw in keywords:
        hits[kw] = s.count(kw.lower())
    return hits


# ----------------------------
# Optional plotting (off by default)
# ----------------------------

def maybe_make_plots(
    *,
    out_prefix: str,
    rows: List[Dict[str, Any]],
    mode_keywords: List[str],
    phase_size: int,
    make_plots: bool,
) -> List[str]:
    """
    If make_plots, write a couple of PNGs:
    - null_fraction_by_toy.png
    - mode_heatmap_by_phase.png
    Returns list of written plot paths.
    """
    if not make_plots:
        return []

    # Import matplotlib lazily
    import matplotlib.pyplot as plt  # noqa: F401

    written: List[str] = []

    # Plot 1: null fraction by toy number (sorted)
    rows_sorted = sorted(rows, key=lambda r: (r.get("toy_number") is None, r.get("toy_number", 10**9), r.get("path", "")))
    xs = [r.get("toy_number", None) for r in rows_sorted]
    ys = [r.get("null_fraction", None) for r in rows_sorted]

    # Filter None
    x_f = []
    y_f = []
    for x, y in zip(xs, ys):
        if x is not None and y is not None:
            x_f.append(x)
            y_f.append(y)

    if len(x_f) >= 1:
        plt.figure()
        plt.plot(x_f, y_f, marker="o")
        plt.xlabel("toy_number")
        plt.ylabel("leaf_null_fraction")
        plt.title("Failure density proxy: null fraction by toy")
        p1 = f"{out_prefix}_null_fraction_by_toy.png"
        plt.tight_layout()
        plt.savefig(p1, dpi=160)
        plt.close()
        written.append(p1)

    # Plot 2: mode heatmap by phase (counts of toys with >=1 hit in that phase)
    phase_ids = sorted({r.get("phase") for r in rows if r.get("phase") is not None})
    if len(phase_ids) >= 1:
        M = np.zeros((len(phase_ids), len(mode_keywords)), dtype=float)
        for i, ph in enumerate(phase_ids):
            phase_rows = [r for r in rows if r.get("phase") == ph]
            for j, kw in enumerate(mode_keywords):
                # count toys in phase with any hit
                M[i, j] = float(sum(1 for rr in phase_rows if rr.get("mode_presence", {}).get(kw, False)))

        import matplotlib.pyplot as plt
        plt.figure()
        plt.imshow(M, aspect="auto")
        plt.yticks(range(len(phase_ids)), [str(p) for p in phase_ids])
        plt.xticks(range(len(mode_keywords)), mode_keywords, rotation=45, ha="right")
        plt.xlabel("failure_mode_keyword")
        plt.ylabel(f"phase (size={phase_size})")
        plt.title("Mode presence by phase (keyword proxy)")
        plt.tight_layout()
        p2 = f"{out_prefix}_mode_heatmap_by_phase.png"
        plt.savefig(p2, dpi=160)
        plt.close()
        written.append(p2)

    return written


# ----------------------------
# Toy 085
# ----------------------------

@dataclass
class ToyRow:
    path: str
    toy_id: Optional[str]
    toy_number: Optional[int]
    phase: Optional[int]
    missing_keys: List[str]
    null_fraction: Optional[float]
    null_count: int
    leaf_count: int
    keyword_hits: Dict[str, int]


class Toy085CrossPhaseComparator:
    toy_id = "085"

    def __init__(self, *, paths: List[str], mode_keywords: List[str], phase_size: int) -> None:
        require(len(paths) >= 1, "Need at least one JSON file path.")
        require(phase_size >= 1, "phase_size must be >= 1")
        self.paths = paths
        self.mode_keywords = mode_keywords
        self.phase_size = phase_size

    def load_one(self, path: str) -> Optional[Dict[str, Any]]:
        try:
            with open(path, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            return None

    def analyze_one(self, path: str) -> ToyRow:
        payload = self.load_one(path)
        if payload is None or not isinstance(payload, dict):
            return ToyRow(
                path=path,
                toy_id=None,
                toy_number=None,
                phase=None,
                missing_keys=REQUIRED_TOP_LEVEL_KEYS[:],
                null_fraction=None,
                null_count=0,
                leaf_count=0,
                keyword_hits={kw: 0 for kw in self.mode_keywords},
            )

        toy_id = payload.get("toy_id", None)
        toy_num = safe_int_from_toy_id(toy_id)
        ph = infer_phase(toy_num, self.phase_size)

        missing = schema_missing_keys(payload)
        nf, nc, lc = leaf_null_fraction(payload)
        hits = keyword_hits(payload, self.mode_keywords)

        return ToyRow(
            path=path,
            toy_id=str(toy_id) if toy_id is not None else None,
            toy_number=toy_num,
            phase=ph,
            missing_keys=missing,
            null_fraction=nf,
            null_count=nc,
            leaf_count=lc,
            keyword_hits=hits,
        )

    def build_payload(
        self,
        *,
        make_plots: bool,
        plots_prefix: str,
    ) -> Dict[str, Any]:
        rows = [self.analyze_one(p) for p in sorted(self.paths)]

        # Aggregate
        n_files = len(rows)
        n_parse_fail = sum(1 for r in rows if r.toy_id is None)
        n_schema_ok = sum(1 for r in rows if len(r.missing_keys) == 0)

        # Null density stats (over valid nf)
        nfs = [r.null_fraction for r in rows if r.null_fraction is not None]
        null_mean = float(np.mean(nfs)) if len(nfs) else None
        null_median = float(np.median(nfs)) if len(nfs) else None
        null_max = float(np.max(nfs)) if len(nfs) else None
        null_min = float(np.min(nfs)) if len(nfs) else None

        # Mode presence (binary) per toy
        mode_presence_rows: List[Dict[str, bool]] = []
        for r in rows:
            mode_presence_rows.append({kw: (r.keyword_hits.get(kw, 0) > 0) for kw in self.mode_keywords})

        # Phase diagram counts: phase x mode -> count of toys with presence
        phases = sorted({r.phase for r in rows if r.phase is not None})
        phase_mode_counts: Dict[str, Dict[str, int]] = {}
        for ph in phases:
            phase_mode_counts[str(ph)] = {}
            phase_rows = [rr for rr in rows if rr.phase == ph]
            for kw in self.mode_keywords:
                phase_mode_counts[str(ph)][kw] = int(sum(1 for rr in phase_rows if rr.keyword_hits.get(kw, 0) > 0))

        # Build sample_points: one per toy file
        sample_points: List[Dict[str, Any]] = []
        row_dicts_for_plots: List[Dict[str, Any]] = []
        for r, mp in zip(rows, mode_presence_rows):
            sample_points.append({
                "coordinates": {
                    "path": r.path,
                    "toy_id": r.toy_id,
                    "toy_number": r.toy_number,
                    "phase": r.phase,
                },
                "curvature_invariants": {
                    "ricci_scalar": None,
                    "kretschmann": None,
                    "note": "Comparator toy: curvature not computed; analyzes exported toy JSON structure and undefined/null density.",
                },
                "local_observables": {
                    "schema": {
                        "missing_required_top_level_keys": r.missing_keys,
                        "schema_ok": (len(r.missing_keys) == 0),
                    },
                    "failure_density_proxy": {
                        "leaf_count": r.leaf_count,
                        "null_count": r.null_count,
                        "null_fraction": finite_or_none(r.null_fraction) if r.null_fraction is not None else None,
                        "note": "Null fraction is a proxy for operational undefinedness / regime exit across the payload.",
                    },
                    "mode_keyword_hits": r.keyword_hits,
                },
                "causal_structure": {
                    "mode_presence": mp,
                    "note": "Mode presence uses keyword proxy scan over payload text; explicit mode tags are recommended for higher fidelity.",
                },
            })
            row_dicts_for_plots.append({
                "path": r.path,
                "toy_number": r.toy_number,
                "phase": r.phase,
                "null_fraction": r.null_fraction,
                "mode_presence": mp,
            })

        plot_paths = maybe_make_plots(
            out_prefix=plots_prefix,
            rows=row_dicts_for_plots,
            mode_keywords=self.mode_keywords,
            phase_size=self.phase_size,
            make_plots=make_plots,
        )

        # Coverage gaps: modes never seen
        total_mode_counts = {kw: int(sum(1 for r in rows if r.keyword_hits.get(kw, 0) > 0)) for kw in self.mode_keywords}
        never_seen = [kw for kw, c in total_mode_counts.items() if c == 0]

        return {
            "toy_id": self.toy_id,
            "theory": "Meta-analysis tool for GR Toy Lab JSON outputs (benchmarking and comparators)",
            "spacetime": "Not a spacetime: parses exported toy JSON and computes failure-density / mode-distribution diagnostics",
            "units": {"G": 1, "c": 1},
            "parameters": {
                "input_files": sorted(self.paths),
                "mode_keywords": self.mode_keywords,
                "phase_size": self.phase_size,
                "plots_enabled": make_plots,
                "plots_written": plot_paths,
            },
            "notes": {
                "pressure_point": (
                    "A large toy suite needs comparators: otherwise 'coverage' is qualitative. "
                    "This toy quantifies undefinedness (null density), schema compliance, and mode keyword distribution by phase."
                ),
                "recommended_next_step": (
                    "Add explicit failure-axis tags into each toy JSON under notes (e.g., notes.failure_axes) "
                    "to replace keyword proxies with exact categorical counts."
                ),
            },
            "sample_points": sample_points,
            "observables": {
                "summary": {
                    "n_files": n_files,
                    "n_parse_failures": n_parse_fail,
                    "n_schema_ok": n_schema_ok,
                    "null_fraction_mean": finite_or_none(null_mean) if null_mean is not None else None,
                    "null_fraction_median": finite_or_none(null_median) if null_median is not None else None,
                    "null_fraction_min": finite_or_none(null_min) if null_min is not None else None,
                    "null_fraction_max": finite_or_none(null_max) if null_max is not None else None,
                    "mode_total_presence_counts": total_mode_counts,
                    "modes_never_seen": never_seen,
                },
                "phase_diagram_keyword_presence": phase_mode_counts,
            },
        }

    def export_json(self, *, make_plots: bool, plots_prefix: str, out_path: Optional[str] = None) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)
        payload = self.build_payload(make_plots=make_plots, plots_prefix=plots_prefix)
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2, sort_keys=True)
        return out_path


# ----------------------------
# CLI
# ----------------------------

def main() -> None:
    ap = argparse.ArgumentParser(description="Toy 085: cross-phase comparator for GR Toy Lab JSON outputs.")
    ap.add_argument(
        "--glob",
        type=str,
        default="toy_*.json",
        help="Glob pattern for input toy JSON files (default: toy_*.json).",
    )
    ap.add_argument(
        "--mode_keywords",
        type=str,
        default=",".join(DEFAULT_MODE_KEYWORDS),
        help="Comma-separated keyword list for failure-mode presence scanning.",
    )
    ap.add_argument(
        "--phase_size",
        type=int,
        default=10,
        help="Phase bin size from toy_number (default 10 => phase=floor((id-1)/10)+1).",
    )
    ap.add_argument(
        "--plots",
        action="store_true",
        help="If set, also write PNG plots (null fraction and phase heatmap) alongside JSON.",
    )
    ap.add_argument(
        "--plots_prefix",
        type=str,
        default="toy_085",
        help="Prefix for plot filenames if --plots is enabled.",
    )
    ap.add_argument("--out", type=str, default="", help="Optional output JSON path; default is <script>.json")
    args = ap.parse_args()

    paths = [p for p in glob.glob(args.glob) if os.path.isfile(p)]
    require(len(paths) >= 1, f"No files matched glob: {args.glob}")

    mode_keywords = [x.strip() for x in args.mode_keywords.split(",") if x.strip()]
    require(len(mode_keywords) >= 1, "Need at least one mode keyword.")

    toy = Toy085CrossPhaseComparator(paths=paths, mode_keywords=mode_keywords, phase_size=int(args.phase_size))

    out_path = args.out.strip() or None
    json_path = toy.export_json(make_plots=bool(args.plots), plots_prefix=str(args.plots_prefix), out_path=out_path)

    print(f"Wrote {json_path}")
    if args.plots:
        print("Plots were enabled; see PNGs with the given prefix.")
    print("Toy 085 complete: comparator exported.")


if __name__ == "__main__":
    main()
