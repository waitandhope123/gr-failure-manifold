#!/usr/bin/env python3
"""
Toy 053 — Anisotropic-stress TOV star (p_r != p_t) and compactness / horizon proximity

What it probes (weak points / pressure points):
- Perfect-fluid intuition can fail: anisotropy (p_t - p_r) changes support against gravity,
  surface radius, compactness, and near-trapping behavior even with the same EOS family.
- "Collapse / horizon formation" diagnostics depend on matter model assumptions, not just geometry.

Model (G=c=1):
- Static, spherically symmetric star with anisotropic stress.
- Metric: ds^2 = -e^{nu(r)} dt^2 + (1 - 2m(r)/r)^{-1} dr^2 + r^2 dΩ^2
- Anisotropic TOV system:
    dm/dr   = 4π r^2 ρ
    dp_r/dr = -(ρ + p_r)(m + 4π r^3 p_r) / (r (r - 2m)) + 2Δ/r
    dnu/dr  = 2 (m + 4π r^3 p_r) / (r (r - 2m))
  where Δ(r) := p_t - p_r is the anisotropy.

Closure (simple controlled EOS + anisotropy ansatz):
- EOS: p_r = w ρ  (constant w in (0,1], so ρ = p_r / w)
- Anisotropy: Δ(r) = alpha * p_r * (r^2 / r0^2)
  (regular at r=0; increases with r; sign of alpha controls tangential vs radial dominance)

Surface:
- Integrate outward from small r=eps until p_r falls to ~0 (surface) or r reaches r_max.
- Match to exterior Schwarzschild at surface:
    e^{nu(R)} = 1 - 2M/R   (apply a constant shift to nu profile after integration)

Curvature diagnostics:
- Ricci scalar from stress-energy trace:
    T = -ρ + p_r + 2 p_t  =>  R = -8π T = 8π (ρ - p_r - 2 p_t)
- Vacuum-like Kretschmann proxy (exact outside; heuristic inside):
    K_proxy = 48 m(r)^2 / r^6

Exports:
- Radial profiles at sample radii, plus global observables (M, R, compactness, redshift).
"""

from __future__ import annotations

import argparse
import json
import math
import os
from typing import Any, Dict, List, Optional, Tuple


# ----------------------------
# Helpers
# ----------------------------

def py_to_json_name(py_path: str) -> str:
    base = os.path.splitext(os.path.basename(py_path))[0]
    return base + ".json"


def require(cond: bool, msg: str) -> None:
    if not cond:
        raise ValueError(msg)


def finite_or_none(x: float) -> Optional[float]:
    return x if math.isfinite(x) else None


# ----------------------------
# Toy 053
# ----------------------------

class Toy053AnisotropicTOV:
    toy_id = "053"

    def __init__(
        self,
        *,
        p_c: float = 1e-3,
        w: float = 0.2,
        alpha: float = 0.0,
        r0: float = 10.0,
        dr: float = 1e-2,
        r_max: float = 50.0,
        p_floor: float = 1e-12,
    ) -> None:
        require(p_c > 0.0, "p_c must be > 0.")
        require(0.0 < w <= 1.0, "w must be in (0,1].")
        require(r0 > 0.0, "r0 must be > 0.")
        require(dr > 0.0, "dr must be > 0.")
        require(r_max > 0.0, "r_max must be > 0.")
        require(p_floor > 0.0, "p_floor must be > 0.")
        self.p_c = float(p_c)
        self.w = float(w)
        self.alpha = float(alpha)
        self.r0 = float(r0)
        self.dr = float(dr)
        self.r_max = float(r_max)
        self.p_floor = float(p_floor)

    # EOS
    def rho_from_pr(self, p_r: float) -> float:
        # p_r = w ρ => ρ = p_r / w
        return p_r / self.w

    # Anisotropy Δ = p_t - p_r
    def delta(self, r: float, p_r: float) -> float:
        return self.alpha * p_r * (r * r) / (self.r0 * self.r0)

    def pt_from_pr(self, r: float, p_r: float) -> float:
        return p_r + self.delta(r, p_r)

    # ODE right-hand sides
    def rhs(self, r: float, m: float, p_r: float, nu: float) -> Tuple[float, float, float]:
        """
        Returns (dm/dr, dp_r/dr, dnu/dr).
        """
        if r <= 0.0:
            return (0.0, 0.0, 0.0)

        rho = self.rho_from_pr(p_r)
        dm = 4.0 * math.pi * r * r * rho

        denom = r * (r - 2.0 * m)
        if denom <= 0.0:
            # Approaching/inside a trapped region in these coordinates; flag elsewhere
            dp = float("nan")
            dnu = float("nan")
            return (dm, dp, dnu)

        dnu = 2.0 * (m + 4.0 * math.pi * r**3 * p_r) / denom

        Delta = self.delta(r, p_r)
        dp = -(rho + p_r) * (m + 4.0 * math.pi * r**3 * p_r) / denom + 2.0 * Delta / r

        return (dm, dp, dnu)

    def integrate(self) -> Dict[str, Any]:
        """
        Integrate from small epsilon outward until p_r hits ~0 or r_max.
        Uses RK4.
        """
        eps = max(1e-6, 0.1 * self.dr)
        r = eps
        m = 0.0
        p = self.p_c
        nu = 0.0  # will shift after matching at surface

        grid: List[Dict[str, float]] = []

        # Store initial point (at eps)
        def record() -> None:
            rho = self.rho_from_pr(p)
            pt = self.pt_from_pr(r, p)
            Delta = pt - p
            denom = r * (r - 2.0 * m)
            trapped = (r <= 2.0 * m)  # local trapped-surface indicator
            # Ricci scalar from trace T = -rho + p_r + 2 p_t  => R = -8πT
            R = 8.0 * math.pi * (rho - p - 2.0 * pt)
            # Vacuum Kretschmann proxy (exact exterior; heuristic interior)
            K_proxy = 48.0 * (m * m) / (r**6) if r > 0.0 else float("nan")
            grid.append({
                "r": r,
                "m": m,
                "p_r": p,
                "rho": rho,
                "p_t": pt,
                "Delta": Delta,
                "nu_raw": nu,
                "ricci_scalar_R": R,
                "kretschmann_proxy": K_proxy,
                "compactness_2m_over_r": (2.0 * m / r) if r > 0.0 else float("nan"),
                "denom_r_rminus2m": denom,
                "trapped_indicator": 1.0 if trapped else 0.0,
            })

        record()

        surfaced = False
        trapped_reached = False

        while r < self.r_max:
            if p <= self.p_floor:
                surfaced = True
                break

            if r <= 2.0 * m:
                trapped_reached = True
                # stop here: coordinates break down / star is beyond Buchdahl-like limits in this model
                break

            # RK4 step for (m, p, nu)
            dm1, dp1, dnu1 = self.rhs(r, m, p, nu)
            dm2, dp2, dnu2 = self.rhs(r + 0.5*self.dr, m + 0.5*self.dr*dm1, p + 0.5*self.dr*dp1, nu + 0.5*self.dr*dnu1)
            dm3, dp3, dnu3 = self.rhs(r + 0.5*self.dr, m + 0.5*self.dr*dm2, p + 0.5*self.dr*dp2, nu + 0.5*self.dr*dnu2)
            dm4, dp4, dnu4 = self.rhs(r + self.dr, m + self.dr*dm3, p + self.dr*dp3, nu + self.dr*dnu3)

            # If any NaNs appear, stop
            if not (math.isfinite(dp1) and math.isfinite(dp2) and math.isfinite(dp3) and math.isfinite(dp4)):
                trapped_reached = True
                break

            m = m + (self.dr/6.0) * (dm1 + 2.0*dm2 + 2.0*dm3 + dm4)
            p = p + (self.dr/6.0) * (dp1 + 2.0*dp2 + 2.0*dp3 + dp4)
            nu = nu + (self.dr/6.0) * (dnu1 + 2.0*dnu2 + 2.0*dnu3 + dnu4)
            r = r + self.dr

            # prevent negative pressures from numerical overshoot (treat as surface)
            if p < 0.0:
                p = 0.0

            record()

        # Determine surface values
        R = grid[-1]["r"]
        M = grid[-1]["m"]

        # If we surfaced, take the last recorded radius as R (where p~0)
        # If not, R is last integrated radius (hit r_max or trapped)
        surfaced_radius = R if surfaced else None

        # Match nu shift at surface if surface exists and exterior is not trapped
        nu_shift = 0.0
        redshift_surface = None
        if surfaced and (R > 0.0) and (R > 2.0 * M):
            target_nu_R = math.log(1.0 - 2.0 * M / R)
            nu_R_raw = grid[-1]["nu_raw"]
            nu_shift = target_nu_R - nu_R_raw
            # gravitational redshift from surface to infinity:
            # z = 1/sqrt(1-2M/R) - 1
            redshift_surface = (1.0 / math.sqrt(1.0 - 2.0 * M / R)) - 1.0

        # Apply nu shift to all stored points
        for row in grid:
            row["nu_matched"] = row["nu_raw"] + nu_shift

        # Derived global quantities
        compactness = (2.0 * M / R) if (R > 0.0) else None
        trapped_any = any((row["trapped_indicator"] > 0.5) for row in grid)

        return {
            "grid": grid,
            "surface_found": surfaced,
            "trapped_reached": trapped_reached,
            "R": R,
            "M": M,
            "compactness_2M_over_R": compactness,
            "nu_shift_applied": nu_shift,
            "redshift_surface_to_infinity": redshift_surface,
            "trapped_any": trapped_any,
        }

    def build_payload(self, n_samples: int = 60) -> Dict[str, Any]:
        require(n_samples >= 5, "n_samples must be >= 5.")

        sol = self.integrate()
        grid = sol["grid"]

        # Choose ~evenly spaced sample points along the integrated grid
        idxs: List[int] = []
        if len(grid) <= n_samples:
            idxs = list(range(len(grid)))
        else:
            for i in range(n_samples):
                j = int(round(i * (len(grid) - 1) / (n_samples - 1)))
                idxs.append(j)
            # unique + sorted
            idxs = sorted(set(idxs))

        sample_points: List[Dict[str, Any]] = []
        for j in idxs:
            row = grid[j]
            r = float(row["r"])
            m = float(row["m"])
            pr = float(row["p_r"])
            rho = float(row["rho"])
            pt = float(row["p_t"])
            Delta = float(row["Delta"])

            # Some diagnostics may be undefined near r=0 or if trapped
            inside_trapped = (r <= 2.0 * m) if r > 0.0 else None

            sample_points.append({
                "coordinates": {"t": None, "r": r, "theta": None, "phi": None},
                "curvature_invariants": {
                    "ricci_scalar_R": finite_or_none(float(row["ricci_scalar_R"])),
                    "kretschmann_proxy_48m2_over_r6": finite_or_none(float(row["kretschmann_proxy"])),
                },
                "local_observables": {
                    "m_enclosed": finite_or_none(m),
                    "rho_energy_density": finite_or_none(rho),
                    "p_r": finite_or_none(pr),
                    "p_t": finite_or_none(pt),
                    "anisotropy_Delta_p_t_minus_p_r": finite_or_none(Delta),
                    "metric_potential_nu_matched": finite_or_none(float(row["nu_matched"])),
                    "compactness_2m_over_r": finite_or_none(float(row["compactness_2m_over_r"])),
                    "sound_speed_squared_cs2": self.w,  # dp/dρ for p=wρ
                },
                "causal_structure": {
                    "trapped_surface_indicator_r_le_2m": inside_trapped,
                    "r_minus_2m": finite_or_none(r - 2.0 * m) if r > 0.0 else None,
                },
            })

        # Summaries at surface / last point
        R = sol["R"]
        M = sol["M"]
        comp = sol["compactness_2M_over_R"]

        # A simple "stability-ish" marker: Buchdahl bound for isotropic perfect fluids is 2M/R < 8/9.
        # For anisotropic matter this bound can be violated; we report comparison but do not enforce.
        buchdahl_ratio = (comp / (8.0/9.0)) if (comp is not None) else None

        return {
            "toy_id": self.toy_id,
            "theory": "General Relativity (static spherically symmetric; anisotropic TOV)",
            "spacetime": "Static spherical star with anisotropic stresses (p_r != p_t)",
            "units": {"G": 1, "c": 1},
            "parameters": {
                "p_c": self.p_c,
                "w_in_p_equals_w_rho": self.w,
                "alpha_anisotropy": self.alpha,
                "r0_anisotropy_scale": self.r0,
                "dr": self.dr,
                "r_max": self.r_max,
                "p_floor_surface_threshold": self.p_floor,
                "n_samples_exported": len(sample_points),
            },
            "notes": {
                "assumptions": [
                    "Static, spherically symmetric configuration",
                    "EOS: p_r = w ρ (constant w)",
                    "Anisotropy: Δ = alpha * p_r * (r^2/r0^2)",
                    "Matched to exterior Schwarzschild at surface via e^{nu(R)}=1-2M/R when a surface is found",
                    "Kretschmann is exported as a vacuum-like proxy 48 m(r)^2 / r^6 (exact outside, heuristic inside)",
                ],
                "pressure_point": (
                    "Matter-model assumptions (perfect fluid vs anisotropic stress) materially change "
                    "compactness, redshift, and proximity to trapped surfaces. 'Collapse' is not purely geometric."
                ),
                "key_equations": {
                    "dm_dr": "dm/dr = 4π r^2 ρ",
                    "anisotropic_TOV": "dp_r/dr = -(ρ+p_r)(m+4π r^3 p_r)/(r(r-2m)) + 2Δ/r",
                    "dnu_dr": "dν/dr = 2(m+4π r^3 p_r)/(r(r-2m))",
                    "trace_to_ricci": "R = -8π(-ρ + p_r + 2 p_t) = 8π(ρ - p_r - 2 p_t)",
                },
            },
            "sample_points": sample_points,
            "observables": {
                "global": {
                    "surface_found": sol["surface_found"],
                    "trapped_reached": sol["trapped_reached"],
                    "M_total": finite_or_none(M),
                    "R_surface_or_last": finite_or_none(R),
                    "compactness_2M_over_R": finite_or_none(comp) if comp is not None else None,
                    "surface_redshift_to_infinity": sol["redshift_surface_to_infinity"],
                    "buchdahl_ratio_compared_to_8over9": finite_or_none(buchdahl_ratio) if buchdahl_ratio is not None else None,
                    "note": (
                        "Buchdahl bound 2M/R<8/9 applies to isotropic perfect fluids; "
                        "anisotropy can evade it. This toy reports compactness and proximity to trapped surfaces."
                    ),
                }
            },
        }

    def export_json(self, out_path: Optional[str] = None, n_samples: int = 60) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)
        payload = self.build_payload(n_samples=n_samples)
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2, sort_keys=True)
        return out_path


# ----------------------------
# CLI
# ----------------------------

def main() -> None:
    ap = argparse.ArgumentParser(description="Toy 053: anisotropic-stress TOV star (p_r != p_t).")
    ap.add_argument("--p_c", type=float, default=1e-3, help="Central radial pressure p_c (>0)")
    ap.add_argument("--w", type=float, default=0.2, help="EOS parameter w in p_r = w rho (0<w<=1)")
    ap.add_argument("--alpha", type=float, default=0.0, help="Anisotropy strength alpha in Δ=alpha p_r (r^2/r0^2)")
    ap.add_argument("--r0", type=float, default=10.0, help="Anisotropy length scale r0 (>0)")
    ap.add_argument("--dr", type=float, default=1e-2, help="Radial step dr (>0)")
    ap.add_argument("--r_max", type=float, default=50.0, help="Maximum radius to integrate to")
    ap.add_argument("--p_floor", type=float, default=1e-12, help="Surface threshold: stop when p_r <= p_floor")
    ap.add_argument("--n_samples", type=int, default=60, help="Number of sample_points to export (>=5)")
    ap.add_argument("--out", type=str, default="", help="Optional output path. If omitted, uses <this_script_name>.json")
    args = ap.parse_args()

    toy = Toy053AnisotropicTOV(
        p_c=float(args.p_c),
        w=float(args.w),
        alpha=float(args.alpha),
        r0=float(args.r0),
        dr=float(args.dr),
        r_max=float(args.r_max),
        p_floor=float(args.p_floor),
    )

    out_path = args.out.strip() or None
    json_path = toy.export_json(out_path=out_path, n_samples=int(args.n_samples))

    print(f"Wrote {json_path}")
    print("Toy 053 complete: anisotropic-stress TOV star.")


if __name__ == "__main__":
    main()
