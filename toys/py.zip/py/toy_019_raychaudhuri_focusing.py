#!/usr/bin/env python3
"""
Toy 019 — Raychaudhuri focusing: null congruences, energy conditions, and caustics

What it probes (pressure point):
- The Raychaudhuri equation is the engine behind the singularity theorems.
- With the Null Energy Condition (NEC), null congruences generically *focus* (θ -> -∞) in finite affine parameter.
- If NEC is violated (R_ab k^a k^b < 0), focusing can be delayed or prevented (defocusing),
  illustrating exactly where “exotic matter” breaks the usual GR causal/focusing logic.

Assumptions / setup:
- Consider a hypersurface-orthogonal null congruence with shear σ=0 and twist ω=0.
  (This is the cleanest focusing channel; adding shear only strengthens focusing.)
- Raychaudhuri (null) reduces to:
    dθ/dλ = - 1/2 θ^2 - Rkk(λ)
  where Rkk(λ) := R_ab k^a k^b along the congruence.
- We provide simple controllable Rkk models:
    * "vacuum":   Rkk = 0
    * "matter":   Rkk = +R0  (NEC-satisfying)
    * "exotic":   Rkk = -R0  (NEC-violating)
  with R0 >= 0.

Area proxy (for intuition, not required by Raychaudhuri):
- Define an "area scale" A(λ) such that:
    d(ln A)/dλ = θ
  Then A(λ) = A0 * exp(∫θ dλ). A -> 0 indicates caustic formation.

Numerics:
- Deterministic RK4 integration with step size dλ.
- "Focusing" detected when θ drops below a large negative threshold (e.g. -1e6),
  interpreted as "θ -> -∞" caustic in finite λ.

STRICT EXPORT RULE:
- Writes JSON named exactly like this .py file (toy_019_raychaudhuri_focusing.json).
- JSON follows the canonical schema with required keys and required subkeys.
- Undefined quantities are exported as null (JSON null).
"""

from __future__ import annotations

import argparse
import json
import math
import os
from typing import Any, Dict, List, Optional


# ----------------------------
# Helpers
# ----------------------------

def py_to_json_name(py_path: str) -> str:
    base = os.path.splitext(os.path.basename(py_path))[0]
    return base + ".json"


def require(cond: bool, msg: str) -> None:
    if not cond:
        raise ValueError(msg)


def parse_csv_floats(s: str) -> List[float]:
    return [float(x.strip()) for x in s.split(",") if x.strip()]


# ----------------------------
# Toy 019
# ----------------------------

class Toy019RaychaudhuriFocusing:
    toy_id = "019"

    def __init__(
        self,
        theta0: float = -0.2,
        model: str = "vacuum",
        R0: float = 0.2,
        lam_max: float = 50.0,
        dlam: float = 0.01,
        focus_theta_threshold: float = -1e6,
        A0: float = 1.0,
    ) -> None:
        require(lam_max > 0.0, "lam_max must be > 0.")
        require(dlam > 0.0, "dlam must be > 0.")
        require(A0 > 0.0, "A0 must be > 0.")
        require(R0 >= 0.0, "R0 must be >= 0.")
        require(model in ("vacuum", "matter", "exotic", "custom_piecewise"), "Unknown model.")

        self.theta0 = float(theta0)
        self.model = str(model)
        self.R0 = float(R0)
        self.lam_max = float(lam_max)
        self.dlam = float(dlam)
        self.focus_theta_threshold = float(focus_theta_threshold)
        self.A0 = float(A0)

        # Optional piecewise custom: user supplies breakpoints and values via CLI
        self.custom_breaks: List[float] = []
        self.custom_values: List[float] = []

    def set_custom_piecewise(self, breaks: List[float], values: List[float]) -> None:
        """
        Defines Rkk(λ) piecewise constant on intervals:
          [0, breaks[0]) -> values[0]
          [breaks[0], breaks[1]) -> values[1]
          ...
          [breaks[-1], ∞) -> values[-1]
        Requires len(values) == len(breaks)+1.
        """
        require(all(b >= 0.0 for b in breaks), "All breaks must be >= 0.")
        require(all(breaks[i] < breaks[i + 1] for i in range(len(breaks) - 1)), "Breaks must be strictly increasing.")
        require(len(values) == len(breaks) + 1, "Need len(values) == len(breaks)+1.")
        self.custom_breaks = list(map(float, breaks))
        self.custom_values = list(map(float, values))

    def Rkk(self, lam: float) -> float:
        if self.model == "vacuum":
            return 0.0
        if self.model == "matter":
            return +self.R0
        if self.model == "exotic":
            return -self.R0
        # custom_piecewise
        if not self.custom_values:
            return 0.0
        for i, b in enumerate(self.custom_breaks):
            if lam < b:
                return self.custom_values[i]
        return self.custom_values[-1]

    # Raychaudhuri ODE
    def dtheta_dlam(self, lam: float, theta: float) -> float:
        # dθ/dλ = -1/2 θ^2 - Rkk(λ)
        return -0.5 * theta * theta - self.Rkk(lam)

    def rk4_step(self, lam: float, theta: float, A: float, h: float) -> Dict[str, float]:
        # Integrate theta and lnA simultaneously:
        # dθ/dλ = f(λ, θ)
        # d(lnA)/dλ = θ
        # Use RK4 on θ and lnA.
        def f(l: float, th: float) -> float:
            return self.dtheta_dlam(l, th)

        def g(_l: float, th: float) -> float:
            return th

        lnA = math.log(A)

        k1_th = f(lam, theta)
        k1_lnA = g(lam, theta)

        k2_th = f(lam + 0.5 * h, theta + 0.5 * h * k1_th)
        k2_lnA = g(lam + 0.5 * h, theta + 0.5 * h * k1_th)

        k3_th = f(lam + 0.5 * h, theta + 0.5 * h * k2_th)
        k3_lnA = g(lam + 0.5 * h, theta + 0.5 * h * k2_th)

        k4_th = f(lam + h, theta + h * k3_th)
        k4_lnA = g(lam + h, theta + h * k3_th)

        theta_next = theta + (h / 6.0) * (k1_th + 2.0 * k2_th + 2.0 * k3_th + k4_th)
        lnA_next = lnA + (h / 6.0) * (k1_lnA + 2.0 * k2_lnA + 2.0 * k3_lnA + k4_lnA)
        A_next = math.exp(lnA_next)

        return {"theta": theta_next, "A": A_next}

    def simulate(self) -> Dict[str, Any]:
        lam = 0.0
        theta = self.theta0
        A = self.A0

        points: List[Dict[str, Any]] = []

        focused = False
        lam_focus: Optional[float] = None
        theta_at_focus: Optional[float] = None
        A_at_focus: Optional[float] = None

        # analytic vacuum focusing estimate if theta0 < 0 and Rkk=0:
        # θ(λ)=θ0 / (1 + (θ0/2)λ) => diverges at λ* = -2/θ0
        analytic_focus_vacuum = None
        if self.model == "vacuum" and self.theta0 < 0.0:
            analytic_focus_vacuum = -2.0 / self.theta0

        n_steps = int(math.ceil(self.lam_max / self.dlam))
        for _ in range(n_steps + 1):
            Rkk_val = self.Rkk(lam)

            points.append({
                "lambda": lam,
                "theta": theta,
                "Rkk": Rkk_val,
                "A": A,
            })

            if theta <= self.focus_theta_threshold and not focused:
                focused = True
                lam_focus = lam
                theta_at_focus = theta
                A_at_focus = A
                break

            step = self.rk4_step(lam, theta, A, self.dlam)
            lam += self.dlam
            theta = step["theta"]
            A = step["A"]

        return {
            "points": points,
            "focused": focused,
            "lam_focus": lam_focus,
            "theta_at_focus": theta_at_focus,
            "A_at_focus": A_at_focus,
            "analytic_focus_vacuum_if_applicable": analytic_focus_vacuum,
        }

    def build_payload(self) -> Dict[str, Any]:
        sim = self.simulate()

        sample_points: List[Dict[str, Any]] = []
        for p in sim["points"]:
            lam = p["lambda"]
            theta = p["theta"]
            Rkk_val = p["Rkk"]
            A = p["A"]

            coordinates = {"lambda": lam}
            curvature_invariants = {
                "ricci_scalar": None,
                "kretschmann": None,
                "note": "Toy integrates the Raychaudhuri ODE; curvature enters only through R_ab k^a k^b (Rkk).",
            }
            local_observables = {
                "raychaudhuri": {
                    "theta_expansion": theta,
                    "dtheta_dlambda": self.dtheta_dlam(lam, theta),
                    "Rkk": Rkk_val,
                    "assumptions": {"shear_sigma": 0.0, "twist_omega": 0.0},
                    "equation": "dθ/dλ = -1/2 θ^2 - Rkk(λ)",
                },
                "area_proxy": {
                    "A": A,
                    "A0": self.A0,
                    "definition": "d(ln A)/dλ = θ",
                },
            }
            causal_structure = {
                "focusing": {
                    "focused_by_threshold": (theta <= self.focus_theta_threshold),
                    "threshold": self.focus_theta_threshold,
                    "interpretation": "θ -> -∞ indicates caustic/focusing in finite affine parameter.",
                },
                "energy_condition_proxy": {
                    "Rkk_sign": ("positive" if Rkk_val > 0 else ("zero" if abs(Rkk_val) < 1e-15 else "negative")),
                    "nec_status_proxy": ("NEC-like (Rkk>=0)" if Rkk_val >= 0 else "NEC-violating (Rkk<0)"),
                },
                "radial_null_cone_dr_dt": None,
            }

            sample_points.append({
                "coordinates": coordinates,
                "curvature_invariants": curvature_invariants,
                "local_observables": local_observables,
                "causal_structure": causal_structure,
            })

        payload: Dict[str, Any] = {
            "toy_id": self.toy_id,
            "theory": "General Relativity (congruence dynamics via Raychaudhuri equation)",
            "spacetime": "Abstract null congruence (shear=0, twist=0) with prescribed R_ab k^a k^b along λ",
            "units": {"G": 1, "c": 1},
            "parameters": {
                "theta0": self.theta0,
                "model": self.model,
                "R0": self.R0,
                "lam_max": self.lam_max,
                "dlam": self.dlam,
                "focus_theta_threshold": self.focus_theta_threshold,
                "A0": self.A0,
                "custom_piecewise_breaks": self.custom_breaks if self.model == "custom_piecewise" else [],
                "custom_piecewise_values": self.custom_values if self.model == "custom_piecewise" else [],
            },
            "notes": {
                "pressure_point": (
                    "Focusing theorems hinge on the sign of R_ab k^a k^b (NEC). "
                    "With Rkk>=0, focusing is strengthened; with Rkk<0 (exotic matter), "
                    "defocusing can occur, breaking singularity-theorem logic."
                ),
                "key_formulas": {
                    "raychaudhuri_null": "dθ/dλ = -1/2 θ^2 - R_ab k^a k^b  (σ=0, ω=0)",
                    "area_proxy": "d(ln A)/dλ = θ",
                    "vacuum_solution": "If Rkk=0 and θ0<0, focusing at λ* = -2/θ0",
                },
                "domain_of_validity": (
                    "ODE-level congruence toy: assumes hypersurface-orthogonal null congruence with σ=0 and ω=0. "
                    "Rkk is prescribed (constant or piecewise), not derived from a full metric in this toy."
                ),
            },
            "sample_points": sample_points,
            "observables": {
                "focusing_detected": sim["focused"],
                "lambda_focus_threshold": sim["lam_focus"],
                "theta_at_focus_threshold": sim["theta_at_focus"],
                "A_at_focus_threshold": sim["A_at_focus"],
                "analytic_focus_vacuum_if_applicable": sim["analytic_focus_vacuum_if_applicable"],
            },
        }
        return payload

    def export_json(self, out_path: Optional[str] = None) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)
        payload = self.build_payload()
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2, sort_keys=True)
        return out_path


# ----------------------------
# CLI
# ----------------------------

def main() -> None:
    ap = argparse.ArgumentParser(description="Toy 019: Raychaudhuri focusing (null congruence ODE).")
    ap.add_argument("--theta0", type=float, default=-0.2, help="Initial expansion θ(0)")
    ap.add_argument("--model", type=str, default="vacuum", choices=["vacuum", "matter", "exotic", "custom_piecewise"],
                    help="Rkk model: vacuum=0, matter=+R0, exotic=-R0, custom_piecewise uses breaks/values")
    ap.add_argument("--R0", type=float, default=0.2, help="Magnitude for constant Rkk models (>=0)")
    ap.add_argument("--lam_max", type=float, default=50.0, help="Max affine parameter to integrate")
    ap.add_argument("--dlam", type=float, default=0.01, help="Step size in affine parameter")
    ap.add_argument("--focus_theta_threshold", type=float, default=-1e6, help="Threshold to declare focusing")
    ap.add_argument("--A0", type=float, default=1.0, help="Initial area proxy A(0)")
    ap.add_argument("--custom_breaks", type=str, default="", help="Comma-separated λ breakpoints for piecewise Rkk")
    ap.add_argument("--custom_values", type=str, default="", help="Comma-separated Rkk values for piecewise (len = breaks+1)")
    ap.add_argument("--out", type=str, default="", help="Optional output path; default is <script>.json")
    args = ap.parse_args()

    toy = Toy019RaychaudhuriFocusing(
        theta0=float(args.theta0),
        model=str(args.model),
        R0=float(args.R0),
        lam_max=float(args.lam_max),
        dlam=float(args.dlam),
        focus_theta_threshold=float(args.focus_theta_threshold),
        A0=float(args.A0),
    )

    if args.model == "custom_piecewise":
        breaks = parse_csv_floats(args.custom_breaks) if args.custom_breaks.strip() else []
        values = parse_csv_floats(args.custom_values) if args.custom_values.strip() else []
        toy.set_custom_piecewise(breaks, values)

    out_path = args.out.strip() or None
    json_path = toy.export_json(out_path=out_path)

    print(f"Wrote {json_path}")
    print(f"Model={toy.model}, theta0={toy.theta0:g}, R0={toy.R0:g}")
    if toy.model == "vacuum" and toy.theta0 < 0:
        print(f"Vacuum analytic focusing estimate: lambda_star approx {-2.0/toy.theta0:g}")
    print("Focusing is declared when theta <= focus_theta_threshold.")


if __name__ == "__main__":
    main()
