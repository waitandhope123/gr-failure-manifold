#!/usr/bin/env python3
"""
Toy 030 — Schwarzschild horizon area, surface gravity, and (proxy) entropy scaling

Model (G=c=1):
Schwarzschild black hole.

Key formulas:
  r_h = 2M
  A   = 4π r_h^2 = 16π M^2
  κ   = 1/(4M)               (surface gravity)
  T_H = κ/(2π) = 1/(8π M)    (Hawking temperature; semiclassical, used as a proxy diagnostic)
  S_BH = A/4 = 4π M^2        (Bekenstein–Hawking entropy; proxy)

Pressure point:
- Thermodynamic-looking relations are global/horizon-based, not localizable as a stress-energy density.
- Shows scaling: A ~ M^2, T ~ 1/M, S ~ M^2.

EXPORT:
- JSON filename matches this script name.
- Canonical schema; no missing keys; undefined => null.
"""

from __future__ import annotations

import argparse
import json
import math
import os
from typing import Any, Dict, List, Optional


# ----------------------------
# Helpers
# ----------------------------

def py_to_json_name(py_path: str) -> str:
    base = os.path.splitext(os.path.basename(py_path))[0]
    return base + ".json"


def parse_csv_floats(s: str) -> List[float]:
    return [float(x.strip()) for x in s.split(",") if x.strip()]


def require(cond: bool, msg: str) -> None:
    if not cond:
        raise ValueError(msg)


# ----------------------------
# Toy 030
# ----------------------------

class Toy030HorizonScaling:
    toy_id = "030"

    def __init__(self, M_values: List[float]) -> None:
        require(len(M_values) >= 1, "Need at least one M.")
        for M in M_values:
            require(M > 0.0, "All M must be > 0.")
        self.M_values = [float(M) for M in M_values]

    def horizon_radius(self, M: float) -> float:
        return 2.0 * M

    def area(self, M: float) -> float:
        rh = self.horizon_radius(M)
        return 4.0 * math.pi * rh * rh

    def surface_gravity(self, M: float) -> float:
        return 1.0 / (4.0 * M)

    def hawking_temperature_proxy(self, M: float) -> float:
        return self.surface_gravity(M) / (2.0 * math.pi)

    def entropy_proxy(self, M: float) -> float:
        # S = A/4 in G=c=ħ=k_B=1 units; we keep G=c=1 and treat as proxy diagnostic.
        return self.area(M) / 4.0

    def build_payload(self) -> Dict[str, Any]:
        sample_points: List[Dict[str, Any]] = []

        for M in self.M_values:
            rh = self.horizon_radius(M)
            A = self.area(M)
            kappa = self.surface_gravity(M)
            T = self.hawking_temperature_proxy(M)
            S = self.entropy_proxy(M)

            sample_points.append({
                "coordinates": {"M": M},
                "curvature_invariants": {
                    # Evaluate Kretschmann at the horizon as a scale indicator:
                    "kretschmann_at_horizon": 48.0 * (M ** 2) / (rh ** 6),
                    "ricci_scalar": 0.0,
                },
                "local_observables": {
                    "horizon_radius": rh,
                    "horizon_area": A,
                    "surface_gravity_kappa": kappa,
                    "hawking_temperature_proxy": T,
                    "entropy_proxy": S,
                    "scalings": {
                        "A_over_M2": A / (M * M),
                        "T_times_M": T * M,
                        "S_over_M2": S / (M * M),
                    },
                },
                "causal_structure": {
                    "has_event_horizon": True,
                    "horizon_radius": rh,
                },
            })

        payload: Dict[str, Any] = {
            "toy_id": self.toy_id,
            "theory": "General Relativity (with semiclassical horizon proxies)",
            "spacetime": "Schwarzschild (horizon area / surface gravity scaling)",
            "units": {"G": 1, "c": 1},
            "parameters": {
                "M_values": self.M_values,
            },
            "notes": {
                "pressure_point": (
                    "Horizon area and surface gravity encode global properties with thermodynamic-like scaling. "
                    "These quantities are not associated with any unique local gravitational energy density."
                ),
                "key_formulas": {
                    "r_h": "2M",
                    "A": "16π M^2",
                    "kappa": "1/(4M)",
                    "T_proxy": "1/(8π M)",
                    "S_proxy": "A/4 = 4π M^2",
                },
                "disclaimer": (
                    "Temperature/entropy here are treated as diagnostic proxies; full Hawking/BH thermodynamics "
                    "requires ħ and quantum field theory in curved spacetime."
                ),
            },
            "sample_points": sample_points,
            "observables": {
                "area_scaling_expectation": "A ∝ M^2",
                "temperature_scaling_expectation": "T ∝ 1/M",
                "entropy_scaling_expectation": "S ∝ M^2",
            },
        }

        return payload

    def export_json(self, out_path: Optional[str] = None) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)
        payload = self.build_payload()
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2, sort_keys=True)
        return out_path


# ----------------------------
# CLI
# ----------------------------

def main() -> None:
    ap = argparse.ArgumentParser(description="Toy 030: Schwarzschild horizon scaling (A, κ, proxy T and S).")
    ap.add_argument(
        "--M",
        type=str,
        default="0.5,1,2,5,10",
        help="Comma-separated masses M (geometric units)",
    )
    ap.add_argument("--out", type=str, default="",
                    help="Optional output path. If omitted, uses <this_script_name>.json")
    args = ap.parse_args()

    M_values = parse_csv_floats(args.M)
    toy = Toy030HorizonScaling(M_values=M_values)

    out_path = args.out.strip() or None
    json_path = toy.export_json(out_path=out_path)

    print(f"Wrote {json_path}")
    print(f"Computed horizon scaling for {len(M_values)} mass values.")


if __name__ == "__main__":
    main()
