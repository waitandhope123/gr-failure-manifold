#!/usr/bin/env python3
"""
Toy 005 — Rindler spacetime (equivalence principle stress test)

What it probes (weak points / pressure points):
- Distinguishes coordinate horizons from curvature:
  * Rindler has a horizon at rho=0 in these coordinates, but spacetime is flat (R=0, K=0).
- Shows "gravity-like" redshift without curvature:
  * 1+z = rho_obs / rho_emit
- Separates proper acceleration from tidal gravity:
  * Proper acceleration of stationary observers a(rho)=1/rho, yet tidal tensor is zero (flat).
- Tests which "observables" are local vs global:
  * Causal structure changes due to coordinates, not geometry.

Model:
Rindler metric (in 1+1 with transverse y,z added):
  ds^2 = -(a0 * rho)^2 dη^2 + dρ^2 + dy^2 + dz^2
Domain: rho > 0

Key results:
- Curvature invariants: Ricci scalar R = 0, Kretschmann K = 0 (exactly).
- Proper time rate for stationary observer at rho: dτ/dη = a0 * rho
- Proper acceleration of stationary observer: a(rho) = 1/rho  (independent of a0 scaling)
- Radial null curves: dρ/dη = ± a0 * rho
- Gravitational redshift between stationary observers:
    f_obs / f_emit = sqrt(-g_tt(rho_emit)) / sqrt(-g_tt(rho_obs)) = rho_emit / rho_obs
    => 1 + z = f_emit/f_obs = rho_obs / rho_emit

STRICT EXPORT RULE:
- Writes JSON named exactly like this .py file (toy_005_rindler_equivalence.json).
- JSON follows the canonical schema with required keys and required subkeys.
- Undefined quantities are exported as null (JSON null).
"""

from __future__ import annotations

import argparse
import json
import math
import os
from typing import Any, Dict, List, Optional


# ----------------------------
# Helpers
# ----------------------------

def py_to_json_name(py_path: str) -> str:
    base = os.path.splitext(os.path.basename(py_path))[0]
    return base + ".json"


def parse_csv_floats(s: str) -> List[float]:
    return [float(x.strip()) for x in s.split(",") if x.strip()]


def parse_pairs(s: str) -> List[Dict[str, float]]:
    """
    Parse "rho_emit:rho_obs,rho_emit:rho_obs,..." into list of dicts.
    Example: "1:2,2:5"
    """
    out: List[Dict[str, float]] = []
    if not s.strip():
        return out
    for chunk in s.split(","):
        chunk = chunk.strip()
        if not chunk:
            continue
        a, b = chunk.split(":")
        out.append({"rho_emit": float(a), "rho_obs": float(b)})
    return out


def require(cond: bool, msg: str) -> None:
    if not cond:
        raise ValueError(msg)


# ----------------------------
# Toy 005: Rindler
# ----------------------------

class Toy005RindlerEquivalence:
    toy_id = "005"

    def __init__(self, a0: float = 1.0) -> None:
        require(a0 > 0.0, "a0 must be > 0.")
        self.a0 = float(a0)

    # Metric component g_tt = -(a0*rho)^2
    def g_tt(self, rho: float) -> float:
        require(rho > 0.0, "rho must be > 0 (Rindler wedge).")
        return - (self.a0 * rho) ** 2

    # --- Curvature invariants (exactly flat) ---
    def curvature_invariants(self) -> Dict[str, float]:
        return {"ricci_scalar": 0.0, "kretschmann": 0.0}

    # --- Local observables ---
    def time_dilation_dtaudeta(self, rho: float) -> float:
        """
        For stationary observer (fixed rho,y,z):
          dτ = sqrt(-g_tt) dη = (a0*rho) dη
        """
        require(rho > 0.0, "rho must be > 0.")
        return self.a0 * rho

    def proper_acceleration(self, rho: float) -> float:
        """
        Proper acceleration magnitude of stationary Rindler observer:
          a(rho) = 1/rho
        """
        require(rho > 0.0, "rho must be > 0.")
        return 1.0 / rho

    def tidal_tensor(self) -> Dict[str, float]:
        """
        Flat spacetime => tidal curvature components vanish.
        Export a minimal representation.
        """
        return {
            "R0rho0rho": 0.0,
            "R0y0y": 0.0,
            "R0z0z": 0.0,
        }

    # --- Causal structure ---
    def radial_null_cone_drho_deta(self, rho: float) -> Dict[str, float]:
        """
        For ds^2=0 with dy=dz=0:
          0 = -(a0*rho)^2 dη^2 + dρ^2
          dρ/dη = ± a0*rho
        """
        require(rho > 0.0, "rho must be > 0.")
        v = self.a0 * rho
        return {"outgoing": v, "ingoing": -v}

    # --- Experiment-style observable ---
    def redshift(self, rho_emit: float, rho_obs: float) -> float:
        """
        For stationary observers:
          (1+z) = rho_obs / rho_emit
        """
        require(rho_emit > 0.0 and rho_obs > 0.0, "rho_emit and rho_obs must be > 0.")
        return (rho_obs / rho_emit) - 1.0

    # Optional: Minkowski coordinate mapping (for intuition / catalog)
    def minkowski_map(self, eta: float, rho: float) -> Dict[str, float]:
        """
        Standard Rindler->Minkowski:
          T = rho * sinh(a0*eta)
          X = rho * cosh(a0*eta)
        """
        require(rho > 0.0, "rho must be > 0.")
        return {
            "T": rho * math.sinh(self.a0 * eta),
            "X": rho * math.cosh(self.a0 * eta),
        }

    # --- Canonical export payload ---
    def build_payload(
        self,
        rho_values: List[float],
        eta_for_map: float,
        redshift_pairs: List[Dict[str, float]],
    ) -> Dict[str, Any]:

        sample_points: List[Dict[str, Any]] = []
        inv = self.curvature_invariants()
        tidal = self.tidal_tensor()

        for rho in rho_values:
            rho = float(rho)
            require(rho > 0.0, "All rho sample points must be > 0.")

            coordinates = {"t": None, "x": None, "y": None, "z": None, "eta": eta_for_map, "rho": rho}

            curvature_invariants = {"ricci_scalar": inv["ricci_scalar"], "kretschmann": inv["kretschmann"]}

            local_observables: Dict[str, Any] = {
                "g_tt": self.g_tt(rho),
                "time_dilation_dtaudeta_stationary": self.time_dilation_dtaudeta(rho),
                "proper_acceleration_stationary": self.proper_acceleration(rho),
                "tidal_tensor_sample": tidal,
                "minkowski_coordinates_at_eta": self.minkowski_map(eta_for_map, rho),
            }

            causal_structure: Dict[str, Any] = {
                "radial_null_cone_dr_dt": None,  # not using Schwarzschild r,t here
                "radial_null_cone_drho_deta": self.radial_null_cone_drho_deta(rho),
                "horizon_radius": None,
                "region": "Rindler wedge rho>0; coordinate horizon at rho=0",
                "coordinate_horizon_location": "rho = 0",
            }

            sample_points.append({
                "coordinates": coordinates,
                "curvature_invariants": curvature_invariants,
                "local_observables": local_observables,
                "causal_structure": causal_structure,
            })

        obs_redshift: List[Dict[str, Any]] = []
        for p in redshift_pairs:
            rho_emit = float(p["rho_emit"])
            rho_obs = float(p["rho_obs"])
            entry = {
                "rho_emit": rho_emit,
                "rho_obs": rho_obs,
                "z": None,
                "valid": None,
            }
            if rho_emit > 0.0 and rho_obs > 0.0:
                entry["z"] = self.redshift(rho_emit, rho_obs)
                entry["valid"] = True
            else:
                entry["valid"] = False
            obs_redshift.append(entry)

        payload: Dict[str, Any] = {
            "toy_id": self.toy_id,
            "theory": "General Relativity (flat spacetime in accelerated coordinates)",
            "spacetime": "Rindler wedge (uniform acceleration frame) — Minkowski in disguise",
            "units": {"G": 1, "c": 1},
            "parameters": {
                "a0": self.a0,
                "eta_for_minkowski_map": eta_for_map,
            },
            "notes": {
                "assumptions": [
                    "Flat spacetime, expressed in Rindler coordinates",
                    "Stationary observers are uniformly accelerated in Minkowski space",
                    "Domain: rho > 0 (one Rindler wedge)",
                ],
                "key_formulas": {
                    "metric": "ds^2 = -(a0*rho)^2 dη^2 + dρ^2 + dy^2 + dz^2",
                    "time_dilation": "dτ/dη = a0*rho",
                    "proper_acceleration": "a(rho) = 1/rho",
                    "null_slopes": "dρ/dη = ± a0*rho",
                    "redshift": "1+z = rho_obs / rho_emit",
                    "rindler_to_minkowski": "T=rho*sinh(a0*eta), X=rho*cosh(a0*eta)",
                },
                "pressure_point": (
                    "This toy produces redshift and a horizon with ZERO curvature (R=K=0). "
                    "So: 'horizon' and 'redshift' do not automatically imply spacetime curvature—"
                    "they can be coordinate/observer effects."
                ),
                "compare_with": [
                    "Toy 001 Schwarzschild: horizon has curvature effects elsewhere (singularity), and tidal field != 0",
                    "Toy 003 GW: curvature invariants can be misleading even when there is a physical effect",
                ],
            },
            "sample_points": sample_points,
            "observables": {
                "redshift_between_stationary_observers": obs_redshift
            },
        }

        return payload

    def export_json(
        self,
        rho_values: List[float],
        eta_for_map: float,
        redshift_pairs: List[Dict[str, float]],
        out_path: Optional[str] = None,
    ) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)

        payload = self.build_payload(rho_values=rho_values, eta_for_map=eta_for_map, redshift_pairs=redshift_pairs)
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2, sort_keys=True)
        return out_path


# ----------------------------
# CLI
# ----------------------------

def main() -> None:
    ap = argparse.ArgumentParser(description="Toy 005: Rindler equivalence principle exporter (GR).")
    ap.add_argument("--a0", type=float, default=1.0, help="Rindler scaling parameter a0 (>0)")
    ap.add_argument("--rho", type=str, default="0.5,1,2,5,10", help="Comma-separated rho sample points (rho>0)")
    ap.add_argument("--eta", type=float, default=0.0, help="Eta used for Minkowski mapping output")
    ap.add_argument("--pairs", type=str, default="1:2,1:5,2:10",
                    help="Comma-separated rho_emit:rho_obs pairs for redshift observable")
    ap.add_argument("--out", type=str, default="",
                    help="Optional output path. If omitted, uses <this_script_name>.json")
    args = ap.parse_args()

    rho_values = parse_csv_floats(args.rho)
    redshift_pairs = parse_pairs(args.pairs)

    toy = Toy005RindlerEquivalence(a0=args.a0)

    out_path = args.out.strip() or None
    json_path = toy.export_json(
        rho_values=rho_values,
        eta_for_map=float(args.eta),
        redshift_pairs=redshift_pairs,
        out_path=out_path,
    )

    print(f"Wrote {json_path}")
    print("Note: R=0 and Kretschmann=0 identically (flat). Horizon at rho=0 is coordinate-only.")


if __name__ == "__main__":
    main()
