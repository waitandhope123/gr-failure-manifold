#!/usr/bin/env python3
"""
Toy 087 — Cosmic string: topology / holonomy invisible to local curvature

What it probes (pressure point):
- Global/topological structure can be nontrivial even when local curvature scalars vanish.
- A straight, infinitesimally thin cosmic string produces a conical spacetime:
  locally flat for r>0 (Ricci=0, Kretschmann=0), but with a global deficit angle.
- Parallel transport around the string yields nontrivial holonomy (a rotation by the deficit),
  and light deflection/lensing occurs without local tidal gravity (outside the string).

Model (G=c=1):
Straight static cosmic string along z-axis with line tension/energy density μ.

Metric (one common convention):
  ds^2 = -dt^2 + dz^2 + dr^2 + (alpha^2) r^2 dphi^2
where alpha = 1 - 4μ, with 0 < alpha <= 1 (requires μ < 1/4).

Deficit angle:
  delta = 2π(1 - alpha) = 8π μ

Key facts:
- For r>0: spacetime is flat (all local curvature invariants vanish).
- At r=0: curvature is distributional (not representable by ordinary pointwise scalars).
  We mark r=0 scalar invariants as null and flag distributional curvature.

Experiment-style observables:
- Circumference at radius r: C(r) = 2π alpha r  (smaller than flat value 2π r)
- Angular deficit: delta = 8π μ
- Holonomy rotation for a loop around the string: holonomy_angle = delta
- Idealized lensing: for a perfectly aligned source, two images separated by ~ delta.

STRICT EXPORT RULE:
- Writes JSON named exactly like this .py file.
- JSON follows canonical schema; undefined quantities are null.
"""

from __future__ import annotations

import argparse
import json
import math
import os
from typing import Any, Dict, List, Optional


# ----------------------------
# Helpers
# ----------------------------

def py_to_json_name(py_path: str) -> str:
    base = os.path.splitext(os.path.basename(py_path))[0]
    return base + ".json"


def parse_csv_floats(s: str) -> List[float]:
    return [float(x.strip()) for x in s.split(",") if x.strip()]


def require(cond: bool, msg: str) -> None:
    if not cond:
        raise ValueError(msg)


# ----------------------------
# Toy 087
# ----------------------------

class Toy087CosmicStringHolonomy:
    toy_id = "087"

    def __init__(self, mu: float = 0.05) -> None:
        self.mu = float(mu)
        require(self.mu >= 0.0, "mu must be >= 0.")
        require(self.mu < 0.25, "mu must be < 1/4 so that alpha = 1-4mu is positive.")
        self.alpha = 1.0 - 4.0 * self.mu
        require(self.alpha > 0.0, "alpha must be > 0.")

    def deficit_angle(self) -> float:
        # delta = 8π μ
        return 8.0 * math.pi * self.mu

    # For r>0, spacetime is flat (excluding distributional source at r=0)
    def ricci_scalar(self, r: float) -> Optional[float]:
        if r <= 0.0:
            return None
        return 0.0

    def kretschmann(self, r: float) -> Optional[float]:
        if r <= 0.0:
            return None
        return 0.0

    def circumference(self, r: float) -> Optional[float]:
        if r < 0.0:
            return None
        return 2.0 * math.pi * self.alpha * r

    def flat_circumference(self, r: float) -> Optional[float]:
        if r < 0.0:
            return None
        return 2.0 * math.pi * r

    def area_disk(self, r: float) -> Optional[float]:
        # area inside radius r on t,z=const slice: A = π alpha r^2
        if r < 0.0:
            return None
        return math.pi * self.alpha * (r ** 2)

    def flat_area_disk(self, r: float) -> Optional[float]:
        if r < 0.0:
            return None
        return math.pi * (r ** 2)

    def build_payload(self, r_values: List[float]) -> Dict[str, Any]:
        sample_points: List[Dict[str, Any]] = []
        delta = self.deficit_angle()

        for r in r_values:
            r = float(r)

            # Coordinates are cylindrical; we only sample radial coordinate r here.
            coordinates = {
                "t": 0.0,
                "z": 0.0,
                "r": r,
                "phi": None,
            }

            curvature_invariants = {
                "ricci_scalar": self.ricci_scalar(r),
                "kretschmann": self.kretschmann(r),
            }

            C = self.circumference(r)
            C0 = self.flat_circumference(r)
            A = self.area_disk(r)
            A0 = self.flat_area_disk(r)

            local_observables = {
                "metric_components": {
                    "g_tt": -1.0,
                    "g_zz": +1.0,
                    "g_rr": +1.0,
                    # g_phiphi = alpha^2 r^2 (well-defined for r>=0; at r=0 it's 0)
                    "g_phiphi": (self.alpha ** 2) * (r ** 2) if r >= 0.0 else None,
                },
                "conical_geometry": {
                    "alpha": self.alpha,
                    "deficit_angle_delta": delta,
                    "circumference_C": C,
                    "circumference_flat_C0": C0,
                    "circumference_ratio_C_over_C0": (C / C0) if (C is not None and C0 is not None and C0 != 0.0) else None,
                    "disk_area_A": A,
                    "disk_area_flat_A0": A0,
                    "area_ratio_A_over_A0": (A / A0) if (A is not None and A0 is not None and A0 != 0.0) else None,
                },
                "experiment_style": {
                    # Holonomy: parallel transport around string rotates by deficit.
                    "holonomy_rotation_angle": (delta if r > 0.0 else None),
                    # Idealized lensing: for perfectly aligned geometry, image separation ~ deficit.
                    "ideal_lensing_image_separation_angle": (delta if r > 0.0 else None),
                },
            }

            causal_structure = {
                "horizon_present": False,
                "ctc_present": False,
                "region": (
                    "axis (distributional source at r=0)" if r == 0.0 else
                    ("regular exterior (r>0)" if r > 0.0 else "unphysical (r<0)")
                ),
                "local_flat_for_r_gt_0": (True if r > 0.0 else None),
                "distributional_curvature_at_axis": (True if r == 0.0 else False),
                "topology_note": (
                    "Conical identification: local curvature invariants vanish for r>0, "
                    "but global deficit angle implies nontrivial holonomy around the axis."
                    if r >= 0.0 else None
                ),
            }

            sample_points.append({
                "coordinates": coordinates,
                "curvature_invariants": curvature_invariants,
                "local_observables": local_observables,
                "causal_structure": causal_structure,
            })

        payload: Dict[str, Any] = {
            "toy_id": self.toy_id,
            "theory": "General Relativity (exact solution with distributional source)",
            "spacetime": "Straight cosmic string (conical Minkowski: topology/holonomy without local curvature for r>0)",
            "units": {"G": 1, "c": 1},
            "parameters": {
                "mu_line_density": self.mu,
                "alpha": self.alpha,
                "deficit_angle_delta": delta,
                "metric_form": "ds^2=-dt^2+dz^2+dr^2+alpha^2 r^2 dphi^2",
            },
            "notes": {
                "pressure_point": (
                    "Local curvature invariants can vanish everywhere you sample (r>0), yet the spacetime can be globally "
                    "nontrivial. The deficit angle produces measurable holonomy and lensing without local tidal gravity."
                ),
                "domain": (
                    "Model is locally flat for r>0; the string core at r=0 is idealized as infinitesimally thin "
                    "and carries distributional curvature/stress-energy."
                ),
                "key_formulas": {
                    "alpha": "alpha = 1 - 4 mu",
                    "deficit": "delta = 2π(1-alpha) = 8π mu",
                    "circumference": "C(r) = 2π alpha r",
                    "area_disk": "A(r) = π alpha r^2",
                    "holonomy": "rotation angle around axis = delta",
                },
            },
            "sample_points": sample_points,
            "observables": {
                "deficit_angle_delta": delta,
                "holonomy_rotation_angle_for_single_loop": delta,
                "alpha": self.alpha,
                "flatness_outside_axis": True,
            },
        }
        return payload

    def export_json(self, r_values: List[float], out_path: Optional[str] = None) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)
        payload = self.build_payload(r_values=r_values)
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2, sort_keys=True)
        return out_path


# ----------------------------
# CLI
# ----------------------------

def main() -> None:
    ap = argparse.ArgumentParser(description="Toy 087: Cosmic string topology/holonomy diagnostic.")
    ap.add_argument("--mu", type=float, default=0.05, help="Cosmic string line density/tension mu (0 <= mu < 1/4).")
    ap.add_argument(
        "--r",
        type=str,
        default="0,0.25,0.5,1,2,5,10",
        help="Comma-separated radii to sample (include r=0 to mark distributional source).",
    )
    ap.add_argument("--out", type=str, default="",
                    help="Optional output path. If omitted, uses <this_script_name>.json")
    args = ap.parse_args()

    toy = Toy087CosmicStringHolonomy(mu=float(args.mu))
    r_values = parse_csv_floats(args.r)

    out_path = args.out.strip() or None
    json_path = toy.export_json(r_values=r_values, out_path=out_path)

    print(f"Wrote {json_path}")
    print(f"alpha = {toy.alpha:g}")
    print(f"deficit angle delta = {toy.deficit_angle():g} rad")


if __name__ == "__main__":
    main()
