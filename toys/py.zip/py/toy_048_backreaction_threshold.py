#!/usr/bin/env python3
"""
Toy 048 — Backreaction threshold for perturbations (test-field / linearization breakdown)

What it probes (weak points / pressure points):
- "Test particle / test field" assumptions fail when the probe's energy is not negligible.
- Linearized (weak-field) approximations fail when perturbations become comparable to the background.
- This toy provides a simple, quantitative threshold: when a perturbing mass m at radius r
  produces a metric perturbation ~ 2m/r that is not small compared to the background curvature scale.

Model (controlled approximation):
- Background: Schwarzschild black hole of mass M (G=c=1).
- Perturbation: compact object of mass m located at radius r (treat as Newtonian-like potential).
- Proxy measures:
  1) Dimensionless perturbation amplitude:  ε ≈ 2m / r
     (inspired by weak-field metric: g_tt ≈ -(1 - 2m/r) in geometric units).
  2) Mass ratio: q = m / M
  3) "Tidal domination" proxy: compare perturbation curvature scale ~ m/r^3 to background ~ M/r^3
     => ratio ≈ m/M = q (radius cancels for this crude scaling near same r).

Operational thresholds:
- test_particle_valid if q < q_max AND ε < eps_max
- linearization_valid if ε < eps_lin_max  (stricter bound)

Exports:
- For each (r, m): q, ε, flags, and a suggested regime label.

Notes:
- This is a *proxy toy* by design (not full self-force / NR). It gives a numerical boundary
  that you can use to decide when you must switch to backreacting dynamics.
"""

from __future__ import annotations

import argparse
import itertools
import json
import math
import os
from typing import Any, Dict, List, Optional, Tuple


# ----------------------------
# Helpers
# ----------------------------

def py_to_json_name(py_path: str) -> str:
    base = os.path.splitext(os.path.basename(py_path))[0]
    return base + ".json"


def require(cond: bool, msg: str) -> None:
    if not cond:
        raise ValueError(msg)


def parse_csv_floats(s: str) -> List[float]:
    return [float(x.strip()) for x in s.split(",") if x.strip()]


def finite_or_none(x: float) -> Optional[float]:
    return x if math.isfinite(x) else None


# ----------------------------
# Toy 048
# ----------------------------

class Toy048BackreactionThreshold:
    toy_id = "048"

    def __init__(
        self,
        *,
        M: float = 1.0,
        q_max: float = 1e-3,
        eps_max: float = 1e-3,
        eps_lin_max: float = 1e-4,
    ) -> None:
        require(M > 0.0, "M must be > 0.")
        require(q_max > 0.0 and eps_max > 0.0 and eps_lin_max > 0.0, "thresholds must be > 0.")
        self.M = float(M)
        self.q_max = float(q_max)
        self.eps_max = float(eps_max)
        self.eps_lin_max = float(eps_lin_max)

    def horizon_radius(self) -> float:
        return 2.0 * self.M

    def perturbation_amplitude_eps(self, m: float, r: float) -> Optional[float]:
        # ε ≈ 2m/r (weak-field-like amplitude)
        if r <= 0.0 or m < 0.0:
            return None
        return finite_or_none(2.0 * m / r)

    def regime_label(self, q: float, eps: float) -> str:
        # A simple categorical label for downstream analysis
        if eps < self.eps_lin_max and q < self.q_max:
            return "linearized_ok_test_particle_ok"
        if eps < self.eps_max and q < self.q_max:
            return "linearized_marginal_test_particle_ok"
        if q < 0.1 and eps < 0.1:
            return "backreaction_needed_self_force_or_perturbative"
        return "fully_nonlinear_required"

    def evaluate(self, r: float, m: float) -> Dict[str, Any]:
        require(r > 0.0, "r must be > 0.")
        require(m >= 0.0, "m must be >= 0.")
        q = m / self.M
        eps = self.perturbation_amplitude_eps(m=m, r=r)

        test_particle_valid = None
        linearization_valid = None
        label = "undefined"

        if eps is not None:
            test_particle_valid = (q < self.q_max) and (eps < self.eps_max)
            linearization_valid = (eps < self.eps_lin_max)
            label = self.regime_label(q=q, eps=eps)

        # Background curvature scaling (Schwarzschild Kretschmann) for context
        K_bg = 48.0 * self.M**2 / (r**6)

        # Perturbation curvature scaling proxy ~ m/r^3 (not an invariant; a scale)
        # Compare perturbation to background at same r: ratio ~ m/M = q
        curvature_ratio_proxy = q

        return {
            "coordinates": {"r": r, "m": m},
            "curvature_invariants": {
                "background_kretschmann_K": finite_or_none(K_bg),
                "perturbation_curvature_ratio_proxy_m_over_M": finite_or_none(curvature_ratio_proxy),
            },
            "local_observables": {
                "mass_ratio_q": finite_or_none(q),
                "perturbation_amplitude_eps_approx_2m_over_r": eps,
                "thresholds": {
                    "q_max_test_particle": self.q_max,
                    "eps_max_test_particle": self.eps_max,
                    "eps_lin_max_linearization": self.eps_lin_max,
                },
                "validity_flags": {
                    "test_particle_valid": test_particle_valid,
                    "linearization_valid": linearization_valid,
                },
                "regime_label": label,
            },
            "causal_structure": {
                "horizon_radius_2M": self.horizon_radius(),
                "inside_horizon": (r < self.horizon_radius()),
            },
        }

    def build_payload(self, r_values: List[float], m_values: List[float]) -> Dict[str, Any]:
        sample_points: List[Dict[str, Any]] = []
        for r, m in itertools.product(r_values, m_values):
            sample_points.append(self.evaluate(r=r, m=m))

        # Count regimes
        counts: Dict[str, int] = {}
        for sp in sample_points:
            label = sp["local_observables"]["regime_label"]
            counts[label] = counts.get(label, 0) + 1

        return {
            "toy_id": self.toy_id,
            "theory": "General Relativity (approximate backreaction proxy)",
            "spacetime": "Schwarzschild background + compact perturbation proxy",
            "units": {"G": 1, "c": 1},
            "parameters": {
                "M": self.M,
                "r_samples": r_values,
                "m_samples": m_values,
                "q_max": self.q_max,
                "eps_max": self.eps_max,
                "eps_lin_max": self.eps_lin_max,
            },
            "notes": {
                "assumptions": [
                    "Background is exact Schwarzschild of mass M",
                    "Perturbing object treated as compact mass m at radius r (proxy)",
                    "Perturbation amplitude estimated as eps ≈ 2m/r",
                    "Backreaction importance measured by q=m/M and eps",
                    "This is not a full self-force/NR treatment; it is a controlled threshold toy",
                ],
                "pressure_point": (
                    "Test-particle and linearized approximations fail beyond quantitative thresholds. "
                    "Backreaction is not optional once eps or q are not small."
                ),
                "key_formulas": {
                    "mass_ratio": "q = m/M",
                    "perturbation_amp": "eps ≈ 2m/r",
                    "background_K": "K_bg = 48 M^2 / r^6",
                    "curvature_ratio_proxy": "~ (m/r^3)/(M/r^3) = m/M = q",
                },
            },
            "sample_points": sample_points,
            "observables": {
                "summary": {
                    "horizon_radius_2M": self.horizon_radius(),
                    "regime_counts": counts,
                    "note": "Counts are over the Cartesian product of r_samples × m_samples.",
                }
            },
        }

    def export_json(self, r_values: List[float], m_values: List[float], out_path: Optional[str] = None) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)
        payload = self.build_payload(r_values=r_values, m_values=m_values)
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2, sort_keys=True)
        return out_path


# ----------------------------
# CLI
# ----------------------------

def main() -> None:
    ap = argparse.ArgumentParser(description="Toy 048: Backreaction threshold proxy (test-field breakdown).")
    ap.add_argument("--M", type=float, default=1.0, help="Background mass M")
    ap.add_argument("--q_max", type=float, default=1e-3, help="Max mass ratio for test-particle validity")
    ap.add_argument("--eps_max", type=float, default=1e-3, help="Max eps≈2m/r for test-particle validity")
    ap.add_argument("--eps_lin_max", type=float, default=1e-4, help="Max eps≈2m/r for linearization validity")
    ap.add_argument("--r", type=str, default="3,4,6,10,20,50", help="Comma-separated radii r>0")
    ap.add_argument("--m", type=str, default="1e-8,1e-6,1e-4,1e-3,1e-2,1e-1", help="Comma-separated perturbing masses m>=0")
    ap.add_argument("--out", type=str, default="", help="Optional output path. If omitted, uses <this_script_name>.json")
    args = ap.parse_args()

    r_values = parse_csv_floats(args.r)
    m_values = parse_csv_floats(args.m)

    toy = Toy048BackreactionThreshold(
        M=float(args.M),
        q_max=float(args.q_max),
        eps_max=float(args.eps_max),
        eps_lin_max=float(args.eps_lin_max),
    )

    out_path = args.out.strip() or None
    json_path = toy.export_json(r_values=r_values, m_values=m_values, out_path=out_path)

    print(f"Wrote {json_path}")
    print("Toy 048 complete: backreaction threshold proxy.")


if __name__ == "__main__":
    main()
