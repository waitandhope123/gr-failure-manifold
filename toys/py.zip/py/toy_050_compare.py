#!/usr/bin/env python3
"""
Toy 050 — Cross-toy automated comparison harness (JSON diff + thresholds)

What it probes (weak points / pressure points):
- Turns the toy suite into a benchmark platform:
  * load multiple toy JSON outputs
  * extract comparable quantities
  * compute diffs against tolerances
  * emit a machine-readable report

This is a META-toy (infrastructure), not a spacetime model.

Inputs:
- One or more JSON files produced by other toys (same canonical schema).

Comparisons implemented (practical + robust):
1) Schema presence checks (required top-level keys)
2) For each file: summary extraction (toy_id, spacetime, parameters)
3) Numeric diff checks for selected "known common" fields if present:
   - curvature invariants: kretschmann_K (common in several toys)
   - ricci_scalar_R (common in several toys)
   - horizon_radius_2M (common in observables.summary or causal_structure)
4) Sample point alignment by matching coordinate keys exactly (e.g., r or t).
   - If coordinates don't match, report as "unmatched" rather than guessing.

Output:
- A JSON report following canonical schema, where:
  * sample_points contain per-quantity diff diagnostics
  * observables.summary contains overall pass/fail and counts

Usage patterns:
- Compare Toy 041 outputs across coordinate charts (should pass).
- Compare Toy 049 broken vs any correct invariant toy (should fail).

Note:
- This tool is intentionally conservative; it won't invent mappings.
"""

from __future__ import annotations

import argparse
import json
import math
import os
from typing import Any, Dict, List, Optional, Tuple


# ----------------------------
# Helpers
# ----------------------------

REQUIRED_TOP_LEVEL_KEYS = [
    "toy_id",
    "theory",
    "spacetime",
    "units",
    "parameters",
    "notes",
    "sample_points",
    "observables",
]


def py_to_json_name(py_path: str) -> str:
    base = os.path.splitext(os.path.basename(py_path))[0]
    return base + ".json"


def require(cond: bool, msg: str) -> None:
    if not cond:
        raise ValueError(msg)


def is_number(x: Any) -> bool:
    return isinstance(x, (int, float)) and math.isfinite(float(x))


def safe_get(d: Dict[str, Any], path: List[str]) -> Any:
    cur: Any = d
    for k in path:
        if not isinstance(cur, dict) or k not in cur:
            return None
        cur = cur[k]
    return cur


def rel_err(a: float, b: float) -> Optional[float]:
    if not (math.isfinite(a) and math.isfinite(b)):
        return None
    if a == 0.0:
        return None if b == 0.0 else math.inf
    return abs(a - b) / abs(a)


def abs_err(a: float, b: float) -> Optional[float]:
    if not (math.isfinite(a) and math.isfinite(b)):
        return None
    return abs(a - b)


def coord_signature(coords: Dict[str, Any]) -> Tuple[Tuple[str, Any], ...]:
    # canonical, hashable signature for alignment
    items = sorted(coords.items(), key=lambda kv: kv[0])
    return tuple((k, v) for k, v in items)


def load_json(path: str) -> Dict[str, Any]:
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def check_schema(payload: Dict[str, Any]) -> List[str]:
    missing = [k for k in REQUIRED_TOP_LEVEL_KEYS if k not in payload]
    return missing


# ----------------------------
# Extractors (conservative)
# ----------------------------

COMMON_FIELDS = [
    # (human_name, path_in_sample_point_or_payload, location)
    ("kretschmann_K", ["curvature_invariants", "kretschmann_K"], "sample_point"),
    ("ricci_scalar_R", ["curvature_invariants", "ricci_scalar_R"], "sample_point"),
    ("ricci_scalar_R", ["curvature_invariants", "ricci_scalar_R_correct"], "sample_point"),  # toy_049 style
    ("horizon_radius_2M", ["causal_structure", "horizon_radius_2M"], "sample_point"),
    ("horizon_radius_2M", ["observables", "summary", "horizon_radius_2M"], "payload"),
]


def build_sample_index(payload: Dict[str, Any]) -> Dict[Tuple[Tuple[str, Any], ...], Dict[str, Any]]:
    idx: Dict[Tuple[Tuple[str, Any], ...], Dict[str, Any]] = {}
    sps = payload.get("sample_points", [])
    if not isinstance(sps, list):
        return idx
    for sp in sps:
        if not isinstance(sp, dict):
            continue
        coords = sp.get("coordinates", {})
        if not isinstance(coords, dict):
            continue
        idx[coord_signature(coords)] = sp
    return idx


def extract_payload_value(payload: Dict[str, Any], human_name: str) -> Optional[float]:
    # currently only horizon_radius_2M supported here
    if human_name == "horizon_radius_2M":
        v = safe_get(payload, ["observables", "summary", "horizon_radius_2M"])
        return float(v) if is_number(v) else None
    return None


def extract_sample_value(sample_point: Dict[str, Any], human_name: str) -> Optional[float]:
    # Try known common paths for the given name
    if human_name == "kretschmann_K":
        v = safe_get(sample_point, ["curvature_invariants", "kretschmann_K"])
        return float(v) if is_number(v) else None
    if human_name == "ricci_scalar_R":
        v = safe_get(sample_point, ["curvature_invariants", "ricci_scalar_R"])
        if is_number(v):
            return float(v)
        v2 = safe_get(sample_point, ["curvature_invariants", "ricci_scalar_R_correct"])
        return float(v2) if is_number(v2) else None
    if human_name == "horizon_radius_2M":
        v = safe_get(sample_point, ["causal_structure", "horizon_radius_2M"])
        return float(v) if is_number(v) else None
    return None


# ----------------------------
# Comparator
# ----------------------------

def compare_two(
    a: Dict[str, Any],
    b: Dict[str, Any],
    a_name: str,
    b_name: str,
    tol_abs: float,
    tol_rel: float,
) -> Dict[str, Any]:
    """
    Compare payload a vs b. Returns a report dict.
    """
    missing_a = check_schema(a)
    missing_b = check_schema(b)

    idx_a = build_sample_index(a)
    idx_b = build_sample_index(b)

    # union of coordinate signatures
    sigs = sorted(set(idx_a.keys()).union(set(idx_b.keys())))

    diffs: List[Dict[str, Any]] = []
    pass_all = True
    matched = 0
    unmatched = 0
    numeric_checks = 0
    numeric_failures = 0

    for sig in sigs:
        sp_a = idx_a.get(sig)
        sp_b = idx_b.get(sig)

        coords = dict(sig)

        if sp_a is None or sp_b is None:
            unmatched += 1
            diffs.append({
                "coordinates": coords,
                "curvature_invariants": {},
                "local_observables": {
                    "alignment": {
                        "matched": False,
                        "present_in_a": sp_a is not None,
                        "present_in_b": sp_b is not None,
                    }
                },
                "causal_structure": {},
            })
            continue

        matched += 1

        # Compare common numeric fields (if both define them)
        field_reports: Dict[str, Any] = {}
        for field in ["kretschmann_K", "ricci_scalar_R", "horizon_radius_2M"]:
            va = extract_sample_value(sp_a, field)
            vb = extract_sample_value(sp_b, field)

            if va is None or vb is None:
                field_reports[field] = {
                    "a": va,
                    "b": vb,
                    "compared": False,
                    "reason": "missing_or_non_numeric",
                }
                continue

            numeric_checks += 1
            ae = abs_err(va, vb)
            re = rel_err(va, vb)

            ok = True
            if ae is not None and ae > tol_abs:
                ok = False
            if re is not None and re > tol_rel:
                ok = False

            if not ok:
                numeric_failures += 1
                pass_all = False

            field_reports[field] = {
                "a": va,
                "b": vb,
                "abs_error": ae,
                "rel_error": re,
                "tolerances": {"abs": tol_abs, "rel": tol_rel},
                "pass": ok,
                "compared": True,
            }

        diffs.append({
            "coordinates": coords,
            "curvature_invariants": {
                "field_diffs": field_reports
            },
            "local_observables": {
                "alignment": {"matched": True}
            },
            "causal_structure": {},
        })

    # Also compare payload-level horizon if present
    horiz_a = extract_payload_value(a, "horizon_radius_2M")
    horiz_b = extract_payload_value(b, "horizon_radius_2M")
    payload_horizon_report: Dict[str, Any]
    if horiz_a is not None and horiz_b is not None:
        ae = abs_err(horiz_a, horiz_b)
        re = rel_err(horiz_a, horiz_b)
        ok = True
        if ae is not None and ae > tol_abs:
            ok = False
        if re is not None and re > tol_rel:
            ok = False
        if not ok:
            pass_all = False
        payload_horizon_report = {
            "a": horiz_a,
            "b": horiz_b,
            "abs_error": ae,
            "rel_error": re,
            "tolerances": {"abs": tol_abs, "rel": tol_rel},
            "pass": ok,
            "compared": True,
        }
    else:
        payload_horizon_report = {
            "a": horiz_a,
            "b": horiz_b,
            "compared": False,
            "reason": "missing_or_non_numeric",
        }

    report = {
        "toy_id": "050",
        "theory": "GR Toy Lab Harness",
        "spacetime": "Cross-toy JSON comparator",
        "units": {"G": 1, "c": 1},
        "parameters": {
            "file_a": a_name,
            "file_b": b_name,
            "tol_abs": tol_abs,
            "tol_rel": tol_rel,
        },
        "notes": {
            "purpose": (
                "Load two toy JSON outputs and compute conservative diffs over common quantities. "
                "Used for regression testing and theory comparisons."
            ),
            "required_top_level_keys": REQUIRED_TOP_LEVEL_KEYS,
            "common_fields_compared": ["kretschmann_K", "ricci_scalar_R", "horizon_radius_2M"],
        },
        "sample_points": diffs,
        "observables": {
            "summary": {
                "schema_missing_a": missing_a,
                "schema_missing_b": missing_b,
                "payload_horizon_comparison": payload_horizon_report,
                "matched_sample_points": matched,
                "unmatched_sample_points": unmatched,
                "numeric_checks": numeric_checks,
                "numeric_failures": numeric_failures,
                "overall_pass": (pass_all and not missing_a and not missing_b),
            }
        },
    }
    return report


# ----------------------------
# CLI
# ----------------------------

def main() -> None:
    ap = argparse.ArgumentParser(description="Toy 050: Compare two toy JSON outputs (conservative diff).")
    ap.add_argument("json_a", type=str, help="Path to first toy JSON")
    ap.add_argument("json_b", type=str, help="Path to second toy JSON")
    ap.add_argument("--tol_abs", type=float, default=1e-12, help="Absolute tolerance")
    ap.add_argument("--tol_rel", type=float, default=1e-12, help="Relative tolerance")
    ap.add_argument("--out", type=str, default="", help="Optional output path; defaults to <this_script_name>.json")
    args = ap.parse_args()

    a = load_json(args.json_a)
    b = load_json(args.json_b)

    report = compare_two(
        a=a,
        b=b,
        a_name=os.path.basename(args.json_a),
        b_name=os.path.basename(args.json_b),
        tol_abs=float(args.tol_abs),
        tol_rel=float(args.tol_rel),
    )

    out_path = args.out.strip() or py_to_json_name(__file__)
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(report, f, indent=2, sort_keys=True)

    print(f"Wrote {out_path}")
    print(f"Overall pass: {report['observables']['summary']['overall_pass']}")


if __name__ == "__main__":
    main()
