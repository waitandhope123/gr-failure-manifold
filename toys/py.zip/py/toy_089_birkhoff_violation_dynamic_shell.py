#!/usr/bin/env python3
"""
Toy 089 — Birkhoff’s theorem boundary: time-dependent exterior from spherically symmetric matter (violation case)

What it probes (pressure point):
- Birkhoff's theorem (GR) says: any spherically symmetric *vacuum* region must be Schwarzschild (static).
- The hidden assumption is VACUUM. If the exterior contains even a spherically symmetric *radiation flux*
  (null dust / Vaidya), the exterior can be time-dependent while retaining spherical symmetry.
- This is a clean "failure axis": how a theorem fails when a hypothesis is dropped.

Model:
- Use outgoing Vaidya metric as an exact spherically symmetric solution with null dust:
    ds^2 = -(1 - 2M(u)/r) du^2 - 2 du dr + r^2 dΩ^2
  where u is retarded time and M(u) decreases with outgoing radiation (mass loss).
- Stress-energy is nonzero when dM/du != 0:
    T_uu = -(1/(4π r^2)) dM/du
  (sign conventions vary; we export a scalar proxy with explicit sign as written here).

Curvature diagnostics:
- Ricci scalar R = 0 for null dust (trace-free) => exported as 0 where r>0 and model is valid.
- Kretschmann for Schwarzschild generalizes to K = 48 M(u)^2 / r^6 (for Vaidya this is the leading Weyl piece;
  additional Ricci terms exist but R itself is zero; we export this clean diagnostic scalar).
- Horizon proxy: apparent horizon r_AH(u) = 2 M(u). (Event horizon is global; we avoid claiming it.)

Failure behavior:
- If M(u) becomes negative or r <= 0 -> undefined (null fields).
- When dM/du -> 0, stress-energy vanishes and exterior becomes Schwarzschild again (Birkhoff recovered).

STRICT EXPORT RULE:
- Writes JSON named exactly like this .py file.
- JSON follows canonical schema; undefined quantities are null.
"""

from __future__ import annotations

import argparse
import json
import math
import os
from typing import Any, Dict, List, Optional


# ----------------------------
# Helpers
# ----------------------------

def py_to_json_name(py_path: str) -> str:
    base = os.path.splitext(os.path.basename(py_path))[0]
    return base + ".json"


def parse_csv_floats(s: str) -> List[float]:
    return [float(x.strip()) for x in s.split(",") if x.strip()]


def require(cond: bool, msg: str) -> None:
    if not cond:
        raise ValueError(msg)


# ----------------------------
# Vaidya mass profiles
# ----------------------------

def mass_profile_linear(u: float, M0: float, gamma: float, u0: float = 0.0) -> float:
    # M(u) = max(M0 - gamma*(u-u0), 0) but we keep raw for diagnostics and mark invalid if negative.
    return M0 - gamma * (u - u0)


def dMdu_linear(_: float, gamma: float) -> float:
    return -gamma


def mass_profile_smoothstep(u: float, M0: float, M1: float, u_mid: float, width: float) -> float:
    # Smooth transition from M0 to M1 using tanh
    require(width > 0.0, "width must be > 0.")
    s = 0.5 * (1.0 + math.tanh((u - u_mid) / width))
    return (1.0 - s) * M0 + s * M1


def dMdu_smoothstep(u: float, M0: float, M1: float, u_mid: float, width: float) -> float:
    # derivative of 0.5*(1+tanh(x)) is 0.5*sech^2(x) * (1/width)
    x = (u - u_mid) / width
    sech2 = 1.0 / (math.cosh(x) ** 2)
    dsdu = 0.5 * sech2 * (1.0 / width)
    return dsdu * (M1 - M0)


# ----------------------------
# Toy 089
# ----------------------------

class Toy089BirkhoffViolationVaidya:
    toy_id = "089"

    def __init__(
        self,
        profile: str,
        M0: float,
        gamma: float,
        M1: float,
        u_mid: float,
        width: float,
    ) -> None:
        self.profile = profile
        self.M0 = float(M0)
        self.gamma = float(gamma)
        self.M1 = float(M1)
        self.u_mid = float(u_mid)
        self.width = float(width)

        require(self.M0 > 0.0, "M0 must be > 0.")
        if self.profile == "linear":
            require(self.gamma >= 0.0, "gamma must be >= 0 for linear mass loss.")
        elif self.profile == "smoothstep":
            require(self.M1 >= 0.0, "M1 must be >= 0.")
            require(self.width > 0.0, "width must be > 0.")
        else:
            raise ValueError("profile must be one of: linear, smoothstep")

    def M(self, u: float) -> float:
        if self.profile == "linear":
            return mass_profile_linear(u=u, M0=self.M0, gamma=self.gamma, u0=0.0)
        return mass_profile_smoothstep(u=u, M0=self.M0, M1=self.M1, u_mid=self.u_mid, width=self.width)

    def dMdu(self, u: float) -> float:
        if self.profile == "linear":
            return dMdu_linear(u, gamma=self.gamma)
        return dMdu_smoothstep(u=u, M0=self.M0, M1=self.M1, u_mid=self.u_mid, width=self.width)

    def f(self, u: float, r: float) -> Optional[float]:
        if r <= 0.0:
            return None
        M = self.M(u)
        if M < 0.0:
            return None
        return 1.0 - 2.0 * M / r

    def ricci_scalar(self, u: float, r: float) -> Optional[float]:
        # Null dust is trace-free => R = 0 (where defined, r>0, M>=0).
        if r <= 0.0:
            return None
        if self.M(u) < 0.0:
            return None
        return 0.0

    def kretschmann_weyl_piece(self, u: float, r: float) -> Optional[float]:
        if r <= 0.0:
            return None
        M = self.M(u)
        if M < 0.0:
            return None
        return 48.0 * (M ** 2) / (r ** 6)

    def stress_energy_Tuu_proxy(self, u: float, r: float) -> Optional[float]:
        # T_uu = -(1/(4π r^2)) dM/du (as written here).
        if r <= 0.0:
            return None
        M = self.M(u)
        if M < 0.0:
            return None
        return -(1.0 / (4.0 * math.pi * (r ** 2))) * self.dMdu(u)

    def apparent_horizon(self, u: float) -> Optional[float]:
        M = self.M(u)
        if M < 0.0:
            return None
        return 2.0 * M

    def build_payload(self, u_values: List[float], r_values: List[float]) -> Dict[str, Any]:
        sample_points: List[Dict[str, Any]] = []

        # Summaries: how time-dependent is it?
        max_abs_dMdu = 0.0
        any_invalid = False

        for u in u_values:
            u = float(u)
            M_u = self.M(u)
            dM_u = self.dMdu(u)
            if M_u < 0.0:
                any_invalid = True
            max_abs_dMdu = max(max_abs_dMdu, abs(dM_u))

            for r in r_values:
                r = float(r)

                fval = self.f(u, r)
                R = self.ricci_scalar(u, r)
                K = self.kretschmann_weyl_piece(u, r)
                Tuu = self.stress_energy_Tuu_proxy(u, r)
                r_AH = self.apparent_horizon(u)

                region = None
                if fval is None:
                    region = "undefined"
                else:
                    # In outgoing EF-like coordinates, f=0 is apparent horizon surface.
                    if abs(fval) < 1e-14:
                        region = "on_apparent_horizon"
                    elif fval > 0.0:
                        region = "outside_apparent_horizon"
                    else:
                        region = "inside_apparent_horizon"

                sample_points.append({
                    "coordinates": {"u_retarded": u, "r": r},
                    "curvature_invariants": {
                        "ricci_scalar": R,
                        "kretschmann": K,
                    },
                    "local_observables": {
                        "mass_function": {
                            "M_u": (M_u if M_u >= 0.0 else None),
                            "dMdu": (dM_u if M_u >= 0.0 else None),
                        },
                        "metric_function": {
                            "f_u_r": fval,
                        },
                        "stress_energy": {
                            "Tuu_null_dust_proxy": Tuu,
                            "trace_T": 0.0 if (R == 0.0) else None,
                        },
                        "horizon_proxies": {
                            "apparent_horizon_r_AH": r_AH,
                        },
                    },
                    "causal_structure": {
                        "spherical_symmetry": True,
                        "vacuum_region": (True if (Tuu == 0.0) else False) if Tuu is not None else None,
                        "birkhoff_applies": (True if (Tuu == 0.0) else False) if Tuu is not None else None,
                        "time_dependent_exterior": (True if (abs(dM_u) > 0.0) else False) if M_u >= 0.0 else None,
                        "region": region,
                    },
                })

        # Global summary checks
        # Birkhoff "fails" (inapplicable) if any point has nonzero Tuu.
        nonvacuum_count = 0
        defined_count = 0
        for sp in sample_points:
            Tuu = sp["local_observables"]["stress_energy"]["Tuu_null_dust_proxy"]
            if Tuu is None:
                continue
            defined_count += 1
            if abs(Tuu) > 0.0:
                nonvacuum_count += 1

        payload: Dict[str, Any] = {
            "toy_id": self.toy_id,
            "theory": "General Relativity (exact spherical null-dust exterior: outgoing Vaidya)",
            "spacetime": "Outgoing Vaidya: spherically symmetric but time-dependent when dM/du != 0",
            "units": {"G": 1, "c": 1},
            "parameters": {
                "profile": self.profile,
                "M0": self.M0,
                "gamma": self.gamma if self.profile == "linear" else None,
                "M1": self.M1 if self.profile == "smoothstep" else None,
                "u_mid": self.u_mid if self.profile == "smoothstep" else None,
                "width": self.width if self.profile == "smoothstep" else None,
                "u_values": u_values,
                "r_values": r_values,
                "metric_form": "ds^2=-(1-2M(u)/r)du^2-2 du dr + r^2 dΩ^2",
                "stress_energy_form": "T_uu = -(1/(4π r^2)) dM/du  (sign convention explicit)",
                "apparent_horizon_proxy": "r_AH(u)=2M(u)",
            },
            "notes": {
                "pressure_point": (
                    "Birkhoff's theorem guarantees a static exterior only for vacuum. "
                    "With even spherically symmetric radiation (null dust), the exterior can be time-dependent: "
                    "spherical symmetry does not imply stationarity once T_ab != 0."
                ),
                "interpretation": (
                    "This toy is a theorem-boundary demonstrator, not a collapse simulation. "
                    "It shows exactly how dropping a hypothesis (vacuum) changes the conclusion."
                ),
                "caution": (
                    "Event horizons are global and not computed here. We export the apparent-horizon proxy r_AH(u)=2M(u)."
                ),
            },
            "sample_points": sample_points,
            "observables": {
                "summary": {
                    "max_abs_dMdu_over_u_samples": max_abs_dMdu,
                    "any_invalid_mass_region_M_u_lt_0": any_invalid,
                    "nonvacuum_points_with_Tuu_nonzero": nonvacuum_count,
                    "defined_points_with_Tuu_defined": defined_count,
                    "fraction_nonvacuum": (nonvacuum_count / defined_count) if defined_count > 0 else None,
                    "birkhoff_applicability": (
                        "applies_only_where_Tuu_is_zero"
                    ),
                }
            },
        }
        return payload

    def export_json(self, u_values: List[float], r_values: List[float], out_path: Optional[str] = None) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)
        payload = self.build_payload(u_values=u_values, r_values=r_values)
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2, sort_keys=True)
        return out_path


# ----------------------------
# CLI
# ----------------------------

def main() -> None:
    ap = argparse.ArgumentParser(description="Toy 089: Birkhoff theorem boundary via outgoing Vaidya.")
    ap.add_argument("--profile", type=str, default="smoothstep", choices=["linear", "smoothstep"])
    ap.add_argument("--M0", type=float, default=1.0, help="Initial mass parameter M0.")
    ap.add_argument("--gamma", type=float, default=0.02, help="Linear mass-loss rate (used if profile=linear).")
    ap.add_argument("--M1", type=float, default=0.6, help="Final mass (used if profile=smoothstep).")
    ap.add_argument("--u_mid", type=float, default=10.0, help="Transition midpoint u_mid (smoothstep).")
    ap.add_argument("--width", type=float, default=2.0, help="Transition width (smoothstep).")
    ap.add_argument("--u", type=str, default="0,5,10,12,15,25",
                    help="Comma-separated retarded times u to sample.")
    ap.add_argument("--r", type=str, default="1.5,2,3,5,10,20",
                    help="Comma-separated radii r to sample.")
    ap.add_argument("--out", type=str, default="")
    args = ap.parse_args()

    u_values = parse_csv_floats(args.u)
    r_values = parse_csv_floats(args.r)

    toy = Toy089BirkhoffViolationVaidya(
        profile=args.profile,
        M0=args.M0,
        gamma=args.gamma,
        M1=args.M1,
        u_mid=args.u_mid,
        width=args.width,
    )

    out_path = args.out.strip() or None
    json_path = toy.export_json(u_values=u_values, r_values=r_values, out_path=out_path)

    print(f"Wrote {json_path}")
    print("Toy 089 complete: Birkhoff theorem boundary (nonvacuum spherical exterior).")


if __name__ == "__main__":
    main()
