#!/usr/bin/env python3
"""
Toy 070 — Patchwork reconstruction failure: global state not determined by local reduced data

What it probes (pressure point):
- Even in flat spacetime (curvature invariants = 0), local measurements / reduced states
  do not uniquely determine the global state.
- Attempting to reconstruct a global Gaussian state from overlapping local patch covariances
  produces ambiguity and inconsistency (non-uniqueness + reconstruction error).
- This operationalizes "failure of reduction": global structure is not recoverable from local pieces
  without extra assumptions.

Model (controlled approximation; ħ = 1 convention for Gaussian states):
- 2D NxN lattice of coupled harmonic oscillators (discretized free massive scalar field).
- Ground state is Gaussian with covariances:
    Cx = 1/2 K^{-1/2},   Cp = 1/2 K^{+1/2}
  where K = m^2 I + Laplacian_2D (nearest-neighbor, open boundary).

Patch data:
- For a patch size L, we consider all LxL square patches that fit on the lattice.
- For each patch P, we assume we have access only to (Cx_P, Cp_P), the reduced covariances.

Naive reconstruction ("stitching"):
- Build global matrices Cx_rec, Cp_rec by averaging entries over all patches that include them.
- This is a deterministic, explicitly defined reconstruction rule.
- Compare to the true global covariances via Frobenius relative error.

Physicality check:
- A valid Gaussian state must satisfy the uncertainty principle. For a *diagonal-mode check*,
  we use eigenvalues of (Cx_rec Cp_rec). For a physical state, eigenvalues >= (1/2)^2 in ideal conditions.
  Reconstruction can violate this (or approach violation) due to inconsistent stitching.

Export:
- Strict JSON schema per lab protocol.
- Undefined quantities => null; keys never omitted.
- Curvature invariants set to zero (flat background).
"""

from __future__ import annotations

import argparse
import json
import math
import os
from typing import Any, Dict, List, Optional, Tuple

import numpy as np


# ----------------------------
# Helpers
# ----------------------------

def py_to_json_name(py_path: str) -> str:
    base = os.path.splitext(os.path.basename(py_path))[0]
    return base + ".json"


def require(cond: bool, msg: str) -> None:
    if not cond:
        raise ValueError(msg)


def finite_or_none(x: float) -> Optional[float]:
    return x if (isinstance(x, (int, float)) and math.isfinite(x)) else None


def parse_csv_ints(s: str) -> List[int]:
    out: List[int] = []
    for tok in s.split(","):
        tok = tok.strip()
        if tok:
            out.append(int(tok))
    return out


def idx(i: int, j: int, N: int) -> int:
    return i * N + j


# ----------------------------
# Lattice ground state (Gaussian)
# ----------------------------

def build_K_matrix(N: int, m: float) -> np.ndarray:
    """
    K = m^2 I + Laplacian_2D with open boundary, nearest-neighbor coupling:
      x^T K x = Σ_a m^2 x_a^2 + Σ_<ab> (x_a - x_b)^2
    """
    require(N >= 2, "N must be >= 2")
    require(m > 0.0, "m must be > 0 (avoids zero modes)")

    n = N * N
    K = np.zeros((n, n), dtype=float)

    for i in range(N):
        for j in range(N):
            a = idx(i, j, N)
            deg = 0
            for di, dj in [(-1, 0), (1, 0), (0, -1), (0, 1)]:
                ii, jj = i + di, j + dj
                if 0 <= ii < N and 0 <= jj < N:
                    b = idx(ii, jj, N)
                    K[a, b] = -1.0
                    deg += 1
            K[a, a] = m * m + deg

    K = 0.5 * (K + K.T)
    return K


def matrix_sqrt_and_invsqrt_spd(A: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
    w, V = np.linalg.eigh(A)
    require(np.all(w > 0.0), "Matrix not SPD (eigenvalue <= 0). Increase m or check construction.")
    sqrt_w = np.sqrt(w)
    invsqrt_w = 1.0 / sqrt_w
    A_sqrt = (V * sqrt_w) @ V.T
    A_invsqrt = (V * invsqrt_w) @ V.T
    return A_sqrt, A_invsqrt


def ground_state_covariances(N: int, m: float) -> Tuple[np.ndarray, np.ndarray]:
    K = build_K_matrix(N, m)
    K_sqrt, K_invsqrt = matrix_sqrt_and_invsqrt_spd(K)
    Cp = 0.5 * K_sqrt
    Cx = 0.5 * K_invsqrt
    return Cx, Cp


# ----------------------------
# Patchwork reconstruction
# ----------------------------

def patch_indices(N: int, L: int, i0: int, j0: int) -> List[int]:
    require(1 <= L <= N, "L must be in [1, N]")
    require(0 <= i0 <= N - L and 0 <= j0 <= N - L, "Patch anchor out of range")
    inds: List[int] = []
    for i in range(i0, i0 + L):
        for j in range(j0, j0 + L):
            inds.append(idx(i, j, N))
    return inds


def reconstruct_by_averaging(C: np.ndarray, N: int, L: int) -> np.ndarray:
    """
    Given true covariance C, pretend we only know all LxL patch submatrices.
    Reconstruct a global covariance C_rec by averaging overlapping patch contributions.
    """
    n = N * N
    C_sum = np.zeros((n, n), dtype=float)
    C_cnt = np.zeros((n, n), dtype=float)

    for i0 in range(0, N - L + 1):
        for j0 in range(0, N - L + 1):
            inds = patch_indices(N, L, i0, j0)
            sub = C[np.ix_(inds, inds)]
            # Add contributions
            for a_loc, a in enumerate(inds):
                for b_loc, b in enumerate(inds):
                    C_sum[a, b] += sub[a_loc, b_loc]
                    C_cnt[a, b] += 1.0

    # Where uncovered (should not happen for L>=1), leave as 0
    C_rec = np.zeros((n, n), dtype=float)
    mask = C_cnt > 0.0
    C_rec[mask] = C_sum[mask] / C_cnt[mask]

    # Symmetrize
    C_rec = 0.5 * (C_rec + C_rec.T)
    return C_rec


def rel_fro_error(A: np.ndarray, B: np.ndarray) -> float:
    num = np.linalg.norm(A - B, ord="fro")
    den = np.linalg.norm(A, ord="fro")
    return float(num / den) if den > 0 else float("nan")


def min_uncertainty_eig(Cx: np.ndarray, Cp: np.ndarray) -> Optional[float]:
    """
    For a consistent Gaussian covariance with no x-p correlations (this model),
    eigenvalues of (Cx Cp) should be >= (1/2)^2 in ideal conditions (mode-by-mode).
    We compute the minimum eigenvalue of symmetrized (Cx Cp).
    """
    M = Cx @ Cp
    M = 0.5 * (M + M.T)
    try:
        eig = np.linalg.eigvalsh(M)
    except np.linalg.LinAlgError:
        return None
    return float(np.min(eig))


# ----------------------------
# Toy 070
# ----------------------------

class Toy070PatchworkReconstructionFailure:
    toy_id = "070"

    def __init__(self, *, N: int, m: float) -> None:
        require(N >= 2, "N must be >= 2.")
        require(m > 0.0, "m must be > 0.")
        self.N = int(N)
        self.m = float(m)
        self.Cx_true, self.Cp_true = ground_state_covariances(self.N, self.m)

    def sample_point(self, L: int) -> Dict[str, Any]:
        Cx_rec = reconstruct_by_averaging(self.Cx_true, self.N, L)
        Cp_rec = reconstruct_by_averaging(self.Cp_true, self.N, L)

        err_Cx = rel_fro_error(self.Cx_true, Cx_rec)
        err_Cp = rel_fro_error(self.Cp_true, Cp_rec)

        lam_min_true = min_uncertainty_eig(self.Cx_true, self.Cp_true)
        lam_min_rec = min_uncertainty_eig(Cx_rec, Cp_rec)

        # Heisenberg mode-wise check: λ_min >= 1/4 (since (1/2)^2)
        phys_true = None if lam_min_true is None else (lam_min_true >= 0.25 - 1e-10)
        phys_rec = None if lam_min_rec is None else (lam_min_rec >= 0.25 - 1e-10)

        return {
            "coordinates": {"t": None, "x": None, "y": None, "z": None, "patch_size_L": L},
            "curvature_invariants": {
                "ricci_scalar": 0.0,
                "kretschmann": 0.0,
                "note": "Flat background: reconstruction failure is informational/operational, not geometric curvature.",
            },
            "local_observables": {
                "lattice_N_by_N": self.N,
                "mass_gap_m": self.m,
                "patch_size_L": L,
                "num_patches": (self.N - L + 1) ** 2,
                "reconstruction_rule": "average overlapping patch entries for Cx and Cp separately",
                "relative_frobenius_error_Cx": finite_or_none(err_Cx),
                "relative_frobenius_error_Cp": finite_or_none(err_Cp),
                "min_eigenvalue_CxCp_true": finite_or_none(lam_min_true) if lam_min_true is not None else None,
                "min_eigenvalue_CxCp_reconstructed": finite_or_none(lam_min_rec) if lam_min_rec is not None else None,
                "heisenberg_modewise_ok_true": phys_true,
                "heisenberg_modewise_ok_reconstructed": phys_rec,
                "note": (
                    "Even with complete local patch covariances, naive stitching does not guarantee recovery of the "
                    "true global covariance, and may degrade physicality diagnostics."
                ),
            },
            "causal_structure": {
                "horizon_radius": None,
                "region": "flat lattice Gaussian ground state (no horizons)",
                "note": "No causal pathology; the pressure point is reconstruction ambiguity from local data.",
            },
        }

    def build_payload(self, L_values: List[int]) -> Dict[str, Any]:
        require(len(L_values) >= 1, "Need at least one L sample.")
        for L in L_values:
            require(1 <= L <= self.N, "Each L must be in [1, N].")

        sample_points = [self.sample_point(L) for L in L_values]

        # Summary: how errors shrink with larger patches, but do not encode uniqueness in principle
        errs_cx = [sp["local_observables"]["relative_frobenius_error_Cx"] for sp in sample_points if sp["local_observables"]["relative_frobenius_error_Cx"] is not None]
        errs_cp = [sp["local_observables"]["relative_frobenius_error_Cp"] for sp in sample_points if sp["local_observables"]["relative_frobenius_error_Cp"] is not None]

        return {
            "toy_id": self.toy_id,
            "theory": "Flat spacetime quantum field toy (Gaussian state); reduction/reconstruction diagnostic",
            "spacetime": "Minkowski (discretized 2D harmonic lattice; no curvature, no horizons)",
            "units": {"G": 1, "c": 1},
            "parameters": {
                "lattice_N_by_N": self.N,
                "mass_gap_m": self.m,
                "patch_sizes_L": L_values,
                "conventions": "ħ = 1; Gaussian ground state; no x-p cross-covariances in this model",
            },
            "notes": {
                "pressure_point": (
                    "Global structure is not determined by local reduced data alone: patchwork reconstruction introduces "
                    "ambiguity and inconsistency even in a simple flat Gaussian field model."
                ),
                "key_equations": {
                    "hamiltonian": "H = 1/2 (p^T p + x^T K x),  K = m^2 I + Laplacian_2D",
                    "covariances": "Cx = 1/2 K^{-1/2}, Cp = 1/2 K^{+1/2}",
                    "reconstruction": "C_rec[a,b] = average over all patches containing (a,b) of the patch submatrix entries",
                    "uncertainty_check": "min eig(Cx Cp) >= 1/4 (mode-wise proxy)",
                },
                "domain_of_validity": (
                    "Diagnostic toy: stitching rule is intentionally naive to expose underdetermination. "
                    "Larger patches reduce error, but do not supply a uniqueness principle."
                ),
            },
            "sample_points": sample_points,
            "observables": {
                "summary": {
                    "curvature_invariants_zero": True,
                    "horizons_present": False,
                    "min_relative_error_Cx_over_samples": finite_or_none(min(errs_cx)) if errs_cx else None,
                    "min_relative_error_Cp_over_samples": finite_or_none(min(errs_cp)) if errs_cp else None,
                    "note": "Errors fall with increasing patch size; reconstruction is not guaranteed uniquely by local data without extra assumptions.",
                }
            },
        }

    def export_json(self, L_values: List[int], out_path: Optional[str] = None) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)
        payload = self.build_payload(L_values=L_values)
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2, sort_keys=True)
        return out_path


def main() -> None:
    ap = argparse.ArgumentParser(description="Toy 070: patchwork reconstruction failure from local Gaussian covariances.")
    ap.add_argument("--N", type=int, default=8, help="Lattice size N (NxN), N>=2")
    ap.add_argument("--m", type=float, default=0.5, help="Mass gap m>0")
    ap.add_argument("--L", type=str, default="1,2,3,4,6,8", help="Comma-separated patch sizes L (<=N)")
    ap.add_argument("--out", type=str, default="", help="Optional output JSON path")
    args = ap.parse_args()

    L_values = parse_csv_ints(args.L)
    toy = Toy070PatchworkReconstructionFailure(N=int(args.N), m=float(args.m))

    out_path = args.out.strip() or None
    json_path = toy.export_json(L_values=L_values, out_path=out_path)

    print(f"Wrote {json_path}")
    print("Toy 070 complete: global state reconstruction from local patches shows ambiguity/inconsistency.")


if __name__ == "__main__":
    main()
