#!/usr/bin/env python3
"""
Toy 040 — Constraint propagation and numerical breakdown (1D linearized ADM constraint toy)

Pressure point / weakness probed:
- Einstein's equations are not "just evolution equations": they include constraints
  (Hamiltonian + momentum constraints) that must hold on every slice.
- In numerical evolution (and even in simplified PDE systems), small constraint violations can
  persist or grow unless explicitly controlled (gauge choice, constraint damping, formulation choice).
- This toy demonstrates constraint propagation on a simplified linearized ADM-like system in 1+1D.

Controlled toy system (linear wave with a constraint):
We evolve a scalar "metric perturbation" h(t,x) with wave equation:
  h_tt = h_xx

Define auxiliary variable:
  p = h_t

Then evolution system:
  h_t = p
  p_t = h_xx

Define a "constraint" C as the mismatch between p and the spatial derivative of a potential-like field:
Here we define a toy constraint mimicking "momentum constraint" structure:
  C(t,x) = p_x - h_tx  (which should be identically zero if p = h_t exactly and derivatives commute)

In discrete evolution, numerical errors make C != 0. We measure:
- L2 norm of constraint: ||C||_2
- max norm of constraint: ||C||_inf

We provide two modes:
- --mode plain: no damping (constraint violations propagate)
- --mode damped: add a simple damping term to p_t:
      p_t = h_xx - kappa * C_x
  (toy "constraint damping"; not GR-accurate but demonstrates principle)

Assumptions:
- Periodic boundary on x in [0, L)
- Finite difference in space, explicit time stepping (leapfrog-ish / RK2)
- Deterministic initial data, with an option to inject a small initial constraint violation.

Export:
- Writes JSON named exactly like this .py file.
- Uses the mandatory schema; undefined quantities are null.
"""

from __future__ import annotations

import argparse
import json
import math
import os
from typing import Any, Dict, List, Optional


# ----------------------------
# Helpers
# ----------------------------

def py_to_json_name(py_path: str) -> str:
    return os.path.splitext(os.path.basename(py_path))[0] + ".json"


def require(cond: bool, msg: str) -> None:
    if not cond:
        raise ValueError(msg)


def periodic_idx(i: int, n: int) -> int:
    return i % n


def ddx_centered(f: List[float], dx: float) -> List[float]:
    n = len(f)
    out = [0.0] * n
    for i in range(n):
        ip = periodic_idx(i + 1, n)
        im = periodic_idx(i - 1, n)
        out[i] = (f[ip] - f[im]) / (2.0 * dx)
    return out


def d2dx2_centered(f: List[float], dx: float) -> List[float]:
    n = len(f)
    out = [0.0] * n
    for i in range(n):
        ip = periodic_idx(i + 1, n)
        im = periodic_idx(i - 1, n)
        out[i] = (f[ip] - 2.0 * f[i] + f[im]) / (dx * dx)
    return out


def l2_norm(f: List[float], dx: float) -> float:
    return math.sqrt(sum(x * x for x in f) * dx)


def linf_norm(f: List[float]) -> float:
    return max(abs(x) for x in f) if f else 0.0


# ----------------------------
# Toy dynamics
# ----------------------------

def initial_h(x: float, L: float, amp: float, k: int) -> float:
    # single Fourier mode: amp * sin(2π k x / L)
    return amp * math.sin(2.0 * math.pi * k * x / L)


def initial_p_consistent(x: float, L: float, amp: float, k: int, omega: float) -> float:
    # For a traveling wave h ~ amp*sin(kx), p = h_t could be chosen 0 initially
    # (standing wave). We'll use p=0 for consistent initial slice.
    _ = (x, L, amp, k, omega)
    return 0.0


def evolve_step(
    h: List[float],
    p: List[float],
    dx: float,
    dt: float,
    mode: str,
    kappa: float,
) -> (List[float], List[float], List[float]):
    """
    One RK2 (midpoint) step for:
      h_t = p
      p_t = h_xx              (plain)
      p_t = h_xx - kappa C_x  (damped)
    where C = p_x - (h_t)_x = p_x - (p)_x = 0 analytically,
    but discretely we compute C = p_x - (d/dx)(h_t_est).
    Here h_t_est = p, so analytically C=0; discretely, we intentionally define
    C using mixed operators to create a meaningful monitor:
      C = p_x - d/dx(p_from_h)
    where p_from_h is computed as (h_new - h_old)/dt would require storage.
    Instead, we create a monitor constraint:
      C = p_x - (d/dx)(p)  computed with two *different* stencils:
        - p_x uses centered
        - (d/dx)(p) uses one-sided (upwind) to mimic formulation inconsistency.
    This yields a nontrivial constraint diagnostic that responds to numerical error.
    """
    n = len(h)

    # Define two derivative operators
    px_center = ddx_centered(p, dx)
    # one-sided derivative (forward difference) for "alternate formulation"
    px_forward = [0.0] * n
    for i in range(n):
        ip = periodic_idx(i + 1, n)
        px_forward[i] = (p[ip] - p[i]) / dx

    C = [px_center[i] - px_forward[i] for i in range(n)]  # constraint monitor
    Cx = ddx_centered(C, dx)

    def rhs(hv: List[float], pv: List[float]) -> (List[float], List[float], List[float]):
        hv_xx = d2dx2_centered(hv, dx)
        pv_t = [0.0] * n
        if mode == "plain":
            for i in range(n):
                pv_t[i] = hv_xx[i]
        else:
            # recompute constraint pieces for this stage
            px_c = ddx_centered(pv, dx)
            px_f = [0.0] * n
            for j in range(n):
                jp = periodic_idx(j + 1, n)
                px_f[j] = (pv[jp] - pv[j]) / dx
            Cv = [px_c[j] - px_f[j] for j in range(n)]
            Cxv = ddx_centered(Cv, dx)
            for i in range(n):
                pv_t[i] = hv_xx[i] - kappa * Cxv[i]
        hv_t = pv[:]  # h_t = p
        # For diagnostics: constraint computed at stage (reuse earlier for plain; for damped compute fresh)
        if mode == "plain":
            Cv_out = C
        else:
            # compute Cv_out consistent with this stage
            px_c = ddx_centered(pv, dx)
            px_f = [0.0] * n
            for j in range(n):
                jp = periodic_idx(j + 1, n)
                px_f[j] = (pv[jp] - pv[j]) / dx
            Cv_out = [px_c[j] - px_f[j] for j in range(n)]
        return hv_t, pv_t, Cv_out

    # RK2 midpoint
    h_t1, p_t1, C1 = rhs(h, p)
    h_mid = [h[i] + 0.5 * dt * h_t1[i] for i in range(n)]
    p_mid = [p[i] + 0.5 * dt * p_t1[i] for i in range(n)]
    h_t2, p_t2, C2 = rhs(h_mid, p_mid)

    h_new = [h[i] + dt * h_t2[i] for i in range(n)]
    p_new = [p[i] + dt * p_t2[i] for i in range(n)]

    # Use constraint from second stage for monitoring
    return h_new, p_new, C2


# ----------------------------
# Toy 040 driver
# ----------------------------

class Toy040ConstraintPropagation:
    toy_id = "040"

    def __init__(
        self,
        L: float,
        nx: int,
        dt: float,
        nsteps: int,
        amp: float,
        k_mode: int,
        inject_constraint: float,
        mode: str,
        kappa: float,
        sample_every: int,
    ) -> None:
        require(L > 0.0, "L must be > 0")
        require(nx >= 16, "nx must be >= 16")
        require(dt > 0.0, "dt must be > 0")
        require(nsteps >= 1, "nsteps must be >= 1")
        require(amp >= 0.0, "amp must be >= 0")
        require(k_mode >= 1, "k_mode must be >= 1")
        require(inject_constraint >= 0.0, "inject_constraint must be >= 0")
        require(mode in {"plain", "damped"}, "mode must be plain|damped")
        require(kappa >= 0.0, "kappa must be >= 0")
        require(sample_every >= 1, "sample_every must be >= 1")

        self.L = float(L)
        self.nx = int(nx)
        self.dt = float(dt)
        self.nsteps = int(nsteps)
        self.amp = float(amp)
        self.k_mode = int(k_mode)
        self.inject_constraint = float(inject_constraint)
        self.mode = mode
        self.kappa = float(kappa)
        self.sample_every = int(sample_every)

    def build_payload(self) -> Dict[str, Any]:
        dx = self.L / self.nx
        xs = [i * dx for i in range(self.nx)]

        # Initial data
        h = [initial_h(x, self.L, self.amp, self.k_mode) for x in xs]
        p = [initial_p_consistent(x, self.L, self.amp, self.k_mode, omega=0.0) for x in xs]

        # Inject a small constraint-violating high-frequency component into p if requested
        if self.inject_constraint > 0.0:
            # add a different Fourier mode into p to break "nice" consistency
            k_bad = self.k_mode * 3
            for i, x in enumerate(xs):
                p[i] += self.inject_constraint * math.sin(2.0 * math.pi * k_bad * x / self.L)

        sample_points: List[Dict[str, Any]] = []

        t = 0.0
        # initial constraint monitor (using the same definition as in evolve_step)
        px_center = ddx_centered(p, dx)
        px_forward = [(p[(i + 1) % self.nx] - p[i]) / dx for i in range(self.nx)]
        C = [px_center[i] - px_forward[i] for i in range(self.nx)]

        for step in range(self.nsteps + 1):
            if step % self.sample_every == 0:
                C_l2 = l2_norm(C, dx)
                C_inf = linf_norm(C)

                # We don't have a real spacetime metric here; export curvature invariants as null.
                sample_points.append({
                    "coordinates": {
                        "t": t,
                        "step": step
                    },
                    "curvature_invariants": {
                        "ricci_scalar": None,
                        "kretschmann": None
                    },
                    "local_observables": {
                        "constraint_L2": C_l2,
                        "constraint_Linf": C_inf,
                        "mode": self.mode,
                        "kappa": self.kappa if self.mode == "damped" else 0.0,
                        "notes": (
                            "Constraint monitor defined from inconsistent discrete derivative operators. "
                            "It is identically zero in the continuum, but captures numerical constraint violation behavior."
                        )
                    },
                    "causal_structure": {
                        "radial_null_cone_dx_dt": {"outgoing": 1.0, "ingoing": -1.0},
                        "horizon_radius": None,
                        "region": "toy linearized evolution with constraints (numerical-relativity analog)",
                        "energy_warning": (
                            "Einstein evolution requires constraints remain satisfied; numerical formulations "
                            "often require constraint damping or careful gauges to prevent growth."
                        )
                    }
                })

            if step == self.nsteps:
                break

            # evolve one step
            h, p, C = evolve_step(h, p, dx, self.dt, self.mode, self.kappa)
            t += self.dt

        # Summaries
        C_l2_vals = [sp["local_observables"]["constraint_L2"] for sp in sample_points]
        C_inf_vals = [sp["local_observables"]["constraint_Linf"] for sp in sample_points]
        payload: Dict[str, Any] = {
            "toy_id": self.toy_id,
            "theory": "General Relativity (numerical formulation / constraint propagation analog)",
            "spacetime": "ADM-like constrained evolution toy (1D linear wave with constraint monitor)",
            "units": {"G": 1, "c": 1},
            "parameters": {
                "L": self.L,
                "nx": self.nx,
                "dx": dx,
                "dt": self.dt,
                "nsteps": self.nsteps,
                "amp": self.amp,
                "k_mode": self.k_mode,
                "inject_constraint": self.inject_constraint,
                "mode": self.mode,
                "kappa": self.kappa if self.mode == "damped" else 0.0,
                "sample_every": self.sample_every
            },
            "notes": {
                "pressure_point": (
                    "GR evolution is constrained: initial data must satisfy constraints and the formulation must preserve them. "
                    "In practice, small numerical violations can persist or grow, motivating constraint-damping formulations. "
                    "This toy demonstrates constraint monitoring and damping in a simplified system."
                ),
                "limitations": (
                    "This is not Einstein's equations; it is a minimal analog demonstrating constraint behavior under evolution."
                ),
                "definitions_used": {
                    "evolution": "h_t=p, p_t=h_xx (plus optional damping term -kappa C_x)",
                    "constraint_monitor": "C = (p_x centered) - (p_x forward) (continuum limit would be zero)",
                    "norms": "L2 and Linf norms of C over the periodic domain"
                }
            },
            "sample_points": sample_points,
            "observables": {
                "summary": {
                    "n_samples": len(sample_points),
                    "constraint_L2_initial": C_l2_vals[0] if C_l2_vals else None,
                    "constraint_L2_final": C_l2_vals[-1] if C_l2_vals else None,
                    "constraint_Linf_initial": C_inf_vals[0] if C_inf_vals else None,
                    "constraint_Linf_final": C_inf_vals[-1] if C_inf_vals else None,
                    "key_result": (
                        "Without damping, constraint violations propagate according to the discretization; "
                        "with damping, norms are typically reduced (depending on kappa, dt, dx)."
                    )
                }
            }
        }
        return payload

    def export_json(self, out_path: Optional[str] = None) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)
        payload = self.build_payload()
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2, sort_keys=True)
        return out_path


def main() -> None:
    ap = argparse.ArgumentParser(description="Toy 040: Constraint propagation + damping (numerical relativity analog).")
    ap.add_argument("--L", type=float, default=1.0, help="Domain length L>0 (periodic)")
    ap.add_argument("--nx", type=int, default=256, help="Grid points nx>=16")
    ap.add_argument("--dt", type=float, default=0.0005, help="Time step dt>0")
    ap.add_argument("--nsteps", type=int, default=4000, help="Number of time steps")
    ap.add_argument("--amp", type=float, default=1e-3, help="Initial wave amplitude for h")
    ap.add_argument("--k", type=int, default=4, help="Fourier mode for initial h")
    ap.add_argument("--inject", type=float, default=1e-6, help="Inject constraint-violating component amplitude into p")
    ap.add_argument("--mode", type=str, default="plain", help="plain | damped")
    ap.add_argument("--kappa", type=float, default=0.1, help="Constraint damping strength (used if mode=damped)")
    ap.add_argument("--sample_every", type=int, default=50, help="Record every N steps")
    ap.add_argument("--out", type=str, default="", help="Optional output path; default is <script>.json")
    args = ap.parse_args()

    toy = Toy040ConstraintPropagation(
        L=float(args.L),
        nx=int(args.nx),
        dt=float(args.dt),
        nsteps=int(args.nsteps),
        amp=float(args.amp),
        k_mode=int(args.k),
        inject_constraint=float(args.inject),
        mode=args.mode.strip().lower(),
        kappa=float(args.kappa),
        sample_every=int(args.sample_every),
    )
    out_path = args.out.strip() or None
    json_path = toy.export_json(out_path=out_path)
    print(f"Wrote {json_path}")
    print("Notes:")
    print("- Compare --mode plain vs --mode damped to see constraint norm behavior.")


if __name__ == "__main__":
    main()
