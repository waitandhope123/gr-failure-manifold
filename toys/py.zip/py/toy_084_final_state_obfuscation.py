#!/usr/bin/env python3
"""
Toy 084 — Final-state obfuscation (Page curve + "unitarity preserved but operationally unstable")

Classification (lab axes):
- Failure Trigger: state + observer (information access / boundary condition)
- Failure Mode: predictability_loss + observer_disagreement
- Failure Sharpness: thick
- Repairable Within Classical GR: only_by_reinterpretation

What it probes (pressure point):
- A unitary evaporation toy can produce a Page-curve-like turnover: radiation entropy rises then falls,
  while information (mutual information with a reference) returns after "Page time".
- "Final-state" ideas (postselected boundary conditions at the end) can enforce purity of radiation,
  but at the cost of operational obfuscation: outcomes depend sensitively on the (unknown) final boundary,
  and postselection success probability can be tiny.

Model (fully deterministic; ħ=k_B=1):
- Qubits: Reference Rf (1), Black hole BH (n_bh), Radiation Rad (n_rad_max).
- Initial state: Rf maximally entangled with BH qubit 0; others |0>.
- Each step:
    (1) Deterministic "scrambler" unitary on BH (H layer + CNOT chain)
    (2) Emit one qubit by SWAP(BH qubit 0, Rad qubit t)

Observables per step:
- S(Rad): von Neumann entropy of radiation subsystem (Page curve proxy)
- S(BH): entropy of BH subsystem
- I(Rad : Rf): mutual information between radiation and reference (information return proxy)

Final-state postselection at end (two deterministic choices):
- Project BH onto |0...0>  (computational-basis final state)
- Project BH onto |+...+>  (Hadamard-basis final state)
Compute:
- postselection success probabilities p0, pplus
- resulting postselected radiation density matrices ρ_R^0, ρ_R^+
- trace distances:
    D(ρ_R, ρ_R^0), D(ρ_R, ρ_R^+), and D(ρ_R^0, ρ_R^+)
These quantify "obfuscation": purity may be enforced, but predictions depend on final boundary choice.

Export:
- Strict JSON schema per lab protocol; writes <script_name>.json.
- Undefined quantities encoded as null; keys never omitted.
"""

from __future__ import annotations

import argparse
import json
import math
import os
from typing import Any, Dict, List, Optional, Sequence, Tuple

import numpy as np


# ----------------------------
# Helpers
# ----------------------------

def py_to_json_name(py_path: str) -> str:
    base = os.path.splitext(os.path.basename(py_path))[0]
    return base + ".json"


def require(cond: bool, msg: str) -> None:
    if not cond:
        raise ValueError(msg)


def finite_or_none(x: float) -> Optional[float]:
    return x if (isinstance(x, (int, float)) and math.isfinite(x)) else None


def bits_to_index(bits: Sequence[int]) -> int:
    idx = 0
    for b in bits:
        idx = (idx << 1) | (b & 1)
    return idx


def kron_n(mats: Sequence[np.ndarray]) -> np.ndarray:
    out = np.array([[1.0]], dtype=complex)
    for M in mats:
        out = np.kron(out, M)
    return out


def partial_trace_rho(rho: np.ndarray, keep: List[int], n_qubits: int) -> np.ndarray:
    """
    Partial trace over qubits not in 'keep'.
    Qubits indexed 0..n_qubits-1.
    Returns reduced density matrix on 'keep' in the order given by 'keep'.
    """
    keep = list(keep)
    trace_over = sorted([q for q in range(n_qubits) if q not in keep], reverse=True)

    # reshape rho into tensor with one axis per qubit (row + col)
    rho_t = rho.reshape([2] * n_qubits * 2)

    current_n = n_qubits
    for q in trace_over:
        # trace over qubit q: row axis = q, col axis = q + current_n
        rho_t = np.trace(rho_t, axis1=q, axis2=q + current_n)
        current_n -= 1  # two axes removed

    # now rho_t has 2*len(keep) axes, but ordered by sorted(keep)
    keep_sorted = sorted(keep)

    # permute to requested order
    perm = [keep_sorted.index(k) for k in keep]
    permuted_axes = perm + [i + len(keep) for i in perm]

    rho_t = np.transpose(rho_t, axes=permuted_axes)

    dim = 2 ** len(keep)
    return rho_t.reshape((dim, dim))

def von_neumann_entropy(rho: np.ndarray) -> float:
    # ensure Hermitian
    rho_h = 0.5 * (rho + rho.conj().T)
    w = np.linalg.eigvalsh(rho_h)
    w = np.real(w)
    w = np.clip(w, 0.0, 1.0)
    s = 0.0
    for p in w:
        if p > 1e-300:
            s -= float(p) * math.log(float(p))
    return s


def mutual_information(rho_ab: np.ndarray, n_a_qubits: int, n_b_qubits: int) -> float:
    """
    Mutual information I(A:B)=S(A)+S(B)-S(AB) for a bipartite state rho_ab
    where A is the first n_a_qubits and B is the next n_b_qubits
    in the ordering of rho_ab.
    """
    require(n_a_qubits >= 1 and n_b_qubits >= 1, "need positive subsystem sizes")
    n_tot = n_a_qubits + n_b_qubits
    dim = 2 ** n_tot
    require(rho_ab.shape == (dim, dim), "rho_ab dim mismatch")

    # A qubits are [0..n_a_qubits-1], B qubits are [n_a_qubits..n_tot-1]
    A_keep = list(range(n_a_qubits))
    B_keep = list(range(n_a_qubits, n_tot))

    rho_a = partial_trace_rho(rho_ab, A_keep, n_tot)
    rho_b = partial_trace_rho(rho_ab, B_keep, n_tot)

    S_a = von_neumann_entropy(rho_a)
    S_b = von_neumann_entropy(rho_b)
    S_ab = von_neumann_entropy(rho_ab)
    return S_a + S_b - S_ab

def trace_distance(rho: np.ndarray, sigma: np.ndarray) -> float:
    # D = 1/2 ||rho - sigma||_1
    delta = 0.5 * ((rho - sigma) + (rho - sigma).conj().T)  # Hermitian part
    w = np.linalg.eigvalsh(delta)
    return 0.5 * float(np.sum(np.abs(np.real(w))))


# ----------------------------
# Gate application on statevector
# ----------------------------

def apply_unitary_state(psi: np.ndarray, U: np.ndarray, targets: List[int], n_qubits: int) -> np.ndarray:
    """
    Apply k-qubit unitary U to 'targets' qubits of n_qubits statevector psi.
    psi shape: (2^n,)
    U shape: (2^k,2^k)
    targets: list of qubit indices (0..n-1), unique.
    """
    k = len(targets)
    dim = 2 ** n_qubits
    require(psi.shape == (dim,), "psi dim mismatch")
    require(U.shape == (2 ** k, 2 ** k), "U dim mismatch")
    require(len(set(targets)) == k, "targets must be unique")
    require(all(0 <= t < n_qubits for t in targets), "target out of range")

    # Move targets to the end via transpose of tensor axes
    psi_t = psi.reshape([2] * n_qubits)
    other = [q for q in range(n_qubits) if q not in targets]
    perm = other + targets
    psi_p = np.transpose(psi_t, axes=perm).reshape((2 ** (n_qubits - k), 2 ** k))

    # Apply U on last subsystem
    psi_p2 = psi_p @ U.T  # (batch, 2^k)
    # Inverse permutation back
    psi_back = psi_p2.reshape([2] * (n_qubits - k) + [2] * k)
    inv_perm = np.argsort(np.array(perm))
    psi_final = np.transpose(psi_back, axes=inv_perm).reshape((dim,))
    return psi_final


def gate_H() -> np.ndarray:
    return (1.0 / math.sqrt(2.0)) * np.array([[1, 1], [1, -1]], dtype=complex)


def gate_X() -> np.ndarray:
    return np.array([[0, 1], [1, 0]], dtype=complex)


def gate_CNOT() -> np.ndarray:
    return np.array(
        [[1, 0, 0, 0],
         [0, 1, 0, 0],
         [0, 0, 0, 1],
         [0, 0, 1, 0]],
        dtype=complex,
    )


def gate_SWAP() -> np.ndarray:
    return np.array(
        [[1, 0, 0, 0],
         [0, 0, 1, 0],
         [0, 1, 0, 0],
         [0, 0, 0, 1]],
        dtype=complex,
    )


# ----------------------------
# Toy 084
# ----------------------------

class Toy084FinalStateObfuscation:
    toy_id = "084"

    def __init__(self, *, n_bh: int, n_rad: int, steps: int) -> None:
        require(n_bh >= 2, "n_bh must be >= 2")
        require(n_rad >= 1, "n_rad must be >= 1")
        require(1 <= steps <= n_rad, "steps must be between 1 and n_rad")
        self.n_bh = int(n_bh)
        self.n_rad = int(n_rad)
        self.steps = int(steps)

        # qubit layout: [Rf] [BH_0..BH_{n_bh-1}] [Rad_0..Rad_{n_rad-1}]
        self.q_rf = 0
        self.q_bh0 = 1
        self.q_rad0 = 1 + self.n_bh
        self.n_total = 1 + self.n_bh + self.n_rad

    def initial_state(self) -> np.ndarray:
        """
        |psi0> = (|0_Rf 0_BH0> + |1_Rf 1_BH0>)/sqrt2 ⊗ |0...0>_(rest)
        """
        dim = 2 ** self.n_total
        psi = np.zeros((dim,), dtype=complex)

        # build basis bitstrings for the two terms
        bits0 = [0] * self.n_total
        bits1 = [0] * self.n_total
        bits1[self.q_rf] = 1
        bits1[self.q_bh0] = 1

        psi[bits_to_index(bits0)] = 1.0 / math.sqrt(2.0)
        psi[bits_to_index(bits1)] = 1.0 / math.sqrt(2.0)
        return psi

    def scrambler_on_bh(self, psi: np.ndarray) -> np.ndarray:
        """
        Deterministic scrambling circuit on BH qubits:
        - Apply H to each BH qubit
        - Apply CNOT chain BH_i -> BH_{i+1}
        """
        H = gate_H()
        CNOT = gate_CNOT()

        # H layer
        for i in range(self.n_bh):
            q = self.q_bh0 + i
            psi = apply_unitary_state(psi, H, [q], self.n_total)

        # CNOT chain
        for i in range(self.n_bh - 1):
            qc = self.q_bh0 + i
            qt = self.q_bh0 + i + 1
            psi = apply_unitary_state(psi, CNOT, [qc, qt], self.n_total)

        return psi

    def emit_one_qubit(self, psi: np.ndarray, t: int) -> np.ndarray:
        """
        Emit at step t by SWAP(BH_0, Rad_t).
        """
        SW = gate_SWAP()
        qb = self.q_bh0
        qr = self.q_rad0 + t
        return apply_unitary_state(psi, SW, [qb, qr], self.n_total)

    def density_matrix(self, psi: np.ndarray) -> np.ndarray:
        return np.outer(psi, psi.conj())

    def step_observables(self, psi: np.ndarray, t: int) -> Dict[str, Any]:
        rho = self.density_matrix(psi)

        rad_qubits = list(range(self.q_rad0, self.q_rad0 + (t + 1)))
        bh_qubits = list(range(self.q_bh0, self.q_bh0 + self.n_bh))
        rf_qubits = [self.q_rf]

        # Reduced states
        rho_rad = partial_trace_rho(rho, rad_qubits, self.n_total)
        rho_bh = partial_trace_rho(rho, bh_qubits, self.n_total)
        rho_rf = partial_trace_rho(rho, rf_qubits, self.n_total)

        # Rad+Rf for mutual info
        rho_radrf = partial_trace_rho(rho, rad_qubits + rf_qubits, self.n_total)

        S_rad = von_neumann_entropy(rho_rad)
        S_bh = von_neumann_entropy(rho_bh)
        I_rad_rf = mutual_information(rho_radrf, n_a_qubits=len(rad_qubits), n_b_qubits=1)

        return {
            "t": t,
            "n_rad_emitted": t + 1,
            "S_rad": S_rad,
            "S_bh": S_bh,
            "S_rf": von_neumann_entropy(rho_rf),
            "I_rad_ref": I_rad_rf,
        }

    def project_bh_final_state(self, psi: np.ndarray, basis: str) -> Tuple[Optional[np.ndarray], Optional[float]]:
        """
        Postselect BH subsystem onto |0...0> (basis='comp') or |+...+> (basis='plus').
        Returns (rho_rad_post, success_prob) with Rad traced out and normalized.
        """
        require(basis in ("comp", "plus"), "basis must be 'comp' or 'plus'")

        # Build projector P on BH space only, then lift to full space by acting on BH qubits.
        # We'll implement by applying a BH-basis change then selecting computational |0...0> on BH.

        psi_work = psi.copy()

        if basis == "plus":
            # Rotate BH qubits so |+> maps to |0>: apply H on each BH qubit (since H|0>=|+>)
            H = gate_H()
            for i in range(self.n_bh):
                q = self.q_bh0 + i
                psi_work = apply_unitary_state(psi_work, H, [q], self.n_total)

        # Now project BH onto |0...0> in computational basis:
        # Keep only amplitudes where all BH bits are 0.
        dim = 2 ** self.n_total
        mask = np.zeros((dim,), dtype=bool)
        for idx in range(dim):
            # decode BH bits by checking positions; avoid full bit decode by shifting:
            ok = True
            x = idx
            # bits are in big-endian per bits_to_index; reconstruct by checking all positions:
            # We'll compute bits by repeated division (ok for dim<=4096 typical)
            bits = []
            y = idx
            for _ in range(self.n_total):
                bits.append(y & 1)
                y >>= 1
            bits = list(reversed(bits))
            for i in range(self.n_bh):
                if bits[self.q_bh0 + i] != 0:
                    ok = False
                    break
            mask[idx] = ok

        psi_proj = np.where(mask, psi_work, 0.0 + 0.0j)
        p = float(np.vdot(psi_proj, psi_proj).real)
        if not math.isfinite(p) or p <= 0.0:
            return None, None

        psi_norm = psi_proj / math.sqrt(p)

        # Reduced radiation state after postselection: trace out Rf and BH
        rho = np.outer(psi_norm, psi_norm.conj())
        rad_qubits = list(range(self.q_rad0, self.q_rad0 + self.steps))
        rho_rad = partial_trace_rho(rho, rad_qubits, self.n_total)
        return rho_rad, p

    def run(self) -> Dict[str, Any]:
        psi = self.initial_state()

        step_data: List[Dict[str, Any]] = []

        for t in range(self.steps):
            psi = self.scrambler_on_bh(psi)
            psi = self.emit_one_qubit(psi, t)

            obs = self.step_observables(psi, t)
            step_data.append(obs)

        # Unconditional final radiation state after steps: trace out BH+Rf
        rho_full = self.density_matrix(psi)
        rad_qubits = list(range(self.q_rad0, self.q_rad0 + self.steps))
        rho_rad = partial_trace_rho(rho_full, rad_qubits, self.n_total)

        # Final-state postselections
        rho0, p0 = self.project_bh_final_state(psi, basis="comp")
        rhop, pp = self.project_bh_final_state(psi, basis="plus")

        # Distances (null if any missing)
        d_r_r0 = trace_distance(rho_rad, rho0) if (rho0 is not None) else None
        d_r_rp = trace_distance(rho_rad, rhop) if (rhop is not None) else None
        d_r0_rp = trace_distance(rho0, rhop) if (rho0 is not None and rhop is not None) else None

        # Entropy of postselected radiation (purity proxy)
        S_r = von_neumann_entropy(rho_rad)
        S_r0 = von_neumann_entropy(rho0) if rho0 is not None else None
        S_rp = von_neumann_entropy(rhop) if rhop is not None else None

        return {
            "step_data": step_data,
            "final": {
                "S_rad_unconditional": S_r,
                "postselect_comp_success_prob": p0,
                "postselect_plus_success_prob": pp,
                "S_rad_post_comp": S_r0,
                "S_rad_post_plus": S_rp,
                "trace_distance_uncond_vs_comp": d_r_r0,
                "trace_distance_uncond_vs_plus": d_r_rp,
                "trace_distance_comp_vs_plus": d_r0_rp,
            },
        }

    def build_payload(self) -> Dict[str, Any]:
        sim = self.run()

        sample_points: List[Dict[str, Any]] = []
        for sd in sim["step_data"]:
            t = int(sd["t"])
            sample_points.append({
                "coordinates": {"step": t, "n_rad_emitted": sd["n_rad_emitted"]},
                "curvature_invariants": {
                    "ricci_scalar": None,
                    "kretschmann": None,
                    "note": "Information-theory toy; no classical curvature computed.",
                },
                "local_observables": {
                    "page_curve_proxy": {
                        "S_rad": finite_or_none(sd["S_rad"]),
                        "S_bh": finite_or_none(sd["S_bh"]),
                        "note": "Radiation entropy rising then falling is a Page-curve-like signature in unitary toy evaporation.",
                    },
                    "information_return_proxy": {
                        "mutual_information_I_rad_ref": finite_or_none(sd["I_rad_ref"]),
                        "note": "Mutual information between radiation and reference tracks information recovery after Page time.",
                    },
                },
                "causal_structure": {
                    "unitary_evolution": True,
                    "observer_access": "full_state (exact ED) for diagnostics; final-state postselection evaluated at end only",
                },
            })

        fin = sim["final"]

        # Obfuscation flag: if different final-state choices give meaningfully different radiation states
        obfuscation = None
        if fin["trace_distance_comp_vs_plus"] is not None:
            obfuscation = True if fin["trace_distance_comp_vs_plus"] > 1e-3 else False

        return {
            "toy_id": self.toy_id,
            "theory": "Unitary evaporation toy + postselected final-state boundary (information/operational diagnostics)",
            "spacetime": "Abstract quantum system (Rf + BH + Radiation); GR analogy via information flow",
            "units": {"G": 1, "c": 1},
            "parameters": {
                "n_bh": self.n_bh,
                "n_rad_max": self.n_rad,
                "steps": self.steps,
                "scrambler": "H layer on BH + CNOT chain",
                "emission": "SWAP(BH_0, Rad_t) each step",
                "final_state_postselections": ["BH=|0...0>", "BH=|+...+> (via H basis)"],
            },
            "notes": {
                "pressure_point": (
                    "Unitarity can coexist with operational unpredictability: enforcing purity via final-state postselection "
                    "makes outcomes depend on an effective boundary condition that observers cannot access, and may require rare postselection."
                ),
                "key_formulas": {
                    "entropy": "S(ρ) = -Tr(ρ log ρ)",
                    "mutual_information": "I(A:B)=S(A)+S(B)-S(AB)",
                    "trace_distance": "D(ρ,σ)=1/2 ||ρ-σ||_1",
                },
                "domain_of_validity": (
                    "Small-qubit exact simulation; meant as a diff-able marker of Page-curve behavior and final-state sensitivity, "
                    "not a derivation of black-hole microphysics."
                ),
            },
            "sample_points": sample_points,
            "observables": {
                "final_state_obfuscation": {
                    "S_rad_unconditional": finite_or_none(fin["S_rad_unconditional"]),
                    "postselect_comp_success_prob": finite_or_none(fin["postselect_comp_success_prob"]) if fin["postselect_comp_success_prob"] is not None else None,
                    "postselect_plus_success_prob": finite_or_none(fin["postselect_plus_success_prob"]) if fin["postselect_plus_success_prob"] is not None else None,
                    "S_rad_post_comp": finite_or_none(fin["S_rad_post_comp"]) if fin["S_rad_post_comp"] is not None else None,
                    "S_rad_post_plus": finite_or_none(fin["S_rad_post_plus"]) if fin["S_rad_post_plus"] is not None else None,
                    "trace_distance_uncond_vs_comp": finite_or_none(fin["trace_distance_uncond_vs_comp"]) if fin["trace_distance_uncond_vs_comp"] is not None else None,
                    "trace_distance_uncond_vs_plus": finite_or_none(fin["trace_distance_uncond_vs_plus"]) if fin["trace_distance_uncond_vs_plus"] is not None else None,
                    "trace_distance_comp_vs_plus": finite_or_none(fin["trace_distance_comp_vs_plus"]) if fin["trace_distance_comp_vs_plus"] is not None else None,
                    "obfuscation_detected": obfuscation,
                    "note": (
                        "If different final-state projections yield significantly different radiation states (large trace distance), "
                        "predictions are boundary-condition-sensitive: unitarity may be preserved but operationally obfuscated."
                    ),
                }
            },
        }

    def export_json(self, out_path: Optional[str] = None) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)
        payload = self.build_payload()
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2, sort_keys=True)
        return out_path


# ----------------------------
# CLI
# ----------------------------

def main() -> None:
    ap = argparse.ArgumentParser(description="Toy 084: final-state obfuscation (Page curve + postselection sensitivity).")
    ap.add_argument("--n_bh", type=int, default=4, help="Number of BH qubits.")
    ap.add_argument("--n_rad", type=int, default=4, help="Max radiation qubits available.")
    ap.add_argument("--steps", type=int, default=4, help="Number of emission steps (<= n_rad).")
    ap.add_argument("--out", type=str, default="", help="Optional output JSON path; default is <script>.json")
    args = ap.parse_args()

    toy = Toy084FinalStateObfuscation(n_bh=int(args.n_bh), n_rad=int(args.n_rad), steps=int(args.steps))
    out_path = args.out.strip() or None
    json_path = toy.export_json(out_path=out_path)

    print(f"Wrote {json_path}")
    print("Toy 084 complete: Page-curve proxy + final-state postselection sensitivity exported.")


if __name__ == "__main__":
    main()
